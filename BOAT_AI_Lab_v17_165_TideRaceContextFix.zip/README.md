# BOAT AI Lab v17.163 Clean Deploy

Clean deployment package rebuilt with ASCII-only archive paths to avoid Linux Errno 36 (File name too long).
Includes tide foundation, tide monitor/manual collection UI, PC tide navigation, and mobile horizontal navigation scrolling from v17.163.
