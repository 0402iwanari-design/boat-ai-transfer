# BOAT AI Lab v17.163 Clean Deploy

Clean deployment package rebuilt with ASCII-only archive paths to avoid Linux Errno 36 (File name too long).
Includes tide foundation, tide monitor/manual collection UI, PC tide navigation, and mobile horizontal navigation scrolling from v17.163.

## v17.166 潮対象場完成版
- 下関: 気象庁 長府(CF) を潮専用Collectorへ追加。
- 若松: 気象庁 日明(N1) を潮専用Collectorへ追加。
- 大村: BOAT RACE大村公式「今節の潮見」専用Providerを追加。公式が公開する満潮/干潮時刻を使用し、公開されていない潮位cmは捏造しない。
- 大村公式取得失敗はJMA各場の潮保存を壊さない独立処理。
- 潮を使わない場の表示を「潮影響なし・収集不要」に変更。
- AI予想への潮補正は引き続きOFF。既存15分前収集/30秒再試行/締切+1分オッズには未接続。

## v17.167 第3段階・複合水面判定
- 保存済み tide_daily / race_schedule と、既存15分前収集で保存済みの beforeinfo.weather を結合。
- 潮×風×場特性の確認用「複合水面」判定を各Rに表示・tide_race_contextへ保存。
- 風データ欠損は0m扱いせず「風データなし」。方角しか取れない場合も向かい/追いを推測せず「相対風向未確定」。
- 江戸川・丸亀・児島・宮島・徳山・若松・福岡は必要入力が揃った場合のみ場固有の確認タグを付与。
- AI予想の点数・出目には未接続（ai_applied=false）。既存の15分前収集、30秒再試行、締切+1分最終オッズは変更なし。
