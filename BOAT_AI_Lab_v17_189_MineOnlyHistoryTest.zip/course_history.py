from __future__ import annotations

"""Nationwide/current-venue actual-entry-course history collection (v17.189 Mine-only validation).

Collection plan
---------------
* 00:00-23:59 JST: only racers appearing in today's saved official racelists are targets.
* For each racer, only nationwide 1-6 course history + the venue they are racing at today
  is required for completion. The other 23 venues are never completion targets.
* One official nationwide daily K file is fetched, then shared across every active target.
  A racer's row is saved once and can simultaneously contribute to nationwide and local history.
* Each target stops as soon as all required nationwide/current-venue course buckets reach 10.
  If a course has fewer than 10 lifetime starts, the scan stops at that racer's debut-term floor
  and the available number is accepted as complete.
* Success/no-data day: 10-second pause. Fetch failure: 60-second retry, max 3 attempts.
  After 3 failures that racer/venue target is shown as an error and is not retried again that day.
* Confirmed live race results continue to update the same history table with no extra web access.
* The scheduler's periodic checks are SQLite-only. It accesses the official history source only
  when a new/incomplete target actually exists.
"""

import io
import re
import threading
import time
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed
from parser import parse_result_list, parse_result_detail

JST = ZoneInfo("Asia/Tokyo")
HISTORY_FLOOR = "20020101"
SUCCESS_PAUSE_SECONDS = 1
RETRY_PAUSE_SECONDS = 60
MAX_FETCH_ATTEMPTS = 3
LOCAL_TARGET_CHECK_SECONDS = 60  # SQLite-only check; no web request when there is no target.

VENUES = [
    "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
    "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村",
]
VENUE_CODE = {name: f"{i:02d}" for i, name in enumerate(VENUES, 1)}

# v17.189 validation scope: prove one racer end-to-end before widening collection.
VALIDATION_REG = "4320"
VALIDATION_NAME = "峰竜太"


def _registration_term_floor(period: int) -> str:
    period = int(period)
    reference_period = 136
    reference_month_index = 2025 * 12 + 4  # May 2025
    month_index = reference_month_index - (reference_period - period) * 6
    year, month0 = divmod(month_index, 12)
    return f"{year:04d}{month0 + 1:02d}01"


def _norm(s: str) -> str:
    return re.sub(r"[\s　]+", "", str(s or "")).replace("ボートレース", "")


def _st_number(raw: str):
    s = str(raw or "").strip().upper().replace("０", "0")
    if not s:
        return None
    m = re.fullmatch(r"F\s*([0-9]*\.?[0-9]+)", s)
    if m:
        try: return -float(m.group(1))
        except ValueError: return None
    if s.startswith("L"):
        return None
    try:
        v = float(s)
        return v if -1 < v < 2 else None
    except ValueError:
        return None


def _normalize_k_st(raw: str) -> str:
    """Convert K-file 3-char ST into the app's display/storage form.

    Official K T1-T6 records use a compact fixed-width ST field.  Keep special
    F/L markers instead of coercing them to zero, and convert ordinary digits
    such as ``012`` to ``.12``.
    """
    s=str(raw or "").strip().upper()
    if not s:
        return ""
    if s.startswith("F"):
        digits=re.sub(r"\D", "", s[1:])
        if digits:
            return f"F.{int(digits):02d}"
        return "F"
    if s.startswith("L"):
        digits=re.sub(r"\D", "", s[1:])
        return f"L.{int(digits):02d}" if digits else "L"
    if re.fullmatch(r"\d{1,3}", s):
        return f".{int(s):02d}"
    if re.fullmatch(r"\.?\d{1,2}", s):
        return "." + s.lstrip(".").zfill(2)
    return s


def _assign_st_ranks(race_rows: list[dict]):
    numeric=[(i,_st_number(x.get("st_raw"))) for i,x in enumerate(race_rows)]
    numeric=[(i,v) for i,v in numeric if v is not None]
    numeric.sort(key=lambda z:z[1])
    last=None; rank=0
    for pos,(idx,value) in enumerate(numeric,1):
        if last is None or abs(value-last)>1e-9:
            rank=pos; last=value
        race_rows[idx]["st_rank"]=rank


def parse_k_text(text: str, yyyymmdd: str) -> list[dict]:
    """Parse the official daily K result file.

    Current official K downloads are fixed-length records beginning with T0,
    TH, T1..T6 and T7.  Older v17.179-v17.186 code incorrectly treated the
    extracted K file as the human-readable result sheet, so a successful K
    download could parse as 0 rows.  This parser reads the actual T records.

    3連単 data is intentionally ignored.
    """
    rows=[]
    jcd=None
    rno=None
    race_rows=[]

    def flush():
        nonlocal race_rows
        if not race_rows:
            return
        _assign_st_ranks(race_rows)
        rows.extend(race_rows)
        race_rows=[]

    lines=text.splitlines()
    has_t_records=any(len(x)>=2 and x[:2] in ("T0","TH","T1","T2","T3","T4","T5","T6","T7") for x in lines[:500])

    if has_t_records:
        for raw_line in lines:
            line=raw_line.rstrip("\r\n")
            if len(line)<2:
                continue
            rtype=line[:2]
            if rtype=="T0":
                flush()
                code=line[2:4].strip() if len(line)>=4 else ""
                if code.isdigit() and 1<=int(code)<=24:
                    jcd=code.zfill(2)
                rno=None
                continue
            if rtype=="TH":
                flush()
                code=line[2:4].strip() if len(line)>=4 else ""
                race=line[4:6].strip() if len(line)>=6 else ""
                if code.isdigit() and 1<=int(code)<=24:
                    jcd=code.zfill(2)
                if race.isdigit() and 1<=int(race)<=12:
                    rno=int(race)
                else:
                    rno=None
                continue
            if rtype=="T7":
                flush()
                continue
            if not (len(rtype)==2 and rtype[0]=="T" and rtype[1] in "123456"):
                continue
            if not jcd or not rno or len(line)<17:
                continue
            lane=int(rtype[1])
            course_s=line[2:3].strip()
            reg=line[3:8].strip()
            finish=line[8:9].strip()
            st_raw=_normalize_k_st(line[14:17])
            if not course_s.isdigit() or not (1<=int(course_s)<=6):
                continue
            # Some K layouts reserve five characters for the registration no.
            # Normalize an optional leading zero, while preserving real digits.
            if not reg.isdigit():
                continue
            reg=reg.lstrip("0") or "0"
            if len(reg)<4:
                reg=reg.zfill(4)
            race_rows.append({
                "date":yyyymmdd,"jcd":jcd,"rno":rno,
                "registration_no":reg,"lane":lane,"course":int(course_s),
                "finish":finish or "0","st_raw":st_raw,"st_rank":None,
                "source":"official-k-download-backfill",
            })
        flush()
        return rows

    # Compatibility fallback for any legacy human-readable result text.
    race_rows=[]; jcd=rno=None; in_result_rows=False
    def flush_legacy():
        nonlocal race_rows
        if not race_rows: return
        _assign_st_ranks(race_rows); rows.extend(race_rows); race_rows=[]
    for raw_line in lines:
        line=raw_line.rstrip("\r\n"); compact=_norm(line)
        for name,code in sorted(VENUE_CODE.items(),key=lambda kv:len(kv[0]),reverse=True):
            if name in compact and ("成績" in compact or "ボートレース" in line):
                flush_legacy(); jcd=code; rno=None; in_result_rows=False; break
        m_race=re.match(r"^\s*(?:第\s*)?(\d{1,2})R\s+.*H\s*\d+",line,re.I)
        if m_race:
            flush_legacy(); rno=int(m_race.group(1)); in_result_rows=False; continue
        if "スタートタイミンク" in line or "スタートタイミング" in line or ("進入" in line and "スタート" in line and "登番" in line):
            in_result_rows=True; continue
        if not in_result_rows or not jcd or not rno: continue
        if not line.strip() or set(line.strip()) <= {"-"}:
            if race_rows and not line.strip(): flush_legacy(); in_result_rows=False
            continue
        finish=lane=reg=entry=st_raw=None
        if len(line)>=48:
            finish=line[2:4].strip(); lane=line[6:7].strip(); reg=line[8:12].strip()
            entry=line[38:39].strip(); st_raw=line[43:47].strip()
        if not (lane and lane.isdigit() and reg and reg.isdigit() and entry and entry.isdigit()):
            continue
        lane_i,course_i=int(lane),int(entry)
        if not (1<=lane_i<=6 and 1<=course_i<=6): continue
        race_rows.append({"date":yyyymmdd,"jcd":jcd,"rno":rno,"registration_no":str(reg),
                          "lane":lane_i,"course":course_i,"finish":str(finish or "").lstrip("0") or "0",
                          "st_raw":str(st_raw or "").strip(),"st_rank":None,
                          "source":"official-k-download-backfill"})
    flush_legacy()
    return rows


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db=db; self._thread=None; self._stop=threading.Event()
        self.status={"phase":"本日の出走表待ち","total_racers":0,"pending_racers":0,"stored_runs":0,"errors":[]}

    @staticmethod
    def _in_window(now: datetime) -> bool:
        return dt_time(0,0) <= now.time() <= dt_time(23,59,59,999999)

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,name="course-history-target-backfill",daemon=True)
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            now=datetime.now(JST)
            today=now.strftime("%Y%m%d")
            if self._in_window(now):
                try: self._run_target_window(today)
                except Exception as exc:
                    self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),"phase":"収集処理エラー","scheduler_error":f"{type(exc).__name__}: {exc}"}
                # This wait only re-checks today's SQLite racelists for newly discovered targets.
                # No official history request occurs unless an incomplete target exists.
                self._stop.wait(LOCAL_TARGET_CHECK_SECONDS)
            else:
                self._stop.wait(60)

    def _fetch_day_from_result_pages(self, session: requests.Session, cursor, active: list[dict]):
        """Collect one historical day from the same official result pages used by live results.

        This deliberately replaces the K-download backfill.  The venue result-list page is used
        only as a cheap index.  A venue is expanded to per-race detail pages only when the HTML
        contains at least one of today's target racer names.  The detail parser is the exact same
        parser already used by the app for confirmed live results, so actual entry course, ST and
        finishing order follow the proven path instead of a second K-specific layout parser.
        """
        ymd=cursor.strftime("%Y%m%d")
        active_regs={str(x.get("registration_no") or "").strip() for x in active}
        active_names={_norm(x.get("name")) for x in active if _norm(x.get("name"))}
        rows=[]; venue_hits=0; detail_count=0; list_count=0
        last_error=None

        def detail_row(jcd: str, rno: int):
            url=f"https://www.boatrace.jp/owpc/pc/race/raceresult?rno={rno}&jcd={jcd}&hd={ymd}"
            r=session.get(url,timeout=20)
            r.raise_for_status()
            return jcd,rno,parse_result_detail(r.text,rno)

        # Result-list pages are small.  Scan all 24 venues, but open 12 race details only for
        # venues whose list actually mentions one of the target racers.
        for jcd in (f"{i:02d}" for i in range(1,25)):
            if self._stop.is_set() or not self._in_window(datetime.now(JST)):
                return "window_end",[],None,{"list_pages":list_count,"detail_pages":detail_count,"venue_hits":venue_hits}
            url=f"https://www.boatrace.jp/owpc/pc/race/resultlist?jcd={jcd}&hd={ymd}"
            try:
                r=session.get(url,timeout=20); list_count+=1
                if r.status_code==404: continue
                r.raise_for_status()
                html=r.text
                compact=_norm(BeautifulSoup(html,"html.parser").get_text(" "))
                if active_names and not any(name in compact for name in active_names):
                    continue
                parsed=parse_result_list(html)
                rnos=sorted({int(x.get("rno") or 0) for x in parsed if 1<=int(x.get("rno") or 0)<=12})
                if not rnos: continue
                venue_hits+=1
                # Four workers matches the existing live-result detail enrichment limit.
                with ThreadPoolExecutor(max_workers=min(4,len(rnos))) as pool:
                    futs=[pool.submit(detail_row,jcd,rno) for rno in rnos]
                    for fut in as_completed(futs):
                        try:
                            code,rno,detail=fut.result(); detail_count+=1
                        except Exception as exc:
                            last_error=f"{type(exc).__name__}: {exc}"; continue
                        starts={int(x.get("lane") or 0):x for x in (detail.get("start_courses") or []) if str(x.get("lane") or "").isdigit()}
                        numeric=[]
                        for lane,x in starts.items():
                            v=_st_number(x.get("st_raw"))
                            if v is not None: numeric.append((lane,v))
                        numeric.sort(key=lambda z:z[1]); ranks={}; last=None; rank=0
                        for pos,(lane,v) in enumerate(numeric,1):
                            if last is None or abs(v-last)>1e-9: rank=pos; last=v
                            ranks[lane]=rank
                        for fin in detail.get("finishers") or []:
                            reg=str(fin.get("registration_no") or "").strip()
                            if reg not in active_regs: continue
                            try: lane=int(fin.get("lane") or 0)
                            except (TypeError,ValueError): continue
                            st=starts.get(lane) or {}
                            try: course=int(fin.get("course") or st.get("course") or 0)
                            except (TypeError,ValueError): continue
                            if not (1<=course<=6): continue
                            rows.append({"date":ymd,"jcd":code,"rno":rno,"registration_no":reg,
                                "lane":lane,"course":course,"finish":fin.get("finish"),
                                "st_raw":fin.get("st_raw") or st.get("st_raw"),"st_rank":ranks.get(lane),
                                "source":"official-result-detail-backfill"})
            except Exception as exc:
                # A single venue failure must not discard other venues from the same day.
                last_error=f"{type(exc).__name__}: {exc}"
                continue
        return "ok",rows,last_error,{"list_pages":list_count,"detail_pages":detail_count,"venue_hits":venue_hits}

    def _resolve_target_floor(self, session: requests.Session, target: dict) -> str:
        """Resolve the historical floor without making one web request per racer.

        v17.185 resolved missing registration terms by opening the official profile
        page for every target before the first K file was processed. With 500+
        racers this could leave the UI at 0 saved runs for a long time even though
        the K backfill itself had not started. v17.186 only uses already-saved
        official profile data here. Missing terms simply keep the existing floor;
        the shared daily K scan starts immediately.
        """
        reg=str(target.get("registration_no") or ""); jcd=str(target.get("jcd") or "").zfill(2)
        existing=str(target.get("floor_date") or HISTORY_FLOOR)
        if existing!=HISTORY_FLOOR: return existing
        period=self.db.get_course_history_profile_period(reg)
        if period is None:
            return existing
        floor=_registration_term_floor(period)
        self.db.set_course_history_target_floor(reg,jcd,floor,period)
        return floor

    def _finish_ready_or_floor(self, today: str):
        pending=self.db.get_course_history_pending_targets(today, VALIDATION_REG); done=[]
        for x in pending:
            key=(str(x["registration_no"]),str(x["jcd"]).zfill(2))
            cursor=str(x.get("cursor_date") or ""); floor=str(x.get("floor_date") or HISTORY_FLOOR)
            if self.db.course_history_target_has_ten(*key) or (cursor and cursor<floor): done.append(key)
        self.db.complete_course_history_targets(done)
        return done

    def _run_target_window(self, today: str):
        now=datetime.now(JST); start_date=(now.date()-timedelta(days=1)).strftime("%Y%m%d")
        self.db.ensure_course_history_today_targets(today,start_date,HISTORY_FLOOR, VALIDATION_REG)
        # v17.189 validation reset: only Mine Ryuta (4320) is crawled.
        # Other racers remain untouched until this one-racer path is proven.
        with self.db.connect() as con:
            key=f"course_history_mine4320_v1:{today}"
            con.execute("CREATE TABLE IF NOT EXISTS app_migrations (migration_key TEXT PRIMARY KEY, applied_at TEXT DEFAULT CURRENT_TIMESTAMP)")
            if not con.execute("SELECT 1 FROM app_migrations WHERE migration_key=?",(key,)).fetchone():
                con.execute("""UPDATE course_history_target_state
                    SET status='pending',cursor_date=?,retry_count=0,failed_date=NULL,last_error=NULL,
                        started_at=NULL,completed_at=NULL,updated_at=CURRENT_TIMESTAMP
                    WHERE target_date=? AND registration_no=?""",(start_date,today,VALIDATION_REG))
                con.execute("INSERT INTO app_migrations(migration_key) VALUES(?)",(key,))
        self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),
                     "validation_mode":"峰竜太1人テスト","current_racer":VALIDATION_NAME,"current_registration_no":VALIDATION_REG}
        targets=self.db.get_course_history_pending_targets(today, VALIDATION_REG)
        if not targets: return

        session=requests.Session(); session.headers.update({"User-Agent":"BOAT-AI-Lab/1.0 official-result-history-current-racers"})
        for target in targets:
            if self._stop.is_set() or not self._in_window(datetime.now(JST)): return
            self._resolve_target_floor(session,target)
        self._finish_ready_or_floor(today)

        while self._in_window(datetime.now(JST)) and not self._stop.is_set():
            self._finish_ready_or_floor(today)
            current=self.db.get_course_history_pending_targets(today, VALIDATION_REG)
            if not current: break
            cursor_text=max(str(x.get("cursor_date") or start_date) for x in current)
            cursor=datetime.strptime(cursor_text,"%Y%m%d").date(); ymd=cursor.strftime("%Y%m%d")
            active=[x for x in current if str(x.get("cursor_date") or start_date)==ymd and ymd>=str(x.get("floor_date") or HISTORY_FLOOR)]
            if not active:
                self._finish_ready_or_floor(today); continue
            active_regs={str(x["registration_no"]) for x in active}
            active_keys=[(str(x["registration_no"]),str(x["jcd"]).zfill(2)) for x in active]
            # Publish progress before the network request so the top screen
            # shows that the collector has actually entered the K-file phase.
            self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),
                         "phase":"公式レース結果履歴取得中",
                         "validation_mode":"峰竜太1人テスト","current_racer":VALIDATION_NAME,"current_registration_no":VALIDATION_REG,
                         "last_fetch_date":ymd,"last_fetch_state":"fetching",
                         "last_parsed_rows":0,"last_matched_rows":0}
            state,rows,error,diag=self._fetch_day_from_result_pages(session,cursor,active)
            # A valid official result day with no Mine entry is normal, not a failure.
            if state=="ok" and not rows:
                state="no_start"
            self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),
                         "validation_mode":"峰竜太1人テスト","current_racer":VALIDATION_NAME,"current_registration_no":VALIDATION_REG,
                         "last_fetch_date":ymd,"last_fetch_state":state,
                         "last_parsed_rows":len(rows or []),"last_matched_rows":0,
                         "last_fetch_error":error,"last_list_pages":diag.get("list_pages",0),
                         "last_detail_pages":diag.get("detail_pages",0),"last_venue_hits":diag.get("venue_hits",0)}
            if state=="window_end": break
            if state=="error":
                self.db.mark_course_history_target_errors(active_keys,ymd,error or "取得失敗",MAX_FETCH_ATTEMPTS)
                self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),
                     "validation_mode":"峰竜太1人テスト","current_racer":VALIDATION_NAME,"current_registration_no":VALIDATION_REG}
                # Other targets with a different cursor may continue on the next local scheduler pass;
                # these failed keys themselves are not retried again today.
                return
            matched_count=0
            if state in ("ok","no_start") and rows:
                filtered=[x for x in rows if str(x.get("registration_no") or "") in active_regs]
                matched_count=len(filtered)
                self.db.save_course_history_runs(filtered,keep_per_local_course=10)
            # Preserve fetch diagnostics after DB progress refresh. A successful
            # K file with parsed_rows=0 is now visible immediately instead of
            # looking like a collector that is simply stuck.
            fetch_diag={"last_fetch_date":ymd,"last_fetch_state":state,
                        "last_parsed_rows":len(rows or []),
                        "last_matched_rows":matched_count,"last_fetch_error":error,
                        "last_list_pages":diag.get("list_pages",0),"last_detail_pages":diag.get("detail_pages",0),
                        "last_venue_hits":diag.get("venue_hits",0)}
            # Targets that now have all 10x(全国+本日の場) finish immediately.
            ready=[k for k in active_keys if self.db.course_history_target_has_ten(*k)]
            self.db.complete_course_history_targets(ready)
            ready_set=set(ready)
            remaining=[k for k in active_keys if k not in ready_set]
            next_date=(cursor-timedelta(days=1)).strftime("%Y%m%d")
            self.db.advance_course_history_targets(remaining,next_date)
            self._finish_ready_or_floor(today)
            self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),**fetch_diag}
            self._stop.wait(SUCCESS_PAUSE_SECONDS)
        self.status={**self.db.get_course_history_target_status(today, VALIDATION_REG),
                     "validation_mode":"峰竜太1人テスト","current_racer":VALIDATION_NAME,"current_registration_no":VALIDATION_REG}
