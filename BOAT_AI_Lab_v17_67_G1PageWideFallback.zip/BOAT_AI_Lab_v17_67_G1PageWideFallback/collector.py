from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone, timedelta

JST = timezone(timedelta(hours=9), name="JST")
BASIC_LOGIC_VERSION = "basic-racelist-deadline-v4-diagnostic-path"


class BackgroundCollector:
    """
    v17.57

    TODAY ONLY.

    Phase 1: basic rebuild
      one R at a time:
        fetch official racelist page
        -> parse 6 racers
        -> parse exact deadline
        -> atomic DB save
        -> DB read-back verification
        -> mark reflected
        -> only then next R

    Phase 2: real-time
      deadline-15m : before info / absence check
      odds         : time-aware low-load polling
      deadline+4m  : result first check
      no result    : retry every 30s
      confirmed    : finish that race permanently
    """

    def __init__(self, source):
        self.source = source
        self.running = False
        self.task = None

        self.today = None
        self.targets = []
        self.target_map = {}

        self.finished = set()
        self.before_due = {}
        self.odds_due = {}
        self.result_due = {}
        self.ai_due = {}

        # ETA state: monotonic timing so PC clock changes do not distort it.
        self._eta = {
            "phase": None,
            "started": None,
            "baseline": 0,
            "last_done": 0,
            "last_total": 0,
        }

        self.status = {
            "running": False,
            "started_at": None,
            "last_cycle": None,
            "active_date": None,
            "auto_day_rollover": True,
            "next_midnight": None,
            "day_rollover_count": 0,
            "day_start_attempt": 0,
            "day_start_last_error": None,

            "eta_phase": None,
            "eta_done": 0,
            "eta_total": 0,
            "eta_seconds": None,
            "eta_avg_seconds_per_race": None,
            "eta_updated_at": None,
            "overall_eta_seconds": None,
            "overall_progress_percent": 0.0,

            "ai_prediction_updates": 0,
            "ai_prediction_errors": 0,
            "ai_last_prediction": None,

            "pre_ai_phase": "待機中",
            "pre_ai_total": 0,
            "pre_ai_complete": 0,
            "pre_ai_failed": 0,
            "pre_ai_percent": 0.0,

            "meeting_results_total": 0,
            "meeting_results_complete": 0,
            "meeting_results_phase": "待機中",

            "phase": "未起動",
            "current_state": "待機中",
            "current_kind": None,
            "current_venue": None,
            "current_jcd": None,
            "current_rno": None,
            "last_message": "未起動",

            "basic_total": 0,
            "basic_complete": 0,
            "basic_failed": 0,
            "basic_last_deadline": None,
            "basic_all_complete": False,

            "odds_phase": "待機中",
            "odds_total": 0,
            "odds_complete": 0,
            "odds_unavailable": 0,
            "odds_all_complete": False,
            "odds_recovery_count": 0,
            "odds_second_pass": 0,
            "scratch_overwrite_count": 0,
            "odds_legacy_recheck": 0,

            "scratch_check_phase": "待機中",
            "scratch_check_venue": None,
            "scratch_check_jcd": None,
            "scratch_check_rno": None,
            "scratch_check_state": "未開始",
            "scratch_found_total": 0,
            "scratch_audit_total": 0,
            "scratch_audit_complete": 0,
            "scratch_audit_failed": 0,
            "scratch_audit_all_complete": False,

            "before_phase": "待機中",
            "before_total": 0,
            "before_complete": 0,
            "before_unavailable": 0,
            "before_all_complete": False,

            "comments_phase": "待機中",
            "comments_total": 0,
            "comments_complete": 0,
            "comments_found": 0,
            "comments_failed": 0,

            "result_phase": "待機中",
            "result_total": 0,
            "result_complete": 0,
            "result_unavailable": 0,
            "result_all_complete": False,

            # backward-compatible fields
            "prefetched_races": 0,
            "racelist_ready": 0,
            "total_target_races": 0,

            "before_updates": 0,
            "odds_updates": 0,
            "result_checks": 0,
            "result_updates": 0,
            "finished_races": 0,

            "success": 0,
            "failed": 0,
            "retried": 0,
            "errors": [],
        }

    def _jst_date_key(self):
        return datetime.now(JST).strftime("%Y%m%d")

    def _next_midnight_iso(self):
        now = datetime.now(JST)
        tomorrow = (
            now + timedelta(days=1)
        ).date()
        next_midnight = datetime(
            tomorrow.year,
            tomorrow.month,
            tomorrow.day,
            0, 0, 0,
            tzinfo=JST,
        )
        return next_midnight.isoformat()

    def _reset_for_date(self, yyyymmdd: str):
        """
        Reset only transient collector state.
        DB data from previous days is preserved.
        """
        self.today = yyyymmdd
        self.targets = []
        self.target_map = {}
        self.finished = set()
        self.before_due = {}
        self.odds_due = {}
        self.result_due = {}

        # Day-specific counters/status.
        for key in [
            "basic_total","basic_complete","basic_failed",
            "odds_total","odds_complete","odds_unavailable",
            "odds_recovery_count","odds_second_pass",
            "scratch_overwrite_count","odds_legacy_recheck",
            "scratch_found_total","scratch_audit_total",
            "scratch_audit_complete","scratch_audit_failed",
            "before_total","before_complete","before_unavailable",
            "comments_total","comments_complete","comments_found",
            "comments_failed","meeting_day_total","meeting_day_complete",
            "meeting_day_failed","meeting_results_total",
            "meeting_results_complete","meeting_results_failed",
            "meeting_results_skipped_day1","meeting_results_eligible_venues",
            "meeting_results_revision",
            "result_total","result_complete",
            "result_unavailable","prefetched_races","racelist_ready",
            "total_target_races","before_updates","odds_updates",
            "result_checks","result_updates","finished_races",
        ]:
            self.status[key] = 0

        for key in [
            "basic_all_complete","odds_all_complete",
            "scratch_audit_all_complete","before_all_complete",
            "result_all_complete",
        ]:
            self.status[key] = False

        self.status["meeting_day_phase"] = "待機中"
        self.status["meeting_results_phase"] = "待機中"
        self.status["meeting_results_current_venue"] = None
        self.status["meeting_results_current_rno"] = None
        self.status["meeting_results_current_stage"] = "未開始"
        self.status["meeting_results_racer_count"] = 0
        self.status["meeting_results_last_saved_jcd"] = None
        self.status["meeting_results_last_saved_rno"] = None
        self.status["odds_phase"] = "待機中"
        self.status["scratch_check_phase"] = "待機中"
        self.status["scratch_check_state"] = "未開始"
        self.status["before_phase"] = "待機中"
        self.status["comments_phase"] = "待機中"
        self.status["result_phase"] = "待機中"

        self.status["active_date"] = yyyymmdd
        self.status["next_midnight"] = self._next_midnight_iso()
        self.status["current_kind"] = None
        self.status["current_venue"] = None
        self.status["current_jcd"] = None
        self.status["current_rno"] = None
        self.status["current_state"] = "日付切替準備中"

        self._eta = {
            "phase": None,
            "started": None,
            "baseline": 0,
            "last_done": 0,
            "last_total": 0,
        }
        self.status["eta_phase"] = None
        self.status["eta_done"] = 0
        self.status["eta_total"] = 0
        self.status["eta_seconds"] = None
        self.status["eta_avg_seconds_per_race"] = None
        self.status["eta_updated_at"] = None
        self.status["overall_eta_seconds"] = None
        self.status["overall_progress_percent"] = 0.0

        try:
            self.finished = set(
                self.source.db.get_confirmed_result_races(
                    self.today
                )
            )
        except Exception:
            self.finished = set()

        self.status["finished_races"] = len(
            self.finished
        )

    def start(self):
        if self.task and not self.task.done():
            return

        now = datetime.now(JST)
        self._reset_for_date(
            self._jst_date_key()
        )

        self.running = True
        self.status["running"] = True
        self.status["started_at"] = now.isoformat()
        self.status["last_message"] = (
            f"{self.today} 自動収集を開始"
        )
        self.task = asyncio.create_task(
            self._run()
        )

    async def stop(self):
        self.running = False
        self.status["running"] = False
        if self.task:
            self.task.cancel()

    def _eta_start(self, phase: str, done: int, total: int):
        done = max(0, int(done or 0))
        total = max(0, int(total or 0))

        self._eta = {
            "phase": phase,
            "started": time.monotonic(),
            "baseline": done,
            "last_done": done,
            "last_total": total,
        }

        self.status["eta_phase"] = phase
        self.status["eta_done"] = done
        self.status["eta_total"] = total
        self.status["eta_seconds"] = None
        self.status["eta_avg_seconds_per_race"] = None
        self.status["eta_updated_at"] = datetime.now(JST).isoformat()
        self.status["overall_eta_seconds"] = None
        self.status["overall_progress_percent"] = (
            round(done / total * 100, 1)
            if total > 0 else 0.0
        )

    def _eta_update(self, done: int, total: int, force_complete: bool = False):
        done = max(0, int(done or 0))
        total = max(0, int(total or 0))

        self.status["eta_done"] = done
        self.status["eta_total"] = total
        self.status["eta_updated_at"] = datetime.now(JST).isoformat()
        self.status["overall_progress_percent"] = (
            round(min(done, total) / total * 100, 1)
            if total > 0 else 0.0
        )

        if force_complete or (total > 0 and done >= total):
            self.status["eta_seconds"] = 0
            self.status["overall_eta_seconds"] = 0
            self._eta["last_done"] = done
            self._eta["last_total"] = total
            return

        started = self._eta.get("started")
        baseline = int(self._eta.get("baseline") or 0)
        processed = done - baseline

        # Need at least one newly processed race before estimating.
        if not started or processed <= 0:
            self.status["eta_seconds"] = None
            self.status["overall_eta_seconds"] = None
            return

        elapsed = max(0.001, time.monotonic() - started)
        avg = elapsed / processed
        remaining = max(0, total - done)
        eta = int(round(avg * remaining))

        # Protect UI from absurd transient values after one very slow retry.
        eta = min(eta, 24 * 60 * 60)

        self.status["eta_avg_seconds_per_race"] = round(avg, 2)
        self.status["eta_seconds"] = eta
        self.status["overall_eta_seconds"] = eta

        self._eta["last_done"] = done
        self._eta["last_total"] = total

    def _eta_finish(self, done: int, total: int):
        self._eta_update(done, total, force_complete=True)

    def _error(self, msg):
        self.status["errors"].append({
            "time": datetime.now(JST).isoformat(),
            "message": str(msg),
        })
        self.status["errors"] = self.status["errors"][-40:]

    def _set_scratch_check(
        self,
        venue=None,
        jcd=None,
        rno=None,
        state="",
        phase="確認中",
    ):
        self.status["scratch_check_phase"] = phase
        self.status["scratch_check_venue"] = venue
        self.status["scratch_check_jcd"] = jcd
        self.status["scratch_check_rno"] = rno
        self.status["scratch_check_state"] = state

    def _set_current(self, kind, venue, jcd, rno, state):
        self.status["current_kind"] = kind
        self.status["current_venue"] = venue
        self.status["current_jcd"] = jcd
        self.status["current_rno"] = rno
        self.status["current_state"] = state

        race_text = f"{rno}R " if rno else ""
        self.status["last_message"] = (
            f"{venue}{race_text}{kind} {state}"
        )

    def _minutes_to(self, deadline):
        if not deadline:
            return None

        try:
            now = datetime.now(JST)
            h, m = map(int, deadline.split(":"))
            target = now.replace(
                hour=h, minute=m, second=0, microsecond=0
            )
            return (target - now).total_seconds() / 60
        except Exception:
            return None

    def _deadline_ts(self, deadline):
        if not deadline:
            return None

        try:
            now = datetime.now(JST)
            h, m = map(int, deadline.split(":"))
            target = now.replace(
                hour=h, minute=m, second=0, microsecond=0
            )
            return target.timestamp()
        except Exception:
            return None

    async def _discover_today_targets(self):
        """
        Discover today's open venues.

        Official get_day is preferred.
        DB racelist presence is merged as fallback, so existing data is not lost
        even if one venue probe temporarily fails.
        """
        self.status["phase"] = "本日開催場確認"
        self.status["last_message"] = "今日の開催場を確認中…"

        day = None
        try:
            day = await asyncio.to_thread(
                self.source.get_day,
                self.today
            )
        except Exception as e:
            self._error(f"開催場確認: {e}")

        venue_names = {
            str(v["code"]).zfill(2): v["name"]
            for v in self.source.venues
        }

        open_codes = set()

        if day:
            for venue in day.get("venues", []):
                if venue.get("open"):
                    open_codes.add(
                        str(venue["code"]).zfill(2)
                    )

        # Existing DB is a fallback proof that this venue raced today.
        try:
            presence = self.source.db.get_racelist_presence(self.today)
            open_codes.update(presence.keys())
        except Exception as e:
            self._error(f"DB開催場確認: {e}")

        if not open_codes:
            raise RuntimeError(
                "本日の開催場を1場も特定できませんでした"
            )

        # Every known open venue gets 1R-12R basic rebuild.
        targets = []

        # 場順は場コード順。場内は必ず1R→12R。
        venue_order = sorted(open_codes)

        for jcd in venue_order:
            venue = venue_names.get(jcd, jcd)

            # 場内では必ず 1R -> 12R の順番。
            for rno in range(1, 13):
                targets.append({
                    "date": self.today,
                    "jcd": jcd,
                    "venue": venue,
                    "rno": rno,
                })

        self.targets = targets
        self.target_map = {
            (x["jcd"], x["rno"]): x
            for x in targets
        }

        self.status["basic_total"] = len(targets)
        self.status["total_target_races"] = len(targets)

    async def _meeting_day_phase(self):
        """
        Re-acquire the official meeting day once per open venue.

        This deliberately runs before the current-meeting-results phase, so
        day 2+ can trigger the missing-result refresh correctly.
        """
        venues = {}
        for item in self.targets:
            jcd = str(item["jcd"]).zfill(2)
            venues[jcd] = item["venue"]

        total = len(venues)
        complete = 0
        failed = 0
        self.status["meeting_day_total"] = total
        self.status["meeting_day_complete"] = 0
        self.status["meeting_day_failed"] = 0
        self.status["meeting_day_phase"] = "開催日数を公式から取得中"

        for jcd in sorted(venues):
            if not self.running:
                return

            venue = venues[jcd]
            self._set_current(
                "開催日数", venue, jcd, None,
                "公式出走表から開催何日目かを確認中…",
            )
            self.status["meeting_day_phase"] = (
                f"開催日数 取得中：{venue}"
            )

            try:
                info = await asyncio.to_thread(
                    self.source.ensure_meeting_day,
                    self.today, jcd, True
                )
                complete += 1
                self.status["meeting_day_complete"] = complete
                self.status["meeting_day_phase"] = (
                    f"開催日数 反映：{venue} "
                    f"{info.get('label') or info.get('official_label') or '取得済み'}"
                )
            except Exception as ex:
                failed += 1
                self.status["meeting_day_failed"] = failed
                self._error(
                    f"開催日数 {jcd}: {ex}"
                )

        self.status["meeting_day_complete"] = complete
        self.status["meeting_day_failed"] = failed
        self.status["meeting_day_phase"] = (
            f"開催日数 反映済み {complete}/{total}場"
            + (f" / 未取得 {failed}場" if failed else "")
        )

    async def _basic_rebuild_phase(self):
        """
        場単位で完全直列処理。

        場A:
          1Rページから締切12R分を保存・検証
          1R -> 保存検証
          2R -> 保存検証
          ...
          12R -> 保存検証
        次に場Bへ。
        """
        self.status["phase"] = "基本データ再構築"

        completed = self.source.db.get_basic_complete_keys(
            self.today,
            BASIC_LOGIC_VERSION,
        )

        self.status["basic_complete"] = len([
            x for x in self.targets
            if (x["jcd"], x["rno"]) in completed
        ])
        self.status["racelist_ready"] = self.status["basic_complete"]
        self.status["prefetched_races"] = self.status["basic_complete"]

        self._eta_start(
            "基本データ",
            self.status["basic_complete"],
            self.status["basic_total"],
        )

        venue_codes = []
        for item in self.targets:
            if item["jcd"] not in venue_codes:
                venue_codes.append(item["jcd"])

        for jcd in venue_codes:
            if not self.running:
                return

            venue_items = [
                x for x in self.targets
                if x["jcd"] == jcd
            ]
            venue_items.sort(key=lambda x: int(x["rno"]))
            venue_name = venue_items[0]["venue"]

            # Step 0: save and verify all 12 deadlines for this venue.
            retry = 0
            while self.running:
                self._set_current(
                    "1〜12R締切一覧",
                    venue_name,
                    jcd,
                    None,
                    "取得・保存中…",
                )

                try:
                    sched = await asyncio.to_thread(
                        self.source.load_official_venue_schedule,
                        self.today,
                        jcd,
                        False,
                    )

                    if not sched.get("ok") or len(sched.get("races") or []) != 12:
                        raise RuntimeError("1〜12R締切一覧の保存が未完了")

                    self._set_current(
                        "1〜12R締切一覧",
                        venue_name,
                        jcd,
                        None,
                        "12R分 保存・検証済み",
                    )
                    await asyncio.sleep(0.15)
                    break

                except asyncio.CancelledError:
                    raise

                except Exception as e:
                    retry += 1
                    self.status["failed"] += 1
                    self.status["retried"] += 1
                    error_text = str(e)
                    self._error(f"締切 {jcd}: {error_text}")
                    print(
                        f"[ERROR] {venue_name} 1-12R schedule "
                        f"retry={retry}: {error_text}",
                        flush=True,
                    )
                    self._set_current(
                        "1〜12R締切一覧",
                        venue_name,
                        jcd,
                        None,
                        f"ERROR: {error_text[:100]} / 再試行{retry}回目",
                    )
                    await asyncio.sleep(min(20, 3 + retry))

            # Step 1..12: strictly ordered.
            for item in venue_items:
                if not self.running:
                    return

                key = (item["jcd"], item["rno"])
                if key in completed:
                    continue

                retry_count = 0

                while self.running:
                    self._set_current(
                        "基本データ",
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        "取得中…",
                    )

                    try:
                        result = await asyncio.to_thread(
                            self.source.fetch_basic_race_atomic,
                            item["date"],
                            item["jcd"],
                            item["rno"],
                            BASIC_LOGIC_VERSION,
                        )

                        if not (
                            result.get("ok")
                            and result.get("saved")
                            and result.get("verified")
                        ):
                            raise RuntimeError(
                                "取得後の保存・検証が未完了"
                            )

                        deadline = result["deadline"]

                        if not self.source.db.verify_basic_race(
                            item["date"],
                            item["jcd"],
                            item["rno"],
                            deadline,
                            BASIC_LOGIC_VERSION,
                        ):
                            raise RuntimeError(
                                "次R移行前のDB最終確認に失敗"
                            )

                        completed.add(key)
                        self.status["basic_complete"] += 1
                        self.status["racelist_ready"] = self.status["basic_complete"]
                        self.status["prefetched_races"] = self.status["basic_complete"]
                        self.status["basic_last_deadline"] = deadline
                        self.status["success"] += 1

                        self._eta_update(
                            self.status["basic_complete"],
                            self.status["basic_total"],
                        )

                        self._set_current(
                            "基本データ",
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            f"反映・保存済み（締切 {deadline}）",
                        )
                        print(
                            f"[BASIC] {item['venue']} {item['rno']}R "
                            f"COMPLETE deadline={deadline} "
                            f"progress={self.status['basic_complete']}/{self.status['basic_total']} "
                            f"eta={self.status.get('eta_seconds')}s",
                            flush=True,
                        )

                        await asyncio.sleep(0.15)
                        break

                    except asyncio.CancelledError:
                        raise

                    except Exception as e:
                        retry_count += 1
                        self.status["failed"] += 1
                        self.status["retried"] += 1
                        self.status["basic_failed"] += 1
                        self._error(
                            f"基本データ {item['jcd']}-{item['rno']}: {e}"
                        )

                        try:
                            self.source.db.mark_basic_error(
                                item["date"],
                                item["jcd"],
                                item["rno"],
                                BASIC_LOGIC_VERSION,
                                str(e),
                            )
                        except Exception:
                            pass

                        self._set_current(
                            "基本データ",
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            f"未完了→同じRを再試行（{retry_count}回目）",
                        )
                        await asyncio.sleep(min(15, 2 + retry_count))

        self.status["phase"] = "基本データ完了"
        self.status["basic_all_complete"] = True
        self._eta_finish(
            self.status["basic_complete"],
            self.status["basic_total"],
        )
        self.status["last_message"] = (
            f"全レース反映・保存済み "
            f"{self.status['basic_complete']}/{self.status['basic_total']}R"
        )
        self.status["current_state"] = "全レース反映・保存済み"
        self.status["current_kind"] = "基本データ"
        self.status["current_venue"] = None
        self.status["current_jcd"] = None
        self.status["current_rno"] = None

        print(
            f"[PHASE] BASIC COMPLETE "
            f"{self.status['basic_complete']}/{self.status['basic_total']}R "
            f"- ALL RACES SAVED AND VERIFIED",
            flush=True,
        )

    async def _scratch_audit_phase(self):
        """
        Independent scratch audit.
        This runs even when odds are already marked complete.
        """
        self.status["phase"] = "欠場選手確認"
        self.status["scratch_check_phase"] = "確認中"
        self.status["scratch_audit_total"] = len(self.targets)

        audited = set(
            self.source.db.get_scratch_audited_keys(self.today)
        )

        target_keys = {
            (x["jcd"], x["rno"])
            for x in self.targets
        }

        self.status["scratch_audit_complete"] = len(
            audited & target_keys
        )

        self._eta_start(
            "欠場選手確認",
            self.status["scratch_audit_complete"],
            self.status["scratch_audit_total"],
        )

        ordered = sorted(
            self.targets,
            key=lambda x: (x["jcd"], int(x["rno"]))
        )

        print(
            f"[PHASE] SCRATCH AUDIT START "
            f"audited={self.status['scratch_audit_complete']}/"
            f"{self.status['scratch_audit_total']}",
            flush=True,
        )

        for item in ordered:
            if not self.running:
                return

            key = (item["jcd"], item["rno"])

            if key in audited:
                continue

            self._set_scratch_check(
                item["venue"],
                item["jcd"],
                item["rno"],
                (
                    f"確認中 "
                    f"{self.status['scratch_audit_complete'] + 1}/"
                    f"{self.status['scratch_audit_total']}R"
                ),
                "確認中",
            )

            success = False
            last_error = ""

            for attempt in (1, 2):
                try:
                    result = await asyncio.to_thread(
                        self.source.audit_scratch_from_odds,
                        self.today,
                        item["jcd"],
                        item["rno"],
                    )

                    scratches = result.get("scratch_lanes") or []

                    audited.add(key)
                    self.status["scratch_audit_complete"] += 1
                    self._eta_update(
                        self.status["scratch_audit_complete"],
                        self.status["scratch_audit_total"],
                    )
                    success = True

                    if scratches:
                        self.status["scratch_overwrite_count"] += 1
                        self.status["scratch_found_total"] += len(scratches)

                        scratch_text = "・".join(
                            f"{x}号艇"
                            for x in scratches
                        )

                        self._set_scratch_check(
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            (
                                f"{scratch_text} 欠場 → "
                                f"出走表上書き・保存確認済み "
                                f"({self.status['scratch_audit_complete']}/"
                                f"{self.status['scratch_audit_total']}R)"
                            ),
                            "欠場あり",
                        )

                        print(
                            f"[SCRATCH-FOUND] "
                            f"{item['venue']} {item['rno']}R "
                            f"lanes={scratches}",
                            flush=True,
                        )

                    else:
                        self._set_scratch_check(
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            (
                                f"欠場なし "
                                f"({self.status['scratch_audit_complete']}/"
                                f"{self.status['scratch_audit_total']}R)"
                            ),
                            "確認済み",
                        )

                    await asyncio.sleep(0.08)
                    break

                except asyncio.CancelledError:
                    raise

                except Exception as e:
                    last_error = str(e)

                    self._set_scratch_check(
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        (
                            f"再確認中 {attempt}/2 / "
                            f"{last_error[:90]}"
                        ),
                        "再確認中",
                    )

                    print(
                        f"[ERROR] SCRATCH-AUDIT "
                        f"{item['venue']} {item['rno']}R "
                        f"attempt={attempt}/2: {last_error}",
                        flush=True,
                    )

                    if attempt == 1:
                        await asyncio.sleep(1.5)

            if not success:
                self.status["scratch_audit_failed"] += 1

                self._set_scratch_check(
                    item["venue"],
                    item["jcd"],
                    item["rno"],
                    (
                        f"確認失敗→次へ / "
                        f"{last_error[:90]}"
                    ),
                    "確認失敗",
                )

        self.status["scratch_audit_all_complete"] = True
        self._eta_finish(
            self.status["scratch_audit_complete"],
            self.status["scratch_audit_total"],
        )
        self.status["scratch_check_phase"] = "確認完了"
        self.status["scratch_check_venue"] = None
        self.status["scratch_check_jcd"] = None
        self.status["scratch_check_rno"] = None
        self.status["scratch_check_state"] = (
            f"監査済み "
            f"{self.status['scratch_audit_complete']}/"
            f"{self.status['scratch_audit_total']}R / "
            f"欠場上書き {self.status['scratch_overwrite_count']}R / "
            f"失敗 {self.status['scratch_audit_failed']}R"
        )

        print(
            f"[PHASE] SCRATCH AUDIT COMPLETE "
            f"audited={self.status['scratch_audit_complete']} "
            f"scratch_races={self.status['scratch_overwrite_count']} "
            f"failed={self.status['scratch_audit_failed']}",
            flush=True,
        )


    async def _odds_initial_phase(self):
        """
        Odds initial collection with automatic recovery.

        Per race:
          level0 normal
          -> level1 cache-buster + alternate parser
          -> level2 independent Session + alternate parser

        After the first pass, all still-missing races are automatically
        revisited once more. This is specifically meant to recover transient
        misses such as only a few races failing while the rest succeeded.
        """
        self.status["phase"] = "オッズ初回反映"
        self.status["odds_phase"] = "反映中"
        self.status["odds_total"] = len(self.targets)

        complete = set(
            self.source.db.get_odds_complete_keys(self.today)
        )

        target_keys = {
            (x["jcd"], x["rno"])
            for x in self.targets
        }

        self.status["odds_complete"] = len(
            complete & target_keys
        )
        self._eta_start(
            "オッズ",
            self.status["odds_complete"],
            self.status["odds_total"],
        )
        self.status["odds_legacy_recheck"] = (
            len(self.targets) - self.status["odds_complete"]
        )
        if self.status["odds_legacy_recheck"] > 0:
            self.status["odds_phase"] = (
                f"旧オッズ再検証中 残り{self.status['odds_legacy_recheck']}R"
            )
            print(
                f"[ODDS-REVALIDATE] legacy/unvalidated="
                f"{self.status['odds_legacy_recheck']}R "
                f"validation={VALIDATION_VERSION}",
                flush=True,
            )

        ordered = sorted(
            self.targets,
            key=lambda x: (x["jcd"], int(x["rno"]))
        )

        async def recover_one(item, second_pass=False):
            key = (item["jcd"], item["rno"])
            errors = []

            # Second pass starts at stronger methods immediately.
            levels = [1, 2] if second_pass else [0, 1, 2]

            for level in levels:
                if not self.running:
                    return False

                label = (
                    "通常取得"
                    if level == 0
                    else (
                        "再取得＋別解析"
                        if level == 1
                        else "別セッション＋別解析"
                    )
                )

                self._set_current(
                    "オッズ",
                    item["venue"],
                    item["jcd"],
                    item["rno"],
                    f"{label} 120通り確認中…",
                )

                self._set_scratch_check(
                    item["venue"],
                    item["jcd"],
                    item["rno"],
                    "オッズ不足時に欠場艇を確認します",
                    "確認待機",
                )

                try:
                    result = await asyncio.to_thread(
                        self.source.fetch_odds_atomic,
                        self.today,
                        item["jcd"],
                        item["rno"],
                        level,
                    )

                    if not (
                        result.get("ok")
                        and result.get("saved")
                        and result.get("verified")
                        and int(result.get("count", 0))
                            == int(result.get("expected_count", result.get("count", 0)))
                    ):
                        raise RuntimeError(
                            "120通りの保存・検証が未完了"
                        )

                    if level > 0:
                        self.status["odds_recovery_count"] += 1

                    if result.get("scratch_lanes"):
                        self.status["scratch_overwrite_count"] += 1
                        self.status["scratch_found_total"] += len(
                            result.get("scratch_lanes") or []
                        )
                        scratch_text = "・".join(
                            f"{x}号艇"
                            for x in (result.get("scratch_lanes") or [])
                        )
                        self._set_scratch_check(
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            f"{scratch_text} 欠場 → 出走表上書き済み",
                            "欠場あり",
                        )
                    else:
                        self._set_scratch_check(
                            item["venue"],
                            item["jcd"],
                            item["rno"],
                            "欠場なし",
                            "確認済み",
                        )

                    self._set_current(
                        "オッズ",
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        (
                            f"{result.get('count',0)}/{result.get('expected_count',result.get('count',0))} "
                            f"反映・保存済み "
                            f"{(' / 欠場艇 '+','.join(map(str,result.get('scratch_lanes') or []))) if result.get('scratch_lanes') else ''}"
                            f"（{label}で成功）"
                        ),
                    )

                    print(
                        f"[ODDS-RECOVERY] "
                        f"{item['venue']} {item['rno']}R "
                        f"SUCCESS level={level} "
                        f"parser={result.get('parser_method')}",
                        flush=True,
                    )
                    return True

                except asyncio.CancelledError:
                    raise

                except Exception as e:
                    err = str(e)
                    errors.append(
                        f"L{level}:{err}"
                    )
                    self._set_scratch_check(
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        f"確認継続中 / {err[:80]}",
                        "再確認中",
                    )
                    self._error(
                        f"オッズ {item['jcd']}-{item['rno']} "
                        f"level={level}: {err}"
                    )
                    print(
                        f"[ODDS-RECOVERY] "
                        f"{item['venue']} {item['rno']}R "
                        f"FAILED level={level}: {err}",
                        flush=True,
                    )

                    # brief backoff between methods
                    await asyncio.sleep(1.5)

            self._set_current(
                "オッズ",
                item["venue"],
                item["jcd"],
                item["rno"],
                "全取得方法失敗→後で再確認",
            )

            print(
                f"[ODDS-RECOVERY] "
                f"{item['venue']} {item['rno']}R "
                f"ALL METHODS FAILED "
                f"{' | '.join(errors)}",
                flush=True,
            )
            return False

        # ---------- First pass ----------
        for item in ordered:
            if not self.running:
                return

            key = (item["jcd"], item["rno"])
            if key in complete:
                continue

            ok = await recover_one(
                item,
                second_pass=False,
            )

            if ok:
                complete.add(key)
                self.status["odds_complete"] = len(
                    complete & target_keys
                )
                self.status["odds_updates"] += 1
                self._eta_update(
                    self.status["odds_complete"],
                    self.status["odds_total"],
                )
                self.status["odds_legacy_recheck"] = max(
                    0,
                    len(self.targets) - self.status["odds_complete"]
                )

            await asyncio.sleep(0.1)

        # ---------- Automatic re-check of only failed races ----------
        missing = [
            item for item in ordered
            if (item["jcd"], item["rno"]) not in complete
        ]

        self.status["odds_second_pass"] = len(missing)

        if missing:
            self.status["odds_phase"] = (
                f"未取得{len(missing)}Rを自動再確認中"
            )

            print(
                f"[ODDS-RECOVERY] SECOND PASS "
                f"missing={len(missing)}R",
                flush=True,
            )

            # Give the official site a little time before retrying only misses.
            await asyncio.sleep(3)

            for item in missing:
                if not self.running:
                    return

                key = (item["jcd"], item["rno"])

                ok = await recover_one(
                    item,
                    second_pass=True,
                )

                if ok:
                    complete.add(key)
                    self.status["odds_complete"] = len(
                        complete & target_keys
                    )
                    self.status["odds_updates"] += 1

                await asyncio.sleep(0.2)

        final_missing = [
            item for item in ordered
            if (item["jcd"], item["rno"]) not in complete
        ]

        self.status["odds_unavailable"] = len(
            final_missing
        )

        self.status["odds_phase"] = "初回反映完了"
        self.status["odds_all_complete"] = True
        self._eta_finish(
            self.status["odds_complete"],
            self.status["odds_total"],
        )
        self.status["phase"] = "オッズ初回反映完了"

        self.status["last_message"] = (
            f"オッズ初回処理完了 "
            f"反映済み{self.status['odds_complete']}R / "
            f"最終未取得{self.status['odds_unavailable']}R / "
            f"自動復旧{self.status['odds_recovery_count']}R / "
            f"対象{self.status['odds_total']}R"
        )

        self.status["current_kind"] = "オッズ"
        self.status["current_venue"] = None
        self.status["current_jcd"] = None
        self.status["current_rno"] = None
        self.status["current_state"] = self.status["last_message"]

        self.status["scratch_check_phase"] = "確認完了"
        self.status["scratch_check_venue"] = None
        self.status["scratch_check_jcd"] = None
        self.status["scratch_check_rno"] = None
        self.status["scratch_check_state"] = (
            f"欠場上書き {self.status['scratch_overwrite_count']}R"
        )

        print(
            f"[PHASE] ODDS RECOVERY COMPLETE "
            f"saved={self.status['odds_complete']} "
            f"recovered={self.status['odds_recovery_count']} "
            f"missing={self.status['odds_unavailable']} "
            f"total={self.status['odds_total']}",
            flush=True,
        )


    async def _before_initial_phase(self):
        self.status["phase"] = "直前情報初回反映"
        self.status["before_phase"] = "反映中"
        self.status["before_total"] = len(self.targets)

        complete = set(
            self.source.db.get_before_complete_keys(self.today)
        )
        self.status["before_complete"] = len([
            x for x in self.targets
            if (x["jcd"], x["rno"]) in complete
        ])

        self._eta_start(
            "直前情報",
            self.status["before_complete"],
            self.status["before_total"],
        )

        ordered = sorted(
            self.targets,
            key=lambda x: (x["jcd"], int(x["rno"]))
        )

        for item in ordered:
            if not self.running:
                return

            key = (item["jcd"], item["rno"])
            if key in complete:
                continue

            success = False
            last_error = ""

            for attempt in (1, 2):
                self._set_current(
                    "直前情報",
                    item["venue"],
                    item["jcd"],
                    item["rno"],
                    f"取得・保存中…（{attempt}/2）",
                )

                try:
                    result = await asyncio.to_thread(
                        self.source.fetch_before_atomic,
                        self.today,
                        item["jcd"],
                        item["rno"],
                    )

                    quality = result.get("quality") or {}
                    complete.add(key)
                    self.status["before_complete"] += 1
                    self.status["before_updates"] += 1
                    self._eta_update(
                        self.status["before_complete"],
                        self.status["before_total"],
                    )
                    success = True

                    self._set_current(
                        "直前情報",
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        (
                            f"反映・保存済み "
                            f"展示{quality.get('racers', 0)}/6 "
                            f"ST{quality.get('starts', 0)}/6 "
                            f"気象{quality.get('weather_fields', 0)}項目"
                        ),
                    )

                    print(
                        f"[BEFORE] {item['venue']} {item['rno']}R "
                        f"COMPLETE racers={quality.get('racers', 0)}/6 "
                        f"starts={quality.get('starts', 0)}/6 "
                        f"weather={quality.get('weather_fields', 0)}",
                        flush=True,
                    )
                    break

                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    last_error = str(e)
                    print(
                        f"[ERROR] BEFORE {item['venue']} "
                        f"{item['rno']}R {attempt}/2: {last_error}",
                        flush=True,
                    )
                    self._error(
                        f"直前情報 {item['jcd']}-{item['rno']}: {last_error}"
                    )
                    if attempt == 1:
                        await asyncio.sleep(2)

            if not success:
                self.status["before_unavailable"] += 1
                self._set_current(
                    "直前情報",
                    item["venue"],
                    item["jcd"],
                    item["rno"],
                    "取得不可として次へ",
                )

        self.status["before_phase"] = "初回反映完了"
        self.status["before_all_complete"] = True
        self._eta_finish(
            self.status["before_complete"],
            self.status["before_total"],
        )
        self.status["phase"] = "直前情報初回反映完了"
        self.status["last_message"] = (
            f"直前情報初回処理完了 "
            f"反映済み{self.status['before_complete']}R / "
            f"取得不可{self.status['before_unavailable']}R / "
            f"対象{self.status['before_total']}R"
        )


    async def _comments_pilot_phase(self):
        """
        Pilot: Toda (jcd=02) only.
        Comments are fetched from the venue's own official site.
        Other race data continues to use boatrace.jp.
        """
        toda = [
            x for x in self.targets
            if str(x["jcd"]).zfill(2) == "02"
        ]

        self.status["comments_total"] = len(toda)

        if not toda:
            self.status["comments_phase"] = "対象なし"
            return

        self.status["comments_phase"] = "戸田公式から取得中"

        for item in sorted(toda, key=lambda x: int(x["rno"])):
            if not self.running:
                return

            self._set_current(
                "選手コメント",
                item["venue"],
                item["jcd"],
                item["rno"],
                "戸田公式サイトから取得中…",
            )

            try:
                result = await asyncio.to_thread(
                    self.source.fetch_venue_comments_for_race,
                    self.today,
                    item["jcd"],
                    item["rno"],
                )

                self.status["comments_complete"] += 1
                count = len(result.get("comments") or [])
                self.status["comments_found"] += count

                if count:
                    self._set_current(
                        "選手コメント",
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        f"{count}選手分 反映・保存済み",
                    )
                else:
                    self._set_current(
                        "選手コメント",
                        item["venue"],
                        item["jcd"],
                        item["rno"],
                        "公式コメントを対応付けできず",
                    )

                print(
                    f"[COMMENTS] {item['venue']} {item['rno']}R "
                    f"comments={count} "
                    f"reason={result.get('reason')}",
                    flush=True,
                )

            except Exception as e:
                self.status["comments_failed"] += 1
                print(
                    f"[ERROR] COMMENTS {item['venue']} "
                    f"{item['rno']}R: {e}",
                    flush=True,
                )

            await asyncio.sleep(0.15)

        self.status["comments_phase"] = (
            f"戸田パイロット完了 "
            f"{self.status['comments_complete']}/{self.status['comments_total']}R"
        )


    async def _result_initial_phase(self):
        """
        2026/09/13 final result backfill.

        Efficient venue-level flow:
          venue resultlist fetch once
          -> parse/save all confirmed R
          -> mark saved R complete
          -> move to next venue

        Max 2 attempts per venue so one venue cannot block everything.
        """
        self.status["phase"] = "結果初回反映"
        self.status["result_phase"] = "反映中"
        self.status["result_total"] = len(self.targets)

        complete = set(
            self.source.db.get_result_complete_keys(
                self.today
            )
        )

        target_keys = {
            (x["jcd"], x["rno"])
            for x in self.targets
        }

        self.status["result_complete"] = len(
            complete & target_keys
        )

        self._eta_start(
            "結果",
            self.status["result_complete"],
            self.status["result_total"],
        )

        venue_codes = []
        for item in self.targets:
            if item["jcd"] not in venue_codes:
                venue_codes.append(item["jcd"])

        for jcd in venue_codes:
            if not self.running:
                return

            venue_items = sorted(
                [
                    x for x in self.targets
                    if x["jcd"] == jcd
                ],
                key=lambda x: int(x["rno"])
            )

            venue_name = venue_items[0]["venue"]
            venue_keys = {
                (jcd, x["rno"])
                for x in venue_items
            }

            # Skip if whole venue already saved.
            if venue_keys.issubset(complete):
                continue

            success = False
            last_error = ""

            for attempt in (1, 2):
                self._set_current(
                    "結果",
                    venue_name,
                    jcd,
                    None,
                    f"1〜12R取得・保存中…（{attempt}/2）",
                )

                try:
                    result = await asyncio.to_thread(
                        self.source.fetch_results_atomic,
                        self.today,
                        jcd,
                    )

                    after = set(
                        self.source.db.get_result_complete_keys(
                            self.today
                        )
                    )

                    new_complete = after & venue_keys
                    before_count = len(
                        complete & target_keys
                    )

                    complete |= new_complete

                    after_count = len(
                        complete & target_keys
                    )

                    self.status["result_complete"] = after_count
                    self.status["result_updates"] += max(
                        0, after_count - before_count
                    )
                    self._eta_update(
                        self.status["result_complete"],
                        self.status["result_total"],
                    )

                    success = True

                    self._set_current(
                        "結果",
                        venue_name,
                        jcd,
                        None,
                        (
                            f"{len(new_complete)}/12R "
                            f"反映・保存済み"
                        ),
                    )

                    print(
                        f"[RESULT] {venue_name} "
                        f"COMPLETE {len(new_complete)}/12R "
                        f"total={after_count}/"
                        f"{self.status['result_total']}",
                        flush=True,
                    )
                    break

                except asyncio.CancelledError:
                    raise

                except Exception as e:
                    last_error = str(e)
                    print(
                        f"[ERROR] RESULT {venue_name} "
                        f"{attempt}/2: {last_error}",
                        flush=True,
                    )
                    self._error(
                        f"結果初回 {jcd}: {last_error}"
                    )
                    if attempt == 1:
                        await asyncio.sleep(2)

            if not success:
                # Count only still-missing races for this venue.
                missing = venue_keys - complete
                self.status["result_unavailable"] += len(
                    missing
                )

                self._set_current(
                    "結果",
                    venue_name,
                    jcd,
                    None,
                    (
                        f"取得不可 {len(missing)}R "
                        f"として次へ"
                    ),
                )

        # Final readback
        complete = set(
            self.source.db.get_result_complete_keys(
                self.today
            )
        )
        self.finished = set(complete)
        self.status["finished_races"] = len(
            complete & target_keys
        )
        self.status["result_complete"] = len(
            complete & target_keys
        )

        missing_total = (
            self.status["result_total"]
            - self.status["result_complete"]
        )
        self.status["result_unavailable"] = max(
            self.status["result_unavailable"],
            missing_total,
        )

        self.status["result_phase"] = "初回反映完了"
        self.status["result_all_complete"] = True
        self._eta_finish(
            self.status["result_complete"],
            self.status["result_total"],
        )
        self.status["phase"] = "結果初回反映完了"

        self.status["last_message"] = (
            f"結果初回処理完了 "
            f"反映済み{self.status['result_complete']}R / "
            f"未取得{missing_total}R / "
            f"対象{self.status['result_total']}R"
        )

        self.status["current_kind"] = "結果"
        self.status["current_venue"] = None
        self.status["current_jcd"] = None
        self.status["current_rno"] = None
        self.status["current_state"] = self.status["last_message"]

        print(
            f"[PHASE] RESULT INITIAL COMPLETE "
            f"saved={self.status['result_complete']} "
            f"missing={missing_total} "
            f"total={self.status['result_total']}",
            flush=True,
        )

    def _load_schedule_map(self):
        rows = self.source.db.get_day_schedule(self.today)
        out = {}

        for jcd, races in rows.items():
            for row in races:
                if row.get("deadline"):
                    out[(str(jcd).zfill(2), int(row["rno"]))] = row["deadline"]

        return out

    def _odds_interval_seconds(self, mins_to_deadline):
        if mins_to_deadline is None:
            return None
        if mins_to_deadline > 60 or mins_to_deadline < 0:
            return None
        if mins_to_deadline > 30:
            return 300       # 5 min
        if mins_to_deadline > 15:
            return 180       # 3 min
        if mins_to_deadline > 5:
            return 60        # 1 min
        return 30            # final 5 min

    def _odds_monitoring_started(self):
        """
        Odds + scratch monitoring starts at 08:00 JST.
        From 00:00 through 07:59:59 we intentionally do not request odds.
        """
        now = datetime.now(JST)
        return now.hour >= 8


    async def _meeting_results_status_phase(self):
        """
        Current-meeting results are collected venue-by-venue.

        Flow:
          1) exclude day-1 venues
          2) sort day-2+ venues by venue code
          3) for one venue, process 1R -> 12R in order
          4) only after all 12 races are checked, move to next venue

        This makes the current stage visible instead of leaving the UI at a
        vague "取得結果を確認中".
        """
        self.status["meeting_results_phase"] = "節間成績：対象場を確認中"
        self.status["meeting_results_total"] = 0
        self.status["meeting_results_complete"] = 0
        self.status["meeting_results_failed"] = 0
        self.status["meeting_results_skipped_day1"] = 0
        self.status["meeting_results_current_venue"] = None
        self.status["meeting_results_current_rno"] = None
        self.status["meeting_results_current_stage"] = "対象場確認"
        self.status["meeting_results_racer_count"] = 0

        # Group all today's targets by venue.
        by_venue = {}
        for item in self.targets:
            jcd = str(item["jcd"]).zfill(2)
            row = by_venue.setdefault(
                jcd,
                {
                    "venue": item["venue"],
                    "jcd": jcd,
                    "races": [],
                },
            )
            row["races"].append(item)

        eligible = []
        skipped_day1 = 0
        unknown_day = 0

        for jcd in sorted(by_venue):
            row = by_venue[jcd]
            day_no = self.source._meeting_day_number_from_db(
                self.today, jcd
            )

            if day_no == 1:
                skipped_day1 += 1
                continue

            if day_no is None:
                unknown_day += 1
                # Meeting-day phase should already have run, but do not silently
                # skip. Keep this venue visible as a failure candidate.
                row["day_no"] = None
                eligible.append(row)
                continue

            if day_no >= 2:
                row["day_no"] = day_no
                eligible.append(row)

        self.status["meeting_results_skipped_day1"] = skipped_day1
        self.status["meeting_results_eligible_venues"] = len(eligible)
        self.status["meeting_results_total"] = len(eligible) * 12

        if not eligible:
            if skipped_day1:
                self.status["meeting_results_phase"] = (
                    f"節間成績：対象場なし（初日 {skipped_day1}場）"
                )
            else:
                self.status["meeting_results_phase"] = (
                    "節間成績：2日目以降の開催場なし"
                )
            return

        complete = 0
        failed = 0

        for venue_index, row in enumerate(eligible, start=1):
            if not self.running:
                return

            venue = row["venue"]
            jcd = row["jcd"]
            day_no = row.get("day_no")

            self.status["meeting_results_current_venue"] = venue
            self.status["meeting_results_current_stage"] = "場を設定"
            self.status["meeting_results_phase"] = (
                f"節間成績 {venue_index}/{len(eligible)}場："
                f"{venue} を処理開始"
                + (f"（{day_no}日目）" if day_no else "（開催日数再確認必要）")
            )

            if day_no is None:
                try:
                    info = await asyncio.to_thread(
                        self.source.ensure_meeting_day,
                        self.today, jcd, True
                    )
                    day_no = info.get("number")
                    row["day_no"] = day_no
                except Exception as ex:
                    failed += 12
                    self.status["meeting_results_failed"] = failed
                    self.status["meeting_results_current_stage"] = (
                        "開催日数の再取得に失敗"
                    )
                    self.status["meeting_results_phase"] = (
                        f"節間成績 {venue}：開催日数を取得できずスキップ"
                    )
                    self._error(f"節間成績 開催日数 {jcd}: {ex}")
                    continue

            if day_no == 1:
                skipped_day1 += 1
                self.status["meeting_results_skipped_day1"] = skipped_day1
                self.status["meeting_results_phase"] = (
                    f"節間成績 {venue}：初日のため対象外"
                )
                continue

            races = sorted(
                row["races"],
                key=lambda x: int(x["rno"])
            )

            venue_ok = 0
            venue_failed = 0

            for item in races:
                if not self.running:
                    return

                rno = int(item["rno"])
                self.status["meeting_results_current_rno"] = rno
                self.status["meeting_results_current_stage"] = "公式出走表取得"
                self.status["meeting_results_phase"] = (
                    f"節間成績 {venue_index}/{len(eligible)}場："
                    f"{venue} {rno}R 公式出走表から収集中…"
                )
                self._set_current(
                    "節間成績",
                    venue, jcd, rno,
                    "公式出走表から今節成績を再収集・色情報確認中…",
                )

                try:
                    # Always re-fetch day-2+ racelist during this dedicated phase.
                    # This avoids reusing an old snapshot that was saved before
                    # meeting results became available.
                    data = await asyncio.to_thread(
                        self.source.refresh_meeting_results_race,
                        self.today, jcd, rno
                    )

                    self.status["meeting_results_current_stage"] = "反映確認"
                    racer_count = self.source._meeting_results_racer_count(data)
                    self.status["meeting_results_racer_count"] = racer_count

                    if self.source._racelist_has_meeting_results(data):
                        venue_ok += 1
                        complete += 1
                        self.status["meeting_results_complete"] = complete
                        self.status["meeting_results_last_saved_jcd"] = jcd
                        self.status["meeting_results_last_saved_rno"] = rno
                        self.status["meeting_results_revision"] = (
                            int(self.status.get("meeting_results_revision") or 0) + 1
                        )
                        self.status["meeting_results_current_stage"] = (
                            "DB保存・画面反映待ち"
                        )
                        self.status["meeting_results_phase"] = (
                            f"節間成績 {venue_index}/{len(eligible)}場："
                            f"{venue} {rno}R 選手6/6反映完了 "
                            f"（場内 {venue_ok}/12R）"
                        )
                    else:
                        venue_failed += 1
                        failed += 1
                        self.status["meeting_results_failed"] = failed
                        self.status["meeting_results_current_stage"] = (
                            f"公式取得済み・解析 {racer_count}/6選手"
                        )
                        self.status["meeting_results_phase"] = (
                            f"節間成績 {venue_index}/{len(eligible)}場："
                            f"{venue} {rno}R "
                            f"公式ページ取得済み / 解析 {racer_count}/6選手"
                        )

                except asyncio.CancelledError:
                    raise
                except Exception as ex:
                    venue_failed += 1
                    failed += 1
                    self.status["meeting_results_failed"] = failed
                    self.status["meeting_results_current_stage"] = "取得失敗"
                    self.status["meeting_results_phase"] = (
                        f"節間成績 {venue_index}/{len(eligible)}場："
                        f"{venue} {rno}R 取得失敗"
                    )
                    self._error(
                        f"節間成績 {jcd}-{rno}R: {ex}"
                    )

            self.status["meeting_results_current_rno"] = None
            self.status["meeting_results_current_stage"] = "場内12R確認完了"
            self.status["meeting_results_phase"] = (
                f"節間成績 {venue_index}/{len(eligible)}場："
                f"{venue} 12R確認完了 "
                f"反映{venue_ok}/12R / 未反映{venue_failed}/12R"
            )

        self.status["meeting_results_current_venue"] = None
        self.status["meeting_results_current_rno"] = None
        self.status["meeting_results_current_stage"] = "全対象場確認完了"
        self.status["meeting_results_complete"] = complete
        self.status["meeting_results_failed"] = failed

        target_total = self.status["meeting_results_total"]
        self.status["meeting_results_phase"] = (
            f"節間成績 全対象場確認完了："
            f"反映 {complete}/{target_total}R"
            + (f" / 未反映 {failed}R" if failed else "")
            + (f" / 初日除外 {skipped_day1}場" if skipped_day1 else "")
        )


    async def _pre_ai_prediction_phase(self):
        """
        Build the before-info-independent prediction for every race of today.

        This phase runs immediately after racelist/basic data is saved.
        The prediction row is also the container that will later be updated
        at T-15 with the before-info prediction.
        """
        ordered = sorted(
            self.targets,
            key=lambda x: (str(x["jcd"]).zfill(2), int(x["rno"]))
        )

        self.status["pre_ai_phase"] = "事前AI予想を反映中"
        self.status["pre_ai_total"] = len(ordered)
        self.status["pre_ai_complete"] = 0
        self.status["pre_ai_failed"] = 0
        self.status["pre_ai_percent"] = 0.0

        for item in ordered:
            if not self.running:
                return

            try:
                existing = await asyncio.to_thread(
                    self.source.get_prediction,
                    self.today, item["jcd"], item["rno"]
                )
                snap = (existing or {}).get("source_snapshot") or {}
                pre = snap.get("pre_prediction") or {}

                current_race_snap = self.source.db.get_snapshot(
                    self.today, item["jcd"], item["rno"], "racelist"
                )
                current_race = (current_race_snap or {}).get("data") or {}
                current_has_meeting = self.source._racelist_has_meeting_results(
                    current_race
                )
                old_availability = {
                    x.get("key"): bool(x.get("available"))
                    for x in (snap.get("availability") or [])
                    if isinstance(x, dict)
                }
                ai_missing_new_meeting = (
                    current_has_meeting
                    and not old_availability.get("meeting_results", False)
                )

                # Reuse only when the stored PRE already contains the currently
                # available meeting-result basis.
                if (
                    (pre.get("picks") or pre.get("lane_scores"))
                    and not ai_missing_new_meeting
                    and pre.get("strategies")
                ):
                    self.status["pre_ai_complete"] += 1
                else:
                    self._set_current(
                        "事前AI予想",
                        item["venue"], item["jcd"], item["rno"],
                        "直前情報を使わない予想を生成・保存中…",
                    )

                    pred = await asyncio.to_thread(
                        self.source.build_ai_prediction,
                        self.today, item["jcd"], item["rno"],
                        "balanced", True, False,
                    )

                    ps = (pred.get("source_snapshot") or {})
                    pre2 = ps.get("pre_prediction") or {}
                    if not (pre2.get("picks") or pre2.get("lane_scores")):
                        raise RuntimeError("事前AI予想の生成結果が空です")

                    self.status["pre_ai_complete"] += 1
                    self.status["ai_prediction_updates"] += 1

            except asyncio.CancelledError:
                raise
            except Exception as e:
                self.status["pre_ai_failed"] += 1
                self.status["ai_prediction_errors"] += 1
                self._error(
                    f"事前AI予想 {item['jcd']}-{item['rno']}: {e}"
                )

            total = max(1, self.status["pre_ai_total"])
            self.status["pre_ai_percent"] = round(
                self.status["pre_ai_complete"] / total * 100, 1
            )

        total = self.status["pre_ai_total"]
        done = self.status["pre_ai_complete"]
        self.status["pre_ai_percent"] = (
            round(done / total * 100, 1) if total else 100.0
        )
        self.status["pre_ai_phase"] = (
            "全レース反映・保存済み"
            if done == total and total > 0
            else "事前AI予想の初回処理完了"
        )

        print(
            f"[PRE-AI] COMPLETE saved={done}/{total} "
            f"failed={self.status['pre_ai_failed']}",
            flush=True,
        )

    async def _dynamic_cycle(self):
        """
        Current-day real-time work after basic data is complete.
        """
        schedule = self._load_schedule_map()
        now_ts = time.time()

        for item in self.targets:
            if not self.running:
                return

            key = (item["jcd"], item["rno"])
            deadline = schedule.get(key)

            if not deadline:
                continue

            # Once final result is stored, this race is dead forever.
            if key in self.finished:
                continue

            mins = self._minutes_to(deadline)
            deadline_ts = self._deadline_ts(deadline)

            if mins is None or deadline_ts is None:
                continue

            # BEFORE INFO + ODDS use one race-specific clock.  Both start at
            # T-15, refresh every minute, and every 30 seconds in the final
            # five minutes.  This guarantees that the prediction never mixes
            # a fresh exhibition snapshot with stale odds.
            live_interval = 30 if 0 <= mins <= 5 else (60 if 0 <= mins <= 15 else None)

            # BEFORE INFO:
            if 0 <= mins <= 15:
                due = self.before_due.get(key, 0)
                if now_ts >= due:
                    self._set_current(
                        "直前情報",
                        item["venue"], item["jcd"], item["rno"],
                        "取得・保存中…",
                    )
                    try:
                        result = await asyncio.to_thread(
                            self.source.fetch_before_atomic,
                            self.today, item["jcd"], item["rno"]
                        )
                        q = result.get("quality") or {}
                        self.status["before_updates"] += 1
                        self.before_due[key] = now_ts + live_interval
                        self._set_current(
                            "直前情報",
                            item["venue"], item["jcd"], item["rno"],
                            f"反映・保存済み 展示{q.get('racers',0)}/6 ST{q.get('starts',0)}/6",
                        )
                    except Exception as e:
                        self.before_due[key] = now_ts + 30
                        self._error(f"直前 {key}: {e}")

            # ODDS + SCRATCH:
            # Do not request odds before 08:00 JST. Official odds are generally
            # not useful/available in the 00:00-08:00 preparation window.
            # Scratch detection is coupled to the official odds matrix, so it
            # starts at the same 08:00 gate.
            #
            # After 08:00, collect at exactly the same race timing as before
            # information: T-15..5 every minute, T-5..0 every 30 seconds.
            interval = (
                live_interval
                if self._odds_monitoring_started() and live_interval is not None
                else None
            )
            if interval is not None:
                due = self.odds_due.get(key, 0)

                if now_ts >= due:
                    self._set_current(
                        "オッズ",
                        item["venue"], item["jcd"], item["rno"],
                        "120通り取得・保存中…",
                    )

                    try:
                        try:
                            result = await asyncio.to_thread(
                                self.source.fetch_odds_atomic,
                                self.today,
                                item["jcd"],
                                item["rno"],
                                0,
                            )
                        except Exception:
                            try:
                                result = await asyncio.to_thread(
                                    self.source.fetch_odds_atomic,
                                    self.today,
                                    item["jcd"],
                                    item["rno"],
                                    1,
                                )
                            except Exception:
                                result = await asyncio.to_thread(
                                    self.source.fetch_odds_atomic,
                                    self.today,
                                    item["jcd"],
                                    item["rno"],
                                    2,
                                )

                        if not (
                            result.get("ok")
                            and result.get("saved")
                            and result.get("verified")
                            and int(result.get("count", 0))
                                == int(result.get("expected_count", result.get("count", 0)))
                        ):
                            raise RuntimeError(
                                "オッズ120通りの保存・検証が未完了"
                            )

                        self.status["odds_updates"] += 1
                        self.odds_due[key] = now_ts + interval

                        self._set_current(
                            "オッズ",
                            item["venue"], item["jcd"], item["rno"],
                            f"120/120 反映・保存済み / 次回{interval}秒後",
                        )

                        print(
                            f"[ODDS] {item['venue']} {item['rno']}R "
                            f"COMPLETE 120/120 next={interval}s",
                            flush=True,
                        )

                    except Exception as e:
                        error_text = str(e)
                        self._error(f"オッズ {key}: {error_text}")

                        print(
                            f"[ERROR] ODDS {item['venue']} {item['rno']}R: "
                            f"{error_text}",
                            flush=True,
                        )

                        # Retry quickly, but not continuously.
                        self.odds_due[key] = now_ts + 30

                        self._set_current(
                            "オッズ",
                            item["venue"], item["jcd"], item["rno"],
                            f"ERROR: {error_text[:90]} / 30秒後再試行",
                        )

            # AI PREDICTION:
            # At T-15 create the PRE prediction and the best POST prediction
            # available at that moment. If core before-info is still missing,
            # retry every 30 seconds until it becomes available.
            if 0 <= mins <= 15:
                ai_due = self.ai_due.get(key, 0)
                if now_ts >= ai_due:
                    try:
                        existing = await asyncio.to_thread(
                            self.source.get_prediction,
                            self.today, item["jcd"], item["rno"]
                        )
                        snap = (existing or {}).get("source_snapshot") or {}
                        post_ready = bool(snap.get("post_ready"))

                        # Refresh saved strategies with current pre-deadline odds.
                        self._set_current(
                            "AI予想",
                            item["venue"], item["jcd"], item["rno"],
                            "事前予想＋直前予想を生成・保存中…",
                        )
                        pred = await asyncio.to_thread(
                            self.source.build_ai_prediction,
                            self.today, item["jcd"], item["rno"],
                            "balanced", True, False,
                        )
                        self.status["ai_prediction_updates"] += 1
                        ps = (pred.get("source_snapshot") or {})
                        now_ready = bool(ps.get("post_ready"))
                        self.ai_due[key] = (
                            now_ts + 30
                        )
                        self.status["ai_last_prediction"] = {
                            "jcd": item["jcd"],
                            "venue": item["venue"],
                            "rno": item["rno"],
                            "confidence": pred.get("confidence"),
                            "judgement": pred.get("judgement"),
                            "post_ready": now_ready,
                        }
                        self._set_current(
                            "AI予想",
                            item["venue"], item["jcd"], item["rno"],
                            (
                                f"公開・保存済み 信頼度{pred.get('confidence','-')}% "
                                + ("直前反映済み" if now_ready else "直前情報待ち→30秒後再計算")
                            ),
                        )
                        print(
                            f"[AI] {item['venue']} {item['rno']}R "
                            f"saved confidence={pred.get('confidence')} "
                            f"post_ready={now_ready}",
                            flush=True,
                        )

                    except Exception as e:
                        self.status["ai_prediction_errors"] += 1
                        self.ai_due[key] = now_ts + 30
                        self._error(f"AI予想 {key}: {e}")

            # RESULT:
            # First check at deadline + 4 min.
            first_result_due = deadline_ts + 240
            due = self.result_due.get(key, first_result_due)

            if now_ts >= due:
                self.status["result_checks"] += 1
                self._set_current(
                    "結果",
                    item["venue"], item["jcd"], item["rno"],
                    "確認中…",
                )

                try:
                    result = await asyncio.to_thread(
                        self.source.get_result_for_race,
                        self.today, item["jcd"], item["rno"]
                    )

                    if result.get("confirmed"):
                        self.finished.add(key)
                        self.status["finished_races"] = len(self.finished)
                        self.status["result_updates"] += 1

                        # Stop all timers for final race.
                        self.before_due.pop(key, None)
                        self.odds_due.pop(key, None)
                        self.result_due.pop(key, None)

                        self._set_current(
                            "結果",
                            item["venue"], item["jcd"], item["rno"],
                            "反映・保存完了→処理終了",
                        )
                    else:
                        self.result_due[key] = now_ts + 30
                        self._set_current(
                            "結果",
                            item["venue"], item["jcd"], item["rno"],
                            "未確定→30秒後再確認",
                        )

                except Exception as e:
                    self._error(f"結果 {key}: {e}")
                    self.result_due[key] = now_ts + 30
                    self._set_current(
                        "結果",
                        item["venue"], item["jcd"], item["rno"],
                        "取得失敗→30秒後再確認",
                    )

    async def _realtime_phase(self):
        self.status["phase"] = "リアルタイム更新"

        while self.running:
            # Midnight rollover detection.
            current_date = self._jst_date_key()
            if current_date != self.today:
                print(
                    f"[DAY-ROLLOVER] {self.today} -> "
                    f"{current_date}",
                    flush=True,
                )
                self.status["last_message"] = (
                    f"0:00 日付切替を検出 "
                    f"{self.today} → {current_date}"
                )
                return

            try:
                await self._dynamic_cycle()
                self.status["last_cycle"] = (
                    datetime.now(JST).isoformat()
                )
                self.status["next_midnight"] = (
                    self._next_midnight_iso()
                )
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self._error(
                    f"リアルタイムループ: {e}"
                )

            await asyncio.sleep(2)

    async def _run_current_day(self):
        """
        Live-day collection flow.

        At startup / midnight:
          discover current day's venues
          -> basic racelist + deadlines + meeting day
          -> save/verify
          -> realtime monitoring

        Heavy historical backfill phases are NOT run at midnight.
        Odds/scratch start at 08:00 JST; before/result use realtime timing rules.
        """
        await self._discover_today_targets()

        if not self.running:
            return

        await self._meeting_day_phase()

        if not self.running:
            return

        await self._basic_rebuild_phase()

        if not self.running:
            return

        await self._meeting_results_status_phase()

        if not self.running:
            return

        await self._pre_ai_prediction_phase()

        if not self.running:
            return

        odds_state = (
            "オッズ・欠場監視開始済み"
            if self._odds_monitoring_started()
            else "オッズ・欠場は08:00 JSTから"
        )
        self.status["last_message"] = (
            f"{self.today} 基本データ反映完了 "
            f"{self.status['basic_complete']}/"
            f"{self.status['basic_total']}R / "
            f"{odds_state} / リアルタイム監視開始"
        )

        print(
            f"[DAY-READY] {self.today} "
            f"basic={self.status['basic_complete']}/"
            f"{self.status['basic_total']}R",
            flush=True,
        )

        await self._realtime_phase()

    async def _run(self):
        """
        Permanent daily supervisor.

        - On app startup, collect the current JST date immediately.
        - At 00:00 JST, detect the new date automatically.
        - If official data is not ready yet, retry after 3 minutes.
        - DB from previous days is preserved.
        """
        try:
            first_day = True

            while self.running:
                current_date = self._jst_date_key()

                if (
                    first_day
                    or current_date != self.today
                ):
                    old_date = self.today
                    self._reset_for_date(
                        current_date
                    )

                    if not first_day:
                        self.status["day_rollover_count"] += 1

                    self.status["phase"] = (
                        "0:00 日付自動切替"
                        if not first_day
                        else "起動時当日収集"
                    )
                    self.status["last_message"] = (
                        f"{current_date} の開催情報を取得開始"
                    )

                    print(
                        f"[DAY-START] date={current_date} "
                        f"reason={'startup' if first_day else 'midnight'}",
                        flush=True,
                    )

                    first_day = False

                try:
                    self.status["day_start_attempt"] += 1
                    self.status["day_start_last_error"] = None

                    await self._run_current_day()

                    # _realtime_phase returns only when date changed
                    # or collector stopped. Loop immediately so the
                    # new date can be initialized.
                    if not self.running:
                        break

                    if self._jst_date_key() != self.today:
                        continue

                except asyncio.CancelledError:
                    raise

                except Exception as e:
                    error_text = str(e)
                    self.status["day_start_last_error"] = (
                        error_text
                    )
                    self._error(
                        f"当日初期取得 {self.today}: "
                        f"{error_text}"
                    )

                    self.status["phase"] = (
                        "当日データ取得再試行待ち"
                    )
                    self.status["last_message"] = (
                        f"{self.today} の開催情報をまだ取得できません。"
                        f"3分後に自動再試行します。"
                    )

                    print(
                        f"[DAY-RETRY] date={self.today} "
                        f"after=180s error={error_text}",
                        flush=True,
                    )

                    # Official site may not have completed its
                    # midnight date switch yet.
                    for _ in range(180):
                        if not self.running:
                            return
                        if (
                            self._jst_date_key()
                            != self.today
                        ):
                            break
                        await asyncio.sleep(1)

                    # Same date: retry discovery. New date: outer
                    # loop initializes the rollover immediately.
                    continue

                # Safety idle; normally realtime phase owns the loop.
                await asyncio.sleep(1)

        except asyncio.CancelledError:
            pass
        except Exception as e:
            self._error(f"collector supervisor: {e}")
            self.status["phase"] = "エラー"
            self.status["last_message"] = (
                f"自動収集エラー: {e}"
            )
