from __future__ import annotations
"""v17.198 validation build: racer 4320 (峰竜太) only.

Collection flow for this validation:
1. Wait until today's official racelist is saved locally.
2. Find 4320 in today's racelist and identify only the venue where he races today.
3. Check whether national/local actual-entry-course buckets are incomplete.
4. Fetch the racer's own yearly all-races pages directly (never crawl 24 venues by date).
5. Classify each run by actual entry course 1..6.
6. Keep newest max 10 for national and today's local venue.
7. Stop as soon as every bucket has 10; otherwise continue only down through 2023.
8. Reaching 2023 with fewer than 10 (including zero) is normal completion.

Special results:
- 欠場 is ignored because the racer did not actually start.
- F/L and other actual-start special results are preserved as text when parseable.
"""
import re, threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup

JST=ZoneInfo('Asia/Tokyo'); FLOOR_YEAR=2023; FLOOR='20230101'
VALIDATION_REG='4320'
VENUES=['桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村']
VENUE_CODE={n:f'{i:02d}' for i,n in enumerate(VENUES,1)}
def _norm(s): return re.sub(r'[\s\u3000]+','',str(s or ''))
def _venue_code(s):
    n=_norm(s)
    return next((code for name,code in VENUE_CODE.items() if _norm(name)==n),None)
def _date_token(s,year):
    m=re.search(r'(?<!\d)(\d{1,2})/(\d{1,2})(?!\d)',str(s or ''))
    return f'{year}{int(m.group(1)):02d}{int(m.group(2)):02d}' if m else None
def _race_token(s):
    m=re.fullmatch(r'\s*(\d{1,2})R\s*',str(s or '')); return int(m.group(1)) if m else None
def _course_token(s):
    t=_norm(s); return int(t) if re.fullmatch(r'[1-6]',t) else None
def _st_token(s):
    """Race ST only. Bare 1..6 must NEVER be accepted as ST."""
    t=_norm(s).upper()
    if re.fullmatch(r'\.\d{1,2}',t): return t
    if re.fullmatch(r'[FL]\.\d{1,2}',t): return t
    if t in {'F','L'}: return t
    return None
def _rank_token(s):
    m=re.fullmatch(r'\(([1-6])\)',_norm(s)); return int(m.group(1)) if m else None
def _finish_token(s):
    t=_norm(s).replace('着','')
    return t if re.fullmatch(r'[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠',t) else None

def _expand_table(table):
    """Expand rowspan/colspan so date headers line up with race/data columns."""
    grid=[]
    spans={}  # col -> [rows_remaining_after_current, text]
    for tr in table.find_all('tr'):
        row=[]; col=0
        cells=tr.find_all(['th','td'], recursive=False)
        ci=0
        while ci < len(cells) or spans:
            while col in spans:
                rem,text=spans[col]
                while len(row)<=col: row.append('')
                row[col]=text
                if rem<=1: del spans[col]
                else: spans[col]=[rem-1,text]
                col+=1
            if ci>=len(cells):
                # only remaining spans at larger columns
                if not spans: break
                next_col=min(spans)
                while col<next_col:
                    row.append(''); col+=1
                continue
            cell=cells[ci]; ci+=1
            text=' '.join(cell.stripped_strings)
            try: cs=max(1,int(cell.get('colspan',1)))
            except (TypeError,ValueError): cs=1
            try: rs=max(1,int(cell.get('rowspan',1)))
            except (TypeError,ValueError): rs=1
            for _ in range(cs):
                while col in spans:
                    rem,old=spans[col]
                    while len(row)<=col: row.append('')
                    row[col]=old
                    if rem<=1: del spans[col]
                    else: spans[col]=[rem-1,old]
                    col+=1
                while len(row)<=col: row.append('')
                row[col]=text
                if rs>1: spans[col]=[rs-1,text]
                col+=1
        grid.append(row)
    width=max((len(r) for r in grid),default=0)
    return [r+['']*(width-len(r)) for r in grid]

class OfficialCourseHistoryCollector:
    def __init__(self,db):
        self.db=db; self._thread=None; self._stop=threading.Event(); self._validation_reset_done=False
        self.status={'phase':'本日の出走表待ち','validation_mode':'峰竜太（4320）1人検証'}
    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,daemon=True,name='mine-course-history-validation'); self._thread.start()
    def _scheduler(self):
        while not self._stop.is_set():
            today=datetime.now(JST).strftime('%Y%m%d')
            try:self._run(today)
            except Exception as e:
                self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),'phase':'収集処理エラー','scheduler_error':f'{type(e).__name__}: {e}','validation_mode':'峰竜太（4320）1人検証'}
            self._stop.wait(10)
    def _reset_validation_racer(self,today):
        if self._validation_reset_done: return
        with self.db.connect() as con:
            # Validation only: remove this racer's old rows once so the collection flow is tested from a clean state.
            con.execute('DELETE FROM racer_course_runs WHERE registration_no=?',(VALIDATION_REG,))
            con.execute("""UPDATE course_history_target_state
                SET status='pending',cursor_date=?,floor_date=?,retry_count=0,failed_date=NULL,last_error=NULL,
                    started_at=NULL,completed_at=NULL,target_date=?,updated_at=CURRENT_TIMESTAMP
                WHERE registration_no=?""",
                ((datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d'),FLOOR,today,VALIDATION_REG))
        self._validation_reset_done=True
    def _counts(self,reg,jcd):
        with self.db.connect() as con:
            n=con.execute('SELECT course,COUNT(*) n FROM racer_course_runs WHERE registration_no=? AND date>=? GROUP BY course',(reg,FLOOR)).fetchall()
            l=con.execute('SELECT course,COUNT(*) n FROM racer_course_runs WHERE registration_no=? AND jcd=? AND date>=? GROUP BY course',(reg,jcd,FLOOR)).fetchall()
        return ({int(x['course']):min(10,int(x['n'])) for x in n},{int(x['course']):min(10,int(x['n'])) for x in l})
    def _done(self,nm,lm): return all(nm.get(c,0)>=10 and lm.get(c,0)>=10 for c in range(1,7))
    def _parse_year(self,html,year,reg):
        soup=BeautifulSoup(html,'html.parser'); out=[]
        for table in soup.find_all('table'):
            grid=_expand_table(table)
            if not grid: continue
            # One event table has one venue. Ignore title text that merely mentions venue names.
            jcd=None
            for row in grid:
                for c in row:
                    vc=_venue_code(c)
                    if vc: jcd=vc; break
                if jcd: break
            if not jcd: continue

            # Expanded colspan makes each race column inherit its MM/DD date.
            dates={}
            for row in grid:
                for col,c in enumerate(row):
                    d=_date_token(c,year)
                    if d: dates[col]=d

            for ri,row in enumerate(grid):
                race_cols={col:_race_token(c) for col,c in enumerate(row) if _race_token(c)}
                if not race_cols: continue
                # BoatFrontier yearly table contract:
                # race row -> actual course -> ST -> (ST rank) -> finish.
                if ri+4>=len(grid): continue
                course_row,st_row,rank_row,finish_row=grid[ri+1],grid[ri+2],grid[ri+3],grid[ri+4]
                for col,rno in race_cols.items():
                    date=dates.get(col)
                    if not date or date<FLOOR: continue
                    course=_course_token(course_row[col] if col<len(course_row) else '')
                    st=_st_token(st_row[col] if col<len(st_row) else '')
                    rank=_rank_token(rank_row[col] if col<len(rank_row) else '')
                    finish=_finish_token(finish_row[col] if col<len(finish_row) else '')
                    if not course or st is None or finish is None or finish=='欠': continue
                    out.append({'date':date,'jcd':jcd,'rno':rno,'registration_no':reg,'lane':None,
                                'course':course,'finish':finish,'st_raw':st,'st_rank':rank,
                                'source':f'racer-yearly:boatfrontier-grid-v3:{year}'})
        uniq={(x['date'],x['jcd'],x['rno']):x for x in out}
        return sorted(uniq.values(),key=lambda x:(x['date'],x['jcd'],x['rno']),reverse=True)
    def _fetch_year(self,reg,name,year,jcd):
        # Current year: prefer the live /allraces page, with /allraces/YYYY as fallback.
        # Past years: use /allraces/YYYY.  A wrong/blocked HTML page must never be
        # treated as a legitimate zero-run year.
        current_year=datetime.now(JST).year
        urls=([f'https://boatfrontier.jp/racer/{reg}/allraces'] if year==current_year else [])
        urls.append(f'https://boatfrontier.jp/racer/{reg}/allraces/{year}')
        # De-duplicate while preserving fallback order.
        urls=list(dict.fromkeys(urls))
        self.status.update({'phase':'選手別年データ取得中','crawl_stage':f'{name}（{reg}） {year}年 全出走データ取得中','scan_date':str(year),'crawl_jcd':jcd,'last_fetch_state':'fetching','last_fetch_error':None})
        s=requests.Session(); s.headers.update({
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language':'ja,en-US;q=0.9,en;q=0.8',
            'Referer':f'https://boatfrontier.jp/racer/{reg}',
            'Cache-Control':'no-cache',
        })
        errors=[]
        for url in urls:
            for attempt in range(1,4):
                try:
                    r=s.get(url,timeout=(5,20),allow_redirects=True); r.raise_for_status()
                    body=r.text or ''
                    rows=self._parse_year(body,year,reg)
                    # A valid racer/year page normally identifies both the racer and
                    # the requested year.  Do not silently convert a wrong/blocked
                    # HTML page into a legitimate 0-run result.
                    looks_like_year_page=(str(reg) in body and (f'{year}年' in body or f'>{year}<' in body))
                    if rows:
                        return rows,{'url':r.url,'http':r.status_code,'attempt':attempt,'parsed':len(rows)}
                    if looks_like_year_page:
                        # A verified historical year with no rows is a legitimate empty year.
                        # For the current year, a racer found in today's racelist cannot
                        # legitimately have zero parsed starts, so treat that as a parse/fetch error.
                        if year < current_year:
                            return [],{'url':r.url,'http':r.status_code,'attempt':attempt,'parsed':0,'verified_empty':True}
                        raise RuntimeError(f'{year}年ページ取得成功だが出走表解析0件: {r.url}')
                    raise RuntimeError(f'年別全出走ページではないHTMLを取得: {r.url}')
                except Exception as e:
                    err=f'{type(e).__name__}: {e}'
                    errors.append(f'{url} attempt{attempt}: {err}')
                    self.status.update({'last_fetch_error':err,'last_fetch_state':f'retry {attempt}/3','direct_source':url})
                    if attempt<3:self._stop.wait(2)
        raise RuntimeError(' / '.join(errors[-4:]) or f'{year}年データ取得失敗')
    def _run(self,today):
        # Validation build: never enqueue or process anyone except 4320.
        self.db.ensure_course_history_today_targets(today,(datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d'),FLOOR,only_registration_no=VALIDATION_REG)
        self._reset_validation_racer(today)
        # Re-run target creation after reset in case 4320 target row was absent before today's racelist arrived.
        self.db.ensure_course_history_today_targets(today,(datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d'),FLOOR,only_registration_no=VALIDATION_REG)
        pending=self.db.get_course_history_pending_targets(today,only_registration_no=VALIDATION_REG)
        if not pending:
            st=self.db.get_course_history_target_status(today,VALIDATION_REG)
            phase='峰竜太（4320）が本日の出走表に未検出' if int(st.get('total_targets') or 0)==0 else '峰竜太（4320）検証履歴完了'
            self.status={**st,'phase':phase,'validation_mode':'峰竜太（4320）1人検証'}; return
        t=pending[0]; reg=str(t['registration_no']); jcd=str(t['jcd']).zfill(2); name=str(t.get('name') or reg)
        nm,lm=self._counts(reg,jcd)
        if self._done(nm,lm): self.db.complete_course_history_targets([(reg,jcd)]); return
        total=0; checked=[]; lastdiag={}; reached_floor=False
        try:
            for year in range(datetime.now(JST).year,FLOOR_YEAR-1,-1):
                nm,lm=self._counts(reg,jcd)
                if self._done(nm,lm): break
                rows,lastdiag=self._fetch_year(reg,name,year,jcd); checked.append(year)
                useful=[]
                for x in rows:
                    c=int(x['course'])
                    # National needs newest 10 regardless of venue. Local needs only today's venue.
                    if nm.get(c,0)<10 or (x['jcd']==jcd and lm.get(c,0)<10): useful.append(x)
                if useful:
                    self.db.save_course_history_runs(useful,keep_per_local_course=10); total+=len(useful)
                nm,lm=self._counts(reg,jcd)
            reached_floor=bool(checked and checked[-1]==FLOOR_YEAR)
            nm,lm=self._counts(reg,jcd)
            if self._done(nm,lm) or reached_floor: self.db.complete_course_history_targets([(reg,jcd)])
            self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),'phase':f'{name} 検証データ確認完了' if (self._done(nm,lm) or reached_floor) else '選手別年データ保存中','validation_mode':'峰竜太（4320）1人検証','current_racer':name,'current_registration_no':reg,'local_jcd':jcd,'last_fetch_state':'ok','last_parsed_rows':total,'last_matched_rows':total,'last_fetch_date':today,'crawl_stage':f'{reg}本人→年別全出走→全国/当地（確認年 {checked}）','national_counts':nm,'local_counts':lm,'checked_years':checked,'floor_reached':reached_floor,'direct_source':lastdiag.get('url'),'note':'v17.198検証版。4320のみ再取得。今日の出走表から当地を1場だけ特定し、選手本人の年別全出走ページだけを取得。24場・日付巡回はしない。各全国/当地コースは最新10走で打切り、不足時のみ2023年まで。2023年到達後の不足・0走は正常完了。'}
        except Exception as e:
            self.db.mark_course_history_target_errors([(reg,jcd)],str(self.status.get('scan_date') or ''),f'{type(e).__name__}: {e}',3)
            self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),'phase':'峰竜太の収集エラー','validation_mode':'峰竜太（4320）1人検証','current_racer':name,'current_registration_no':reg,'scheduler_error':f'{type(e).__name__}: {e}'}
