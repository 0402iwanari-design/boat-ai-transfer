# v17.317 Statistical AI experimental module: validation

## Base

The **only** source code base is the user-uploaded file `RACEPO_v17_316_Result_Triggered_Instant_Final_Stats(1).zip` (173 members). This is not the older handoff archive. All unchanged original members are byte identical. No VPS, GitHub, live domain, or installed DB modified.

## Added

- `statistical_ai.py`: manual importer (read-only original DB / opt-in historical CSV), separate research SQLite database, strict 6-finisher and payout checks, venue features, formation and 120 single-combo calculations, condition discovery and date-split backtesting.
- `pattern_ai_admin.html`: admin-only saved report UI (24 venues, two-way first-place pair rates, all 120 trifecta stats, research candidates).
- `test_statistical_ai_v17317.py`: deterministic isolated tests.
- `統計AI_使い方_v17_317.md`: usage / limitations / next steps.
- `app.py`: appended two secured read-only routes only. No existing routes changed.

## Checks

- `python -m unittest test_statistical_ai_v17317` — 10/10 passed.
- `python -m unittest test_statistics_refresh_v17316 test_statistics_finalization_v315 test_v17314 test_statistical_ai_v17317` — 20/20 passed.
- `python -m py_compile statistical_ai.py app.py` — passed.
- `from app import app` — passed (85 routes).
- Unauthenticated GET `/admin/statistical-ai` — 401.
- Unauthenticated GET `/api/admin/statistical-ai/report?venue=12` — 401.
- Verified `1-23-234` expands to exactly 4 tickets, with whole-group stake and payout accounting. Invalid result/payout combinations excluded. Missing/too-small samples generate no claimed candidates. SQLite UTC capture compared with JST deadline.
- Unit fixtures are synthetic (explicitly not measured BOAT RACE performance).

## Not performed / caveats

- No large-scale real historical CSV collection or official archive backfill (network access to the CSV host unavailable in this build environment); no real winning-rate or ROI claims.
- No always-on scheduler, ML model weight fitting, automatic purchase or automatic adoption by the production predictor.
- Date-split retrospective validation is not true future validation; many tested hypotheses can still overfit. Research-only labels are intentional.
- Tide details, 3T pre-close odds, late scratches/refunds/ties, complete data rights checks and live performance benchmarking remain future tasks.
