import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from db import BoatDB
from daily_data_audit import audit_day


class DailyAuditTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = BoatDB(str(Path(self.temp.name) / 'test.db'))
        self.now = datetime(2026, 11, 9, 23, 0, tzinfo=ZoneInfo('Asia/Tokyo'))
        self.db.save_race_schedule('20261108', '12', [{'rno': 1, 'deadline': '11:00'}, {'rno': 2, 'deadline': '11:30'}])

    def tearDown(self):
        self.temp.cleanup()

    def test_missing_is_reported(self):
        self.db.save_snapshot('20261108', '12', 1, 'racelist', {'racers': [{'lane': n} for n in range(1, 7)]})
        data = audit_day(self.db, '20261108', self.now)
        self.assertEqual(data['venue_count'], 1)
        self.assertEqual(data['venues'][0]['fields']['racelist']['missing_races'], [2])
        self.assertEqual(data['venues'][0]['fields']['result']['missing_races'], [1, 2])
        self.assertEqual(data['venues'][0]['status'], 'incomplete')

    def test_all_evidence_saved(self):
        for n in (1, 2):
            self.db.save_snapshot('20261108', '12', n, 'racelist', {'racers': [{'lane': i} for i in range(1, 7)]})
            self.db.save_snapshot('20261108', '12', n, 'beforeinfo', {'weather': {'wind_speed': 3}})
            self.db.save_snapshot('20261108', '12', n, 'odds3t', {'odds': [{}] * 120})
        self.db.save_results('20261108', '12', [{'rno': n, 'trifecta': '1-2-3', 'payout_yen': 320, 'payload': {'ok': True}} for n in (1,2)])
        data = audit_day(self.db, '20261108', self.now)
        self.assertEqual(data['venues'][0]['status'], 'complete')
        self.assertEqual(data['field_totals']['result'], 2)

    def test_unrecorded_day_not_assumed_complete(self):
        self.assertEqual(audit_day(self.db, '20261107', self.now)['status'], 'no_data')

    def test_future_rejected(self):
        with self.assertRaises(ValueError):
            audit_day(self.db, '20261110', self.now)


if __name__ == '__main__':
    unittest.main()
