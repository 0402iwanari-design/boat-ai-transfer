v17.325: Daily audit mobile visual-only revision. Dark date-picker input; compact status cards with progress, expandable record details. Data query and audit computations unchanged.
