import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from statistics_snapshot_cache import (read_final_snapshot, read_snapshot,
                                       save_snapshot, fingerprint)
from statistics_refresh_worker import refresh


class StatisticsRefreshTests(unittest.TestCase):
    def test_final_snapshot_is_available_after_restart_without_db(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'boat.db'
            db.write_bytes(b'fake database')
            fp = fingerprint(db)
            self.assertTrue(save_snapshot(db, '20261107', {'total': 17}, fp, finalized=True))
            db.unlink()
            self.assertEqual(read_final_snapshot(db, '20261107'), {'total': 17})

    def test_active_snapshot_rejects_new_database_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'boat.db'
            db.write_bytes(b'first')
            self.assertTrue(save_snapshot(db, '20261108', {'total': 1}, fingerprint(db)))
            self.assertEqual(read_snapshot(db, '20261108', float('inf')), {'total': 1})
            db.write_bytes(b'second update')
            self.assertIsNone(read_snapshot(db, '20261108', float('inf')))

    def test_final_snapshot_cannot_be_overwritten_by_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'boat.db'
            db.write_bytes(b'first')
            save_snapshot(db, '20261107', {'total': 3}, fingerprint(db), finalized=True)
            class FakeDB:
                path = db
            with patch('review_statistics.build_statistics', side_effect=AssertionError('recomputed')):
                self.assertTrue(refresh(FakeDB(), None, '20261107'))
            self.assertEqual(read_final_snapshot(db, '20261107'), {'total': 3})

    def test_refresh_marks_completed_day_final(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'boat.db'
            db.write_bytes(b'first')
            class FakeDB:
                path = db
            with patch('review_statistics.build_statistics', return_value={'hit': 50}), \
                 patch('statistics_snapshot_cache.results_finalized', return_value=True):
                self.assertTrue(refresh(FakeDB(), None, '20261107'))
            self.assertEqual(read_final_snapshot(db, '20261107'), {'hit': 50})


if __name__ == '__main__':
    unittest.main()
