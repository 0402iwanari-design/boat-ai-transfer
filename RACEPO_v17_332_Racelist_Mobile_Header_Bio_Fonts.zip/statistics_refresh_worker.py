"""Refresh statistics after official results/prediction writes, never on page opens.

Single daemon coalesces bursts. A failed refresh is retried by a later write or
first read; it never interrupts official result collection.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime, timedelta, timezone

_lock = threading.Lock()
_pending = set()
_wakeup = threading.Event()
_worker = None
_database = None
_venues = None


def configure(db, venues):
    global _database, _venues
    with _lock:
        _database, _venues = db, venues


def notify(date):
    global _worker
    with _lock:
        if _database is None:
            return
        _pending.add(str(date))
        if _worker is None or not _worker.is_alive():
            _worker = threading.Thread(target=_run, name='racepo-statistics-refresh', daemon=True)
            _worker.start()
    _wakeup.set()


def refresh(db, venues, date):
    from review_statistics import build_statistics
    from statistics_snapshot_cache import (fingerprint, save_snapshot,
                                           read_final_snapshot, results_finalized)
    path = db.path
    if read_final_snapshot(path, date) is not None:
        return True  # Intentionally immutable after the official card is complete.
    before = fingerprint(path)
    today = datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d')
    finalized = results_finalized(db, date, today)
    result = build_statistics(db, date, venues)
    return save_snapshot(path, date, result, before, finalized=finalized)


def _run():
    while True:
        _wakeup.wait()
        _wakeup.clear()
        # Collect multiple official updates into one aggregation.
        time.sleep(0.4)
        with _lock:
            dates = sorted(_pending)
            _pending.clear()
            db, venues = _database, _venues
        for date in dates:
            try:
                refresh(db, venues, date)
            except Exception as exc:
                print(f'[STATISTICS] refresh failed date={date}: {exc}', flush=True)
