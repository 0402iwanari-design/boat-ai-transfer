import tempfile
import time
import unittest
from pathlib import Path
from statistics_snapshot_cache import fingerprint, read_snapshot, save_snapshot

class SnapshotTests(unittest.TestCase):
    def test_persist_and_invalidate(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'test.db';db.write_bytes(b'first')
            fp=fingerprint(db)
            self.assertTrue(save_snapshot(db,'20261107',{'value':123},fp))
            self.assertEqual(read_snapshot(db,'20261107',86400),{'value':123})
            self.assertIsNone(read_snapshot(db,'20261107',-1))
            db.write_bytes(b'second long')
            self.assertIsNone(read_snapshot(db,'20261107',86400))
    def test_reject_change_during_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'test.db';db.write_bytes(b'a')
            before=fingerprint(db);db.write_bytes(b'changed')
            self.assertFalse(save_snapshot(db,'20261107',{},before))
    def test_wal_change_invalidates(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'test.db';db.write_bytes(b'a')
            before=fingerprint(db)
            self.assertTrue(save_snapshot(db,'20261107',{'ok':True},before))
            Path(str(db)+'-wal').write_bytes(b'wal changed')
            self.assertIsNone(read_snapshot(db,'20261107',86400))

if __name__=='__main__':unittest.main()
