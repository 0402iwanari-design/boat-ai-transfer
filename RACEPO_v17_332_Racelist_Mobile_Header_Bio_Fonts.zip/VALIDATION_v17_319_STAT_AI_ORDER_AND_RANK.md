# v17.319 - Statistical AI venue ordering and comparative ranking

## Changes
- Venue dropdown is created by an explicit numeric for-loop from 01 Kiryu through 24 Omura. Zero padded keys previously enumerated 10-24 before 01-09 in JavaScript.
- Owner-only statistics tab now has a color-coded comparison ranking using **existing saved report data only**. This displays training and validation rates and ROI side-by-side, with race count and per-row conditions. It sorts on training ROI, not on validation ROI, and shows at most ten rows.
- No invented statistics or external video numbers were included; a venue without analyzed data displays a no-candidates message.
- App APIs, existing AI prediction, collector, research engine and hosting files remain unchanged.

## Important
- Training vs validation is a time-based split; it is **not** a 1-year vs 2-year comparison.
- Candidate discovery and selection previously depend on validation ROI; this report is descriptive and **not independent prospective evidence**.
- Site/VPS/GitHub are not modified.

## Tests conducted
- `python -m py_compile app.py statistical_ai.py`: PASS
- `python -m unittest test_statistical_ai_v17317 test_statistics_refresh_v17316 test_statistics_finalization_v315 test_v17314 -q`: 20/20 PASS
- Extracted main inline JavaScript `node --check`: PASS
- Node-based DOM behavior test: 24 choices numbered 01..24, ranking order, numeric presentation, formation badges, and empty data states: PASS
- Attempted Chromium/Playwright smoke test, but browser navigation is blocked by the environment (`ERR_BLOCKED_BY_ADMINISTRATOR`) even for localhost and file://. Full visual browser validation is therefore NOT COMPLETE.
- No real historical statistics were imported; screenshots or test fixtures must not be mistaken for measured results.
