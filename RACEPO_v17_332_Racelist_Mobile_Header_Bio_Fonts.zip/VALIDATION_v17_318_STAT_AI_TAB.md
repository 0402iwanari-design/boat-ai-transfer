# RACEPO v17.318 統計AI タブ統合 — 検証結果

## 変更範囲

- `static/index.html`: 管理者限定の左メニュー「統計AI」と画面内部の一覧（24場選択、1-2〜1-6、3連単120通り、複合条件候補）を追加。既存の v17.317 API を読み取り専用で呼び出す。
- `static/racepo-stat-ai-tab-v17318.css`: PC/スマホ対応の表示と、管理者メニューが CSS の競合で未ログイン時に表示される問題を抑止。
- `統計AI_使い方_v17_317.md`: タブ操作説明を追記。
- `app.py`, `statistical_ai.py`, 既存予想・収集処理、運用環境は変更なし。

## 確認

- `python -m py_compile app.py statistical_ai.py` — 成功。
- `python -m unittest test_statistical_ai_v17317 test_statistics_refresh_v17316 test_statistics_finalization_v315 test_v17314 -q` — 20/20 成功。
- 抽出したメインインライン JavaScript の `node --check` — 成功。
- Chromium + Playwright で外部/APIデータをモックした画面操作テスト — PC/スマホとも成功。
  - 未ログイン時のメニュー非表示
  - ログイン時のメニュー表示とタブ切り替え
  - 24場切替、統計有り/未集計の切替、各一覧の数値表示
  - ログアウト後の非表示
  - PC / スマホのレイアウト確認
- 画面操作テストで表示した値はテスト用架空データであり、実際の住之江の統計ではない。

## 未実施・注意

- 本番DBに存在する実際のレポートとの照合と、本番環境での速度測定は未実施。
- 研究DBに過去の結果を取り込む操作は実施していない。
- 研究レポートは過去データの学習・検証期間分割にすぎず、将来の収益・予想精度は保証しない。
- 公開サイト、VPS、GitHub への変更は行っていない。
