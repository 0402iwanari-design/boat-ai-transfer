"""v17.322 regression: explicit imports, integrity, status, new filter dimensions."""
from datetime import date, timedelta
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from statistical_ai import (Store, feature_map, import_csv_day,
                            filtered_venue_comparisons)
from statistical_ai_jobs import ResearchImportManager, validated_dates


def sample_streams(day, venue='12', race_no=9, payout=1800):
    code=day.replace('-','')+venue+f'{race_no:02d}'
    result={'レースコード':code,'締切時刻':'19:20'}
    result.update({f'{i}着_艇番':str(i) for i in range(1,7)})
    return {
      'results/realtime':[result],
      'results/payouts':[{'レースコード':code,'3連単_組番':'1-2-3','3連単_払戻金':str(payout)}],
      'programs/race_cards':[{'レースコード':code,'艇1_級別':'A1','艇2_級別':'B1',
                               '艇1_全国平均ST':'0.12'}],
      'programs/title':[{'レースコード':code,'グレード':'G1'}],
      'previews/sui':[{'レースコード':code,'レース日':day,
                       '取得日時':f'{day}T19:11:00+09:00',
                       '風向':'北','風速(m)':'3','波の高さ(cm)':'2'}]
    }


class RealResearchImportTests(unittest.TestCase):
    def test_date_bounds(self):
        self.assertEqual(validated_dates('2026-04-01','2026-04-30',today=date(2026,11,9)),
                         (date(2026,4,1),date(2026,4,30)))
        with self.assertRaises(ValueError):
            validated_dates('2026-11-09','2026-11-09',today=date(2026,11,9))
        with self.assertRaises(ValueError):
            validated_dates('2025-01-01','2026-10-30',today=date(2026,11,9))
        with self.assertRaises(ValueError):
            validated_dates('2025-11-01','2025-10-01',today=date(2026,11,9))

    def test_manual_web_import_persists_real_entries_and_separates_venues(self):
        with TemporaryDirectory() as tmp:
            source_calls=[]; analyzed=[]
            def fake_downloader(day):
                source_calls.append(day)
                if day == '2026-05-02': return {}, {'results/realtime':'not_found'}
                return sample_streams(day),{}
            manager=ResearchImportManager(Path(tmp)/'research.db',
                downloader=fake_downloader, analyzer=lambda store,venue: analyzed.append(venue),
                pause_seconds=0)
            manager.start('web','2026-05-01','2026-05-03')
            manager._thread.join(timeout=10)
            result=manager.status()
            self.assertEqual(result['state'],'finished', result)
            self.assertEqual(result['total_records'],2)
            self.assertEqual(result['venue_counts']['12'],2)
            self.assertEqual(result['venue_counts']['11'],0)
            self.assertEqual(result['completed_days'],3)
            self.assertEqual(result['missing_days'],1)
            self.assertEqual(result['imported_rows'],2)
            self.assertEqual(analyzed,['12'])
            rows=Store(Path(tmp)/'research.db').read_venue('12')
            self.assertEqual(rows[0]['combo'],'1-2-3')
            self.assertEqual(rows[0]['payout_yen'],1800)
            self.assertEqual(rows[0]['features']['wind_speed'],'2-3')
            self.assertEqual(rows[0]['features']['wave'],'0-2')
            self.assertEqual(source_calls,['2026-05-01','2026-05-02','2026-05-03'])
            manager.start('web','2026-05-01','2026-05-03')
            manager._thread.join(timeout=10)
            self.assertEqual(manager.status()['total_records'],2)  # idempotent

    def test_pre_close_guard_and_bad_payout(self):
        with TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'research.db')
            data=sample_streams('2026-06-01')
            data['previews/sui'][0]['取得日時']='2026-06-01T19:30:00+09:00'
            self.assertEqual(import_csv_day(store,'2026-06-01',data)['imported'],1)
            self.assertNotIn('wind_speed',store.read_venue('12')[0]['features'])
            bad=sample_streams('2026-06-02')
            bad['results/payouts'][0]['3連単_組番']='2-1-3'
            self.assertEqual(import_csv_day(store,'2026-06-02',bad)['imported'],0)

    def test_new_conditions_and_custom_formation_with_stake_and_payout(self):
        with TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'research.db')
            base=date(2026,1,1)
            data=[]
            for i in range(130):
                day=(base+timedelta(days=i)).isoformat()
                features=feature_map(day,9,clock='19:10',grade='G1',
                                     wind_speed=2,wave=2,racers={1:{'class':'A1'},2:{'class':'B1'}})
                data.append({'key':day.replace('-','')+'1209','day':day,'venue':'12',
                  'rno':9,'combo':'1-2-3' if i%3 else '2-1-3','payout_yen':2400,
                  'features':json.dumps(features),'source':'fixture'})
            store.upsert(data)
            res=filtered_venue_comparisons(store,'12',
               {'grade':'G1','hour_band':'night','lane1_class':'A1','lane2_class':'B1','race_no':'9'},
               custom_formation='1-23-234')
            self.assertEqual(res['matching_races'],130)
            # Same as a fixed formation; not duplicated in results.
            self.assertEqual(len(res['comparisons']),8)
            custom=filtered_venue_comparisons(store,'12',{'grade':'G1'},
                                              custom_formation='2-1-3')
            self.assertEqual(len(custom['comparisons']),9)
            matching=next(x for x in custom['comparisons'] if x['formation']=='指定：2-1-3')
            self.assertEqual(matching['train']['total_stake_yen'],matching['train']['races']*100)
            self.assertEqual(matching['validation']['total_stake_yen'],matching['validation']['races']*100)
            self.assertEqual(matching['train']['total_payout_yen'],matching['train']['hits']*2400)
            with self.assertRaises(ValueError):
                filtered_venue_comparisons(store,'12',{},custom_formation='1-1-3')
            with self.assertRaises(ValueError):
                filtered_venue_comparisons(store,'12',{'month':'13'})

    def test_status_restores_interrupted_job(self):
        with TemporaryDirectory() as tmp:
            status=Path(tmp)/'status.json'
            status.write_text(json.dumps({'job_id':'old','state':'running','completed_days':2,
                                           'total_days':20}),encoding='utf-8')
            mgr=ResearchImportManager(Path(tmp)/'research.db',status_path=status)
            self.assertEqual(mgr.status()['state'],'interrupted')


if __name__=='__main__': unittest.main(verbosity=2)
