"""Best-effort, atomic, disk-backed statistics response snapshots.

The DB/WAL fingerprint prevents serving snapshots after database writes.  This
is intentionally conservative: unrelated writes can cause recomputation, but
never justify serving an outdated statistics snapshot.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import time


def fingerprint(db_path):
    base = Path(db_path)
    signature = []
    for path in (base, Path(str(base) + '-wal')):
        try:
            stat = path.stat()
            signature.append([str(path), stat.st_size, stat.st_mtime_ns])
        except FileNotFoundError:
            signature.append([str(path), None, None])
    return signature


def cache_file(db_path, date):
    base = Path(db_path)
    identity = hashlib.sha256(str(base.resolve()).encode()).hexdigest()[:16]
    return base.parent / '.racepo_statistics_cache' / f'{identity}_{date}.json'


def read_snapshot(db_path, date, ttl_seconds, finalized=False):
    path = cache_file(db_path, date)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('version') != 1 or data.get('date') != date:
            return None
        if finalized and not data.get('finalized'):
            return None
        if not finalized and time.time() - float(data['saved_at']) >= ttl_seconds:
            return None
        if not finalized and data['fingerprint'] != fingerprint(db_path):
            return None
        return data['payload']
    except (OSError, ValueError, KeyError, TypeError):
        return None


def read_final_snapshot(db_path, date):
    """Fast path: a finalized result is immutable; no DB inspection required."""
    path = cache_file(db_path, date)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('version') == 1 and data.get('date') == date and data.get('finalized') is True:
            return data['payload']
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return None


def save_snapshot(db_path, date, payload, before, finalized=False):
    if before != fingerprint(db_path):
        return False  # Data changed while calculating: never persist a stale result.
    path = cache_file(db_path, date)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp = tempfile.mkstemp(prefix='.pending_', suffix='.json', dir=path.parent)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as out:
                json.dump({'version': 1, 'date': date, 'saved_at': time.time(),
                           'fingerprint': before, 'finalized': bool(finalized), 'payload': payload}, out,
                          ensure_ascii=False, separators=(',', ':'))
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
        return True
    except OSError:
        return False  # Read-only installation: calculations still work.


def results_finalized(db, date, today):
    """Freeze only a complete day's official race card, never a partial feed.

    A complete schedule has twelve races per participating venue and every
    scheduled race has both a valid trifecta and payout.  Future dates are
    never frozen. Missing schedules remain live rather than freezing early.
    """
    if date > today:
        return False
    try:
        with db.connect() as con:
            schedules = con.execute(
                "SELECT jcd,rno FROM race_schedule WHERE date=?", (date,)
            ).fetchall()
            if not schedules:
                return False
            per_venue = {}
            expected = set()
            for row in schedules:
                venue = str(row['jcd']).zfill(2)
                per_venue[venue] = per_venue.get(venue, 0) + 1
                expected.add((venue, int(row['rno'])))
            if any(n != 12 for n in per_venue.values()):
                return False
            actual = con.execute(
                "SELECT jcd,rno,trifecta,payout_yen FROM race_results WHERE date=?",
                (date,),
            ).fetchall()
            completed = {(str(r['jcd']).zfill(2), int(r['rno'])) for r in actual
                         if r['trifecta'] and r['payout_yen'] is not None}
            return expected <= completed
    except (OSError, ValueError):
        return False
