import sqlite3
import tempfile
import unittest
from pathlib import Path
from statistics_snapshot_cache import results_finalized, fingerprint, read_snapshot, save_snapshot

class DB:
    def __init__(self, path): self.path = str(path)
    def connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

class FinalizationTest(unittest.TestCase):
    def test_requires_complete_schedule_and_results(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = DB(Path(tmp)/'test.db')
            with db.connect() as con:
                con.execute('CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER)')
                con.execute('CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER)')
                for i in range(1,12):
                    con.execute('INSERT INTO race_schedule VALUES(?,?,?)',('20261108','01',i))
                    con.execute('INSERT INTO race_results VALUES(?,?,?,?,?)',('20261108','01',i,'1-2-3',1000))
            self.assertFalse(results_finalized(db,'20261108','20261108'))
            with db.connect() as con:
                con.execute('INSERT INTO race_schedule VALUES(?,?,?)',('20261108','01',12))
            self.assertFalse(results_finalized(db,'20261108','20261108'))
            with db.connect() as con:
                con.execute('INSERT INTO race_results VALUES(?,?,?,?,?)',('20261108','01',12,'1-2-3',1000))
            self.assertTrue(results_finalized(db,'20261108','20261108'))
            self.assertFalse(results_finalized(db,'20261108','20261107'))
    def test_final_snapshot_ignores_age_and_unrelated_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'test.db'; db.write_bytes(b'old')
            fp=fingerprint(db)
            self.assertTrue(save_snapshot(db,'20261108',{'rate':42},fp,finalized=True))
            db.write_bytes(b'new')
            self.assertEqual(read_snapshot(db,'20261108',0,finalized=True),{'rate':42})
            self.assertIsNone(read_snapshot(db,'20261108',0,finalized=False))
    def test_active_snapshot_invalidated_on_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            db=Path(tmp)/'test.db'; db.write_bytes(b'old')
            fp=fingerprint(db)
            self.assertTrue(save_snapshot(db,'20261108',{'rate':42},fp))
            self.assertEqual(read_snapshot(db,'20261108',3600),{'rate':42})
            db.write_bytes(b'changed')
            self.assertIsNone(read_snapshot(db,'20261108',3600))
            self.assertIsNone(read_snapshot(db,'20261108',3600,finalized=True))
if __name__ == '__main__': unittest.main()
