"""Explicit, admin-triggered research data imports for Statistical AI.

No import is started on application boot. Writes ONLY the separate research
SQLite DB and a progress JSON file; never touches the live prediction tables.
Web mode fetches the public BoatraceCSV dataset; local mode reads the live DB
with SQLite mode=ro (no migrations). No user-controlled URL or DB path.
"""
from __future__ import annotations

from collections import Counter
from datetime import date, datetime, timedelta, timezone
import json
import os
from pathlib import Path
from threading import Event, Lock, Thread
import time
import uuid

from statistical_ai import (Store, REQUIRED, VENUES, analyze_venue,
                            default_store, fetch_day, import_csv_day, import_local_db)

JST = timezone(timedelta(hours=9))
MAX_RANGE_DAYS = 366


def local_db_path():
    return Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'BOAT_AI_Lab' / 'boat_ai.db'


def validated_dates(start, end, today=None):
    """No future or today-incomplete results, bounded one-year task."""
    try:
        a, b = date.fromisoformat(start), date.fromisoformat(end)
    except (ValueError, TypeError) as exc:
        raise ValueError('開始日・終了日は YYYY-MM-DD で指定してください') from exc
    today = today or datetime.now(JST).date()
    if a < date(2020, 1, 1) or b < a or b >= today:
        raise ValueError('2020年以降の過去日を、開始日≦終了日で指定してください（当日・未来不可）')
    if (b - a).days + 1 > MAX_RANGE_DAYS:
        raise ValueError('1回の対象期間は最大366日です。期間を分けて取り込んでください')
    return a, b


class ResearchImportManager:
    def __init__(self, db_path=None, status_path=None, downloader=None, local_reader=None,
                 analyzer=None, pause_seconds=0.3):
        self.db_path = Path(db_path or default_store())
        self.status_path = Path(status_path or self.db_path.with_name('statistical_ai_import_status.json'))
        self.downloader = downloader or fetch_day
        self.local_reader = local_reader or import_local_db
        self.analyzer = analyzer or analyze_venue
        self.pause_seconds = pause_seconds
        self._lock = Lock()
        self._stop = Event()
        self._thread = None
        self._state = {'state': 'idle', 'mode': None, 'completed_days': 0,
                       'total_days': 0, 'imported_rows': 0}
        try:
            state = json.loads(self.status_path.read_text(encoding='utf-8'))
            if isinstance(state, dict):
                if state.get('state') in ('running', 'analyzing', 'cancelling'):
                    state['state'] = 'interrupted'
                    state['message'] = 'サーバーの停止などで中断しました。再取得は重複しないため再実行できます。'
                self._state.update(state)
        except (OSError, ValueError, TypeError):
            pass

    def _snapshot(self):
        with self._lock:
            return dict(self._state)

    def status(self):
        state = self._snapshot()
        # Display counts from the separate research DB only. Reading never creates it.
        per_venue = {v: 0 for v in sorted(VENUES)}
        if self.db_path.is_file():
            import sqlite3
            try:
                con = sqlite3.connect(f'file:{self.db_path.resolve().as_posix()}?mode=ro', uri=True, timeout=3)
                try:
                    for venue, count in con.execute('SELECT venue, COUNT(*) FROM pattern_races GROUP BY venue'):
                        if venue in per_venue: per_venue[venue] = count
                finally:
                    con.close()
            except (OSError, sqlite3.Error):
                state['count_error'] = '研究DBの件数を確認できませんでした'
        state['venue_counts'] = per_venue
        state['total_records'] = sum(per_venue.values())
        return state

    def _set(self, **updates):
        # Keep the state + atomic file write serialized: cancel and worker can
        # otherwise attempt to replace the same temporary file concurrently.
        with self._lock:
            self._state.update(updates)
            snapshot = dict(self._state)
            self.status_path.parent.mkdir(parents=True, exist_ok=True)
            path = self.status_path.with_name(self.status_path.name + '.' + snapshot['job_id'] + '.tmp')
            path.write_text(json.dumps(snapshot, ensure_ascii=False), encoding='utf-8')
            os.replace(path, self.status_path)

    def start(self, mode, start=None, end=None):
        if mode not in ('web', 'local'):
            raise ValueError('取得方法は web または local を指定してください')
        if mode == 'web':
            first, last = validated_dates(start, end)
            total_days = (last - first).days + 1
        else:
            first = last = None
            total_days = 1
            if not local_db_path().is_file():
                raise ValueError('既存のレースポDBが見つかりません。公開CSVからの取得を選んでください')
        with self._lock:
            if self._state.get('state') in ('running', 'analyzing', 'cancelling') or (self._thread is not None and self._thread.is_alive()):
                raise RuntimeError('別の統計AI取り込み処理が実行中です')
            self._stop.clear()
            self._state = {
                'job_id': uuid.uuid4().hex, 'state': 'running', 'mode': mode,
                'from_date': first.isoformat() if first else None,
                'to_date': last.isoformat() if last else None,
                'total_days': total_days, 'completed_days': 0,
                'imported_rows': 0, 'missing_days': 0, 'skipped_rows': {},
                'last_day': None, 'last_error': None,
                'started_at': datetime.now(JST).isoformat(timespec='seconds'),
                'finished_at': None,
                'message': '既存DBを読み取り中' if mode == 'local' else '公開CSVを日付順に取得中',
            }
            # Need not retain sensitive logs or source data in the progress file.
            state = dict(self._state)
            worker = Thread(target=self._run, args=(mode, first, last), daemon=True,
                            name='RACEPO-StatisticalAI-ExplicitImport')
            self._thread = worker
        self._set(**state)
        worker.start()
        return self._snapshot()

    def cancel(self):
        with self._lock:
            if self._thread is None or not self._thread.is_alive() or self._state.get('state') not in ('running', 'analyzing', 'cancelling'):
                return self._state.copy()
            self._stop.set()
        self._set(state='cancelling', message='現在の1日分が終了したら中断します')
        return self._snapshot()

    def _run(self, mode, first, last):
        changed = set()
        skipped = Counter()
        imported = 0
        completed = 0
        missing_days = 0
        try:
            store = Store(self.db_path)
            if mode == 'local':
                result = self.local_reader(store, local_db_path())
                imported += result.get('imported', 0)
                skipped.update(result.get('skipped', {}))
                completed = 1
                # A local import can affect all venues, including updates to old rows.
                changed.update(VENUES)
                self._set(imported_rows=imported, completed_days=1, skipped_rows=dict(skipped))
            else:
                day = first
                while day <= last:
                    if self._stop.is_set():
                        break
                    day_str = day.isoformat()
                    try:
                        rows, errors = self.downloader(day_str)
                        if all(rows.get(k) for k in REQUIRED):
                            result = import_csv_day(store, day_str, rows)
                            imported += result['imported']
                            skipped.update(result['skipped'])
                            for venue in VENUES:
                                if any(row.get('レースコード', '')[8:10] == venue
                                       for row in rows['results/realtime']):
                                    changed.add(venue)
                        else:
                            missing_days += 1
                            skipped['required_csv_not_available'] += 1
                    except Exception as exc:
                        missing_days += 1
                        skipped['download_or_import_error'] += 1
                        self._set(last_error=f'{day_str}: {type(exc).__name__}')
                    completed += 1
                    self._set(last_day=day_str, completed_days=completed,
                              imported_rows=imported, missing_days=missing_days,
                              skipped_rows=dict(skipped))
                    if self._stop.wait(self.pause_seconds):
                        break
                    day += timedelta(days=1)
            if self._stop.is_set():
                self._set(state='cancelled', message='中断しました。取得済みデータは保存されています。')
                return
            # Research-only reports refresh after import; filtered stats read the DB directly.
            self._set(state='analyzing', message='取り込み済みデータを場別に分析中')
            failed_venues = []
            for venue in sorted(changed):
                if self._stop.is_set():
                    break
                try:
                    self.analyzer(store, venue)
                except Exception as exc:
                    failed_venues.append(f'{venue}:{type(exc).__name__}')
            if self._stop.is_set():
                self._set(state='cancelled', message='取り込み済みデータは保存されています。')
            else:
                message = '取得・分析が完了しました。条件を指定して集計してください。'
                if missing_days:
                    message += f' 未取得の日付が{missing_days}日あります。'
                if failed_venues:
                    message += f' 分析に失敗した場が{len(failed_venues)}場あります。'
                self._set(state='finished', message=message, analyze_errors=failed_venues[:24])
        except Exception as exc:
            self._set(state='error', last_error=type(exc).__name__, message='取得・分析が失敗しました。入力と実行ログを確認してください。')
        finally:
            self._set(finished_at=datetime.now(JST).isoformat(timespec='seconds'))


_import_manager = None
_manager_lock = Lock()


def get_import_manager():
    global _import_manager
    with _manager_lock:
        if _import_manager is None:
            _import_manager = ResearchImportManager()
        return _import_manager
