# v17.322 検証記録

- 起点: `RACEPO_v17_321_StatisticalAI_Condition_Filters.zip`
- 変更した既存ファイル: `statistical_ai.py`, `app.py`, `static/index.html`, `static/racepo-stat-ai-tab-v17318.css`
- 新規ファイル: `statistical_ai_jobs.py`, `test_statistical_ai_v17322.py`, この検証記録および取込方法の説明

## 完了した検証
- `python -m unittest -q test_statistical_ai_v17317 test_statistical_ai_v17320 test_statistical_ai_v17321 test_statistical_ai_v17322 test_statistics_finalization_v315 test_statistics_refresh_v17316`: **33テスト成功**
- `python -m py_compile` で関連Pythonを構文確認
- `node --check` でメインHTMLから抽出したインラインJavaScriptを構文確認
- オフラインChromiumのPC相当（1366幅）、スマホ相当（390幅）で統計AIの取得状況パネル、条件別統計、選択フォームの表示・操作を検証（JSON応答はモック）
- FastAPI TestClient: 管理者未認証の取得状況・開始・停止・条件別集計は401。認証チェックをテスト用モックにした場合、取得開始202、停止応答、条件別照会200、不正フィルター400。
- インポート・重複排除・場別分離・締切後のデータ除外・払戻照合・フォーメーション総投資額／総払戻額・中断扱いの継続情報をモックCSVで検証。

## 現実の検証制限
- 開発実行環境は `boatracecsv.github.io` へのDNS/HTTP接続が制限されており、実データのダウンロードおよび数年分の払戻結果との突合せは未実施。**実データ投入済みとは主張しない**。
- 実際のレースポ全機能を起動した状態でのブラウザ結合試験は未実施。オフラインChromiumでは統計AIの主要コントロールとレンダラーのみを検証。
- 「公開CSVから取得開始」は、ネットワーク接続可能なPC/サーバーで管理者が操作したときに動作する。
- 公開サイト・ConoHa VPS・GitHub は未変更。本番AI予想テーブルも変更していない。
