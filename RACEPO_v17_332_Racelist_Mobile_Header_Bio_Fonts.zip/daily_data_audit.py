"""Read-only coverage audit of race data saved by the existing collector.

Counts are evidence of storage, NOT claims that the publisher exposes all fields.
The report never triggers collection or modifies the prediction database.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

JST = ZoneInfo('Asia/Tokyo')
VENUES = ('桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村')
FIELDS = ('racelist', 'beforeinfo', 'odds3t', 'result', 'weather', 'original', 'tide')


def _valid_snapshot(kind, raw):
    try:
        value = json.loads(raw or '{}')
        if not isinstance(value, dict):
            return False
        if kind == 'racelist':
            return len(value.get('racers') or []) == 6
        if kind == 'beforeinfo':
            return bool(value.get('racers') or value.get('start_display') or value.get('weather') or value.get('original_exhibition'))
        if kind == 'odds3t':
            return len(value.get('odds') or []) == 120
    except (TypeError, ValueError):
        pass
    return False


def audit_day(db, day, now=None):
    now = now or datetime.now(JST)
    if now.tzinfo is None:
        now = now.replace(tzinfo=JST)
    today = now.astimezone(JST).strftime('%Y%m%d')
    if len(day) != 8 or not day.isdigit() or day > today:
        raise ValueError('本日までの年月日（YYYYMMDD）を指定してください')
    try:
        datetime.strptime(day, '%Y%m%d')
    except ValueError as exc:
        raise ValueError('存在する日付を指定してください') from exc

    with db.connect() as con:
        schedules = con.execute('SELECT jcd,rno,deadline FROM race_schedule WHERE date=?', (day,)).fetchall()
        snapshots = con.execute('SELECT jcd,rno,kind,payload FROM race_snapshots WHERE date=? AND kind IN (\'racelist\',\'beforeinfo\',\'odds3t\')', (day,)).fetchall()
        results = con.execute('SELECT jcd,rno,trifecta,payout_yen,payload FROM race_results WHERE date=?', (day,)).fetchall()
        tides = con.execute('SELECT jcd,rno,estimated_level_cm,tide_phase FROM tide_race_context WHERE date=?', (day,)).fetchall()
    expected = defaultdict(set)
    deadline = {}
    valid = {f: defaultdict(set) for f in FIELDS}
    for row in schedules:
        venue = str(row['jcd']).zfill(2)
        if venue not in {f'{i:02d}' for i in range(1,25)} or not 1 <= int(row['rno']) <= 12:
            continue
        race = int(row['rno'])
        expected[venue].add(race)
        deadline[(venue,race)] = row['deadline']
    for row in tides:
        venue = str(row['jcd']).zfill(2)
        race = int(row['rno'])
        if 1 <= race <= 12 and (row['estimated_level_cm'] is not None or row['tide_phase']):
            valid['tide'][venue].add(race)
    for row in snapshots:
        venue = str(row['jcd']).zfill(2)
        race = int(row['rno'])
        if 1 <= race <= 12 and _valid_snapshot(row['kind'], row['payload']):
            valid[row['kind']][venue].add(race)
            expected[venue].add(race)
        if row['kind'] == 'beforeinfo' and 1 <= race <= 12:
            try:
                before = json.loads(row['payload'] or '{}')
                weather = before.get('weather') or {}
                if isinstance(weather, dict) and any(v is not None and v != '' for v in weather.values()):
                    valid['weather'][venue].add(race)
                if before.get('original_exhibition'):
                    valid['original'][venue].add(race)
            except (TypeError, ValueError, AttributeError):
                pass
    for row in results:
        venue = str(row['jcd']).zfill(2)
        race = int(row['rno'])
        if not 1 <= race <= 12:
            continue
        expected[venue].add(race)
        try:
            payload = json.loads(row['payload'] or '{}')
        except (ValueError, TypeError):
            payload = {}
        # A result without official finishing order can still legitimately be
        # a cancellation. Only mark complete where result detail is present.
        if (row['trifecta'] and row['payout_yen'] is not None) or payload.get('is_cancelled'):
            valid['result'][venue].add(race)
    venues = []
    total = {field: 0 for field in FIELDS}
    required = 0
    for venue in sorted(expected):
        ids = sorted(expected[venue])
        required += len(ids)
        sections = {}
        for field in FIELDS:
            have = sorted(set(ids) & valid[field][venue])
            missing = sorted(set(ids) - set(have))
            total[field] += len(have)
            sections[field] = {'saved': len(have), 'expected': len(ids), 'missing_races': missing}
        # Completion is based on results, not guessed closing times. Missing
        # results after a calendar day rolls over are marked as outstanding.
        done = all(r in valid['result'][venue] for r in ids)
        full = done and all(not sections[f]['missing_races'] for f in ('racelist', 'beforeinfo', 'odds3t', 'result'))
        status = 'complete' if full else ('incomplete' if day < today or done else 'ongoing')
        venues.append({'code': venue, 'name': VENUES[int(venue)-1], 'status': status,
                       'result_final': done, 'expected_races': len(ids), 'fields': sections})
    return {'date': day, 'generated_at': now.isoformat(), 'status': 'no_data' if not venues else
            ('complete' if all(v['status']=='complete' for v in venues) else 'incomplete'),
            'venue_count': len(venues), 'expected_races': required, 'field_totals': total,
            'venues': venues, 'note': '保存済みデータの照合結果です。天候・オリジナル展示・潮は参考項目で、未提供の場合もあります。予定未取得の開催場やレース、各項目内部の欠損は別途確認が必要です。'}
