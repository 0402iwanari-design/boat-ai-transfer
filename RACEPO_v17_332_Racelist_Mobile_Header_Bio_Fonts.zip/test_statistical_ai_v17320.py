"""v17.320: seasonal research evidence must be transparent and non-prescriptive."""
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest

from statistical_ai import (Store, SEASON_BY_MONTH, _coverage, _comparison_formations,
                            _historical_comparisons, feature_map, analyze_venue,
                            inspect_formation)


class SeasonalEvidenceTests(unittest.TestCase):
    def test_four_seasons_and_extended_winter_window(self):
        for month, expected in ((1,'winter'),(2,'winter'),(3,'spring'),
                                (5,'spring'),(6,'summer'),(8,'summer'),
                                (9,'autumn'),(11,'autumn'),(12,'winter')):
            features = feature_map(f'2025-{month:02d}-10', 10)
            self.assertEqual(features['season'], expected)
            self.assertEqual(features['season_window'], '11-03' if month in (11,12,1,2,3) else '04-10')
        self.assertEqual(len(SEASON_BY_MONTH), 12)

    def test_old_research_records_are_normalized_on_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'data.db')
            for day, expected in [('2024-11-10','autumn'),('2024-12-10','winter'),('2025-03-10','spring')]:
                key=day.replace('-','')+'1209'
                store.upsert([{'key':key,'day':day,'venue':'12','rno':9,'combo':'1-2-3',
                               'payout_yen':1500,'source':'legacy',
                               'features':json.dumps({'season':'11-03','race_band':'9-12'})}])
            rows=store.read_venue('12')
            self.assertEqual([r['features']['season'] for r in rows], ['autumn','winter','spring'])
            # Old CLI callers remain compatible with the pre-existing 11-03 query.
            self.assertEqual(inspect_formation(store,'12','1-23-234',{'season':'11-03'})['historical']['races'],3)
            self.assertEqual(inspect_formation(store,'12','1-23-234',{'season':'winter'})['historical']['races'],1)

    def test_comparison_forms_include_descriptive_20_point_without_changing_live_limit(self):
        forms=dict(_comparison_formations())
        self.assertEqual(len(forms['1-全-全']),20)
        self.assertEqual(len(forms['1-2345-2345']),12)
        self.assertEqual(len(forms['1-23-234']),4)
        self.assertEqual(len(forms['1-23-23']),2)
        self.assertEqual(len(forms['1-234-234']),6)
        self.assertIn('1-2-3',forms['1-23-234'])

    def test_true_roi_for_loss_making_and_winning_historical_comparisons(self):
        train=[{'features':feature_map('2024-12-01',11,racers={1:{'class':'A1'}}),
                'combo':'1-2-3' if i%2==0 else '2-1-3','payout_yen':1400} for i in range(40)]
        validation=[{'features':feature_map('2025-01-11',11,racers={1:{'class':'A1'}}),
                     'combo':'5-4-3','payout_yen':5000} for _ in range(20)]
        comparisons=_historical_comparisons(train,validation)
        self.assertTrue(comparisons)
        target=next(x for x in comparisons if x['condition']==[{'field':'season','value':'winter'}]
                    and x['formation']=='1-23-234')
        self.assertEqual(target['train']['races'],40)
        self.assertEqual(target['train']['hits'],20)
        self.assertEqual(target['train']['hit_rate'],50)
        self.assertEqual(target['train']['total_stake_yen'],16000)
        self.assertEqual(target['train']['total_payout_yen'],28000)
        self.assertEqual(target['train']['roi'],175)
        # Unfavorable later-period results are preserved, NOT removed by ROI filters.
        self.assertEqual(target['validation']['races'],20)
        self.assertEqual(target['validation']['hits'],0)
        self.assertEqual(target['validation']['hit_rate'],0)
        self.assertEqual(target['validation']['roi'],0)
        self.assertEqual(target['validation']['total_stake_yen'],8000)
        self.assertEqual(target['validation']['total_payout_yen'],0)
        self.assertEqual(target['status'],'historical_comparison_only')
        # The baseline 20-point purchase costs 20*100 each race.
        baseline=next(x for x in comparisons if x['condition']==[{'field':'season','value':'winter'}]
                      and x['formation']=='1-全-全')
        self.assertEqual(baseline['train']['total_stake_yen'],80000)

    def test_comparisons_available_even_when_candidate_gate_is_not_met(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'data.db')
            records=[]
            for i in range(100):
                day=(date(2024,12,1)+timedelta(days=i)).isoformat()
                key=day.replace('-','')+'1209'
                records.append({'key':key,'day':day,'venue':'12','rno':9,'combo':'1-2-3',
                                'payout_yen':1400,'features':json.dumps(feature_map(day,9)),
                                'source':'test'})
            store.upsert(records)
            report=analyze_venue(store,'12')
            self.assertEqual(report['status'],'not_enough_data')
            self.assertEqual(report['candidates'],[])
            # Dec-Feb has at least 30 training, 15 validation; it may be shown as history.
            self.assertTrue(any(x['season']=='winter' for x in report['comparisons']))
            self.assertEqual(sum(report['season_counts'].values()),100)
            self.assertEqual(store.report('12')['comparisons'],report['comparisons'])


if __name__=='__main__': unittest.main(verbosity=2)
