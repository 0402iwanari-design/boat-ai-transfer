from __future__ import annotations

"""Nationwide/local actual-entry-course history collection.

Policy (v17.180)
----------------
* Historical backfill may access the official daily K download only from
  00:00 through 04:00 JST.
* At 00:00, only racers already seen by BOAT AI Lab whose historical scan is
  not complete are selected. Completed racers are never crawled again.
* One official daily file is downloaded at a time, filtered to those target
  racers, reflected into SQLite, then the persisted cursor moves backward.
* There is a 30-second pause after each successful/no-data day. A failed
  request is retried at most three times with a 60-second pause. After the
  third failure the nightly job stops and the affected racers are exposed as
  errors on the home screen. The same date is retried the next night.
* At 04:00 the historical job stops even when unfinished and resumes from the
  saved cursor the next night.
* During race hours this module performs NO historical web access. Confirmed
  live race results update the same table through BoatDB.save_results().
* Detailed rows are retained only for the newest 10 runs per
  racer/venue/actual-course. Nationwide newest-10 is reconstructed from those
  bounded local rows.
"""

import io
import re
import threading
import time
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo

import requests

JST = ZoneInfo("Asia/Tokyo")
HISTORY_FLOOR = "20020101"
SUCCESS_PAUSE_SECONDS = 30
RETRY_PAUSE_SECONDS = 60
MAX_FETCH_ATTEMPTS = 3

VENUES = [
    "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
    "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村",
]
VENUE_CODE = {name: f"{i:02d}" for i, name in enumerate(VENUES, 1)}


def _norm(s: str) -> str:
    return re.sub(r"[\s　]+", "", str(s or "")).replace("ボートレース", "")


def _st_number(raw: str):
    s = str(raw or "").strip().upper().replace("０", "0")
    if not s:
        return None
    m = re.fullmatch(r"F\s*([0-9]*\.?[0-9]+)", s)
    if m:
        try:
            return -float(m.group(1))
        except ValueError:
            return None
    if s.startswith("L"):
        return None
    try:
        v = float(s)
        return v if -1 < v < 2 else None
    except ValueError:
        return None


def parse_k_text(text: str, yyyymmdd: str) -> list[dict]:
    """Parse official K text into racer/run rows; 3連単 is intentionally omitted."""
    rows: list[dict] = []
    jcd = None
    rno = None
    in_result_rows = False
    race_rows: list[dict] = []

    def flush_race():
        nonlocal race_rows
        if not race_rows:
            return
        numeric = [(i, _st_number(x.get("st_raw"))) for i, x in enumerate(race_rows)]
        numeric = [(i, v) for i, v in numeric if v is not None]
        numeric.sort(key=lambda z: z[1])
        last = None
        rank = 0
        for pos, (idx, value) in enumerate(numeric, 1):
            if last is None or abs(value - last) > 1e-9:
                rank = pos
                last = value
            race_rows[idx]["st_rank"] = rank
        rows.extend(race_rows)
        race_rows = []

    for raw_line in text.splitlines():
        line = raw_line.rstrip("\r\n")
        compact = _norm(line)
        for name, code in sorted(VENUE_CODE.items(), key=lambda kv: len(kv[0]), reverse=True):
            if name in compact and ("成績" in compact or "ボートレース" in line):
                flush_race()
                jcd = code
                rno = None
                in_result_rows = False
                break

        m_race = re.match(r"^\s*(\d{1,2})R\s+.*H\s*\d+", line, re.I)
        if m_race:
            flush_race()
            rno = int(m_race.group(1))
            in_result_rows = False
            continue
        if "スタートタイミンク" in line or "スタートタイミング" in line:
            in_result_rows = True
            continue
        if not in_result_rows or not jcd or not rno:
            continue
        if not line.strip() or set(line.strip()) <= {"-"}:
            if race_rows and not line.strip():
                flush_race()
                in_result_rows = False
            continue

        finish = lane = reg = entry = st_raw = None
        if len(line) >= 48:
            finish = line[2:4].strip()
            lane = line[6:7].strip()
            reg = line[8:12].strip()
            entry = line[38:39].strip()
            st_raw = line[43:47].strip()
        if not (lane and lane.isdigit() and reg and reg.isdigit() and entry and entry.isdigit()):
            m = re.match(r"^\s*(\S{1,2})\s+([1-6])\s+(\d{4})\s+(.+?)\s+(\d{1,2})\s+(\d{1,2})\s+(\d\.\d{2})\s+([1-6])\s+(\S+)", line)
            if not m:
                continue
            finish, lane, reg, entry, st_raw = m.group(1), m.group(2), m.group(3), m.group(8), m.group(9)
        try:
            lane_i, course_i = int(lane), int(entry)
        except (TypeError, ValueError):
            continue
        if not (1 <= lane_i <= 6 and 1 <= course_i <= 6):
            continue
        finish_clean = str(finish or "").lstrip("0") or "0"
        race_rows.append({
            "date": yyyymmdd, "jcd": jcd, "rno": rno,
            "registration_no": str(reg), "lane": lane_i,
            "course": course_i, "finish": finish_clean,
            "st_raw": str(st_raw or "").strip(), "st_rank": None,
            "source": "official-k-download-nightly",
        })
    flush_race()
    return rows


class OfficialCourseHistoryCollector:
    """Restart-safe nightly historical collector; never crawls during race hours."""

    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = self.db.get_course_history_collection_status()

    @staticmethod
    def _in_window(now: datetime) -> bool:
        return dt_time(0, 0) <= now.time() < dt_time(4, 0)

    @staticmethod
    def _seconds_until_next_midnight(now: datetime) -> float:
        tomorrow = (now + timedelta(days=1)).date()
        next_run = datetime.combine(tomorrow, dt_time(0, 0), tzinfo=JST)
        return max(1.0, (next_run - now).total_seconds())

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._scheduler, name="course-history-nightly", daemon=True)
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            now = datetime.now(JST)
            if self._in_window(now):
                self._run_nightly_window()
                now = datetime.now(JST)
                # After a nightly run/error, do not start a second pass in the
                # same window. Wait until the next midnight.
                self._stop.wait(self._seconds_until_next_midnight(now))
            else:
                self.status = self.db.get_course_history_collection_status()
                self._stop.wait(min(self._seconds_until_next_midnight(now), 300))

    def _fetch_day(self, session: requests.Session, cursor) -> tuple[str, list[dict], str | None]:
        ymd = cursor.strftime("%Y%m%d")
        yy = cursor.strftime("%y%m%d")
        url = f"https://www1.mbrace.or.jp/od2/K/{cursor:%Y%m}/k{yy}.lzh"
        last_error = None
        for attempt in range(1, MAX_FETCH_ATTEMPTS + 1):
            if self._stop.is_set() or not self._in_window(datetime.now(JST)):
                return "window_end", [], None
            try:
                r = session.get(url, timeout=20)
                if r.status_code == 404:
                    return "no_data", [], None
                r.raise_for_status()
                try:
                    import lhafile
                except ImportError as exc:
                    raise RuntimeError("lhafile が未導入です。requirements.txt から再デプロイしてください") from exc
                archive = lhafile.Lhafile(io.BytesIO(r.content))
                names = archive.namelist()
                if not names:
                    raise RuntimeError("公式Kファイルを展開できませんでした")
                raw = archive.read(names[0])
                return "ok", parse_k_text(raw.decode("cp932", errors="replace"), ymd), None
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt < MAX_FETCH_ATTEMPTS:
                    self._stop.wait(RETRY_PAUSE_SECONDS)
        return "error", [], last_error

    def _run_nightly_window(self):
        now = datetime.now(JST)
        start_date = (now.date() - timedelta(days=1)).strftime("%Y%m%d")
        self.db.ensure_course_history_racer_targets(start_date, HISTORY_FLOOR)
        targets = self.db.get_course_history_pending_racers()
        if not targets:
            self.status = self.db.get_course_history_collection_status()
            return

        # Error rows are retried the next night from exactly the failed date.
        target_regs = {str(x["registration_no"]) for x in targets}
        cursors = [str(x.get("cursor_date") or start_date) for x in targets]
        cursor = datetime.strptime(max(cursors), "%Y%m%d").date()
        floor = datetime.strptime(HISTORY_FLOOR, "%Y%m%d").date()

        session = requests.Session()
        session.headers.update({"User-Agent": "BOAT-AI-Lab/1.0 official-result-history-nightly"})

        while cursor >= floor and self._in_window(datetime.now(JST)) and not self._stop.is_set():
            ymd = cursor.strftime("%Y%m%d")
            # Only racers whose own persisted cursor has reached this day are
            # affected. This lets a later-added racer coexist with an older
            # unfinished one without re-saving completed racers.
            current = self.db.get_course_history_pending_racers()
            active = {
                str(x["registration_no"]): x for x in current
                if str(x["registration_no"]) in target_regs
                and str(x.get("cursor_date") or start_date) >= ymd
            }
            if not active:
                next_dates = [str(x.get("cursor_date") or "") for x in current if str(x["registration_no"]) in target_regs and x.get("cursor_date")]
                if not next_dates:
                    break
                cursor = datetime.strptime(max(next_dates), "%Y%m%d").date()
                continue

            state, rows, error = self._fetch_day(session, cursor)
            if state == "window_end":
                break
            if state == "error":
                self.db.mark_course_history_fetch_error(list(active), ymd, error or "取得失敗", MAX_FETCH_ATTEMPTS)
                self.status = self.db.get_course_history_collection_status()
                return

            if state == "ok" and rows:
                filtered = [x for x in rows if str(x.get("registration_no") or "") in active]
                self.db.save_course_history_runs(filtered, keep_per_local_course=10)

            next_date = (cursor - timedelta(days=1)).strftime("%Y%m%d")
            self.db.advance_course_history_racers(list(active), next_date)
            self.status = self.db.get_course_history_collection_status()
            cursor -= timedelta(days=1)
            self._stop.wait(SUCCESS_PAUSE_SECONDS)

        # Reaching the historical floor means fewer-than-10 groups are
        # legitimate 'available runs only' data, not an endless pending state.
        if cursor < floor:
            current = self.db.get_course_history_pending_racers()
            done = [str(x["registration_no"]) for x in current if str(x["registration_no"]) in target_regs]
            self.db.complete_course_history_racers(done)
        else:
            current = self.db.get_course_history_pending_racers()
            paused = [str(x["registration_no"]) for x in current if str(x["registration_no"]) in target_regs]
            self.db.mark_course_history_window_paused(paused)
        self.status = self.db.get_course_history_collection_status()
