from __future__ import annotations
"""v17.204 validation build: 峰竜太(4320) nationwide actual-entry history.

Validated collection method used in this build:
1. Use the racer's yearly all-races page only as a *candidate race index*.
   We do NOT trust its course/ST/finish columns for storage.
2. Read candidate races newest first, starting with the current year.
3. Open BOAT RACE official result page for each candidate race.
4. Locate racer 4320 in the official finish table to identify the lane/finish.
5. Read the official "スタート情報" lane order.  The lane's position in that
   order is the actual entry course (実進入).  This correctly handles 前づけ/進入変更.
6. Preserve the official ST text and compute ST rank from all starters.
7. Put the run into actual-course bucket 1..6.  Stop adding to a bucket once it
   has its newest 10 runs.
8. Continue to older years only while at least one bucket has fewer than 10.
   Stop at 2023.  Fewer than 10 (including zero) after checking 2023 is normal.

欠場/non-start is ignored.  Special results are kept when the racer actually
started and the official result/start information can identify the run.
"""

import re
import threading
import time
import unicodedata
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
FLOOR_YEAR = 2023
FLOOR = "20230101"
VALIDATION_REG = "4320"
VALIDATION_NAME = "峰竜太"
VALIDATION_LOCAL_JCD = "16"  # target-row compatibility only; nationwide validation

VENUES = [
    "桐生", "戸田", "江戸川", "平和島", "多摩川", "浜名湖", "蒲郡", "常滑", "津", "三国", "びわこ", "住之江",
    "尼崎", "鳴門", "丸亀", "児島", "宮島", "徳山", "下関", "若松", "芦屋", "福岡", "唐津", "大村",
]
VENUE_CODE = {n: f"{i:02d}" for i, n in enumerate(VENUES, 1)}


def _nfkc(s):
    return unicodedata.normalize("NFKC", str(s or ""))


def _norm(s):
    return re.sub(r"[\s\u3000]+", "", _nfkc(s))


def _venue_code(s):
    n = _norm(s)
    return next((code for name, code in VENUE_CODE.items() if _norm(name) == n), None)


def _date_token(s, year):
    text = _nfkc(s)
    # 8/30, 08/30, 2026/08/30, 2026-08-30
    m = re.search(r"(?<!\d)(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})(?!\d)", text)
    if not m:
        return None
    y = int(m.group(1) or year)
    return f"{y:04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def _race_token(s):
    m = re.fullmatch(r"\s*(\d{1,2})\s*R\s*", _nfkc(s), re.I)
    if not m:
        return None
    r = int(m.group(1))
    return r if 1 <= r <= 12 else None


def _st_token(s):
    """Official start text. Bare 1..6 is never ST."""
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return t
    if re.fullmatch(r"[FL]\.\d{1,2}", t):
        return t
    if t in {"F", "L"}:
        return t
    return None


def _st_value(s):
    """Signed value for ST ranking. F.01 -> -0.01. L without numeric is unranked."""
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return float("0" + t)
    m = re.fullmatch(r"F\.(\d{1,2})", t)
    if m:
        return -float("0." + m.group(1))
    m = re.fullmatch(r"L\.(\d{1,2})", t)
    if m:
        return float("0." + m.group(1))
    return None


def _finish_token(s):
    t = _norm(s).replace("着", "")
    # Numeric finishes + common BOAT RACE special result notation.
    return t if re.fullmatch(r"[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠", t) else None


def _expand_table(table):
    """Expand rowspan/colspan into a rectangular text grid."""
    grid = []
    spans = {}  # col -> [remaining rows, text]
    for tr in table.find_all("tr"):
        row, col = [], 0
        cells = tr.find_all(["th", "td"], recursive=False)
        ci = 0
        while ci < len(cells) or spans:
            while col in spans:
                rem, text = spans[col]
                while len(row) <= col:
                    row.append("")
                row[col] = text
                if rem <= 1:
                    del spans[col]
                else:
                    spans[col] = [rem - 1, text]
                col += 1
            if ci >= len(cells):
                if not spans:
                    break
                next_col = min(spans)
                while col < next_col:
                    row.append("")
                    col += 1
                continue
            cell = cells[ci]
            ci += 1
            text = " ".join(cell.stripped_strings)
            try:
                cs = max(1, int(cell.get("colspan", 1)))
            except (TypeError, ValueError):
                cs = 1
            try:
                rs = max(1, int(cell.get("rowspan", 1)))
            except (TypeError, ValueError):
                rs = 1
            for _ in range(cs):
                while col in spans:
                    rem, old = spans[col]
                    while len(row) <= col:
                        row.append("")
                    row[col] = old
                    if rem <= 1:
                        del spans[col]
                    else:
                        spans[col] = [rem - 1, old]
                    col += 1
                while len(row) <= col:
                    row.append("")
                row[col] = text
                if rs > 1:
                    spans[col] = [rs - 1, text]
                col += 1
        grid.append(row)
    width = max((len(r) for r in grid), default=0)
    return [r + [""] * (width - len(r)) for r in grid]


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = {
            "phase": "本日の出走表待ち",
            "validation_mode": "峰竜太（4320）全国・公式結果照合方式",
        }

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._scheduler, daemon=True, name="mine-course-history-official-verify"
        )
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            today = datetime.now(JST).strftime("%Y%m%d")
            try:
                self._run(today)
            except Exception as e:
                self.status = {
                    **self.db.get_course_history_target_status(today, VALIDATION_REG),
                    "phase": "収集処理エラー",
                    "scheduler_error": f"{type(e).__name__}: {e}",
                    "validation_mode": "峰竜太（4320）全国・公式結果照合方式",
                }
            self._stop.wait(10)

    def _reset_validation_racer(self, today):
        """One-time clean slate for course-history tables only.

        Previous all-racer course-history data was known to contain mismatches.  This
        migration removes only the course-history subsystem, not predictions/results/etc.
        """
        key = "course_history_v17_204_dailyindex_official_actual_entry_mine4320"
        start = (datetime.now(JST).date() - timedelta(days=1)).strftime("%Y%m%d")
        with self.db.connect() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS app_migrations (
                    migration_key TEXT PRIMARY KEY, applied_at TEXT DEFAULT CURRENT_TIMESTAMP
                )"""
            )
            if con.execute("SELECT 1 FROM app_migrations WHERE migration_key=?", (key,)).fetchone():
                return False
            con.execute("DELETE FROM racer_course_runs")
            con.execute("DELETE FROM course_history_target_state")
            con.execute("DELETE FROM course_history_racer_state")
            con.execute(
                """UPDATE course_history_backfill_state
                   SET status='pending',next_date=?,days_scanned=0,runs_saved=0,last_success_date=NULL,
                       last_error=NULL,completed=0,updated_at=CURRENT_TIMESTAMP WHERE id=1""",
                (start,),
            )
            con.execute("INSERT INTO app_migrations(migration_key) VALUES(?)", (key,))
        return True

    def _ensure_validation_target(self, today):
        start = (datetime.now(JST).date() - timedelta(days=1)).strftime("%Y%m%d")
        with self.db.connect() as con:
            old = con.execute(
                "SELECT 1 FROM course_history_target_state WHERE registration_no=? AND jcd=?",
                (VALIDATION_REG, VALIDATION_LOCAL_JCD),
            ).fetchone()
            if old is None:
                con.execute(
                    """INSERT INTO course_history_target_state
                       (registration_no,jcd,name,status,cursor_date,floor_date,target_date)
                       VALUES(?,?,?,'pending',?,?,?)""",
                    (VALIDATION_REG, VALIDATION_LOCAL_JCD, VALIDATION_NAME, start, FLOOR, today),
                )
            else:
                con.execute(
                    """UPDATE course_history_target_state
                       SET name=?,status=CASE WHEN target_date=? AND status='complete' THEN status ELSE 'pending' END,
                           cursor_date=COALESCE(cursor_date,?),floor_date=?,target_date=?,retry_count=0,
                           failed_date=NULL,last_error=NULL,updated_at=CURRENT_TIMESTAMP
                       WHERE registration_no=? AND jcd=?""",
                    (
                        VALIDATION_NAME,
                        today,
                        start,
                        FLOOR,
                        today,
                        VALIDATION_REG,
                        VALIDATION_LOCAL_JCD,
                    ),
                )

    def _national_counts(self, reg):
        with self.db.connect() as con:
            rows = con.execute(
                """SELECT course,COUNT(*) n FROM racer_course_runs
                   WHERE registration_no=? AND date>=? GROUP BY course""",
                (reg, FLOOR),
            ).fetchall()
        return {int(x["course"]): min(10, int(x["n"])) for x in rows}

    @staticmethod
    def _national_done(nm):
        return all(nm.get(c, 0) >= 10 for c in range(1, 7))

    def _extract_candidates_from_daily_json(self, data, reg, ymd):
        """Find this racer in one daily public race JSON.

        This page is only the candidate index.  Course/ST/finish from this JSON are
        NOT stored.  Every candidate is verified again on BOAT RACE official result.
        """
        out = []
        stadiums = (((data or {}).get("programs") or {}).get("stadiums") or {})
        for skey, stadium in stadiums.items():
            races = ((stadium or {}).get("races") or {})
            for rkey, race in races.items():
                result = (race or {}).get("result") or {}
                racers = result.get("racers") or {}
                found = False
                vals = racers.values() if isinstance(racers, dict) else racers if isinstance(racers, list) else []
                for rr in vals:
                    if not isinstance(rr, dict):
                        continue
                    if str(rr.get("number") or "") == str(reg):
                        found = True
                        break
                if not found:
                    continue
                try:
                    jcd = str(int((race or {}).get("stadium_number") or skey)).zfill(2)
                    rno = int((race or {}).get("race_number") or rkey)
                except Exception:
                    continue
                out.append({"date": str(ymd), "jcd": jcd, "rno": rno})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["jcd"], x["rno"]), reverse=True)

    def _fetch_candidate_day(self, session, reg, ymd):
        year = str(ymd)[:4]
        url = f"https://boatraceopenapi.github.io/api/v1/{year}/{ymd}.json"
        self.status.update({
            "phase": "全国コース履歴・候補日確認中",
            "crawl_stage": f"{ymd} 全国24場JSONから峰竜太4320の出走候補を検索",
            "scan_date": str(ymd),
            "last_fetch_state": "fetching daily candidate index",
            "last_fetch_error": None,
            "direct_source": url,
        })
        last = None
        for attempt in range(1, 4):
            try:
                r = session.get(url, timeout=(5, 20))
                if r.status_code == 404:
                    return [], {"url": url, "http": 404, "attempt": attempt}
                r.raise_for_status()
                data = r.json()
                rows = self._extract_candidates_from_daily_json(data, reg, ymd)
                self.status.update({
                    "last_fetch_state": "daily candidate index ok",
                    "last_fetch_error": None,
                    "candidate_races": len(rows),
                    "direct_source": r.url,
                })
                return rows, {"url": r.url, "http": r.status_code, "attempt": attempt}
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                self.status.update({
                    "last_fetch_error": last,
                    "last_fetch_state": f"daily candidate retry {attempt}/3",
                    "direct_source": url,
                })
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or f"{ymd}候補日取得失敗")

    def _official_result_url(self, x):
        return (
            "https://www.boatrace.jp/owpc/pc/race/raceresult"
            f"?hd={x['date']}&jcd={str(x['jcd']).zfill(2)}&rno={int(x['rno'])}"
        )

    def _parse_official_result(self, html, candidate, reg):
        """Parse one official result page and return this racer's actual-entry run.

        Actual course is determined ONLY from the lane order in スタート情報:
        first lane shown = 1C, second = 2C ... sixth = 6C.
        """
        soup = BeautifulSoup(html, "html.parser")

        # --- finish/lane from the result table ---
        lane = None
        finish = None
        for tr in soup.find_all("tr"):
            cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
            if not cells:
                continue
            joined = " ".join(cells)
            if not re.search(rf"(?<!\d){re.escape(str(reg))}(?!\d)", _nfkc(joined)):
                continue
            # Result rows are normally: 着 / 枠 / racer / time.
            finish_candidates = [_finish_token(c) for c in cells]
            finish_candidates = [x for x in finish_candidates if x is not None]
            if finish_candidates:
                finish = finish_candidates[0]
            # The lane is the first plain 1..6 cell after the finish cell.  Prefer cell 2.
            for idx, c in enumerate(cells):
                t = _norm(c)
                if re.fullmatch(r"[1-6]", t):
                    # If cell 0 is numeric it is usually finish, cell 1 is lane.
                    if idx == 0 and len(cells) > 1 and re.fullmatch(r"[1-6]", _norm(cells[1])):
                        continue
                    lane = int(t)
                    break
            if lane is not None:
                break

        # Racer not in finish table -> 欠場/non-start or page mismatch. Do not store.
        if lane is None or finish is None or finish == "欠":
            return None

        # --- official start order / ST ---
        lines = [x.strip() for x in soup.get_text("\n").splitlines() if x.strip()]
        try:
            start_i = next(i for i, x in enumerate(lines) if _norm(x) == "スタート情報")
        except StopIteration:
            return None

        end_i = len(lines)
        for i in range(start_i + 1, len(lines)):
            n = _norm(lines[i])
            if n in {"勝式", "払戻金", "水面気象情報", "返還", "決まり手"}:
                end_i = i
                break

        start_rows = []  # [(lane, st_raw)] in the exact displayed order
        seg = lines[start_i + 1 : end_i]
        i = 0
        while i < len(seg):
            t = _norm(seg[i])
            if re.fullmatch(r"[1-6]", t):
                slane = int(t)
                st = None
                # Images/決まり手 text can be between lane and ST; search only nearby.
                for j in range(i + 1, min(i + 6, len(seg))):
                    st = _st_token(seg[j])
                    if st is not None:
                        break
                    # Stop if another lane begins before ST was found.
                    if re.fullmatch(r"[1-6]", _norm(seg[j])):
                        break
                if st is not None and slane not in [z[0] for z in start_rows]:
                    start_rows.append((slane, st))
            i += 1

        # Some official pages render lane and ST in the same text fragment. Fallback regex.
        if len(start_rows) < 2:
            block = "\n".join(seg)
            for m in re.finditer(r"(?m)^\s*([1-6])\s*(?:\n|\s)+((?:F|L)?\.\d{1,2}|F|L)\s*$", block):
                pair = (int(m.group(1)), _norm(m.group(2)).upper())
                if pair[0] not in [z[0] for z in start_rows]:
                    start_rows.append(pair)

        if lane not in [z[0] for z in start_rows]:
            return None

        course_by_lane = {slane: pos for pos, (slane, _st) in enumerate(start_rows, 1)}
        st_by_lane = {slane: st for slane, st in start_rows}
        course = course_by_lane.get(lane)
        st_raw = st_by_lane.get(lane)
        if not course or not (1 <= course <= 6) or st_raw is None:
            return None

        # Competition rank: tied STs share rank and following rank is skipped.
        numeric = []
        for slane, st in start_rows:
            v = _st_value(st)
            if v is not None:
                numeric.append((slane, v))
        numeric.sort(key=lambda z: z[1])
        ranks, last, rank = {}, None, 0
        for pos, (slane, v) in enumerate(numeric, 1):
            if last is None or abs(v - last) > 1e-9:
                rank = pos
                last = v
            ranks[slane] = rank

        return {
            "date": str(candidate["date"]),
            "jcd": str(candidate["jcd"]).zfill(2),
            "rno": int(candidate["rno"]),
            "registration_no": str(reg),
            "lane": int(lane),
            "course": int(course),
            "finish": str(finish),
            "st_raw": str(st_raw),
            "st_rank": ranks.get(lane),
            "source": "boatrace-official-result:actual-entry-v17204",
        }

    def _fetch_official_run(self, session, candidate, reg):
        url = self._official_result_url(candidate)
        last = None
        for attempt in range(1, 4):
            try:
                r = session.get(url, timeout=(5, 20))
                r.raise_for_status()
                row = self._parse_official_result(r.text, candidate, reg)
                return row, {"url": r.url, "http": r.status_code, "attempt": attempt}
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or "公式レース結果取得失敗")

    def _run(self, today):
        reset_now = self._reset_validation_racer(today)
        self._ensure_validation_target(today)
        started = time.monotonic()
        self.status = {
            **self.db.get_course_history_target_status(today, VALIDATION_REG),
            "phase": "峰竜太（4320）全国・実進入履歴をゼロから取得開始",
            "validation_mode": "峰竜太（4320）全国・日別候補→公式結果照合方式",
            "current_racer": VALIDATION_NAME,
            "current_registration_no": VALIDATION_REG,
            "clean_reset_applied": bool(reset_now),
            "crawl_stage": "日別全国24場データで候補抽出 → BOAT RACE公式結果で実進入確認",
            "note": "v17.204。候補抽出は2026年の日別全国データ、保存値は各レースのBOAT RACE公式結果だけを使用。",
        }

        pending = self.db.get_course_history_pending_targets(today, only_registration_no=VALIDATION_REG)
        if not pending:
            st = self.db.get_course_history_target_status(today, VALIDATION_REG)
            self.status = {**st, "phase": "峰竜太（4320）全国履歴完了", "validation_mode": "峰竜太（4320）全国・日別候補→公式結果照合方式"}
            return

        t = pending[0]
        reg = str(t["registration_no"])
        jcd = str(t["jcd"]).zfill(2)
        name = str(t.get("name") or reg)
        nm = self._national_counts(reg)
        if self._national_done(nm):
            self.db.complete_course_history_targets([(reg, jcd)])
            return

        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
            "Accept-Language": "ja,en-US;q=0.8,en;q=0.6",
        })

        scan_day = datetime.now(JST).date() - timedelta(days=1)
        api_floor = datetime(2026, 1, 1, tzinfo=JST).date()
        checked_days = 0
        verified = 0
        candidate_total = 0
        saved = 0
        skipped = 0
        lastdiag = {}
        seen_races = set()

        try:
            while scan_day >= api_floor:
                nm = self._national_counts(reg)
                if self._national_done(nm):
                    break

                ymd = scan_day.strftime("%Y%m%d")
                candidates, lastdiag = self._fetch_candidate_day(session, reg, ymd)
                checked_days += 1
                candidate_total += len(candidates)
                self.status.update({
                    "checked_days": checked_days,
                    "crawl_list_pages": checked_days,
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                    "national_counts": nm,
                })

                for idx, cand in enumerate(candidates, 1):
                    key = (cand["date"], cand["jcd"], int(cand["rno"]))
                    if key in seen_races:
                        continue
                    seen_races.add(key)
                    nm = self._national_counts(reg)
                    if self._national_done(nm):
                        break

                    self.status.update({
                        "phase": "BOAT RACE公式結果で実進入確認中",
                        "crawl_stage": f"{ymd} 候補 {idx}/{len(candidates)} → 場{cand['jcd']} {cand['rno']}R",
                        "last_fetch_state": "verifying official result",
                        "direct_source": self._official_result_url(cand),
                        "crawl_detail_pages": verified,
                        "crawl_elapsed_seconds": int(time.monotonic() - started),
                        "last_parsed_rows": saved,
                        "last_matched_rows": verified,
                        "checked_days": checked_days,
                        "national_counts": nm,
                    })

                    row, detaildiag = self._fetch_official_run(session, cand, reg)
                    verified += 1
                    lastdiag = detaildiag
                    if row is None:
                        skipped += 1
                        continue

                    course = int(row["course"])
                    nm = self._national_counts(reg)
                    if nm.get(course, 0) >= 10:
                        continue

                    self.db.save_course_history_runs([row], keep_per_local_course=10)
                    saved += 1
                    nm = self._national_counts(reg)
                    self.status.update({
                        "last_fetch_state": "official result saved",
                        "last_parsed_rows": saved,
                        "last_matched_rows": verified,
                        "last_fetch_date": row["date"],
                        "national_counts": nm,
                        "crawl_detail_pages": verified,
                        "crawl_elapsed_seconds": int(time.monotonic() - started),
                        "last_verified_run": f"{row['date']} 場{row['jcd']} {row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    })

                scan_day -= timedelta(days=1)

            nm = self._national_counts(reg)
            if self._national_done(nm):
                self.db.complete_course_history_targets([(reg, jcd)])
                phase = f"{name} 全国1〜6C 各直近10走の確認完了"
            else:
                phase = f"{name} 2026年確認終了・不足コースあり（次段階で2025〜2023対応）"

            self.status = {
                **self.db.get_course_history_target_status(today, VALIDATION_REG),
                "phase": phase,
                "validation_mode": "峰竜太（4320）全国・日別候補→公式結果照合方式",
                "current_racer": name,
                "current_registration_no": reg,
                "last_fetch_state": "complete" if self._national_done(nm) else "2026 scan complete",
                "last_parsed_rows": saved,
                "last_matched_rows": verified,
                "crawl_list_pages": checked_days,
                "crawl_detail_pages": verified,
                "crawl_elapsed_seconds": int(time.monotonic() - started),
                "crawl_stage": f"日別確認 {checked_days}日 → 候補 {candidate_total}走 → 公式結果 {verified}走確認 → 実進入別保存 {saved}走 / 除外 {skipped}走",
                "national_counts": nm,
                "local_counts": {},
                "checked_days": checked_days,
                "direct_source": lastdiag.get("url"),
                "note": "v17.204。ChatGPTで検証した流れと同じく、候補レースを新しい日から拾い、各候補をBOAT RACE公式結果で実進入確認して1〜6Cへ振り分ける。峰4320は2026年内で各10走到達する想定。",
            }
        except Exception as e:
            self.db.mark_course_history_target_errors([(reg, jcd)], str(self.status.get("scan_date") or ""), f"{type(e).__name__}: {e}", 3)
            self.status = {
                **self.db.get_course_history_target_status(today, VALIDATION_REG),
                "phase": "峰竜太の全国履歴収集エラー",
                "validation_mode": "峰竜太（4320）全国・日別候補→公式結果照合方式",
                "current_racer": name,
                "current_registration_no": reg,
                "scheduler_error": f"{type(e).__name__}: {e}",
                "crawl_elapsed_seconds": int(time.monotonic() - started),
                "national_counts": self._national_counts(reg),
                "checked_days": checked_days,
            }

