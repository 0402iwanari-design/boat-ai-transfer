from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import requests
from bs4 import BeautifulSoup

JST = timezone(timedelta(hours=9), name="JST")
JMA_URL = "https://www.data.jma.go.jp/kaiyou/db/tide/suisan/suisan.php"

# Fixed venue knowledge. Daily web access is disabled for venues where tide is not
# useful enough to justify another collector. station_status=verified means the
# JMA station is suitable for automatic collection; candidate mappings remain
# replaceable without touching collector/AI code.
TIDE_VENUE_MASTER = {
    "01": dict(name="桐生", enabled=False, importance="OFF", water="淡水"),
    "02": dict(name="戸田", enabled=False, importance="OFF", water="淡水"),
    "03": dict(name="江戸川", enabled=True, importance="VERY_HIGH", water="汽水", station="TK", station_name="東京", station_status="candidate", special="河川。潮向・流速と風の複合評価を優先"),
    "04": dict(name="平和島", enabled=True, importance="MEDIUM", water="海水", station="TK", station_name="東京", station_status="candidate"),
    "05": dict(name="多摩川", enabled=False, importance="OFF", water="淡水"),
    "06": dict(name="浜名湖", enabled=True, importance="LOW", water="汽水", station="MI", station_name="舞阪", station_status="candidate"),
    "07": dict(name="蒲郡", enabled=True, importance="LOW", water="汽水", station="G4", station_name="三河", station_status="candidate"),
    "08": dict(name="常滑", enabled=False, importance="OFF", water="海水", special="水位自動制御・潮位変化を予想補正に使わない"),
    "09": dict(name="津", enabled=False, importance="OFF", water="海水"),
    "10": dict(name="三国", enabled=False, importance="OFF", water="淡水"),
    "11": dict(name="びわこ", enabled=False, importance="OFF", water="淡水"),
    "12": dict(name="住之江", enabled=False, importance="OFF", water="淡水"),
    "13": dict(name="尼崎", enabled=False, importance="OFF", water="淡水"),
    "14": dict(name="鳴門", enabled=True, importance="HIGH", water="海水", station="KM", station_name="小松島", station_status="candidate"),
    "15": dict(name="丸亀", enabled=True, importance="VERY_HIGH", water="海水", station="TA", station_name="高松", station_status="candidate"),
    "16": dict(name="児島", enabled=True, importance="VERY_HIGH", water="海水", station="UN", station_name="宇野", station_status="verified", special="場公式潮汐表が宇野港基準を明記"),
    "17": dict(name="宮島", enabled=True, importance="VERY_HIGH", water="海水", station="Q8", station_name="広島", station_status="candidate"),
    "18": dict(name="徳山", enabled=True, importance="VERY_HIGH", water="海水", station="QA", station_name="徳山", station_status="verified"),
    # 関門系は場公式との照合余地を残す。現段階では日次自動取得を無理に有効化しない。
    "19": dict(name="下関", enabled=False, importance="CONDITIONAL", water="海水", station=None, station_name="関門系", station_status="pending", special="通常影響小・高潮位時のみ条件発動。対応地点確定後ON"),
    "20": dict(name="若松", enabled=False, importance="VERY_HIGH", water="海水", station=None, station_name="関門系", station_status="pending", special="場公式潮見表との対応地点確定後ON"),
    "21": dict(name="芦屋", enabled=False, importance="OFF", water="淡水"),
    "22": dict(name="福岡", enabled=True, importance="VERY_HIGH", water="海水", station="QF", station_name="博多", station_status="verified"),
    "23": dict(name="唐津", enabled=False, importance="OFF", water="海水"),
    "24": dict(name="大村", enabled=False, importance="MEDIUM", water="海水", station=None, station_name="大村湾系", station_status="pending", special="対応地点確定後ON"),
}


def _date_key(d: datetime) -> str:
    return d.strftime("%Y%m%d")


def _parse_jma_html(html: str, wanted_dates: set[str]) -> dict[str, dict[str, Any]]:
    """Parse JMA tide tables by row shape, independent of cosmetic HTML changes."""
    soup = BeautifulSoup(html, "html.parser")
    out: dict[str, dict[str, Any]] = {d: {"hourly": None, "high": [], "low": []} for d in wanted_dates}
    date_re = re.compile(r"(20\d{2})[/-](\d{1,2})[/-](\d{1,2})")
    time_re = re.compile(r"^\d{1,2}:\d{2}$")
    int_re = re.compile(r"^-?\d+$")
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
        if not cells:
            continue
        m = date_re.search(cells[0])
        if not m:
            continue
        key = f"{int(m.group(1)):04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"
        if key not in out:
            continue
        rest = cells[1:]
        numeric = []
        for x in rest:
            s = x.replace("−", "-").strip()
            if int_re.fullmatch(s):
                numeric.append(int(s))
        # Hourly table has exactly/at least 24 consecutive numeric values after date.
        if len(numeric) >= 24 and out[key]["hourly"] is None:
            out[key]["hourly"] = numeric[:24]
            continue
        # High/low table: collect time+following numeric level. JMA order is highs then lows.
        pairs = []
        i = 0
        while i < len(rest) - 1:
            t = rest[i].strip()
            lv = rest[i + 1].replace("−", "-").replace("#", "").strip()
            if time_re.fullmatch(t) and int_re.fullmatch(lv):
                pairs.append({"time": t, "level_cm": int(lv)})
                i += 2
            else:
                i += 1
        if pairs:
            # JMA table exposes up to four high then up to four low columns. In ordinary
            # days 2+2 pairs are returned; split by local extrema against hourly values
            # when possible, otherwise use first half as high and second as low.
            hourly = out[key].get("hourly")
            if hourly:
                for p in pairs:
                    hh, mm = map(int, p["time"].split(":"))
                    prevv = hourly[(hh - 1) % 24]
                    nextv = hourly[(hh + 1) % 24]
                    (out[key]["high"] if p["level_cm"] >= max(prevv, nextv) else out[key]["low"]).append(p)
            else:
                half = (len(pairs) + 1) // 2
                out[key]["high"] = pairs[:half]
                out[key]["low"] = pairs[half:]
    return out


class TideCollector:
    """Independent daily tide collector. Never participates in 15m/30s/final-odds loops."""
    def __init__(self, db):
        self.db = db
        self.running = False
        self.thread = None
        self.stop_event = threading.Event()
        self.status = {
            "running": False, "phase": "待機中", "last_run": None, "last_success": None,
            "last_error": None, "next_run": None, "days_ahead": 7,
            "enabled_venues": [v["name"] for v in TIDE_VENUE_MASTER.values() if v.get("enabled")],
            "pending_mapping": [v["name"] for v in TIDE_VENUE_MASTER.values() if v.get("station_status") == "pending"],
            "saved_rows": 0, "source": "気象庁 潮位表（天文潮位）",
        }
        self._sync_master()

    def _sync_master(self):
        with self.db.connect() as con:
            for jcd, v in TIDE_VENUE_MASTER.items():
                con.execute("""INSERT INTO tide_venue_master
                    (jcd,venue_name,enabled,importance,water_type,station_code,station_name,station_status,time_offset_minutes,special_rule,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(jcd) DO UPDATE SET venue_name=excluded.venue_name,enabled=excluded.enabled,
                    importance=excluded.importance,water_type=excluded.water_type,station_code=excluded.station_code,
                    station_name=excluded.station_name,station_status=excluded.station_status,special_rule=excluded.special_rule,updated_at=CURRENT_TIMESTAMP""",
                    (jcd,v["name"],1 if v.get("enabled") else 0,v.get("importance"),v.get("water"),v.get("station"),v.get("station_name"),v.get("station_status"),0,v.get("special")))

    def start(self):
        if self.running:
            return
        self.running = True
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._loop, name="tide-daily-collector", daemon=True)
        self.thread.start()

    def _next_0430(self, now: datetime) -> datetime:
        target = now.replace(hour=4, minute=30, second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)
        return target

    def _has_today(self, today: str) -> bool:
        enabled = sum(1 for v in TIDE_VENUE_MASTER.values() if v.get("enabled") and v.get("station"))
        with self.db.connect() as con:
            row = con.execute("SELECT COUNT(*) n FROM tide_daily WHERE date=? AND status='OK'", (today,)).fetchone()
        return int(row["n"] or 0) >= enabled

    def _loop(self):
        # Startup recovery: if today's cache is missing, collect immediately. This is
        # intentionally independent of BackgroundCollector.
        while not self.stop_event.is_set():
            now = datetime.now(JST)
            today = _date_key(now)
            if not self._has_today(today):
                ok = False
                for attempt in range(1, 7):
                    if self.stop_event.is_set(): return
                    self.status.update(phase=f"潮データ取得中 {attempt}/6", last_error=None)
                    try:
                        self.collect(days=7)
                        ok = True
                        break
                    except Exception as e:
                        self.status["last_error"] = f"{type(e).__name__}: {e}"
                        self.status["phase"] = f"取得失敗・5分後再試行 {attempt}/6"
                        if attempt < 6:
                            self.stop_event.wait(300)
                if not ok:
                    self.status["phase"] = "収集エラー（既存収集・AIは継続）"
            nxt = self._next_0430(datetime.now(JST))
            self.status["next_run"] = nxt.isoformat()
            if self.status.get("phase") != "収集エラー（既存収集・AIは継続）":
                self.status["phase"] = "取得済み・次回待機"
            wait = max(30, (nxt - datetime.now(JST)).total_seconds())
            self.stop_event.wait(wait)

    def collect(self, days: int = 7):
        now = datetime.now(JST)
        dates = [now + timedelta(days=i) for i in range(days)]
        wanted = {_date_key(d) for d in dates}
        # One request per station, not per venue/race. Venues sharing a station share data.
        stations: dict[str, list[str]] = {}
        for jcd, v in TIDE_VENUE_MASTER.items():
            if v.get("enabled") and v.get("station"):
                stations.setdefault(v["station"], []).append(jcd)
        saved = 0
        session = requests.Session()
        session.headers.update({"User-Agent": "BOAT-AI-Lab/17.159 tide-cache"})
        for station, jcds in stations.items():
            first, last = dates[0], dates[-1]
            params = {"LV":"DL","S_HILO":"on","S_HOUR":"on","stn":station,
                      "ys":first.year,"ms":f"{first.month:02d}","ds":f"{first.day:02d}",
                      "ye":last.year,"me":f"{last.month:02d}","de":f"{last.day:02d}"}
            r = session.get(JMA_URL, params=params, timeout=20)
            r.raise_for_status()
            r.encoding = r.apparent_encoding or "utf-8"
            parsed = _parse_jma_html(r.text, wanted)
            for jcd in jcds:
                v = TIDE_VENUE_MASTER[jcd]
                for date, data in parsed.items():
                    status = "OK" if data.get("hourly") and len(data["hourly"]) == 24 else "ERROR"
                    with self.db.connect() as con:
                        con.execute("""INSERT INTO tide_daily
                            (date,jcd,station_code,station_name,high_tides_json,low_tides_json,hourly_levels_json,source,fetched_at,status,error_message)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?)
                            ON CONFLICT(date,jcd) DO UPDATE SET station_code=excluded.station_code,station_name=excluded.station_name,
                            high_tides_json=excluded.high_tides_json,low_tides_json=excluded.low_tides_json,
                            hourly_levels_json=excluded.hourly_levels_json,source=excluded.source,fetched_at=excluded.fetched_at,
                            status=excluded.status,error_message=excluded.error_message""",
                            (date,jcd,station,v.get("station_name"),json.dumps(data.get("high") or [],ensure_ascii=False),
                             json.dumps(data.get("low") or [],ensure_ascii=False),json.dumps(data.get("hourly"),ensure_ascii=False),
                             "JMA astronomical tide",datetime.now(JST).isoformat(),status,None if status=="OK" else "毎時潮位24点を確認できませんでした"))
                    if status == "OK": saved += 1
        self.status.update(running=True, phase="取得完了", last_run=now.isoformat(), last_success=datetime.now(JST).isoformat(), saved_rows=saved, last_error=None)
        return saved

    def day_status(self, date: str) -> dict[str, Any]:
        with self.db.connect() as con:
            rows = con.execute("""SELECT d.*,m.venue_name,m.importance,m.station_status FROM tide_daily d
                LEFT JOIN tide_venue_master m ON m.jcd=d.jcd WHERE d.date=? ORDER BY d.jcd""", (date,)).fetchall()
            master = con.execute("SELECT * FROM tide_venue_master ORDER BY jcd").fetchall()
        return {"date":date,"rows":[dict(r) for r in rows],"master":[dict(r) for r in master]}
