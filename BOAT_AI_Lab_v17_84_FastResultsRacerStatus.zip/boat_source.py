from __future__ import annotations

from ai_predictor import predict as ai_predict, build_venue_profile
from datetime import datetime, timezone, timedelta
import threading
import re
import hashlib
import json
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any

import requests
from bs4 import BeautifulSoup

from cache import FileCache
from db import BoatDB
from venue_comments import fetch_venue_comments
from parser import (
    parse_meeting_day, parse_race_index, parse_race_list, parse_race_deadline, parse_deadline_from_saved_text, parse_venue_meta, grade_markup_diagnostic,
    parse_before_info, parse_odds3t, parse_odds3t_recovery, parse_odds3t_for_active_lanes, parse_odds3t_matrix, parse_result_list,
    parse_result_detail,
)

BASE = "https://www.boatrace.jp"


class BoatRaceSource:
    def __init__(self):
        self.cache = FileCache()
        self.db = BoatDB()
        self._local = threading.local()
        self._local_frame_stats_cache = {}
        self._racer_course_stats_cache = {}

        names = [
            "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
            "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村"
        ]
        self.venues = [
            {"code": f"{i:02d}", "name": name}
            for i, name in enumerate(names, start=1)
        ]

    def _save_grade_diagnostic(self, yyyymmdd: str, venue: dict, html: str, meta: dict):
        """Keep markup evidence locally; it helps fix an official layout change without guessing."""
        local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
        directory = Path(local_app) / "BOAT_AI_Lab" / "diagnostics" / "grade_markup"
        directory.mkdir(parents=True, exist_ok=True)
        payload = {
            "date": yyyymmdd, "jcd": venue.get("code"), "venue": venue.get("name"),
            "parsed_grade": meta.get("event_grade"), "parsed_title": meta.get("event_title"),
            **grade_markup_diagnostic(html),
        }
        (directory / f"{yyyymmdd}_{str(venue.get('code')).zfill(2)}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def _session(self):
        session = getattr(self._local, "session", None)
        if session is None:
            session = requests.Session()
            session.headers.update({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36"
            })
            self._local.session = session
        return session

    def _decode_response_like_diagnostic(self, response) -> tuple[str, str]:
        candidates = []
        seen = set()

        for enc in [
            response.encoding,
            response.apparent_encoding,
            "utf-8",
            "cp932",
            "shift_jis",
            "euc_jp",
        ]:
            if not enc:
                continue
            key = str(enc).lower()
            if key in seen:
                continue
            seen.add(key)
            try:
                text = response.content.decode(enc, errors="replace")
                candidates.append((enc, text))
            except Exception:
                pass

        def score(item):
            enc, text = item
            s = 0
            for token in ["締切予定時刻", "締切", "戸田", "1R", "12R"]:
                if token in text:
                    s += 20
            s += min(
                len(re.findall(r"(?<!\d)\d{1,2}:\d{2}(?!\d)", text)),
                30,
            )
            return s

        candidates.sort(key=score, reverse=True)
        if candidates:
            return candidates[0][1], str(candidates[0][0])

        return response.text, str(response.encoding or "unknown")

    def _get(
        self,
        url: str,
        ttl: int = 300,
        *,
        fresh: bool = False,
        diagnostic_label: str | None = None,
    ) -> str:
        key = "html_v13_" + hashlib.sha256(
            url.encode("utf-8")
        ).hexdigest()

        if not fresh:
            cached = self.cache.get(key, ttl)
            if cached is not None:
                return cached

        response = self._session().get(url, timeout=(5.0, 15.0))
        response.raise_for_status()

        html, selected_encoding = self._decode_response_like_diagnostic(response)

        if diagnostic_label:
            print(
                f"[HTTP] {diagnostic_label} OK "
                f"status={response.status_code} bytes={len(response.content)} "
                f"encoding={selected_encoding}",
                flush=True,
            )

        self.cache.set(key, html)
        return html

    def _probe_venue(self, yyyymmdd: str, venue: dict):
        """
        One official racelist page contains the whole 1R-12R schedule.
        Use that page as the single source for venue-open + deadlines.
        """
        jcd = venue["code"]
        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )

        try:
            html = self._get(url, ttl=1800)
            races = parse_race_index(html)
            venue_meta = parse_venue_meta(html)
            if not venue_meta.get("event_grade"):
                self._save_grade_diagnostic(yyyymmdd, venue, html, venue_meta)
            meeting_day = parse_meeting_day(html, yyyymmdd)
            is_open = len(races) == 12

            if is_open:
                self.db.save_race_schedule(
                    yyyymmdd,
                    jcd,
                    races,
                    source="racelist-schedule",
                )
                if meeting_day:
                    self.db.save_meeting_day(
                        yyyymmdd, jcd, meeting_day.get("number"),
                        meeting_day.get("label"), meeting_day.get("official_label"),
                        source="racelist-schedule-and-grade",
                    )

            return {
                **venue,
                "event_grade": venue_meta.get("event_grade"),
                "event_title": venue_meta.get("event_title"),
                "meeting_day_number": (meeting_day or {}).get("number"),
                "meeting_day_label": (meeting_day or {}).get("label"),
                "meeting_day_official_label": (meeting_day or {}).get("official_label"),
                "open": is_open,
                "races": races if is_open else [],
                "source_url": url,
            }

        except Exception as e:
            return {
                **venue,
                "open": False,
                "races": [],
                "error": str(e),
                "source_url": url,
            }

    def _validate_requested_racelist_date(
        self,
        html: str,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Guard against the official site's UI/default date being the previous
        day during the early-morning window.

        Requests always carry hd=YYYYMMDD explicitly. We additionally verify
        that the returned racelist exposes the requested month/day somewhere
        in its official date navigation/text before saving it.
        """
        if not html or len(yyyymmdd) != 8:
            raise RuntimeError("出走表の日付検証に必要なHTML/日付がありません")

        month = int(yyyymmdd[4:6])
        day = int(yyyymmdd[6:8])
        text = BeautifulSoup(html, "html.parser").get_text(" ")
        text = text.translate(
            str.maketrans("０１２３４５６７８９", "0123456789")
        )
        text = re.sub(r"\\s+", "", text)

        wanted = f"{month}月{day}日"
        if wanted not in text:
            raise RuntimeError(
                f"公式出走表の日付検証失敗: "
                f"要求={yyyymmdd} 場={str(jcd).zfill(2)} {int(rno)}R "
                f"（前日等のページを保存しません）"
            )
        return True


    def ensure_meeting_day(
        self,
        yyyymmdd: str,
        jcd: str,
        force: bool = False,
    ):
        """
        Ensure current meeting-day metadata exists for one venue.

        This is intentionally independent from the saved 1R-12R deadlines.
        Older versions returned early once deadlines existed, which meant a
        venue could stay "開催日数取得中" forever.
        """
        jcd = str(jcd).zfill(2)

        saved = self.db.get_day_meeting_days(yyyymmdd).get(jcd)
        if (
            not force
            and saved
            and saved.get("number") is not None
            and saved.get("label")
        ):
            return {
                "ok": True,
                "jcd": jcd,
                **saved,
                "source": saved.get("source") or "db",
                "stage": "verified",
            }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )
        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} meeting-day racelist 1R",
        )

        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, 1
        )
        parsed = parse_meeting_day(html, yyyymmdd)
        if not parsed:
            # Keep diagnostics useful without falsely writing day 1.
            sample = re.sub(
                r"\s+", " ",
                BeautifulSoup(html, "html.parser").get_text(" ")
            )
            date_token = (
                f"{int(yyyymmdd[4:6])}月"
                f"{int(yyyymmdd[6:8])}日"
            )
            pos = sample.find(date_token)
            snippet = sample[max(0, pos-100):pos+220] if pos >= 0 else ""
            raise RuntimeError(
                f"開催日数解析失敗: {jcd} {yyyymmdd}"
                + (f" / date周辺={snippet[:300]}" if snippet else "")
            )

        self.db.save_meeting_day(
            yyyymmdd,
            jcd,
            parsed.get("number"),
            parsed.get("label"),
            parsed.get("official_label"),
            source="boatrace-official-racelist-v17.43",
        )

        print(
            f"[MEETING-DAY] {jcd} "
            f"{parsed.get('label')} saved",
            flush=True,
        )

        return {
            "ok": True,
            "jcd": jcd,
            **parsed,
            "source": "boatrace.jp",
            "source_url": url,
            "stage": "saved",
        }


    def ensure_venue_schedule(self, yyyymmdd: str, jcd: str):
        """
        Ensure the venue has all 12 deadlines persisted.
        One racelist page (rno=1) contains the venue's 1R-12R schedule.
        This is independent from race-finished status.
        """
        jcd = str(jcd).zfill(2)
        saved = self.db.get_race_schedule(yyyymmdd, jcd)
        saved_by_rno = {
            int(x["rno"]): x.get("deadline")
            for x in saved
            if x.get("deadline")
        }

        if len(saved_by_rno) >= 12:
            meeting_saved = self.db.get_day_meeting_days(
                yyyymmdd
            ).get(jcd)
            if not meeting_saved or meeting_saved.get("number") is None:
                self.ensure_meeting_day(
                    yyyymmdd, jcd, force=True
                )
            return {
                "complete": True,
                "saved": len(saved_by_rno),
                "source": "db",
            }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )
        html = self._get(url, ttl=300)
        races = parse_race_index(html)

        if len(races) == 12:
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                races,
                source="racelist-page-schedule-backfill",
            )
            return {
                "complete": True,
                "saved": 12,
                "source": "official-racelist",
            }

        return {
            "complete": False,
            "saved": len(saved_by_rno),
            "parsed": len(races),
            "source": "official-racelist",
        }

    def get_day_fast(self, yyyymmdd: str) -> Dict[str, Any]:
        """
        UI向け高速開催情報。
        締切時刻は共通DBのrace_scheduleを最優先で利用する。
        """
        db_presence = self.db.get_racelist_presence(yyyymmdd)
        db_schedule = self.db.get_day_schedule(yyyymmdd)
        db_meeting_days = self.db.get_day_meeting_days(yyyymmdd)
        cached = self.cache.get(f"day_v16_{yyyymmdd}", 3600)

        by_code = {}
        if cached:
            for v in cached.get("venues", []):
                by_code[str(v.get("code")).zfill(2)] = dict(v)

        items = []

        for venue in self.venues:
            code = venue["code"]
            saved_rnos = sorted(set(db_presence.get(code, [])))
            schedule_rows = db_schedule.get(code, [])
            schedule_by_rno = {int(r["rno"]): r for r in schedule_rows}

            item = by_code.get(code, {
                **venue,
                "open": False,
                "races": [],
            })

            cached_races = {
                int(r.get("rno")): dict(r)
                for r in (item.get("races") or [])
                if r.get("rno") is not None
            }

            known_rnos = sorted(
                set(saved_rnos)
                | set(schedule_by_rno.keys())
                | set(cached_races.keys())
            )

            if known_rnos:
                races = []
                for rno in known_rnos:
                    deadline = None
                    if rno in schedule_by_rno:
                        deadline = schedule_by_rno[rno].get("deadline")
                    if not deadline and rno in cached_races:
                        deadline = cached_races[rno].get("deadline")

                    races.append({
                        "rno": rno,
                        "deadline": deadline,
                        "source": "db-schedule" if rno in schedule_by_rno else "cache",
                    })

                item = {
                    **item,
                    "open": True,
                    "races": races,
                    "restored_from_db": True,
                }

            meeting = db_meeting_days.get(code)
            if meeting:
                item["meeting_day_number"] = meeting.get("number")
                item["meeting_day_label"] = meeting.get("label")
                item["meeting_day_official_label"] = meeting.get("official_label")

            items.append(item)

        return {
            "date": yyyymmdd,
            "open_count": sum(1 for x in items if x.get("open")),
            "venues": items,
            "fast": True,
            "official_cached": bool(cached),
            "db_restored_count": sum(1 for x in items if x.get("restored_from_db")),
            "deadline_saved_count": sum(len(v) for v in db_schedule.values()),
        }

    def get_day(self, yyyymmdd: str) -> Dict[str, Any]:
        """
        Day/open-venue detection with DB fallback.

        Rules:
        1) Try official-site venue detection.
        2) If official parsing says "closed" but the shared DB already has
           racelists for that venue/date, restore it as open.
        3) Never persist an obviously broken "all 24 venues closed" result
           when the DB proves races exist.
        """
        cache_key = f"day_v16_{yyyymmdd}"
        cached = self.cache.get(cache_key, 120)

        db_presence = self.db.get_racelist_presence(yyyymmdd)

        # Cached result is acceptable only if it is not contradicted by DB.
        if cached is not None:
            cached_open = {
                str(v.get("code")).zfill(2)
                for v in cached.get("venues", [])
                if v.get("open")
            }
            db_open = set(db_presence.keys())

            if not db_open or db_open.issubset(cached_open):
                return cached

        by_code = {}

        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="boat-day") as pool:
            futures = {
                pool.submit(self._probe_venue, yyyymmdd, venue): venue["code"]
                for venue in self.venues
            }

            for future in as_completed(futures):
                code = futures[future]
                try:
                    by_code[code] = future.result()
                except Exception as e:
                    venue = next(v for v in self.venues if v["code"] == code)
                    by_code[code] = {
                        **venue,
                        "open": False,
                        "races": [],
                        "error": str(e),
                    }

        items = []

        for venue in self.venues:
            code = venue["code"]
            item = by_code.get(code, {
                **venue,
                "open": False,
                "races": [],
            })

            saved_rnos = sorted(set(db_presence.get(code, [])))

            # Official parser failed / returned closed, but DB proves this venue
            # has today's racelists. Restore it as open.
            if saved_rnos and not item.get("open"):
                existing_races = item.get("races") or []
                by_rno = {
                    int(r.get("rno")): dict(r)
                    for r in existing_races
                    if r.get("rno") is not None
                }

                restored = []
                for rno in range(1, 13):
                    if rno in by_rno:
                        restored.append(by_rno[rno])
                    elif rno in saved_rnos:
                        restored.append({
                            "rno": rno,
                            "deadline": None,
                            "source": "db-fallback",
                        })

                item = {
                    **item,
                    "open": True,
                    "races": restored,
                    "restored_from_db": True,
                }

            # If official detection succeeded but omitted some saved race cards,
            # merge the DB-known races rather than hiding them.
            elif item.get("open") and saved_rnos:
                existing_races = item.get("races") or []
                by_rno = {
                    int(r.get("rno")): dict(r)
                    for r in existing_races
                    if r.get("rno") is not None
                }
                for rno in saved_rnos:
                    by_rno.setdefault(rno, {
                        "rno": rno,
                        "deadline": None,
                        "source": "db-fallback",
                    })
                item["races"] = [by_rno[r] for r in sorted(by_rno)]

            items.append(item)

        open_count = sum(1 for x in items if x.get("open"))

        # 締切予定時刻は当日の固定基本データとして共通DBへ保存。
        for item in items:
            if not item.get("open"):
                continue

            fixed_schedule = [
                {
                    "rno": int(r["rno"]),
                    "deadline": r.get("deadline"),
                }
                for r in (item.get("races") or [])
                if r.get("rno") is not None and r.get("deadline")
            ]

            if fixed_schedule:
                self.db.save_race_schedule(
                    yyyymmdd,
                    item["code"],
                    fixed_schedule,
                    source="boatrace-official",
                )

        data = {
            "date": yyyymmdd,
            "open_count": open_count,
            "venues": items,
            "db_restored_count": sum(1 for x in items if x.get("restored_from_db")),
        }

        # Save only meaningful day data. Do not poison shared cache with
        # "all closed" when DB contains today's racelists.
        if open_count > 0 or not db_presence:
            self.cache.set(cache_key, data)

        return data

    def load_official_venue_schedule(
        self,
        yyyymmdd: str,
        jcd: str,
        force: bool = False,
    ):
        jcd = str(jcd).zfill(2)

        if not force:
            saved = self.db.get_race_schedule(yyyymmdd, jcd)
            saved_map = {
                int(x["rno"]): x.get("deadline")
                for x in saved
                if x.get("deadline")
            }
            if len(saved_map) == 12:
                # Deadlines may be old/complete while meeting-day metadata is
                # missing. Repair that independently before returning.
                meeting_saved = self.db.get_day_meeting_days(
                    yyyymmdd
                ).get(jcd)
                if not meeting_saved or meeting_saved.get("number") is None:
                    self.ensure_meeting_day(
                        yyyymmdd, jcd, force=True
                    )

                print(
                    f"[SCHEDULE] {jcd} DB already has 12/12 deadlines",
                    flush=True,
                )
                return {
                    "ok": True,
                    "jcd": jcd,
                    "races": [
                        {"rno": rno, "deadline": saved_map[rno]}
                        for rno in range(1, 13)
                    ],
                    "source": "db",
                    "stage": "verified",
                }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )

        print(f"[SCHEDULE] {jcd} 1-12R deadline HTML fetching...", flush=True)

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} racelist 1R",
        )

        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, 1
        )
        meeting_day = parse_meeting_day(html, yyyymmdd)
        if meeting_day:
            self.db.save_meeting_day(
                yyyymmdd,
                jcd,
                meeting_day.get("number"),
                meeting_day.get("label"),
                meeting_day.get("official_label"),
                source="boatrace-official-racelist",
            )
            print(
                f"[MEETING] {jcd} {meeting_day.get('label')} saved",
                flush=True,
            )

        keyword_found = "締切予定時刻" in html
        print(
            f"[SCHEDULE] {jcd} keyword "
            f"'締切予定時刻'={'FOUND' if keyword_found else 'NOT FOUND'}",
            flush=True,
        )

        pos = html.find("締切予定時刻")
        raw_times = []
        if pos >= 0:
            window = html[pos:pos + 5000]
            raw_times = re.findall(
                r"(?<!\d)(\d{1,2}:\d{2})(?!\d)",
                window,
            )

        print(
            f"[SCHEDULE] {jcd} raw time candidates after label={len(raw_times)}",
            flush=True,
        )

        races = parse_race_index(html)

        print(
            f"[SCHEDULE] {jcd} parser={len(races)}/12 "
            f"{[x.get('deadline') for x in races]}",
            flush=True,
        )

        if len(races) != 12:
            raise RuntimeError(
                f"締切解析失敗: keyword={keyword_found}, "
                f"raw_times={len(raw_times)}, parser={len(races)}/12"
            )

        actual_rnos = [int(x["rno"]) for x in races]
        if actual_rnos != list(range(1, 13)):
            raise RuntimeError(f"R番号対応失敗: {actual_rnos}")

        print(f"[SCHEDULE] {jcd} DB saving 12 deadlines...", flush=True)

        self.db.save_race_schedule(
            yyyymmdd,
            jcd,
            races,
            source="boatrace-official-diagnostic-path",
        )

        saved = self.db.get_race_schedule(yyyymmdd, jcd)
        saved_map = {
            int(x["rno"]): x.get("deadline")
            for x in saved
            if x.get("deadline")
        }

        print(f"[SCHEDULE] {jcd} DB readback={len(saved_map)}/12", flush=True)

        if len(saved_map) != 12:
            raise RuntimeError(f"締切DB保存後検証失敗: {len(saved_map)}/12")

        for rno in range(1, 13):
            if not saved_map.get(rno):
                raise RuntimeError(f"締切DB検証失敗: {rno}R missing")

        print(f"[SCHEDULE] {jcd} COMPLETE 12/12", flush=True)

        return {
            "ok": True,
            "jcd": jcd,
            "races": [
                {"rno": rno, "deadline": saved_map[rno]}
                for rno in range(1, 13)
            ],
            "source": "boatrace.jp",
            "source_url": url,
            "stage": "verified",
        }

    def fetch_basic_race_atomic(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        logic_version: str,
    ):
        """
        BOAT RACE公式一本化。

        事前条件:
          その場の1R〜12R締切が race_schedule に保存済み。

        そのRでは:
          racelistページ取得
          -> 6艇解析
          -> 事前保存済み締切とセット
          -> atomic save
          -> read-back verify
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        # Ensure venue schedule first.
        schedule = self.load_official_venue_schedule(
            yyyymmdd, jcd, force=False
        )
        by_rno = {
            int(x["rno"]): x["deadline"]
            for x in schedule["races"]
        }

        deadline = by_rno.get(rno)
        if not deadline:
            raise RuntimeError(
                f"{jcd}-{rno}R 締切時刻が保存されていません"
            )

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(url, ttl=120, diagnostic_label=f"{jcd} {rno}R racelist")
        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, rno
        )
        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )
        racers = parsed.get("racers") or []

        if len(racers) != 6:
            raise ValueError(
                f"基本データ未完成: 出走表 {len(racers)}/6艇"
            )

        # Cross-check schedule from current race page too.
        page_deadline = parse_race_deadline(html, rno)
        if page_deadline and page_deadline != deadline:
            # Current page is more recent; update schedule and use it.
            deadline = page_deadline
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                [{"rno": rno, "deadline": deadline}],
                source="boatrace-official-racelist-crosscheck",
            )

        race_data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
            "deadline": deadline,
            "basic_source": "boatrace.jp",
        }

        self.db.save_basic_race_atomic(
            yyyymmdd,
            jcd,
            rno,
            race_data,
            deadline,
            logic_version,
        )

        verified = self.db.verify_basic_race(
            yyyymmdd,
            jcd,
            rno,
            deadline,
            logic_version,
        )

        if not verified:
            raise RuntimeError(
                "保存後の基本データ検証に失敗"
            )

        return {
            "ok": True,
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "deadline": deadline,
            "racers": 6,
            "saved": True,
            "verified": True,
            "data": race_data,
            "source": "boatrace.jp",
            "source_url": url,
        }

    def _meeting_day_number_from_db(self, yyyymmdd: str, jcd: str):
        try:
            with self.db.connect() as con:
                row = con.execute("""
                    SELECT day_number
                    FROM venue_meeting_day
                    WHERE date=? AND jcd=?
                """, (yyyymmdd, str(jcd).zfill(2))).fetchone()
            if row and row["day_number"] is not None:
                return int(row["day_number"])
        except Exception:
            pass
        return None

    def _meeting_results_racer_count(self, data):
        racers = (data or {}).get("racers") or []
        count = 0
        for x in racers:
            if not isinstance(x, dict):
                continue
            m = x.get("meeting_results")
            if not isinstance(m, dict):
                continue
            if m.get("entries") or m.get("display"):
                count += 1
        return count

    def _racelist_has_meeting_results(self, data):
        # "反映済み" is only considered complete when all six racers have
        # current-meeting records. This prevents a partial 1/6 parse from being
        # reported as success.
        racers = (data or {}).get("racers") or []
        return (
            len(racers) == 6
            and self._meeting_results_racer_count(data) == 6
        )

    def refresh_meeting_results_race(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Dedicated fresh fetch for current-meeting results.

        Used only in the venue-by-venue meeting-results phase so stale
        racelist snapshots/cache cannot hide newly published series results.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R meeting-results fresh",
        )
        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, rno
        )
        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )

        racers = parsed.get("racers") or []
        if len(racers) != 6:
            raise ValueError(
                f"節間成績用出走表が6艇揃っていません: "
                f"{jcd}-{rno} ({len(racers)}艇)"
            )

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        deadline = parse_race_deadline(html, rno)
        if deadline:
            data["deadline"] = deadline
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                [{"rno": rno, "deadline": deadline}],
                source="meeting-results-racelist",
            )

        # Persist parser diagnostics with the fresh snapshot. These fields
        # make it possible to distinguish HTTP success from actual extraction.
        data["meeting_results_racer_count"] = self._meeting_results_racer_count(data)
        data["meeting_results_parser_ok"] = (
            data["meeting_results_racer_count"] == 6
        )

        self.db.save_snapshot(
            yyyymmdd, jcd, rno, "racelist", data
        )

        return data


    def get_race(self, yyyymmdd: str, jcd: str, rno: int):
        """
        出走表は一度6艇そろって保存できたら、そのDBスナップショットを優先利用。
        直前情報・オッズ・結果の取得では絶対に上書きしない。
        大村(24)のみ、通常取得失敗時に予備URLを1回試す。
        """
        jcd = str(jcd).zfill(2)

        # 既に6艇そろって保存済みなら、そのまま返す。
        existing = self.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
        if existing:
            existing_data = existing.get("data") or {}
            racers = existing_data.get("racers") or []

            if len(racers) == 6:
                # First check persistent schedule DB.
                saved_schedule = self.db.get_race_schedule(yyyymmdd, jcd)
                saved_deadline = next(
                    (
                        x.get("deadline")
                        for x in saved_schedule
                        if int(x.get("rno", 0)) == int(rno)
                    ),
                    None
                )

                if saved_deadline:
                    existing_data["deadline"] = saved_deadline

                    # 初日以外は節間成績を重要データとして扱う。
                    # 古いスナップショットに節間成績が無ければ、ここでは
                    # 早期returnせず公式出走表を1回取り直して補完する。
                    meeting_day = self._meeting_day_number_from_db(
                        yyyymmdd, jcd
                    )
                    needs_meeting_refresh = (
                        meeting_day is not None
                        and meeting_day >= 2
                        and not self._racelist_has_meeting_results(existing_data)
                    )

                    if not needs_meeting_refresh:
                        return existing_data

                # Old snapshots contain raw_text from the original official page.
                recovered = parse_deadline_from_saved_text(
                    existing_data.get("raw_text") or "",
                    rno,
                )
                if recovered:
                    existing_data["deadline"] = recovered
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        [{"rno": int(rno), "deadline": recovered}],
                        source="old-racelist-raw-text",
                    )
                    self.db.save_snapshot(
                        yyyymmdd, jcd, rno, "racelist", existing_data
                    )
                    return existing_data

                # If neither DB nor old raw_text has the deadline, do NOT
                # return early. Continue below and fetch the official
                # racelist page once to repair the schedule.

        urls = [
            f"{BASE}/owpc/pc/race/racelist?jcd={jcd}&hd={yyyymmdd}&rno={rno}",
        ]

        # 大村専用フォールバック。公式側でページ遷移や応答差がある場合に備える。
        if jcd == "24":
            urls.append(
                f"{BASE}/owpc/pc/race/pcexpect?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            )

        errors = []

        for idx, url in enumerate(urls):
            try:
                meeting_day = self._meeting_day_number_from_db(
                    yyyymmdd, jcd
                )
                existing_snap = self.db.get_snapshot(
                    yyyymmdd, jcd, rno, "racelist"
                )
                existing_data_for_refresh = (
                    (existing_snap or {}).get("data") or {}
                )
                force_meeting_refresh = (
                    meeting_day is not None
                    and meeting_day >= 2
                    and not self._racelist_has_meeting_results(
                        existing_data_for_refresh
                    )
                )

                html = self._get(
                    url,
                    ttl=900 if idx == 0 else 120,
                    fresh=force_meeting_refresh,
                    diagnostic_label=(
                        f"{jcd} {rno}R racelist meeting-results"
                        if force_meeting_refresh else None
                    ),
                )
                self._validate_requested_racelist_date(
                    html, yyyymmdd, jcd, rno
                )
                meeting_day_info = parse_meeting_day(html, yyyymmdd)
                parsed = parse_race_list(
                    html,
                    meeting_day_no=(meeting_day_info or {}).get("number"),
                )
                data = {
                    "date": yyyymmdd,
                    "jcd": jcd,
                    "rno": rno,
                    "source_url": url,
                    **parsed,
                }

                racers = data.get("racers") or []
                if len(racers) != 6:
                    raise ValueError(
                        f"出走表が6艇揃っていません: {jcd}-{rno} ({len(racers)}艇)"
                    )

                # One racelist page contains the complete venue schedule.
                full_schedule = parse_race_index(html)
                if len(full_schedule) == 12:
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        full_schedule,
                        source="racelist-page-full-schedule",
                    )

                # The racelist page itself is now the primary source for this R's deadline.
                # This ties "racelist saved" and "deadline saved" together.
                deadline = data.get("deadline") or parse_race_deadline(html, rno)
                if deadline:
                    data["deadline"] = deadline
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        [{"rno": int(rno), "deadline": deadline}],
                        source="racelist-page",
                    )

                self.db.save_snapshot(yyyymmdd, jcd, rno, "racelist", data)
                return data

            except Exception as e:
                errors.append(f"{url}: {e}")

        raise RuntimeError(" / ".join(errors))


    def apply_scratch_lanes_to_saved_racelist(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        scratch_lanes,
        source_name: str = "official-odds-matrix",
    ):
        jcd=str(jcd).zfill(2)
        rno=int(rno)
        scratch_set={int(x) for x in (scratch_lanes or [])}

        snap=self.db.get_snapshot(yyyymmdd,jcd,rno,"racelist")
        if not snap:
            return False

        data=snap.get("data") or {}
        racers=data.get("racers") or []
        if len(racers)!=6:
            return False

        updated=[]
        for racer in racers:
            row=dict(racer)
            lane=int(row.get("lane",0))
            row["scratched"]=lane in scratch_set
            row["status"]="欠場" if row["scratched"] else "出走"
            updated.append(row)

        data["racers"]=updated
        data["scratch_lanes"]=sorted(scratch_set)
        data["has_scratch"]=bool(scratch_set)
        data["scratch_source"]=source_name
        data["scratch_checked"]=True

        self.db.save_snapshot(yyyymmdd,jcd,rno,"racelist",data)

        check=self.db.get_snapshot(yyyymmdd,jcd,rno,"racelist")
        cdata=(check or {}).get("data") or {}
        saved=sorted(int(x.get("lane")) for x in (cdata.get("racers") or []) if x.get("scratched"))
        ok=saved==sorted(scratch_set)

        print(
            f"[SCRATCH-OVERWRITE] {jcd} {rno}R "
            f"requested={sorted(scratch_set)} saved={saved} verified={ok}",
            flush=True,
        )
        return ok


    def refresh_scratch_status(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Freshly re-check the official racelist when odds are incomplete.

        If a scratched boat is found:
          - update the saved racelist snapshot
          - preserve richer previously saved racer fields
          - mark the boat as scratched
          - return active lanes and expected odds count
        """
        import time as _time

        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            f"&_scratchcheck={int(_time.time() * 1000)}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R scratch-check",
        )

        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )
        fresh_racers = parsed.get("racers") or []

        existing = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "racelist"
        )
        old_data = (
            (existing or {}).get("data")
            or {}
        )
        old_racers = old_data.get("racers") or []
        old_by_lane = {
            int(x.get("lane", 0)): x
            for x in old_racers
        }

        merged = []
        fresh_by_lane = {
            int(x.get("lane", 0)): x
            for x in fresh_racers
        }

        # Preserve all six saved rows, but refresh scratch flags and any
        # official fields we successfully parsed now.
        for lane in range(1, 7):
            old = dict(old_by_lane.get(lane) or {})
            fresh = dict(fresh_by_lane.get(lane) or {})

            if old and fresh:
                old.update({
                    k: v
                    for k, v in fresh.items()
                    if v is not None
                })
                row = old
            elif fresh:
                row = fresh
            else:
                row = old

            if row:
                # Fresh page is authoritative for scratch status.
                row["scratched"] = bool(
                    fresh.get("scratched", False)
                ) if fresh else bool(
                    row.get("scratched", False)
                )
                row["status"] = (
                    "欠場"
                    if row.get("scratched")
                    else "出走"
                )
                merged.append(row)

        scratch_lanes = sorted([
            int(x["lane"])
            for x in merged
            if x.get("scratched")
        ])

        active_lanes = [
            lane for lane in range(1, 7)
            if lane not in scratch_lanes
        ]

        n = len(active_lanes)
        expected_count = (
            n * (n - 1) * (n - 2)
            if n >= 3
            else 0
        )

        updated = {
            **old_data,
            **parsed,
            "racers": merged,
            "scratch_lanes": scratch_lanes,
            "has_scratch": bool(scratch_lanes),
            "scratch_checked": True,
            "deadline": old_data.get("deadline"),
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
        }

        if len(merged) == 6:
            self.db.save_snapshot(
                yyyymmdd,
                jcd,
                rno,
                "racelist",
                updated,
            )

        print(
            f"[SCRATCH] {jcd} {rno}R "
            f"scratch={scratch_lanes} "
            f"active={active_lanes} "
            f"expected_odds={expected_count}",
            flush=True,
        )

        return {
            "scratch_lanes": scratch_lanes,
            "active_lanes": active_lanes,
            "expected_count": expected_count,
            "racelist": updated,
        }


    def audit_scratch_from_odds(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Dedicated scratch audit.
        Runs independently from odds completeness.

        1) Fresh official odds3t fetch
        2) Parse official odds matrix, including literal "欠場"
        3) Detect scratched lane(s)
        4) Force-overwrite saved racelist
        5) Stamp scratch_audit_version
        6) Read back and verify
        """
        import time as _time

        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/odds3t"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            f"&_scratchaudit={int(_time.time() * 1000)}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R scratch-audit",
        )

        matrix = parse_odds3t_matrix(html)

        records = int(matrix.get("matrix_records") or 0)
        scratch_lanes = [
            int(x)
            for x in (matrix.get("scratch_lanes") or [])
        ]

        print(
            f"[SCRATCH-AUDIT] {jcd} {rno}R "
            f"records={records} "
            f"scratch={scratch_lanes} "
            f"parsed={matrix.get('count')}/"
            f"{matrix.get('expected_count')}",
            flush=True,
        )

        # If the matrix parser couldn't map most of the official board,
        # don't stamp the audit as successful.
        if records < 100:
            raise RuntimeError(
                f"欠場監査用オッズ表の解析不足: records={records}/120"
            )

        snap = self.db.get_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
        )
        if not snap:
            raise RuntimeError("保存済み出走表がありません")

        data = snap.get("data") or {}
        racers = data.get("racers") or []

        if len(racers) != 6:
            raise RuntimeError(
                f"保存済み出走表が6艇ではありません: {len(racers)}/6"
            )

        scratch_set = set(scratch_lanes)
        updated = []

        for racer in racers:
            row = dict(racer)
            lane = int(row.get("lane", 0))
            scratched = lane in scratch_set
            row["scratched"] = scratched
            row["status"] = "欠場" if scratched else "出走"
            updated.append(row)

        data["racers"] = updated
        data["scratch_lanes"] = sorted(scratch_set)
        data["has_scratch"] = bool(scratch_set)
        data["scratch_checked"] = True
        data["scratch_source"] = "official-odds-matrix-audit"
        data["scratch_audit_version"] = "scratch-audit-v1"
        data["scratch_audited_at"] = int(_time.time())

        # Force overwrite even if the racelist was saved long ago.
        self.db.save_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
            data,
        )

        check = self.db.get_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
        )
        cdata = (check or {}).get("data") or {}
        cracers = cdata.get("racers") or []

        saved_scratch = sorted([
            int(x.get("lane"))
            for x in cracers
            if x.get("scratched")
        ])

        verified = (
            cdata.get("scratch_audit_version") == "scratch-audit-v1"
            and saved_scratch == sorted(scratch_lanes)
        )

        if not verified:
            raise RuntimeError(
                f"欠場監査保存後検証失敗: "
                f"expected={sorted(scratch_lanes)} saved={saved_scratch}"
            )

        print(
            f"[SCRATCH-AUDIT-SAVED] {jcd} {rno}R "
            f"scratch={saved_scratch} verified=True",
            flush=True,
        )

        return {
            "ok": True,
            "jcd": jcd,
            "rno": rno,
            "scratch_lanes": saved_scratch,
            "has_scratch": bool(saved_scratch),
            "matrix_records": records,
            "expected_count": matrix.get("expected_count"),
            "odds_count": matrix.get("count"),
            "verified": True,
        }


    def fetch_odds_atomic(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        recovery_level: int = 0,
    ):
        import time as _time
        jcd=str(jcd).zfill(2)
        rno=int(rno)
        base_url=f"{BASE}/owpc/pc/race/odds3t?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        url=base_url
        if recovery_level>=1:
            url=base_url+f"&_recover={int(_time.time()*1000)}"

        if recovery_level>=2:
            s=requests.Session()
            s.headers.update({
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",
                "Cache-Control":"no-cache",
                "Pragma":"no-cache",
            })
            resp=s.get(url,timeout=(5.0,15.0))
            resp.raise_for_status()
            html,enc=self._decode_response_like_diagnostic(resp)
            print(f"[HTTP-RECOVERY] {jcd} {rno}R level=2 status={resp.status_code} bytes={len(resp.content)} encoding={enc}",flush=True)
        else:
            html=self._get(
                url,ttl=0,fresh=True,
                diagnostic_label=f"{jcd} {rno}R odds3t recovery={recovery_level}",
            )

        matrix=parse_odds3t_matrix(html)
        print(
            f"[ODDS-MATRIX] {jcd} {rno}R "
            f"records={matrix.get('matrix_records')} "
            f"scratch={matrix.get('scratch_lanes')} "
            f"parsed={matrix.get('count')}/{matrix.get('expected_count')} "
            f"diag={matrix.get('matrix_diagnostics')}",
            flush=True,
        )

        data=matrix
        odds=data.get("odds") or []
        scratch_lanes=data.get("scratch_lanes") or []
        expected=int(data.get("expected_count") or 120)

        if scratch_lanes:
            if not self.apply_scratch_lanes_to_saved_racelist(
                yyyymmdd,jcd,rno,scratch_lanes,
                source_name="official-odds-matrix",
            ):
                raise RuntimeError(f"欠場フラグの出走表上書き検証に失敗: {scratch_lanes}")

        if len(odds)!=expected and not scratch_lanes:
            if recovery_level==0:
                data=parse_odds3t(html)
                data["parser_method"]="primary"
            else:
                data=parse_odds3t_recovery(html)
            odds=data.get("odds") or []
            expected=120

        combos=[str(x.get("combo") or "") for x in odds]
        if len(odds)!=expected:
            raise ValueError(
                f"3連単オッズ未完成: {len(odds)}/{expected} "
                f"scratch={scratch_lanes} level={recovery_level} "
                f"parser={data.get('parser_method')}"
            )
        if len(set(combos))!=expected:
            raise ValueError(f"3連単オッズ組合せ重複: unique={len(set(combos))}/{expected}")

        scratch_set={str(x) for x in scratch_lanes}
        invalid=[c for c in combos if scratch_set.intersection(c.split("-"))]
        if invalid:
            raise ValueError(f"欠場艇を含む有効オッズを検出: {invalid[:5]}")

        active=[lane for lane in range(1,7) if lane not in set(scratch_lanes)]
        payload={
            "date":yyyymmdd,"jcd":jcd,"rno":rno,
            "source_url":base_url,
            "recovery_level":recovery_level,
            **data,
        }
        payload["expected_count"]=expected
        payload["scratch_lanes"]=scratch_lanes
        payload["active_lanes"]=active
        payload["has_scratch"]=bool(scratch_lanes)
        payload["odds"]=odds
        payload["count"]=len(odds)
        payload["odds_validation_version"]="scratch-matrix-v2"
        payload["scratch_revalidated"]=True

        self.db.save_odds_atomic(yyyymmdd,jcd,rno,payload)
        verified=self.db.verify_odds_snapshot(yyyymmdd,jcd,rno)
        if not verified:
            raise RuntimeError("オッズ保存後のDB検証に失敗")

        return {
            "ok":True,"date":yyyymmdd,"jcd":jcd,"rno":rno,
            "count":len(odds),"expected_count":expected,
            "saved":True,"verified":True,
            "recovery_level":recovery_level,
            "parser_method":payload.get("parser_method"),
            "scratch_lanes":scratch_lanes,
            "active_lanes":active,
            "data":payload,
        }


    def fetch_venue_comments_for_race(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        race = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "racelist"
        )
        racers = ((race or {}).get("data") or {}).get("racers") or []

        result = fetch_venue_comments(
            yyyymmdd,
            jcd,
            rno,
            racers,
        )

        before = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "beforeinfo"
        )
        data = ((before or {}).get("data") or {})

        # Save explicit comment status even when no comment is available.
        data["comments"] = result.get("comments") or []
        data["comments_source_url"] = result.get("source_url")
        data["comments_source_reason"] = result.get("reason")
        data["comments_source_jcd"] = jcd

        # Keep the rest of beforeinfo untouched.
        self.db.save_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "beforeinfo",
            data,
        )

        return result


    def fetch_before_atomic(self, yyyymmdd: str, jcd: str, rno: int):
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        url = (
            f"{BASE}/owpc/pc/race/beforeinfo"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R beforeinfo",
        )

        parsed = parse_before_info(html)
        racers = parsed.get("racers") or []
        starts = parsed.get("start_display") or []
        weather = parsed.get("weather") or {}
        wf = sum(1 for v in weather.values() if v is not None and v != "")

        if not racers and not starts and wf == 0:
            raise ValueError("直前情報未発表または取得不可")

        payload = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        self.db.save_before_atomic(yyyymmdd, jcd, rno, payload)

        quality = self.db.before_snapshot_quality(
            yyyymmdd, jcd, rno
        )
        if not quality.get("meaningful"):
            raise RuntimeError("直前情報保存後のDB検証に失敗")

        return {
            "ok": True,
            "saved": True,
            "verified": True,
            "quality": quality,
            "data": payload,
        }

    def get_before_info(self, yyyymmdd: str, jcd: str, rno: int):
        """
        直前情報専用。出走表には一切触れない。
        未発表ならDB保存しない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/beforeinfo?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        html = self._get(url, ttl=75)
        parsed = parse_before_info(html)

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        weather = data.get("weather") or {}
        has_weather = any(v is not None for v in weather.values())
        racers = data.get("racers") or []
        starts = data.get("start_display") or []

        published = bool(racers) or bool(starts) or has_weather

        if published:
            self.db.save_snapshot(yyyymmdd, jcd, rno, "beforeinfo", data)

        return data

    def get_odds3t(self, yyyymmdd: str, jcd: str, rno: int):
        """
        3連単オッズ専用。120通り揃った場合のみDB保存。
        出走表・直前情報には一切触れない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/odds3t?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        html = self._get(url, ttl=40)
        parsed = parse_odds3t(html)

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        odds = data.get("odds") or []
        if len(odds) == 120:
            self.db.save_snapshot(yyyymmdd, jcd, rno, "odds3t", data)

        return data


    def fetch_results_atomic(self, yyyymmdd: str, jcd: str):
        """
        One venue result-list fetch:
          fresh official resultlist
          -> parse 1R-12R
          -> keep confirmed rows only
          -> save all confirmed rows
          -> DB readback verification
        """
        jcd = str(jcd).zfill(2)
        url = (
            f"{BASE}/owpc/pc/race/resultlist"
            f"?jcd={jcd}&hd={yyyymmdd}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} resultlist",
        )

        # Save the official result-list immediately.  Per-race detail pages
        # (popularity / winning method) are fetched lazily only when needed.
        # This avoids waiting for up to twelve extra requests before a result
        # appears in the app.
        parsed = parse_result_list(html)

        confirmed = []
        for row in parsed:
            if (
                row.get("trifecta")
                and row.get("payout_yen") is not None
            ):
                confirmed.append(row)

        if confirmed:
            self.db.save_results(
                yyyymmdd,
                jcd,
                confirmed,
            )
            self.db.sync_trial_racer_tracker(yyyymmdd, jcd, confirmed)

        saved_keys = self.db.get_result_complete_keys(
            yyyymmdd
        )
        venue_saved = sorted(
            rno for code, rno in saved_keys
            if str(code).zfill(2) == jcd
        )

        # Every confirmed parsed row must exist after save.
        parsed_rnos = sorted(
            int(x["rno"]) for x in confirmed
        )

        missing = [
            rno for rno in parsed_rnos
            if rno not in venue_saved
        ]

        if missing:
            raise RuntimeError(
                f"結果保存後検証失敗 missing={missing}"
            )

        return {
            "ok": True,
            "date": yyyymmdd,
            "jcd": jcd,
            "confirmed_count": len(venue_saved),
            "confirmed_rnos": venue_saved,
            "parsed_confirmed_count": len(confirmed),
            "source_url": url,
        }

    def get_results(self, yyyymmdd: str, jcd: str):
        """
        結果専用。確定条件を満たす結果だけ保存。
        出走表/直前/オッズには一切触れない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/resultlist?jcd={jcd}&hd={yyyymmdd}"
        html = self._get(url, ttl=90)
        # Result visibility must not wait for detail-page enrichment.
        parsed = parse_result_list(html)

        confirmed = []
        for row in parsed:
            trifecta = row.get("trifecta")
            payout = row.get("payout_yen")
            if trifecta and payout:
                confirmed.append(row)

        if confirmed:
            self.db.save_results(yyyymmdd, jcd, confirmed)
            self.db.sync_trial_racer_tracker(yyyymmdd, jcd, confirmed)

        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "source_url": url,
            "results": confirmed,
        }

    def _enrich_result_details(self, yyyymmdd: str, jcd: str, rows: list[dict]):
        """Add official popularity and winning method from per-race pages."""
        enriched = []
        for row in rows:
            item = dict(row)
            rno = int(item.get("rno") or 0)
            existing = self.db.get_result_for_race_db(yyyymmdd, jcd, rno)
            if existing:
                for key in (
                    "popularity", "odds", "kimarite", "finishers",
                    "start_courses", "event_grade", "event_title", "race_name",
                ):
                    if item.get(key) is None and existing.get(key) is not None:
                        item[key] = existing.get(key)

            enriched.append(item)

        pending = [
            (index, item) for index, item in enumerate(enriched)
            if (
                item.get("popularity") is None
                or item.get("kimarite") is None
                or len(item.get("finishers") or []) < 6
                or len(item.get("start_courses") or []) < 6
            )
        ]

        def fetch_detail(index, item):
            rno = int(item["rno"])
            url = (
                f"{BASE}/owpc/pc/race/raceresult"
                f"?rno={rno}&jcd={str(jcd).zfill(2)}&hd={yyyymmdd}"
            )
            detail_html = self._get(url, ttl=21600)
            return index, url, parse_result_detail(detail_html, rno)

        if pending:
            with ThreadPoolExecutor(max_workers=min(4, len(pending))) as pool:
                futures = [pool.submit(fetch_detail, index, item) for index, item in pending]
                for future in as_completed(futures):
                    try:
                        index, url, detail = future.result()
                    except Exception:
                        # The venue-level confirmed result remains valid. A
                        # later poll retries only the missing detail fields.
                        continue
                    item = enriched[index]
                    if detail.get("trifecta") != item.get("trifecta"):
                        continue
                    for key in (
                        "popularity", "odds", "kimarite", "finishers",
                        "start_courses", "event_grade", "event_title", "race_name",
                    ):
                        if detail.get(key) is not None:
                            item[key] = detail[key]
                    item["detail_source_url"] = url
        return enriched

    def get_saved_result_detail(self, yyyymmdd: str, jcd: str, rno: int):
        """Read a saved result and lazily fill official detail fields."""
        jcd = str(jcd).zfill(2)
        existing = self.db.get_result_for_race_db(yyyymmdd, jcd, rno)
        if not existing or not existing.get("trifecta"):
            return existing
        if (
            existing.get("popularity") is not None
            and existing.get("kimarite")
            and len(existing.get("finishers") or []) >= 6
            and len(existing.get("start_courses") or []) >= 6
        ):
            return existing
        row = {**existing, "rno": int(rno)}
        enriched = self._enrich_result_details(yyyymmdd, jcd, [row])[0]
        self.db.save_results(yyyymmdd, jcd, [enriched])
        self.db.sync_trial_racer_tracker(yyyymmdd, jcd, [enriched])
        return self.db.get_result_for_race_db(yyyymmdd, jcd, rno)


    def get_result_for_race(self, yyyymmdd: str, jcd: str, rno: int):
        """
        Confirm one race result.
        The official result-list page is venue-level, so fetch it once,
        then return only the requested R.

        Final/confirmed condition:
        - requested rno exists
        - trifecta exists
        - payout_yen exists
        """
        data = self.get_results(yyyymmdd, jcd)
        rows = data.get("results") or []

        target = next(
            (row for row in rows if int(row.get("rno", 0)) == int(rno)),
            None
        )

        confirmed = bool(
            target
            and target.get("trifecta")
            and target.get("payout_yen")
        )

        return {
            "date": yyyymmdd,
            "jcd": str(jcd).zfill(2),
            "rno": int(rno),
            "confirmed": confirmed,
            "result": target,
        }

    def get_bundle(self, yyyymmdd: str, jcd: str, rno: int, include_odds=True):
        race = self.get_race(yyyymmdd, jcd, rno)
        self._attach_local_frame_stats(yyyymmdd, jcd, race)
        data = {
            "race": race,
            "before": self.get_before_info(yyyymmdd, jcd, rno),
        }
        if include_odds:
            data["odds3t"] = self.get_odds3t(yyyymmdd, jcd, rno)
        return data

    def save_prediction(self, yyyymmdd: str, jcd: str, rno: int, data: dict):
        self.db.save_prediction(yyyymmdd, jcd, rno, data)
        return self.db.get_prediction(yyyymmdd, jcd, rno)

    def get_current_venue_profile(self, jcd: str):
        """
        Venue characteristics are reference data, not a frozen part of an old
        race prediction. Always rebuild this display profile from the latest
        saved venue documents.
        """
        jcd = str(jcd).zfill(2)
        docs = self.db.get_venue_knowledge_text(jcd, 600)
        profile = build_venue_profile(docs)
        profile["jcd"] = jcd
        return profile

    def get_prediction(self, yyyymmdd: str, jcd: str, rno: int):
        pred = self.db.get_prediction(
            yyyymmdd, str(jcd).zfill(2), rno
        )
        if not pred:
            return pred

        # Old prediction rows may contain an old venue-profile message.
        # Keep the historical race prediction itself, but replace only the
        # venue-reference display with the latest saved material.
        snap = dict(pred.get("source_snapshot") or {})
        snap["venue_profile"] = self.get_current_venue_profile(jcd)
        pred["source_snapshot"] = snap
        return pred

    def save_comments(self, yyyymmdd: str, jcd: str, rno: int, comments: list[dict]):
        self.db.save_comments(yyyymmdd, jcd, rno, comments)
        return self.db.get_comments(yyyymmdd, jcd, rno)

    def get_comments(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.get_comments(yyyymmdd, jcd, rno)

    def compare(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.compare_prediction(yyyymmdd, jcd, rno)

    def get_cached_bundle(self, yyyymmdd: str, jcd: str, rno: int):
        race = self.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
        before = self.db.get_snapshot(yyyymmdd, jcd, rno, "beforeinfo")
        odds = self.db.get_snapshot(yyyymmdd, jcd, rno, "odds3t")
        result = self.db.get_result_for_race_db(
            yyyymmdd, jcd, rno
        )

        race_data = race["data"] if race else None
        self._attach_local_frame_stats(yyyymmdd, jcd, race_data)
        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "race": race_data,
            "before": before["data"] if before else None,
            "odds3t": odds["data"] if odds else None,
            "result": result,
            "captured_at": {
                "race": race["captured_at"] if race else None,
                "before": before["captured_at"] if before else None,
                "odds3t": odds["captured_at"] if odds else None,
                "result": result.get("updated_at") if result else None,
            }
        }

    def _attach_local_frame_stats(self, yyyymmdd: str, jcd: str, race_data):
        """Attach historical local-frame figures without rewriting snapshots."""
        if not isinstance(race_data, dict):
            return race_data
        racers = race_data.get("racers") or []
        # PRE prediction uses the current official racelist values.  Keep a
        # single immutable monthly snapshot as the audit/history source while
        # avoiding needless repeated writes during the same month.
        self.db.save_monthly_official_racer_data(yyyymmdd, racers)
        signature = tuple(sorted(
            (str(x.get("registration_no") or ""), int(x.get("lane") or 0))
            for x in racers
        ))
        cache_key = (yyyymmdd, str(jcd).zfill(2), signature)
        stats = self._local_frame_stats_cache.get(cache_key)
        if stats is None:
            stats = self.db.get_local_frame_stats(
                yyyymmdd, str(jcd).zfill(2), racers
            )
            if len(self._local_frame_stats_cache) > 2000:
                self._local_frame_stats_cache.clear()
            self._local_frame_stats_cache[cache_key] = stats
        for racer in racers:
            key = (
                str(racer.get("registration_no") or ""),
                int(racer.get("lane") or 0),
            )
            racer["local_frame_stats"] = stats.get(key)
        registrations = tuple(sorted(
            str(x.get("registration_no") or "") for x in racers
            if x.get("registration_no")
        ))
        course_cache_key = (yyyymmdd, registrations)
        course_stats = self._racer_course_stats_cache.get(course_cache_key)
        if course_stats is None:
            course_stats = self.db.get_racer_course_stats(yyyymmdd, racers)
            if len(self._racer_course_stats_cache) > 2000:
                self._racer_course_stats_cache.clear()
            self._racer_course_stats_cache[course_cache_key] = course_stats
        for racer in racers:
            reg = str(racer.get("registration_no") or "")
            # Player-history rates are deliberately held back until a full
            # half-year is available; before that the AI uses official stats.
            player = self.db.get_racer_public_data(reg) if reg else {}
            six = (player.get("course_rates") or {}).get("six_months") or {}
            racer["course_stats"] = ({str(x["course"]): x for x in six.get("courses") or []}
                                     if six.get("published") else {})
        return race_data

    def get_local_frame_history(self, yyyymmdd: str, jcd: str, rno: int):
        jcd = str(jcd).zfill(2)
        snap = self.db.get_snapshot(yyyymmdd, jcd, int(rno), "racelist")
        race = (snap or {}).get("data") or {}
        racers = race.get("racers") or []
        data = self.db.get_local_frame_history(yyyymmdd, jcd, racers, 10)
        pending = data.get("missing_details") or []
        if pending:
            with ThreadPoolExecutor(max_workers=min(4, len(pending))) as pool:
                futures = [
                    pool.submit(self.get_saved_result_detail, x["date"], jcd, x["rno"])
                    for x in pending[:60]
                ]
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception:
                        pass
            data = self.db.get_local_frame_history(yyyymmdd, jcd, racers, 10)
        data.update({"date": yyyymmdd, "jcd": jcd, "rno": int(rno)})
        return data

    def get_day_racelists(self, yyyymmdd: str):
        rows = self.db.get_day_snapshots(yyyymmdd, "racelist")
        return {"date": yyyymmdd, "count": len(rows), "races": rows}


    def build_ai_prediction(
        self, yyyymmdd: str, jcd: str, rno: int,
        mode: str = "balanced", save: bool = False, preview: bool = False
    ):
        jcd = str(jcd).zfill(2)
        existing = self.db.get_prediction(yyyymmdd, jcd, rno)
        deadline = next((x.get("deadline") for x in self.db.get_race_schedule(yyyymmdd, jcd)
                         if int(x["rno"]) == int(rno)), None)
        cutoff = None
        if deadline:
            try:
                cutoff = datetime.strptime(yyyymmdd + " " + deadline, "%Y%m%d %H:%M").replace(tzinfo=timezone(timedelta(hours=9)))
            except ValueError:
                pass
        if save and (cutoff is None or datetime.now(timezone.utc) >= cutoff or
                     self.db.get_result_for_race_db(yyyymmdd, jcd, rno)):
            if existing:
                return existing
            return {"source_snapshot": {}, "main_picks": [], "judgement": "締切前の保存なし"}
        bundle = self.get_cached_bundle(yyyymmdd, jcd, rno)
        docs = self.db.get_venue_knowledge_text(jcd, 300)

        data = ai_predict(
            yyyymmdd, jcd, rno,
            bundle.get("race"),
            bundle.get("before"),
            bundle.get("odds3t"),
            docs,
            mode=mode,
            preview=preview,
        )

        if save:
            # Calculation may cross the deadline; recheck immediately before saving.
            if datetime.now(timezone.utc) >= cutoff:
                return existing or {"source_snapshot": {}, "main_picks": [], "judgement": "締切前の保存なし"}
            snap = data["source_snapshot"]
            snap.setdefault("generated_at", datetime.now(timezone(timedelta(hours=9))).isoformat())
            old = (existing or {}).get("source_snapshot") or {}
            preserve_pre = bool((old.get("pre_prediction") or {}).get("picks")) and len((snap.get("pre_prediction") or {}).get("missing", [])) >= len((old.get("pre_prediction") or {}).get("missing", []))
            if preserve_pre:
                # Preserve the saved PRE score and picks; add current odds strategies to
                # these original PRE scores, without using later meeting/result inputs.
                from ai_predictor import _combo_list, _extract_odds, strategy_options
                pre = old["pre_prediction"]
                scores = {int(k): x["score"] for k, x in pre.get("lane_scores", {}).items()}
                active = [int(x["lane"]) for x in (bundle.get("race") or {}).get("racers", [])
                          if not x.get("scratched") and x.get("status") != "欠場"]
                scores = {k: v for k, v in scores.items() if k in active}
                if len(scores) >= 3:
                    _, candidates = _combo_list(
                        scores, list(scores), _extract_odds(bundle.get("odds3t")),
                        venue_profile=old.get("venue_profile") or snap.get("venue_profile"),
                    )
                    pre["strategies"] = strategy_options(candidates)
                    pre["strategies_saved_at"] = snap["generated_at"]
                snap["pre_prediction"] = pre
            snap["pre_saved_at"] = (old.get("pre_saved_at") or old.get("generated_at") or snap["generated_at"]) if preserve_pre else snap["generated_at"]
            snap["saved_before_deadline"] = True
            self.db.save_prediction(yyyymmdd, jcd, rno, data)
            return self.db.get_prediction(yyyymmdd, jcd, rno)

        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": int(rno),
            **data,
        }

    def prediction_summary(self, date: str | None = None):
        return self.db.prediction_summary(date)


    def get_race_revision(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.get_race_revision(
            yyyymmdd, str(jcd).zfill(2), rno
        )
