@echo off
cd /d "%~dp0"
call "%~dp0START_BOAT_AI_LAB.bat"
