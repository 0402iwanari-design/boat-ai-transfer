from pathlib import Path
import tempfile
from boat_source import BoatRaceSource
from db import BoatDB

REG='4857'
TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
PARTS={1:[77.8,5.6,5.6],2:[22.2,33.3,27.8],3:[18.2,36.4,18.2],4:[28.6,50.0,7.1],5:[25.0,12.5,25.0],6:[0.0,15.4,23.1]}
AVG={1:.15,2:.16,3:.13,4:.18,5:.16,6:.19}
ENTRY={1:20.0,2:20.0,3:12.2,4:15.6,5:17.8,6:14.4}
START={1:2.2,2:3.3,3:2.8,4:3.5,5:3.7,6:4.5}

def table(values, heading=''):
    rows=''.join(f'<tr><td>{c}</td><td>{values[c]}</td></tr>' for c in range(1,7))
    return f'<table><tr><th colspan="2">{heading}</th></tr>{rows}</table>'

# Important regression shape: the official 3-place table has totals, but no
# decodable progress1/progress2/progress3 classes. v17.271 prefilled [0,0,0]
# and incorrectly decided the colour split was complete, so fallback never ran.
official_html='<html><body><h2>加藤翔馬</h2>'+table(ENTRY,'コース別進入率')+table(TOTALS,'コース別3連対率')+table(AVG,'コース別平均スタートタイミング')+table(START,'コース別スタート順')+'</body></html>'
mirror_html='''<html><body><h2>コース別3連対率</h2><div>1着率2着率3着率</div>
<div>1 | 77.8 5.6 5.6 | 88.9%</div><div>2 | 22.2 33.3 27.8 | 83.3%</div>
<div>3 | 18.2 36.4 18.2 | 72.7%</div><div>4 | 28.6 50.0 7.1 | 85.7%</div>
<div>5 | 25.0 12.5 25.0 | 62.5%</div><div>6 | 0.0 15.4 23.1 | 38.5%</div>
<h2>コース別スタート順</h2></body></html>'''

with tempfile.TemporaryDirectory() as td:
    src=BoatRaceSource.__new__(BoatRaceSource)
    src.cache=type('Cache',(),{'get':lambda *a:None,'set':lambda *a:None})()
    src._racer_course_stats_cache={}
    src.db=BoatDB(str(Path(td)/'boat.db'))
    calls=[]
    def fake_get(url,*args,**kwargs):
        calls.append(url)
        return mirror_html if 'boatnavi.hochi.co.jp' in url else official_html
    src._get=fake_get
    data=src.fetch_official_racer_course_data(REG,'加藤翔馬')
    assert any('boatnavi.hochi.co.jp' in u for u in calls), calls
    rows={int(r['course']):r for r in data['course_stats']}
    assert len(rows)==6
    for c in range(1,7):
        got=[rows[c]['first_rate'],rows[c]['second_rate'],rows[c]['third_rate']]
        assert got==PARTS[c], (c,got,PARTS[c])
        assert abs(sum(got)-TOTALS[c]) <= .35
    assert data['course_breakdown_complete'] is True
    src.db.save_official_racer_search_data('20261008',data)
    saved=src.db.get_racer_public_data(REG)['official_data']['data']['course_stats']
    saved={int(r['course']):r for r in saved}
    for c in range(1,7):
        assert [saved[c]['first_rate'],saved[c]['second_rate'],saved[c]['third_rate']]==PARTS[c]
    print('PASS 4857 E2E: official DOM split missing -> BOATNAVI repair invoked -> 6 courses x 1st/2nd/3rd saved')
    print('PASS values:', {c:PARTS[c] for c in range(1,7)})
