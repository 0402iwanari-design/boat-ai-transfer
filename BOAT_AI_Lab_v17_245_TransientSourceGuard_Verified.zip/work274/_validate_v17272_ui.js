const fs=require('fs');
const html=fs.readFileSync('static/index.html','utf8');
const m=html.match(/function officialCourseBreakdownChart\(courses\)\{[\s\S]*?\n\}\n\n\nfunction rankOdds/);
if(!m) throw new Error('chart function not found');
const fn=m[0].replace(/\n\n\nfunction rankOdds[\s\S]*$/,'');
eval(fn);
const rows=[
 {course:1,trio_rate:88.9,first_rate:77.8,second_rate:5.6,third_rate:5.6},
 {course:2,trio_rate:83.3,first_rate:22.2,second_rate:33.3,third_rate:27.8},
 {course:3,trio_rate:72.7,first_rate:18.2,second_rate:36.4,third_rate:18.2},
 {course:4,trio_rate:85.7,first_rate:28.6,second_rate:50.0,third_rate:7.1},
 {course:5,trio_rate:62.5,first_rate:25.0,second_rate:12.5,third_rate:25.0},
 {course:6,trio_rate:38.5,first_rate:0.0,second_rate:15.4,third_rate:23.1}
];
const out=officialCourseBreakdownChart(rows);
if((out.match(/class="official-first" style=/g)||[]).length!==6) throw new Error('first bars !=6');
if((out.match(/class="official-second" style=/g)||[]).length!==6) throw new Error('second bars !=6');
if((out.match(/class="official-third" style=/g)||[]).length!==6) throw new Error('third bars !=6');
for(const token of ['width:77.8%','width:5.6%','width:33.3%','width:50%','width:15.4%','width:23.1%']) if(!out.includes(token)) throw new Error('missing '+token);
if(out.includes('total-only')) throw new Error('unexpected total-only fallback');
console.log('PASS UI: 6 courses render 1st/2nd/3rd stacked colour segments');
