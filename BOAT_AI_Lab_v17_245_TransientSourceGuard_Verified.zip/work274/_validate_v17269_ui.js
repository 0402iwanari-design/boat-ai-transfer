const num=v=>{ if(v===null||v===undefined||v==="") return null; const n=Number(v); return Number.isFinite(n)?n:null; };
if(num(null)!==null) throw new Error('null became zero');
const rows=[
 {course:1,trio_rate:88.9,first_rate:77.8,second_rate:5.6,third_rate:5.6},
 {course:2,trio_rate:83.3,first_rate:22.2,second_rate:33.3,third_rate:27.8},
 {course:3,trio_rate:72.7,first_rate:18.2,second_rate:36.4,third_rate:18.2},
 {course:4,trio_rate:85.7,first_rate:28.6,second_rate:50.0,third_rate:7.1},
 {course:5,trio_rate:62.5,first_rate:25.0,second_rate:12.5,third_rate:25.0},
 {course:6,trio_rate:38.5,first_rate:0.0,second_rate:15.4,third_rate:23.1}
];
for(const r of rows){
  const parts=['first_rate','second_rate','third_rate'].map(k=>num(r[k]));
  if(parts.some(v=>v===null)) throw new Error('missing split '+r.course);
  if(Math.abs(parts.reduce((a,b)=>a+b,0)-r.trio_rate)>.35) throw new Error('sum mismatch '+r.course);
}
console.log('PASS: UI null handling and all six stacked rows');
