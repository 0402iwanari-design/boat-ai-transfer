import json, tempfile, types
from pathlib import Path
from datetime import datetime
import sys
sys.path.insert(0, str(Path(__file__).parent))
from boat_source import BoatRaceSource
from db import BoatDB

TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
PARTS={1:[77.8,5.6,5.6],2:[22.2,33.3,27.8],3:[18.2,36.4,18.2],4:[28.6,50.0,7.1],5:[25.0,12.5,25.0],6:[0.0,15.4,23.1]}

# 1) Parse a page fragment matching the currently published visible values for racer 4857.
rows=''.join(f'<div><span>{c}</span><span>{PARTS[c][0]} {PARTS[c][1]} {PARTS[c][2]}</span><span>{TOTALS[c]}%</span></div>' for c in range(1,7))
html=f'<h2>コース別3連対率</h2><div>1着率2着率3着率</div>{rows}<h2>コース別スタート順</h2>'
src=BoatRaceSource.__new__(BoatRaceSource)
parsed=src._parse_boatnavi_course_breakdown(html,TOTALS)
assert parsed==PARTS, parsed

# 2) Reproduce the actual stale bug: old rows are [0,0,total], so no field is None.
#    v17.272 therefore skipped repair. v17.273 must force one refresh and persist the 3-way split.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    old={
      'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
      'course_breakdown_version':0,'course_breakdown_complete':True,
      'profile':{'name':'加藤翔馬'},
      'course_stats':[{
          'course':c,'entry_rate':10.0,'first_rate':0.0,'second_rate':0.0,
          'third_rate':TOTALS[c],'quinella_rate':0.0,'trio_rate':TOTALS[c],
          'avg_st':0.14,'start_rank':3.0
      } for c in range(1,7)]
    }
    db.save_official_racer_search_data('20261008',old)
    src2=BoatRaceSource.__new__(BoatRaceSource)
    src2.db=db
    src2._racer_course_stats_cache={}
    calls=[]
    def fake_fetch(self, reg, name=None):
        calls.append(reg)
        return {
          'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
          'course_breakdown_version':5,'course_breakdown_complete':True,
          'course_breakdown_source':'boatnavi-hochi-text+boatrace-total',
          'profile':{'name':'加藤翔馬'},
          'course_stats':[{
              'course':c,'entry_rate':10.0,'first_rate':PARTS[c][0],
              'second_rate':PARTS[c][1],'third_rate':PARTS[c][2],
              'quinella_rate':round(PARTS[c][0]+PARTS[c][1],1),
              'trio_rate':TOTALS[c],'avg_st':0.14,'start_rank':3.0
          } for c in range(1,7)]
        }
    src2.fetch_official_racer_course_data=types.MethodType(fake_fetch,src2)
    out=src2.get_racer_public_data_with_course_breakdown('4857')['official_data']['data']
    assert calls==['4857'], calls
    assert out['course_breakdown_version']==5
    for row in out['course_stats']:
        c=row['course']
        assert [row['first_rate'],row['second_rate'],row['third_rate']]==PARTS[c], row
        assert abs(sum(PARTS[c])-TOTALS[c])<=0.35
    persisted=db.get_racer_public_data('4857')['official_data']['data']
    assert persisted['course_breakdown_version']==5
    assert all(r['first_rate'] is not None and r['second_rate'] is not None and r['third_rate'] is not None for r in persisted['course_stats'])

# 3) Existing pre-v5 snapshots must not be treated as fresh for today's entrants.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    date='20261008'
    # seed a racelist with the target racer so daily_official_racer_targets sees it
    db.save_basic_race_atomic(date,'12',1,{'racers':[{'registration_no':'4857','name':'加藤翔馬'}]},'12:00','test')
    old={
      'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
      'course_breakdown_version':0,'course_breakdown_complete':True,
      'profile':{'name':'加藤翔馬'},
      'course_stats':[{'course':c,'first_rate':0.0,'second_rate':0.0,'third_rate':TOTALS[c],'trio_rate':TOTALS[c],'avg_st':0.14} for c in range(1,7)]
    }
    db.save_official_racer_search_data(date,old)
    pending=db.official_racer_collection_pending(date)
    assert any(x['registration_no']=='4857' for x in pending), pending
    # Once a v5 snapshot is stored, it becomes reusable again.
    new=dict(old)
    new['course_breakdown_version']=5
    new['course_breakdown_complete']=True
    new['course_stats']=[{'course':c,'first_rate':PARTS[c][0],'second_rate':PARTS[c][1],'third_rate':PARTS[c][2],'trio_rate':TOTALS[c],'avg_st':0.14} for c in range(1,7)]
    db.save_official_racer_search_data(date,new)
    pending2=db.official_racer_collection_pending(date)
    assert not any(x['registration_no']=='4857' for x in pending2), pending2

# 4) UI has three distinct classes and widths tied to the three numeric fields.
ui=Path(__file__).with_name('static').joinpath('index.html').read_text()
assert '.official-first{background:#1976c9}' in ui
assert '.official-second{background:#69a4d5}' in ui
assert '.official-third{background:#bdd4e8}' in ui
assert 'width:${clamp(x.first)}%' in ui and 'width:${clamp(x.second)}%' in ui and 'width:${clamp(x.third)}%' in ui
print('PASS v17.273: real 4857 numeric split parses, stale [0,0,total] snapshot is forcibly repaired, pre-v5 current-day data refreshes once, and UI maps three rates to three distinct colors')
