import json, tempfile
from pathlib import Path
from db import BoatDB, _official_course_payload

# Reproduce the exact failure class: official six-course core values exist,
# but coloured 1/2/3 DOM could not be decoded.
core = {
    'course_stats_version': 4,
    'course_breakdown_complete': False,
    'course_stats': [
        {'course':c,'entry_rate':10+c,'trio_rate':30+c,'avg_st':round(.10+c/100,2),
         'start_rank':2+c/10,'first_rate':None,'second_rate':None,'third_rate':None,
         'quinella_rate':None}
        for c in range(1,7)
    ]
}
assert _official_course_payload(core) is not None, 'optional colour split must not invalidate core data'

# Valid coloured split remains accepted.
colored=json.loads(json.dumps(core))
for r in colored['course_stats']:
    r['first_rate']=10.0; r['second_rate']=10.0; r['third_rate']=r['trio_rate']-20.0
    r['quinella_rate']=20.0
assert _official_course_payload(colored) is not None

# Bad colour split must degrade to core data, not turn the racer into failed.
bad=json.loads(json.dumps(colored))
bad['course_stats'][0]['first_rate']=99.0
out=_official_course_payload(bad)
assert out is not None
assert out['course_stats'][0]['first_rate'] is None
assert out['course_stats'][0]['avg_st']==.11

# DB read-back must retain avg ST for all 6 courses after save.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    payload=dict(core, registration_no='9999', name='検証太郎', profile={'name':'検証太郎'})
    db.save_official_racer_search_data('20261007',payload)
    got=db.get_racer_public_data('9999')
    official=(got.get('official_data') or {}).get('data') or {}
    rows=official.get('course_stats') or []
    assert len(rows)==6
    assert [r.get('avg_st') for r in rows]==[.11,.12,.13,.14,.15,.16]
print('v17.267 regression PASS: optional 3-colour split no longer causes mass failure; avg ST survives read-back')
