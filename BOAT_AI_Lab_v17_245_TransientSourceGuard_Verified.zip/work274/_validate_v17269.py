import json, tempfile, types, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from db import BoatDB
from boat_source import BoatRaceSource

TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
PARTS={1:[77.8,5.6,5.6],2:[22.2,33.3,27.8],3:[18.2,36.4,18.2],4:[28.6,50.0,7.1],5:[25.0,12.5,25.0],6:[0.0,15.4,23.1]}

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    old={
      'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
      'profile':{'name':'加藤翔馬'},
      'course_stats':[{'course':c,'entry_rate':10,'first_rate':None,'second_rate':None,'third_rate':None,'quinella_rate':None,'trio_rate':TOTALS[c],'avg_st':.14,'start_rank':3.0} for c in range(1,7)]
    }
    db.save_official_racer_search_data('20261007',old)
    before=db.get_racer_public_data('4857')['official_data']['data']['course_stats']
    assert [r['trio_rate'] for r in before]==[TOTALS[c] for c in range(1,7)]
    assert all(r['first_rate'] is None for r in before)

    src=BoatRaceSource.__new__(BoatRaceSource)
    src.db=db
    src._racer_course_stats_cache={}
    def fake_fetch(self, reg, name=None):
        return {
          'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
          'profile':{'name':'加藤翔馬'},
          'course_stats':[{
            'course':c,'entry_rate':10,'first_rate':PARTS[c][0],
            'second_rate':PARTS[c][1],'third_rate':PARTS[c][2],
            'quinella_rate':round(PARTS[c][0]+PARTS[c][1],1),
            'trio_rate':TOTALS[c],'avg_st':.14,'start_rank':3.0
          } for c in range(1,7)]
        }
    src.fetch_official_racer_course_data=types.MethodType(fake_fetch,src)
    after=src.get_racer_public_data_with_course_breakdown('4857')['official_data']['data']['course_stats']
    assert len(after)==6
    for row in after:
        c=row['course']
        assert abs(row['first_rate']+row['second_rate']+row['third_rate']-row['trio_rate']) <= .35
        assert row['trio_rate']==TOTALS[c]
    # Verify persisted readback, not only returned transient data.
    persisted=db.get_racer_public_data('4857')['official_data']['data']['course_stats']
    assert persisted[1]['trio_rate']==83.3 and persisted[1]['first_rate']==22.2
    assert persisted[5]['trio_rate']==38.5 and persisted[5]['second_rate']==15.4
print('PASS: old completed v4 snapshot is repaired on player-open and persists all six 3-color rows')
