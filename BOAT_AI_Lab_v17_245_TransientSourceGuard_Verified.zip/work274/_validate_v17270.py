import sys, tempfile, types
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from boat_source import BoatRaceSource
from db import BoatDB

TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
PARTS={1:[77.8,5.6,5.6],2:[22.2,33.3,27.8],3:[18.2,36.4,18.2],4:[28.6,50.0,7.1],5:[25.0,12.5,25.0],6:[0.0,15.4,23.1]}

# Mimic current BOATNAVI visible structure without any <table> tags.
rows=''.join(f'<div class="course-row"><span>{c}</span><span>{PARTS[c][0]} {PARTS[c][1]} {PARTS[c][2]}</span><b>{TOTALS[c]}%</b></div>' for c in range(1,7))
html=f'''<html><body>
<div>コース別進入率 1 20% 2 20%</div>
<h2>コース別3連対率</h2><div>1着率2着率3着率</div>{rows}
<h2>コース別スタート順</h2><div>1 2.2 2 3.3</div>
</body></html>'''
src=BoatRaceSource.__new__(BoatRaceSource)
parsed=src._parse_boatnavi_course_breakdown(html,TOTALS)
assert parsed==PARTS, (parsed, PARTS)

# A row whose split disagrees with official total must be rejected.
bad=html.replace('77.8 5.6 5.6','10.0 10.0 10.0',1)
parsed_bad=src._parse_boatnavi_course_breakdown(bad,TOTALS)
assert 1 not in parsed_bad and all(c in parsed_bad for c in range(2,7)), parsed_bad

# Verify an old saved total-only snapshot is repaired and persists all 6 rows.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    old={
      'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
      'profile':{'name':'加藤翔馬'},
      'course_stats':[{'course':c,'entry_rate':10,'first_rate':None,'second_rate':None,'third_rate':None,'quinella_rate':None,'trio_rate':TOTALS[c],'avg_st':.14,'start_rank':3.0} for c in range(1,7)]
    }
    db.save_official_racer_search_data('20261007',old)
    src2=BoatRaceSource.__new__(BoatRaceSource)
    src2.db=db
    src2._racer_course_stats_cache={}
    def fake_fetch(self, reg, name=None):
        return {
          'registration_no':'4857','name':'加藤翔馬','course_stats_version':4,
          'profile':{'name':'加藤翔馬'},
          'course_stats':[{
            'course':c,'entry_rate':10,'first_rate':PARTS[c][0],
            'second_rate':PARTS[c][1],'third_rate':PARTS[c][2],
            'quinella_rate':round(PARTS[c][0]+PARTS[c][1],1),
            'trio_rate':TOTALS[c],'avg_st':.14,'start_rank':3.0
          } for c in range(1,7)]
        }
    src2.fetch_official_racer_course_data=types.MethodType(fake_fetch,src2)
    out=src2.get_racer_public_data_with_course_breakdown('4857')['official_data']['data']['course_stats']
    assert len(out)==6
    for row in out:
        c=row['course']
        assert [row['first_rate'],row['second_rate'],row['third_rate']]==PARTS[c]
        assert abs(sum(PARTS[c])-TOTALS[c]) <= .35
    persisted=db.get_racer_public_data('4857')['official_data']['data']['course_stats']
    assert all(r['first_rate'] is not None and r['second_rate'] is not None and r['third_rate'] is not None for r in persisted)

print('PASS: non-table BOATNAVI parser gets all six 3-color rows, validates totals, and persisted repair works')
