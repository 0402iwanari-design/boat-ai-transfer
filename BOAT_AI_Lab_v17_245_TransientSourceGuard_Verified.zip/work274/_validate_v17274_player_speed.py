import time, threading
from boat_source import BoatRaceSource

src=BoatRaceSource()
state={
    'fetch_calls':0,
    'saved':False,
}

def make_current():
    courses=[]
    for c in range(1,7):
        if state['saved']:
            first,second,third,total=10.0,20.0,30.0,60.0
            version=5
        else:
            first,second,third,total=0.0,0.0,60.0,60.0
            version=4
        courses.append({'course':c,'first_rate':first,'second_rate':second,'third_rate':third,'trio_rate':total,'avg_st':0.15})
    return {
        'registration_no':'4857',
        'profile':{'name':'加藤翔馬','profile_json':{}},
        'recent_meetings':[],
        'official_data':{'month':'202610','saved_at':'2026-10-08 00:00:00','data':{
            'course_stats':courses,
            'course_breakdown_version':version,
        }},
        'legacy_course_st':{},
    }

def get_data(reg):
    return make_current()

def slow_fetch(reg,name):
    state['fetch_calls']+=1
    time.sleep(1.2)
    d=make_current()['official_data']['data']
    # Return valid repaired payload.
    for row in d['course_stats']:
        row['first_rate']=10.0; row['second_rate']=20.0; row['third_rate']=30.0; row['trio_rate']=60.0
    d['course_breakdown_version']=5
    return {'registration_no':reg,'name':name,**d}

def save(date,payload):
    state['saved']=True

src.db.get_racer_public_data=get_data
src.fetch_official_racer_course_data=slow_fetch
src.db.save_official_racer_search_data=save

t0=time.perf_counter(); out1=src.get_racer_public_data_fast('4857'); elapsed1=time.perf_counter()-t0
assert elapsed1 < 0.25, elapsed1
assert out1['course_breakdown_refreshing'] is True
# A second immediate click must not start another external request.
t1=time.perf_counter(); out2=src.get_racer_public_data_fast('4857'); elapsed2=time.perf_counter()-t1
assert elapsed2 < 0.25, elapsed2
# Wait for background completion.
time.sleep(1.5)
assert state['fetch_calls']==1, state
t2=time.perf_counter(); out3=src.get_racer_public_data_fast('4857'); elapsed3=time.perf_counter()-t2
assert elapsed3 < 0.25, elapsed3
assert out3['course_breakdown_refreshing'] is False
assert out3['official_data']['data']['course_stats'][0]['first_rate']==10.0
print(f'PASS player fast response first={elapsed1:.4f}s second={elapsed2:.4f}s after={elapsed3:.4f}s fetch_calls={state["fetch_calls"]}')
