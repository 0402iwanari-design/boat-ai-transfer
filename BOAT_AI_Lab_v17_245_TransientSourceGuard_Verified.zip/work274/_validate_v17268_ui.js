function officialCourseBreakdownChart(courses,historyRates){
  const byCourse=new Map((courses||[]).map(x=>[Number(x.course),x]));
  const historyByCourse=new Map(((historyRates&&historyRates.courses)||[]).map(x=>[Number(x.course),x]));
  const num=v=>{const n=Number(v);return Number.isFinite(n)?n:null};
  const clamp=v=>Math.max(0,Math.min(100,Number(v)||0));
  const label=v=>v===null||v===undefined||!Number.isFinite(Number(v))?"—":`${Number(v).toFixed(1)}%`;
  const rows=[1,2,3,4,5,6].map(course=>{
    const official=byCourse.get(course)||{};
    let first=num(official.first_rate), second=num(official.second_rate), third=num(official.third_rate);
    let total=num(official.trio_rate); let source="official";
    const officialSplitOk=[first,second,third].every(v=>v!==null) && (total===null || Math.abs((first+second+third)-total)<=0.35);
    if(!officialSplitOk){ const h=historyByCourse.get(course)||{}; const starts=num(h.starts), f=num(h.first), s=num(h.second), t=num(h.third);
      if(starts!==null && starts>0 && f!==null && s!==null && t!==null){first=f/starts*100;second=s/starts*100;third=t/starts*100;total=first+second+third;source="history";}
      else{first=second=third=null;source="total-only";}
    }
    return {course,first,second,third,total,source};
  });
  const anyHistory=rows.some(x=>x.source==="history"); const anySplit=rows.some(x=>x.first!==null||x.second!==null||x.third!==null);
  const note=anyHistory?`<div class="official-course-note">history</div>`:"";
  return `<div class="official-course-chart boater-style">${rows.map(x=>`<div class="official-course-row"><div class="official-course-label">${x.course}コース</div><div class="official-course-bar-wrap"><div class="official-course-bar ${x.source==="total-only"?"total-only":""}">${x.source==="total-only"?`<span class="official-total-fallback" style="width:${clamp(x.total)}%"></span>`:`<span class="official-first" style="width:${clamp(x.first)}%"></span><span class="official-second" style="width:${clamp(x.second)}%"></span><span class="official-third" style="width:${clamp(x.third)}%"></span>`}</div></div><strong class="official-course-total">${label(x.total)}</strong></div>`).join("")}${!anySplit?`<div>total only</div>`:""}${note}</div>`;
}
const official=[82.6,61.1,77.3,50.0,33.3,7.7].map((t,i)=>({course:i+1,trio_rate:t,first_rate:null,second_rate:null,third_rate:null}));
const history={published:true,courses:[
 {course:1,starts:23,first:14,second:4,third:3},
 {course:2,starts:18,first:2,second:8,third:1},
 {course:3,starts:22,first:8,second:6,third:3},
 {course:4,starts:20,first:2,second:5,third:3},
 {course:5,starts:18,first:2,second:3,third:1},
 {course:6,starts:13,first:0,second:1,third:0}
]};
const html=officialCourseBreakdownChart(official,history);
if((html.match(/official-course-row/g)||[]).length!==6) throw new Error('six rows not rendered');
if((html.match(/official-first\" style=\"width:(?!0%)/g)||[]).length<5) throw new Error('first-place colored bars not visible');
if((html.match(/official-second\" style=\"width:(?!0%)/g)||[]).length<6) throw new Error('second-place colored bars not visible');
if(!html.includes('1コース')||!html.includes('6コース')) throw new Error('course labels missing');
if(!html.includes('history')) throw new Error('fallback source note missing');
console.log('PASS v17.268: null official split renders six visible stacked rows from saved 6-month actual-course history');
