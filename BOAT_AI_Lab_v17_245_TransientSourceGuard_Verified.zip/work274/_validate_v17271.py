from pathlib import Path
import tempfile
from boat_source import BoatRaceSource
from db import BoatDB

HTML = '''
<html><body>
<h2>コース別3連対率</h2>
<div>1着率</div><div>2着率</div><div>3着率</div>
<div><span>1</span><span>77.8</span><span>5.6</span><span>5.6</span><b>88.9%</b></div>
<div><span>2</span><span>22.2</span><span>33.3</span><span>27.8</span><b>83.3%</b></div>
<div><span>3</span><span>18.2</span><span>36.4</span><span>18.2</span><b>72.7%</b></div>
<div><span>4</span><span>28.6</span><span>50.0</span><span>7.1</span><b>85.7%</b></div>
<div><span>5</span><span>25.0</span><span>12.5</span><span>25.0</span><b>62.5%</b></div>
<div><span>6</span><span>0.0</span><span>15.4</span><span>23.1</span><b>38.5%</b></div>
<h2>コース別スタート順</h2>
</body></html>
'''
TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
src=object.__new__(BoatRaceSource)
out=src._parse_boatnavi_course_breakdown(HTML,TOTALS)
assert len(out)==6, out
assert out[1]==[77.8,5.6,5.6], out
assert out[2]==[22.2,33.3,27.8], out
assert out[6]==[0.0,15.4,23.1], out
print('PASS parser: all 6 courses + 1st/2nd/3rd split')

# A flattened response without row/table structure must also work.
flat='''<html><body>コース別3連対率 1着率 2着率 3着率 1 77.8 5.6 5.6 88.9% 2 22.2 33.3 27.8 83.3% 3 18.2 36.4 18.2 72.7% 4 28.6 50.0 7.1 85.7% 5 25.0 12.5 25.0 62.5% 6 0.0 15.4 23.1 38.5% コース別スタート順</body></html>'''
out2=src._parse_boatnavi_course_breakdown(flat,TOTALS)
assert out2==out, out2
print('PASS parser: flattened non-table text')

# Wrong split is rejected rather than painted with fake colours.
bad=flat.replace('77.8 5.6 5.6 88.9%','70.0 5.6 5.6 88.9%')
out3=src._parse_boatnavi_course_breakdown(bad,TOTALS)
assert 1 not in out3, out3
print('PASS parser: invalid split rejected')

# Local rolling course-rate accumulation is removed. Recent race rows remain.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'test.db'))
    with db.connect() as con:
        con.execute("INSERT INTO tracked_racer_profiles(registration_no,name,active) VALUES('4857','加藤翔馬',1)")
        # Four distinct meetings. The oldest should be deleted, not aggregated.
        for i,(mid,date) in enumerate([('m1','20260101'),('m2','20260201'),('m3','20260301'),('m4','20260401')],1):
            con.execute('''INSERT INTO tracked_racer_results
              (registration_no,meeting_id,date,jcd,meeting_day,rno,lane,course,finish,st_raw,source_url)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)''',('4857',mid,date,'12',1,1,1,1,1,'.10','x'))
        db._compact_trial_racer_locked(con,'4857')
        cnt=con.execute("SELECT COUNT(*) c FROM tracked_racer_results WHERE registration_no='4857'").fetchone()['c']
        monthly=con.execute("SELECT COUNT(*) c FROM tracked_racer_course_monthly WHERE registration_no='4857'").fetchone()['c']
    assert cnt==3, cnt
    assert monthly==0, monthly
    public=db.get_racer_public_data('4857')
    assert 'course_rates' not in public, public.keys()
    assert public['monthly_aggregates']==[]
print('PASS storage: no rolling course-rate aggregation; recent 3 meetings preserved')

html=Path(__file__).with_name('static').joinpath('index.html').read_text()
assert 'コース別率は半年分の保存データが貯まるまで収集中です。' not in html
assert 'course_rates?.six_months' not in html
assert 'コース別3連対率（公式）' in html
print('PASS UI: old six-month waiting block removed; official course chart used')
