from __future__ import annotations

"""Nationwide/current-venue actual-entry-course history collection (v17.187).

Collection plan
---------------
* 00:00-23:59 JST: only racers appearing in today's saved official racelists are targets.
* For each racer, only nationwide 1-6 course history + the venue they are racing at today
  is required for completion. The other 23 venues are never completion targets.
* One official nationwide daily K file is fetched, then shared across every active target.
  A racer's row is saved once and can simultaneously contribute to nationwide and local history.
* Each target stops as soon as all required nationwide/current-venue course buckets reach 10.
  If a course has fewer than 10 lifetime starts, the scan stops at that racer's debut-term floor
  and the available number is accepted as complete.
* Success/no-data day: 10-second pause. Fetch failure: 60-second retry, max 3 attempts.
  After 3 failures that racer/venue target is shown as an error and is not retried again that day.
* Confirmed live race results continue to update the same history table with no extra web access.
* The scheduler's periodic checks are SQLite-only. It accesses the official history source only
  when a new/incomplete target actually exists.
"""

import io
import re
import threading
import time
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
HISTORY_FLOOR = "20020101"
SUCCESS_PAUSE_SECONDS = 10
RETRY_PAUSE_SECONDS = 60
MAX_FETCH_ATTEMPTS = 3
LOCAL_TARGET_CHECK_SECONDS = 300  # SQLite-only check; no web request when there is no target.

VENUES = [
    "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
    "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村",
]
VENUE_CODE = {name: f"{i:02d}" for i, name in enumerate(VENUES, 1)}


def _registration_term_floor(period: int) -> str:
    period = int(period)
    reference_period = 136
    reference_month_index = 2025 * 12 + 4  # May 2025
    month_index = reference_month_index - (reference_period - period) * 6
    year, month0 = divmod(month_index, 12)
    return f"{year:04d}{month0 + 1:02d}01"


def _norm(s: str) -> str:
    return re.sub(r"[\s　]+", "", str(s or "")).replace("ボートレース", "")


def _st_number(raw: str):
    s = str(raw or "").strip().upper().replace("０", "0")
    if not s:
        return None
    m = re.fullmatch(r"F\s*([0-9]*\.?[0-9]+)", s)
    if m:
        try: return -float(m.group(1))
        except ValueError: return None
    if s.startswith("L"):
        return None
    try:
        v = float(s)
        return v if -1 < v < 2 else None
    except ValueError:
        return None


def _normalize_k_st(raw: str) -> str:
    """Convert K-file 3-char ST into the app's display/storage form.

    Official K T1-T6 records use a compact fixed-width ST field.  Keep special
    F/L markers instead of coercing them to zero, and convert ordinary digits
    such as ``012`` to ``.12``.
    """
    s=str(raw or "").strip().upper()
    if not s:
        return ""
    if s.startswith("F"):
        digits=re.sub(r"\D", "", s[1:])
        if digits:
            return f"F.{int(digits):02d}"
        return "F"
    if s.startswith("L"):
        digits=re.sub(r"\D", "", s[1:])
        return f"L.{int(digits):02d}" if digits else "L"
    if re.fullmatch(r"\d{1,3}", s):
        return f".{int(s):02d}"
    if re.fullmatch(r"\.?\d{1,2}", s):
        return "." + s.lstrip(".").zfill(2)
    return s


def _assign_st_ranks(race_rows: list[dict]):
    numeric=[(i,_st_number(x.get("st_raw"))) for i,x in enumerate(race_rows)]
    numeric=[(i,v) for i,v in numeric if v is not None]
    numeric.sort(key=lambda z:z[1])
    last=None; rank=0
    for pos,(idx,value) in enumerate(numeric,1):
        if last is None or abs(value-last)>1e-9:
            rank=pos; last=value
        race_rows[idx]["st_rank"]=rank


def parse_k_text(text: str, yyyymmdd: str) -> list[dict]:
    """Parse the official daily K result file.

    Current official K downloads are fixed-length records beginning with T0,
    TH, T1..T6 and T7.  Older v17.179-v17.186 code incorrectly treated the
    extracted K file as the human-readable result sheet, so a successful K
    download could parse as 0 rows.  This parser reads the actual T records.

    3連単 data is intentionally ignored.
    """
    rows=[]
    jcd=None
    rno=None
    race_rows=[]

    def flush():
        nonlocal race_rows
        if not race_rows:
            return
        _assign_st_ranks(race_rows)
        rows.extend(race_rows)
        race_rows=[]

    lines=text.splitlines()
    has_t_records=any(len(x)>=2 and x[:2] in ("T0","TH","T1","T2","T3","T4","T5","T6","T7") for x in lines[:500])

    if has_t_records:
        for raw_line in lines:
            line=raw_line.rstrip("\r\n")
            if len(line)<2:
                continue
            rtype=line[:2]
            if rtype=="T0":
                flush()
                code=line[2:4].strip() if len(line)>=4 else ""
                if code.isdigit() and 1<=int(code)<=24:
                    jcd=code.zfill(2)
                rno=None
                continue
            if rtype=="TH":
                flush()
                code=line[2:4].strip() if len(line)>=4 else ""
                race=line[4:6].strip() if len(line)>=6 else ""
                if code.isdigit() and 1<=int(code)<=24:
                    jcd=code.zfill(2)
                if race.isdigit() and 1<=int(race)<=12:
                    rno=int(race)
                else:
                    rno=None
                continue
            if rtype=="T7":
                flush()
                continue
            if not (len(rtype)==2 and rtype[0]=="T" and rtype[1] in "123456"):
                continue
            if not jcd or not rno or len(line)<17:
                continue
            lane=int(rtype[1])
            course_s=line[2:3].strip()
            reg=line[3:8].strip()
            finish=line[8:9].strip()
            st_raw=_normalize_k_st(line[14:17])
            if not course_s.isdigit() or not (1<=int(course_s)<=6):
                continue
            # Some K layouts reserve five characters for the registration no.
            # Normalize an optional leading zero, while preserving real digits.
            if not reg.isdigit():
                continue
            reg=reg.lstrip("0") or "0"
            if len(reg)<4:
                reg=reg.zfill(4)
            race_rows.append({
                "date":yyyymmdd,"jcd":jcd,"rno":rno,
                "registration_no":reg,"lane":lane,"course":int(course_s),
                "finish":finish or "0","st_raw":st_raw,"st_rank":None,
                "source":"official-k-download-backfill",
            })
        flush()
        return rows

    # Compatibility fallback for any legacy human-readable result text.
    race_rows=[]; jcd=rno=None; in_result_rows=False
    def flush_legacy():
        nonlocal race_rows
        if not race_rows: return
        _assign_st_ranks(race_rows); rows.extend(race_rows); race_rows=[]
    for raw_line in lines:
        line=raw_line.rstrip("\r\n"); compact=_norm(line)
        for name,code in sorted(VENUE_CODE.items(),key=lambda kv:len(kv[0]),reverse=True):
            if name in compact and ("成績" in compact or "ボートレース" in line):
                flush_legacy(); jcd=code; rno=None; in_result_rows=False; break
        m_race=re.match(r"^\s*(?:第\s*)?(\d{1,2})R\s+.*H\s*\d+",line,re.I)
        if m_race:
            flush_legacy(); rno=int(m_race.group(1)); in_result_rows=False; continue
        if "スタートタイミンク" in line or "スタートタイミング" in line or ("進入" in line and "スタート" in line and "登番" in line):
            in_result_rows=True; continue
        if not in_result_rows or not jcd or not rno: continue
        if not line.strip() or set(line.strip()) <= {"-"}:
            if race_rows and not line.strip(): flush_legacy(); in_result_rows=False
            continue
        finish=lane=reg=entry=st_raw=None
        if len(line)>=48:
            finish=line[2:4].strip(); lane=line[6:7].strip(); reg=line[8:12].strip()
            entry=line[38:39].strip(); st_raw=line[43:47].strip()
        if not (lane and lane.isdigit() and reg and reg.isdigit() and entry and entry.isdigit()):
            continue
        lane_i,course_i=int(lane),int(entry)
        if not (1<=lane_i<=6 and 1<=course_i<=6): continue
        race_rows.append({"date":yyyymmdd,"jcd":jcd,"rno":rno,"registration_no":str(reg),
                          "lane":lane_i,"course":course_i,"finish":str(finish or "").lstrip("0") or "0",
                          "st_raw":str(st_raw or "").strip(),"st_rank":None,
                          "source":"official-k-download-backfill"})
    flush_legacy()
    return rows


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db=db; self._thread=None; self._stop=threading.Event()
        self.status={"phase":"本日の出走表待ち","total_racers":0,"pending_racers":0,"stored_runs":0,"errors":[]}

    @staticmethod
    def _in_window(now: datetime) -> bool:
        return dt_time(0,0) <= now.time() <= dt_time(23,59,59,999999)

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,name="course-history-target-backfill",daemon=True)
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            now=datetime.now(JST)
            today=now.strftime("%Y%m%d")
            if self._in_window(now):
                try: self._run_target_window(today)
                except Exception as exc:
                    self.status={**self.db.get_course_history_target_status(today),"phase":"収集処理エラー","scheduler_error":f"{type(exc).__name__}: {exc}"}
                # This wait only re-checks today's SQLite racelists for newly discovered targets.
                # No official history request occurs unless an incomplete target exists.
                self._stop.wait(LOCAL_TARGET_CHECK_SECONDS)
            else:
                self._stop.wait(60)

    def _fetch_day(self, session: requests.Session, cursor):
        ymd=cursor.strftime("%Y%m%d"); yy=cursor.strftime("%y%m%d")
        url=f"https://www1.mbrace.or.jp/od2/K/{cursor:%Y%m}/k{yy}.lzh"
        last_error=None
        for attempt in range(1,MAX_FETCH_ATTEMPTS+1):
            if self._stop.is_set() or not self._in_window(datetime.now(JST)): return "window_end",[],None
            try:
                r=session.get(url,timeout=20)
                if r.status_code==404: return "no_data",[],None
                r.raise_for_status()
                try: import lhafile
                except ImportError as exc: raise RuntimeError("lhafile が未導入です。requirements.txt から再デプロイしてください") from exc
                archive=lhafile.Lhafile(io.BytesIO(r.content)); names=archive.namelist()
                if not names: raise RuntimeError("公式Kファイルを展開できませんでした")
                raw=archive.read(names[0])
                return "ok",parse_k_text(raw.decode("cp932",errors="replace"),ymd),None
            except Exception as exc:
                last_error=f"{type(exc).__name__}: {exc}"
                if attempt<MAX_FETCH_ATTEMPTS: self._stop.wait(RETRY_PAUSE_SECONDS)
        return "error",[],last_error

    def _resolve_target_floor(self, session: requests.Session, target: dict) -> str:
        """Resolve the historical floor without making one web request per racer.

        v17.185 resolved missing registration terms by opening the official profile
        page for every target before the first K file was processed. With 500+
        racers this could leave the UI at 0 saved runs for a long time even though
        the K backfill itself had not started. v17.186 only uses already-saved
        official profile data here. Missing terms simply keep the existing floor;
        the shared daily K scan starts immediately.
        """
        reg=str(target.get("registration_no") or ""); jcd=str(target.get("jcd") or "").zfill(2)
        existing=str(target.get("floor_date") or HISTORY_FLOOR)
        if existing!=HISTORY_FLOOR: return existing
        period=self.db.get_course_history_profile_period(reg)
        if period is None:
            return existing
        floor=_registration_term_floor(period)
        self.db.set_course_history_target_floor(reg,jcd,floor,period)
        return floor

    def _finish_ready_or_floor(self, today: str):
        pending=self.db.get_course_history_pending_targets(today); done=[]
        for x in pending:
            key=(str(x["registration_no"]),str(x["jcd"]).zfill(2))
            cursor=str(x.get("cursor_date") or ""); floor=str(x.get("floor_date") or HISTORY_FLOOR)
            if self.db.course_history_target_has_ten(*key) or (cursor and cursor<floor): done.append(key)
        self.db.complete_course_history_targets(done)
        return done

    def _run_target_window(self, today: str):
        now=datetime.now(JST); start_date=(now.date()-timedelta(days=1)).strftime("%Y%m%d")
        self.db.ensure_course_history_today_targets(today,start_date,HISTORY_FLOOR)
        # v17.187 parser migration: v17.179-v17.186 could successfully download K files
        # but parse 0 rows. Replay today's incomplete targets from yesterday exactly once.
        self.db.ensure_course_history_parser_v2_replay(today,start_date)
        self.status=self.db.get_course_history_target_status(today)
        targets=self.db.get_course_history_pending_targets(today)
        if not targets: return

        session=requests.Session(); session.headers.update({"User-Agent":"BOAT-AI-Lab/1.0 official-result-history-current-racers"})
        for target in targets:
            if self._stop.is_set() or not self._in_window(datetime.now(JST)): return
            self._resolve_target_floor(session,target)
        self._finish_ready_or_floor(today)

        while self._in_window(datetime.now(JST)) and not self._stop.is_set():
            self._finish_ready_or_floor(today)
            current=self.db.get_course_history_pending_targets(today)
            if not current: break
            cursor_text=max(str(x.get("cursor_date") or start_date) for x in current)
            cursor=datetime.strptime(cursor_text,"%Y%m%d").date(); ymd=cursor.strftime("%Y%m%d")
            active=[x for x in current if str(x.get("cursor_date") or start_date)==ymd and ymd>=str(x.get("floor_date") or HISTORY_FLOOR)]
            if not active:
                self._finish_ready_or_floor(today); continue
            active_regs={str(x["registration_no"]) for x in active}
            active_keys=[(str(x["registration_no"]),str(x["jcd"]).zfill(2)) for x in active]
            # Publish progress before the network request so the top screen
            # shows that the collector has actually entered the K-file phase.
            self.status={**self.db.get_course_history_target_status(today),
                         "phase":"公式Kデータ取得中",
                         "last_fetch_date":ymd,"last_fetch_state":"fetching",
                         "last_parsed_rows":0,"last_matched_rows":0}
            state,rows,error=self._fetch_day(session,cursor)
            self.status={**self.db.get_course_history_target_status(today),
                         "last_fetch_date":ymd,"last_fetch_state":state,
                         "last_parsed_rows":len(rows or []),"last_matched_rows":0,
                         "last_fetch_error":error}
            if state=="window_end": break
            if state=="error":
                self.db.mark_course_history_target_errors(active_keys,ymd,error or "取得失敗",MAX_FETCH_ATTEMPTS)
                self.status=self.db.get_course_history_target_status(today)
                # Other targets with a different cursor may continue on the next local scheduler pass;
                # these failed keys themselves are not retried again today.
                return
            matched_count=0
            if state=="ok" and rows:
                filtered=[x for x in rows if str(x.get("registration_no") or "") in active_regs]
                matched_count=len(filtered)
                self.db.save_course_history_runs(filtered,keep_per_local_course=10)
            # Preserve fetch diagnostics after DB progress refresh. A successful
            # K file with parsed_rows=0 is now visible immediately instead of
            # looking like a collector that is simply stuck.
            fetch_diag={"last_fetch_date":ymd,"last_fetch_state":state,
                        "last_parsed_rows":len(rows or []),
                        "last_matched_rows":matched_count,"last_fetch_error":error}
            # Targets that now have all 10x(全国+本日の場) finish immediately.
            ready=[k for k in active_keys if self.db.course_history_target_has_ten(*k)]
            self.db.complete_course_history_targets(ready)
            ready_set=set(ready)
            remaining=[k for k in active_keys if k not in ready_set]
            next_date=(cursor-timedelta(days=1)).strftime("%Y%m%d")
            self.db.advance_course_history_targets(remaining,next_date)
            self._finish_ready_or_floor(today)
            self.status={**self.db.get_course_history_target_status(today),**fetch_diag}
            self._stop.wait(SUCCESS_PAUSE_SECONDS)
        self.status=self.db.get_course_history_target_status(today)
