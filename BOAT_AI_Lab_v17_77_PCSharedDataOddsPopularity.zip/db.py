from __future__ import annotations

import json
import os
import shutil
import sqlite3
from pathlib import Path
from typing import Any

class BoatDB:
    def __init__(self, path: str | None = None):
        if path is None:
            local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
            shared_dir = Path(local_app) / "BOAT_AI_Lab"
            shared_dir.mkdir(parents=True, exist_ok=True)
            shared_db = shared_dir / "boat_ai.db"

            # 初回だけ旧バージョンの同階層DBがあれば移行
            legacy = Path("boat_ai.db")
            if not shared_db.exists() and legacy.exists():
                try:
                    shutil.copy2(legacy, shared_db)
                except Exception:
                    pass

            self.path = shared_db
        else:
            self.path = Path(path)

        self._init()

    def connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self.connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS venue_meeting_day (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                day_number INTEGER,
                day_label TEXT,
                official_label TEXT,
                source TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd)
            );

            CREATE TABLE IF NOT EXISTS race_schedule (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                deadline TEXT,
                source TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS basic_data_state (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                logic_version TEXT NOT NULL,
                status TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_error TEXT,
                PRIMARY KEY(date, jcd, rno, logic_version)
            );

            CREATE TABLE IF NOT EXISTS race_snapshots (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                kind TEXT NOT NULL,
                captured_at TEXT DEFAULT CURRENT_TIMESTAMP,
                payload TEXT NOT NULL,
                PRIMARY KEY(date, jcd, rno, kind)
            );

            CREATE TABLE IF NOT EXISTS race_results (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                trifecta TEXT,
                payout_yen INTEGER,
                odds REAL,
                kimarite TEXT,
                payload TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                confidence REAL,
                judgement TEXT,
                scenario TEXT,
                main_picks TEXT,
                value_picks TEXT,
                leaks TEXT,
                source_snapshot TEXT,
                ai_comment TEXT,
                UNIQUE(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS racer_comments (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                lane INTEGER NOT NULL,
                comment TEXT NOT NULL,
                source TEXT,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno, lane)
            );

            CREATE TABLE IF NOT EXISTS venue_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jcd TEXT NOT NULL,
                venue TEXT,
                source_url TEXT NOT NULL,
                source_kind TEXT NOT NULL,
                title TEXT,
                content_text TEXT,
                content_hash TEXT,
                local_path TEXT,
                fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(jcd, source_url)
            );

            CREATE INDEX IF NOT EXISTS idx_venue_knowledge_jcd
            ON venue_knowledge(jcd);

            CREATE TABLE IF NOT EXISTS venue_knowledge_state (
                jcd TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                completed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                source_count INTEGER DEFAULT 0
            );
            """)



    def save_before_atomic(self, date, jcd, rno, data):
        payload = json.dumps(data, ensure_ascii=False)
        with self.connect() as con:
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, str(jcd).zfill(2), int(rno), "beforeinfo", payload))
            con.commit()

    def before_snapshot_quality(self, date, jcd, rno):
        snap = self.get_snapshot(date, str(jcd).zfill(2), int(rno), "beforeinfo")
        if not snap:
            return {"meaningful": False, "racers": 0, "starts": 0, "original_exhibition": 0, "weather_fields": 0}

        data = snap.get("data") or {}
        racers = data.get("racers") or []
        starts = data.get("start_display") or []
        original = data.get("original_exhibition") or []
        weather = data.get("weather") or {}
        wf = sum(1 for v in weather.values() if v is not None and v != "")

        return {
            "meaningful": bool(racers or starts or original or wf),
            "racers": len(racers),
            "starts": len(starts),
            "original_exhibition": len(original),
            "weather_fields": wf,
        }

    def get_before_complete_keys(self, date):
        out = set()
        for row in self.get_day_snapshots(date, "beforeinfo"):
            data = row.get("data") or {}
            racers = data.get("racers") or []
            starts = data.get("start_display") or []
            original = data.get("original_exhibition") or []
            weather = data.get("weather") or {}
            wf = sum(1 for v in weather.values() if v is not None and v != "")
            if racers or starts or original or wf:
                out.add((str(row["jcd"]).zfill(2), int(row["rno"])))
        return out

    def get_scratch_audited_keys(self, date: str):
        REQUIRED_AUDIT_VERSION = "scratch-audit-v1"

        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload
                FROM race_snapshots
                WHERE date=? AND kind='racelist'
            """, (date,)).fetchall()

        out = set()

        for row in rows:
            try:
                data = json.loads(row["payload"])
                if data.get("scratch_audit_version") == REQUIRED_AUDIT_VERSION:
                    out.add(
                        (
                            str(row["jcd"]).zfill(2),
                            int(row["rno"]),
                        )
                    )
            except Exception:
                pass

        return out

    def get_odds_complete_keys(self, date: str):
        REQUIRED_VALIDATION_VERSION = "scratch-matrix-v2"

        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload
                FROM race_snapshots
                WHERE date=? AND kind='odds3t'
            """, (date,)).fetchall()

        out = set()
        for row in rows:
            try:
                data = json.loads(row["payload"])
                if data.get("odds_validation_version") != REQUIRED_VALIDATION_VERSION:
                    continue

                odds = data.get("odds") or []
                expected = int(data.get("expected_count") or 120)
                combos = [str(x.get("combo") or "") for x in odds]

                if (
                    expected > 0
                    and len(odds) == expected
                    and len(set(combos)) == expected
                ):
                    out.add((str(row["jcd"]).zfill(2), int(row["rno"])))
            except Exception:
                pass
        return out

    def save_odds_atomic(
        self,
        date: str,
        jcd: str,
        rno: int,
        odds_data: dict,
    ):
        """
        Save the 3連単 odds snapshot only when caller already validated
        that all 120 combinations exist.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        payload = json.dumps(odds_data, ensure_ascii=False)

        with self.connect() as con:
            con.execute("BEGIN")
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, jcd, rno, "odds3t", payload))
            con.commit()

    def verify_odds_snapshot(self, date: str, jcd: str, rno: int):
        REQUIRED_VALIDATION_VERSION = "scratch-matrix-v2"
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        with self.connect() as con:
            row = con.execute("""
                SELECT payload
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind='odds3t'
            """, (date, jcd, rno)).fetchone()

        if not row:
            return False

        try:
            data = json.loads(row["payload"])
        except Exception:
            return False

        if data.get("odds_validation_version") != REQUIRED_VALIDATION_VERSION:
            return False

        odds = data.get("odds") or []
        expected = int(data.get("expected_count") or 120)
        combos = [str(x.get("combo") or "") for x in odds]

        return (
            expected > 0
            and len(odds) == expected
            and len(combos) == expected
            and len(set(combos)) == expected
            and all("-" in c for c in combos)
        )

    def save_basic_race_atomic(
        self,
        date: str,
        jcd: str,
        rno: int,
        race_data: dict,
        deadline: str,
        logic_version: str,
    ):
        """
        One transaction:
          1) racelist snapshot
          2) deadline schedule
          3) completed state

        If any SQL step fails, none of the three is committed.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        payload = json.dumps(race_data, ensure_ascii=False)

        with self.connect() as con:
            con.execute("BEGIN")

            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, jcd, rno, "racelist", payload))

            con.execute("""
                INSERT INTO race_schedule(date,jcd,rno,deadline,source,updated_at)
                VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno)
                DO UPDATE SET
                    deadline=excluded.deadline,
                    source=excluded.source,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, jcd, rno, deadline,
                "racelist-basic-atomic"
            ))

            con.execute("""
                INSERT INTO basic_data_state(
                    date,jcd,rno,logic_version,status,last_error,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno,logic_version)
                DO UPDATE SET
                    status=excluded.status,
                    last_error=NULL,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, jcd, rno, logic_version,
                "complete", None
            ))

            con.commit()

    def mark_basic_error(
        self,
        date: str,
        jcd: str,
        rno: int,
        logic_version: str,
        error: str,
    ):
        with self.connect() as con:
            con.execute("""
                INSERT INTO basic_data_state(
                    date,jcd,rno,logic_version,status,last_error,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno,logic_version)
                DO UPDATE SET
                    status='error',
                    last_error=excluded.last_error,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, str(jcd).zfill(2), int(rno),
                logic_version, "error", str(error)[:1000]
            ))
            con.commit()

    def get_basic_complete_keys(self, date: str, logic_version: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno
                FROM basic_data_state
                WHERE date=? AND logic_version=? AND status='complete'
            """, (date, logic_version)).fetchall()

        return {
            (str(row["jcd"]).zfill(2), int(row["rno"]))
            for row in rows
        }

    def basic_progress(self, date: str, logic_version: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT status, COUNT(*) AS cnt
                FROM basic_data_state
                WHERE date=? AND logic_version=?
                GROUP BY status
            """, (date, logic_version)).fetchall()

        result = {"complete": 0, "error": 0}
        for row in rows:
            result[row["status"]] = int(row["cnt"])
        return result

    def verify_basic_race(
        self,
        date: str,
        jcd: str,
        rno: int,
        expected_deadline: str,
        logic_version: str,
    ):
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        with self.connect() as con:
            snap = con.execute("""
                SELECT payload
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind='racelist'
            """, (date, jcd, rno)).fetchone()

            sched = con.execute("""
                SELECT deadline
                FROM race_schedule
                WHERE date=? AND jcd=? AND rno=?
            """, (date, jcd, rno)).fetchone()

            state = con.execute("""
                SELECT status
                FROM basic_data_state
                WHERE date=? AND jcd=? AND rno=? AND logic_version=?
            """, (date, jcd, rno, logic_version)).fetchone()

        if not snap or not sched or not state:
            return False

        try:
            data = json.loads(snap["payload"])
        except Exception:
            return False

        racers = data.get("racers") or []

        return (
            len(racers) == 6
            and str(sched["deadline"]) == str(expected_deadline)
            and state["status"] == "complete"
        )

    def save_snapshot(self, date: str, jcd: str, rno: int, kind: str, data: Any):
        payload = json.dumps(data, ensure_ascii=False)
        with self.connect() as con:
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET payload=excluded.payload, captured_at=CURRENT_TIMESTAMP
            """, (date,jcd,rno,kind,payload))

    def save_results(self, date: str, jcd: str, rows: list[dict]):
        with self.connect() as con:
            for row in rows:
                payload = json.dumps(row, ensure_ascii=False)
                con.execute("""
                    INSERT INTO race_results(date,jcd,rno,trifecta,payout_yen,odds,kimarite,payload)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(date,jcd,rno)
                    DO UPDATE SET
                      trifecta=excluded.trifecta,
                      payout_yen=excluded.payout_yen,
                      odds=excluded.odds,
                      kimarite=excluded.kimarite,
                      payload=excluded.payload,
                      updated_at=CURRENT_TIMESTAMP
                """, (
                    date, jcd, row["rno"], row.get("trifecta"),
                    row.get("payout_yen"), row.get("odds"),
                    row.get("kimarite"), payload
                ))

    def result_history(self, jcd: str, limit: int = 100):
        with self.connect() as con:
            rows = con.execute("""
                SELECT * FROM race_results
                WHERE jcd=?
                ORDER BY date DESC, rno DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def save_prediction(self, date: str, jcd: str, rno: int, data: dict):
        with self.connect() as con:
            con.execute("""
                INSERT INTO predictions(
                    date,jcd,rno,confidence,judgement,scenario,
                    main_picks,value_picks,leaks,source_snapshot,ai_comment
                )
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(date,jcd,rno)
                DO UPDATE SET
                    created_at=CURRENT_TIMESTAMP,
                    confidence=excluded.confidence,
                    judgement=excluded.judgement,
                    scenario=excluded.scenario,
                    main_picks=excluded.main_picks,
                    value_picks=excluded.value_picks,
                    leaks=excluded.leaks,
                    source_snapshot=excluded.source_snapshot,
                    ai_comment=excluded.ai_comment
            """, (
                date, jcd, rno,
                data.get("confidence"),
                data.get("judgement"),
                data.get("scenario"),
                json.dumps(data.get("main_picks", []), ensure_ascii=False),
                json.dumps(data.get("value_picks", []), ensure_ascii=False),
                json.dumps(data.get("leaks", []), ensure_ascii=False),
                json.dumps(data.get("source_snapshot", {}), ensure_ascii=False),
                data.get("ai_comment"),
            ))

    def get_prediction(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            row = con.execute("""
                SELECT * FROM predictions
                WHERE date=? AND jcd=? AND rno=?
            """, (date,jcd,rno)).fetchone()
        if not row:
            return None
        d = dict(row)
        for k in ["main_picks","value_picks","leaks","source_snapshot"]:
            try:
                d[k] = json.loads(d[k]) if d.get(k) else ([] if k != "source_snapshot" else {})
            except Exception:
                pass
        return d

    def save_comments(self, date: str, jcd: str, rno: int, comments: list[dict]):
        with self.connect() as con:
            for c in comments:
                con.execute("""
                    INSERT INTO racer_comments(date,jcd,rno,lane,comment,source)
                    VALUES(?,?,?,?,?,?)
                    ON CONFLICT(date,jcd,rno,lane)
                    DO UPDATE SET
                      comment=excluded.comment,
                      source=excluded.source,
                      saved_at=CURRENT_TIMESTAMP
                """, (date,jcd,rno,c["lane"],c["comment"],c.get("source")))

    def get_comments(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            rows = con.execute("""
                SELECT lane,comment,source,saved_at
                FROM racer_comments
                WHERE date=? AND jcd=? AND rno=?
                ORDER BY lane
            """,(date,jcd,rno)).fetchall()
        return [dict(x) for x in rows]

    def compare_prediction(self, date: str, jcd: str, rno: int):
        pred = self.get_prediction(date,jcd,rno)
        with self.connect() as con:
            res = con.execute("""
                SELECT * FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """,(date,jcd,rno)).fetchone()

        if not pred or not res:
            return {
                "prediction": pred,
                "result": dict(res) if res else None,
                "comparison": None
            }

        result = dict(res)
        actual = result.get("trifecta")
        main = pred.get("main_picks") or []
        value = pred.get("value_picks") or []
        all_picks = [x.get("combo") if isinstance(x,dict) else x for x in (main + value)]

        hit = actual in all_picks if actual else False

        expected_first = None
        if all_picks:
            try:
                firsts = [str(x).split("-")[0] for x in all_picks if x]
                expected_first = max(set(firsts), key=firsts.count) if firsts else None
            except Exception:
                expected_first = None

        actual_first = str(actual).split("-")[0] if actual else None
        first_match = expected_first == actual_first if expected_first and actual_first else None

        return {
            "prediction": pred,
            "result": result,
            "comparison": {
                "hit": hit,
                "expected_first": expected_first,
                "actual_first": actual_first,
                "first_match": first_match,
                "kimarite": result.get("kimarite")
            }
        }



    def get_snapshot(self, date: str, jcd: str, rno: int, kind: str):
        with self.connect() as con:
            row = con.execute("""
                SELECT payload,captured_at
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind=?
            """,(date,jcd,rno,kind)).fetchone()
        if not row:
            return None
        try:
            return {
                "data": json.loads(row["payload"]),
                "captured_at": row["captured_at"]
            }
        except Exception:
            return None


    def get_day_snapshots(self, date: str, kind: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload,captured_at
                FROM race_snapshots
                WHERE date=? AND kind=?
                ORDER BY jcd,rno
            """,(date,kind)).fetchall()

        out = []
        for row in rows:
            try:
                payload = json.loads(row["payload"])
            except Exception:
                continue
            out.append({
                "jcd": row["jcd"],
                "rno": row["rno"],
                "captured_at": row["captured_at"],
                "data": payload,
            })
        return out

    def get_local_frame_stats(self, before_date: str, jcd: str, racers: list[dict]):
        """Build racer x venue x frame history from already saved official races.

        Only races before ``before_date`` are used, so a prediction can never
        learn from its own day or a future result.  The trifecta identifies the
        top three boat numbers; the saved racelist supplies registration number
        and frame.
        """
        wanted = {
            (str(x.get("registration_no") or ""), int(x.get("lane") or 0))
            for x in (racers or [])
            if x.get("registration_no") and 1 <= int(x.get("lane") or 0) <= 6
        }
        if not wanted:
            return {}

        with self.connect() as con:
            rows = con.execute("""
                SELECT s.date,s.payload,rr.trifecta
                FROM race_snapshots s
                JOIN race_results rr
                  ON rr.date=s.date AND rr.jcd=s.jcd AND rr.rno=s.rno
                WHERE s.kind='racelist' AND s.jcd=? AND s.date<?
                  AND rr.trifecta IS NOT NULL
                ORDER BY s.date,s.rno
            """, (str(jcd).zfill(2), before_date)).fetchall()

        counts = {
            key: {"starts": 0, "first": 0, "second": 0, "third": 0,
                  "from_date": None, "to_date": None}
            for key in wanted
        }
        for row in rows:
            try:
                data = json.loads(row["payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            top = [x for x in str(row["trifecta"] or "").replace(" ", "").split("-") if x in "123456"]
            if len(top) != 3 or len(set(top)) != 3:
                continue
            positions = {int(lane): pos + 1 for pos, lane in enumerate(top)}
            for racer in data.get("racers") or []:
                reg = str(racer.get("registration_no") or "")
                lane = int(racer.get("lane") or 0)
                key = (reg, lane)
                if key not in counts or racer.get("scratched"):
                    continue
                item = counts[key]
                item["starts"] += 1
                pos = positions.get(lane)
                if pos == 1:
                    item["first"] += 1
                elif pos == 2:
                    item["second"] += 1
                elif pos == 3:
                    item["third"] += 1
                item["from_date"] = item["from_date"] or row["date"]
                item["to_date"] = row["date"]

        out = {}
        for (reg, lane), item in counts.items():
            starts = item["starts"]
            if not starts:
                continue
            out[(reg, lane)] = {
                **item,
                "frame": lane,
                "win_rate": round(item["first"] / starts * 100, 1),
                "quinella_rate": round((item["first"] + item["second"]) / starts * 100, 1),
                "trio_rate": round((item["first"] + item["second"] + item["third"]) / starts * 100, 1),
                "source": "saved-official-racelist-and-results",
            }
        return out

    def get_local_frame_history(self, before_date: str, jcd: str, racers: list[dict], limit: int = 10):
        """Last local starts for each racer in the same frame as today's race."""
        targets = {
            (str(x.get("registration_no") or ""), int(x.get("lane") or 0)): {
                "lane": int(x.get("lane") or 0),
                "registration_no": str(x.get("registration_no") or ""),
                "name": x.get("name"),
                "history": [],
            }
            for x in (racers or []) if x.get("registration_no")
        }
        if not targets:
            return {"racers": [], "missing_details": []}
        with self.connect() as con:
            rows = con.execute("""
                SELECT s.date,s.rno,s.payload,rr.trifecta,rr.payload AS result_payload
                FROM race_snapshots s JOIN race_results rr
                  ON rr.date=s.date AND rr.jcd=s.jcd AND rr.rno=s.rno
                WHERE s.kind='racelist' AND s.jcd=? AND s.date<?
                  AND rr.trifecta IS NOT NULL
                ORDER BY s.date DESC,s.rno DESC
            """, (str(jcd).zfill(2), before_date)).fetchall()
        missing = set()
        for row in rows:
            try:
                race = json.loads(row["payload"] or "{}")
                result = json.loads(row["result_payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            finishers = result.get("finishers") or []
            by_reg = {str(x.get("registration_no") or ""): x for x in finishers}
            by_lane = {int(x.get("lane") or 0): x for x in finishers}
            top = [int(x) for x in str(row["trifecta"] or "").split("-") if x.isdigit()]
            for old in race.get("racers") or []:
                key = (str(old.get("registration_no") or ""), int(old.get("lane") or 0))
                target = targets.get(key)
                if not target or len(target["history"]) >= limit or old.get("scratched"):
                    continue
                found = by_reg.get(key[0]) or by_lane.get(key[1])
                if found:
                    finish = found.get("finish")
                    course = found.get("course")
                    if course is None or finish is None:
                        missing.add((row["date"], int(row["rno"])))
                else:
                    finish = top.index(key[1]) + 1 if key[1] in top else None
                    course = None
                    missing.add((row["date"], int(row["rno"])))
                target["history"].append({
                    "date": row["date"], "rno": int(row["rno"]),
                    "frame": key[1], "course": course, "finish": finish,
                    "detail_complete": bool(found and course is not None and finish is not None),
                })
        return {
            "racers": [targets[k] for k in sorted(targets, key=lambda x: x[1])],
            "missing_details": [
                {"date": date, "jcd": str(jcd).zfill(2), "rno": rno}
                for date, rno in sorted(missing, reverse=True)
            ],
        }







    def get_result_for_race_db(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            row = con.execute("""
                SELECT trifecta,payout_yen,odds,kimarite,payload,updated_at
                FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), int(rno))).fetchone()

        if not row:
            return None

        try:
            payload = json.loads(row["payload"]) if row["payload"] else {}
        except Exception:
            payload = {}

        return {
            **payload,
            "trifecta": row["trifecta"],
            "payout_yen": row["payout_yen"],
            "odds": row["odds"],
            "kimarite": row["kimarite"],
            "updated_at": row["updated_at"],
        }

    def get_result_complete_keys(self, date: str):
        return self.get_confirmed_result_races(date)

    def get_confirmed_result_races(self, date: str):
        """
        Return {(jcd, rno)} for races whose final result is already persisted.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno
                FROM race_results
                WHERE date=? AND trifecta IS NOT NULL AND payout_yen IS NOT NULL
            """, (date,)).fetchall()

        return {
            (str(row["jcd"]).zfill(2), int(row["rno"]))
            for row in rows
        }

    def save_meeting_day(
        self,
        date: str,
        jcd: str,
        day_number: int | None,
        day_label: str | None,
        official_label: str | None = None,
        source: str = "official",
    ):
        with self.connect() as con:
            con.execute("""
                INSERT INTO venue_meeting_day(
                    date,jcd,day_number,day_label,official_label,source,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd) DO UPDATE SET
                    day_number=excluded.day_number,
                    day_label=excluded.day_label,
                    official_label=excluded.official_label,
                    source=excluded.source,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, str(jcd).zfill(2),
                day_number, day_label, official_label, source
            ))
            con.commit()

    def get_day_meeting_days(self, date: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,day_number,day_label,official_label,source
                FROM venue_meeting_day
                WHERE date=?
            """, (date,)).fetchall()

        return {
            str(row["jcd"]).zfill(2): {
                "number": row["day_number"],
                "label": row["day_label"],
                "official_label": row["official_label"],
                "source": row["source"],
            }
            for row in rows
        }

    def save_race_schedule(self, date: str, jcd: str, races: list[dict], source: str = "official"):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            for race in races:
                rno = int(race["rno"])
                deadline = race.get("deadline")
                if not deadline:
                    continue
                con.execute("""
                    INSERT INTO race_schedule(date,jcd,rno,deadline,source,updated_at)
                    VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(date,jcd,rno) DO UPDATE SET
                        deadline=excluded.deadline,
                        source=excluded.source,
                        updated_at=CURRENT_TIMESTAMP
                """, (date, jcd, rno, deadline, source))
            con.commit()

    def get_race_schedule(self, date: str, jcd: str):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            rows = con.execute("""
                SELECT rno,deadline,source,updated_at
                FROM race_schedule
                WHERE date=? AND jcd=?
                ORDER BY rno
            """, (date, jcd)).fetchall()
        return [
            {
                "rno": int(row["rno"]),
                "deadline": row["deadline"],
                "source": row["source"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def get_day_schedule(self, date: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,deadline,source,updated_at
                FROM race_schedule
                WHERE date=?
                ORDER BY jcd,rno
            """, (date,)).fetchall()

        out = {}
        for row in rows:
            jcd = str(row["jcd"]).zfill(2)
            out.setdefault(jcd, []).append({
                "rno": int(row["rno"]),
                "deadline": row["deadline"],
                "source": row["source"],
                "updated_at": row["updated_at"],
            })
        return out

    def get_racelist_presence(self, date: str):
        """
        Return {jcd: [rno,...]} for racelist snapshots already stored for date.
        Used only as a fallback for day/open-venue detection.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno
                FROM race_snapshots
                WHERE date=? AND kind='racelist'
                ORDER BY jcd,rno
            """, (date,)).fetchall()

        out = {}
        for row in rows:
            jcd = str(row["jcd"]).zfill(2)
            out.setdefault(jcd, []).append(int(row["rno"]))
        return out

    def get_race_revision(self, date: str, jcd: str, rno: int):
        """
        軽量な更新検知用。
        payload本体を返さず、各データの更新時刻だけ返す。
        """
        with self.connect() as con:
            snaps = con.execute("""
                SELECT kind,captured_at
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), rno)).fetchall()

            result = con.execute("""
                SELECT updated_at
                FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), rno)).fetchone()

        out = {
            "racelist": None,
            "beforeinfo": None,
            "odds3t": None,
            "result": result["updated_at"] if result else None,
        }
        for row in snaps:
            if row["kind"] in out:
                out[row["kind"]] = row["captured_at"]

        out["token"] = "|".join([
            str(out["racelist"] or ""),
            str(out["beforeinfo"] or ""),
            str(out["odds3t"] or ""),
            str(out["result"] or ""),
        ])
        return out

    def get_snapshot_index(self, date: str, kind: str):
        """Return {(jcd, rno): captured_at} for one day/kind."""
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,captured_at
                FROM race_snapshots
                WHERE date=? AND kind=?
            """, (date, kind)).fetchall()
        return {
            (str(row["jcd"]).zfill(2), int(row["rno"])): row["captured_at"]
            for row in rows
        }

    def prediction_summary(self, date: str | None = None):
        with self.connect() as con:
            if date:
                pred_rows = con.execute("""
                    SELECT date,jcd,rno FROM predictions WHERE date=?
                """,(date,)).fetchall()
            else:
                pred_rows = con.execute("""
                    SELECT date,jcd,rno FROM predictions
                """).fetchall()

            total = len(pred_rows)
            hit = 0

            for p in pred_rows:
                pred = self.get_prediction(p["date"], p["jcd"], p["rno"])
                res = con.execute("""
                    SELECT trifecta FROM race_results
                    WHERE date=? AND jcd=? AND rno=?
                """,(p["date"],p["jcd"],p["rno"])).fetchone()

                if not res or not res["trifecta"] or not pred:
                    continue

                picks = []
                for item in (pred.get("main_picks") or []) + (pred.get("value_picks") or []):
                    picks.append(item.get("combo") if isinstance(item,dict) else item)

                if res["trifecta"] in picks:
                    hit += 1

        return {
            "predictions": total,
            "hits": hit,
            "hit_rate": round(hit / total * 100, 1) if total else None,
        }


    def save_venue_knowledge(
        self, jcd, venue, source_url, source_kind,
        title="", content_text="", content_hash="", local_path=None
    ):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            con.execute("""
                INSERT INTO venue_knowledge(
                    jcd, venue, source_url, source_kind, title,
                    content_text, content_hash, local_path
                )
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(jcd, source_url)
                DO UPDATE SET
                    venue=excluded.venue,
                    source_kind=excluded.source_kind,
                    title=excluded.title,
                    content_text=excluded.content_text,
                    content_hash=excluded.content_hash,
                    local_path=excluded.local_path,
                    fetched_at=CURRENT_TIMESTAMP
            """, (
                jcd, venue, source_url, source_kind, title,
                content_text, content_hash, local_path
            ))
            con.commit()

    def get_venue_knowledge(self, jcd, limit=500):
        jcd = str(jcd).zfill(2)
        limit = min(max(int(limit), 1), 2000)
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,venue,source_url,source_kind,title,
                       content_hash,local_path,fetched_at,
                       length(content_text) AS text_length
                FROM venue_knowledge
                WHERE jcd=?
                ORDER BY fetched_at DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def get_venue_knowledge_text(self, jcd, limit=300):
        jcd = str(jcd).zfill(2)
        limit = min(max(int(limit), 1), 1000)
        with self.connect() as con:
            rows = con.execute("""
                SELECT source_url,source_kind,title,content_text,fetched_at
                FROM venue_knowledge
                WHERE jcd=? AND coalesce(content_text,'') <> ''
                ORDER BY
                  CASE source_kind
                    WHEN 'boatrace-official-stadium' THEN 0
                    WHEN 'venue-official-pdf' THEN 1
                    ELSE 2
                  END,
                  fetched_at DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def is_venue_knowledge_complete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            row = con.execute("""
                SELECT status FROM venue_knowledge_state
                WHERE jcd=?
            """, (jcd,)).fetchone()
        return bool(row and row["status"] == "complete")

    def mark_venue_knowledge_complete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            count = con.execute("""
                SELECT count(*) AS n
                FROM venue_knowledge
                WHERE jcd=?
            """, (jcd,)).fetchone()["n"]

            con.execute("""
                INSERT INTO venue_knowledge_state(
                    jcd,status,completed_at,source_count
                )
                VALUES(?, 'complete', CURRENT_TIMESTAMP, ?)
                ON CONFLICT(jcd)
                DO UPDATE SET
                    status='complete',
                    completed_at=CURRENT_TIMESTAMP,
                    source_count=excluded.source_count
            """, (jcd, int(count or 0)))
            con.commit()
        return int(count or 0)

    def mark_venue_knowledge_incomplete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            count = con.execute("""
                SELECT count(*) AS n
                FROM venue_knowledge
                WHERE jcd=?
            """, (jcd,)).fetchone()["n"]
            con.execute("""
                INSERT INTO venue_knowledge_state(
                    jcd,status,completed_at,source_count
                )
                VALUES(?, 'incomplete', CURRENT_TIMESTAMP, ?)
                ON CONFLICT(jcd)
                DO UPDATE SET
                    status='incomplete',
                    completed_at=CURRENT_TIMESTAMP,
                    source_count=excluded.source_count
            """, (jcd, int(count or 0)))
            con.commit()

    def venue_knowledge_complete_codes(self):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd FROM venue_knowledge_state
                WHERE status='complete'
                ORDER BY jcd
            """).fetchall()
        return [str(x["jcd"]).zfill(2) for x in rows]

    def venue_knowledge_monitor(self):
        names = {
            "01":"桐生","02":"戸田","03":"江戸川","04":"平和島",
            "05":"多摩川","06":"浜名湖","07":"蒲郡","08":"常滑",
            "09":"津","10":"三国","11":"びわこ","12":"住之江",
            "13":"尼崎","14":"鳴門","15":"丸亀","16":"児島",
            "17":"宮島","18":"徳山","19":"下関","20":"若松",
            "21":"芦屋","22":"福岡","23":"唐津","24":"大村",
        }
        out=[]
        with self.connect() as con:
            states={
                str(r["jcd"]).zfill(2): dict(r)
                for r in con.execute(
                    "SELECT * FROM venue_knowledge_state"
                ).fetchall()
            }
            rows=con.execute("""
                SELECT jcd, source_kind, count(*) AS n,
                       sum(length(coalesce(content_text,''))) AS chars
                FROM venue_knowledge
                GROUP BY jcd, source_kind
            """).fetchall()

        by={}
        for r in rows:
            j=str(r["jcd"]).zfill(2)
            x=by.setdefault(j, {"kinds":{}, "sources":0, "chars":0})
            x["kinds"][r["source_kind"]]=int(r["n"] or 0)
            x["sources"]+=int(r["n"] or 0)
            x["chars"]+=int(r["chars"] or 0)

        for jcd in [f"{i:02d}" for i in range(1,25)]:
            x=by.get(jcd, {"kinds":{}, "sources":0, "chars":0})
            st=states.get(jcd,{})
            kinds=x["kinds"]
            official=sum(
                n for k,n in kinds.items()
                if k != "external-summary-fallback"
            )
            fallback=int(kinds.get("external-summary-fallback",0))
            complete=(st.get("status")=="complete")
            if complete:
                label="反映完了"
            elif fallback:
                label="外部資料で補完中"
            elif official:
                label="公式資料を解析中"
            else:
                label="未取得"
            out.append({
                "jcd":jcd, "venue":names[jcd],
                "status":st.get("status") or "pending",
                "label":label,
                "sources":x["sources"],
                "chars":x["chars"],
                "official_sources":official,
                "fallback_sources":fallback,
                "source_kinds":kinds,
            })
        return out

    def venue_knowledge_summary(self):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,
                       count(*) AS sources,
                       sum(CASE WHEN source_kind LIKE '%pdf%' OR
                                         source_kind LIKE '%file%'
                                THEN 1 ELSE 0 END) AS files,
                       max(fetched_at) AS last_fetched_at
                FROM venue_knowledge
                GROUP BY jcd
                ORDER BY jcd
            """).fetchall()
        return [dict(x) for x in rows]
