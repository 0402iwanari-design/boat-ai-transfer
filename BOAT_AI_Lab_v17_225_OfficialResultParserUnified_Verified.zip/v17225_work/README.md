BOAT AI Lab v17.225

Purpose
- Fix the common retry error: 「公式結果ページ解析0件」.
- Keep v17.223/v17.224 archive-first acceleration, 3-racer concurrency, retry-reason display, and existing DB progress.

Root cause fixed
- course_history.py had its own fragile official-result DOM parser.
- The main BOAT AI Lab already has parser.parse_result_detail(), used by the live result collector and designed for the official result page.
- v17.225 reuses that shared parser instead of maintaining a second incompatible parser.
- A compatibility fallback reads the stable visible semantics (着/枠/ボートレーサー + スタート情報) when historical wrapper classes differ.

Course-history rules preserved
- Actual entry course, never frame number, is the classification key.
- ST / ST rank / finish are kept from the official result page when official verification is used.
- 欠場 is excluded because no start occurred.
- F/L and accident/special finishes are retained when the racer actually started.
- Existing completed history and progress are not reset. Failed individual races remain retry-only.

Validation performed before ZIP
1. Modern official DOM-shaped fixture: 6 racers parsed; 峰4320 = lane1/course1/ST .18/ST-rank5/finish1.
2. Historical-wrapper fallback fixture: entry order 1-2-4-3-6-5; 峰4320 lane4 correctly classified as course3.
3. Special-result fixture: 欠場 excluded; F and 転 retained with ST.
4. v17.222 regression suite: PASS.
5. v17.223 regression/integration suites: PASS.
6. Python compile: PASS.
7. FastAPI import/version: PASS (1.0.225).
8. ZIP integrity: PASS.

Note
- The model container cannot directly make outbound requests to boatrace.jp, so live VPS networking still must be observed after deployment. The parser itself is now unified with the application's already-used official result parser, and both modern and wrapper-variant fixtures are covered.
