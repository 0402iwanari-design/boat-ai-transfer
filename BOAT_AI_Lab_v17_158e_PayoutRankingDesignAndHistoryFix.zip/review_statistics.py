from __future__ import annotations

import calendar
import json
from datetime import datetime

from review_results import combo, timely
from ai_predictor import _bet_recommendation


STAGES = (("pre_prediction", "PRE"), ("post_prediction", "POST"))
MODES = (("hit", "的中率重視"), ("return", "回収率重視"))
PERIODS = (
    ("today", 0, "本日"),
    ("1m", 1, "直近1か月"),
    ("6m", 6, "直近6か月"),
    ("1y", 12, "直近1年"),
)


def _month_start(end_date: str, months: int) -> str:
    end = datetime.strptime(end_date, "%Y%m%d").date()
    serial = end.year * 12 + end.month - 1 - months
    year, month0 = divmod(serial, 12)
    day = min(end.day, calendar.monthrange(year, month0 + 1)[1])
    shifted = end.replace(year=year, month=month0 + 1, day=day)
    # Inclusive SQL range: the day after the shifted boundary.
    return shifted.fromordinal(shifted.toordinal() + 1).strftime("%Y%m%d")


def _loads(raw):
    try:
        return json.loads(raw) if raw else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def _prediction_records(db, end_date: str):
    """Return deadline-valid strategy simulations up to the selected day."""
    with db.connect() as con:
        rows = con.execute(
            """
            SELECT p.date,p.jcd,p.rno,p.created_at,p.source_snapshot,
                   rr.trifecta,rr.payout_yen,rr.odds,
                   rs.deadline
            FROM predictions p
            JOIN race_results rr
              ON rr.date=p.date AND rr.jcd=p.jcd AND rr.rno=p.rno
            LEFT JOIN race_schedule rs
              ON rs.date=p.date AND rs.jcd=p.jcd AND rs.rno=p.rno
            WHERE p.date<=?
              AND rr.trifecta IS NOT NULL
              AND rr.payout_yen IS NOT NULL
            ORDER BY p.date,p.jcd,p.rno
            """,
            (end_date,),
        ).fetchall()

    records = []
    for row in rows:
        snap = _loads(row["source_snapshot"])
        if snap.get("preview"):
            continue
        actual = combo(row["trifecta"])
        if not actual:
            continue
        for stage_key, stage_label in STAGES:
            stage = snap.get(stage_key) or {}
            if stage_label == "POST" and not snap.get("post_ready"):
                continue
            stamp = (
                snap.get("pre_saved_at") if stage_label == "PRE" else None
            ) or snap.get("generated_at") or row["created_at"]
            # New records must be strictly proved as saved before the exact
            # closing time.  Older saved predictions may not have a preserved
            # deadline/snapshot after an app upgrade; do not make their
            # already-confirmed results disappear from the history screen.
            strict_valid = bool(row["deadline"]) and (
                timely(stamp, row["date"], row["deadline"], utc=not bool(snap.get("generated_at")))
                and timely(row["created_at"], row["date"], row["deadline"], utc=True)
            )
            legacy_history = row["date"] < end_date and bool(stage.get("picks") or stage.get("strategies"))
            valid = strict_valid or legacy_history
            if not valid:
                continue
            for mode, mode_label in MODES:
                option = (stage.get("strategies") or {}).get(mode) or {}
                mode_stamp = stage.get("strategies_saved_at") or stamp
                if not legacy_history and not timely(
                    mode_stamp, row["date"], row["deadline"],
                    utc=not bool(snap.get("generated_at")),
                ):
                    continue
                picks = [
                    combo(x.get("combo") if isinstance(x, dict) else x)
                    for x in (option.get("picks") or [])
                ]
                picks = list(dict.fromkeys(x for x in picks if x))
                if not picks:
                    continue
                hit = actual in picks
                payout = int(row["payout_yen"] or 0)
                official_odds = row["odds"]
                if official_odds is None and payout:
                    official_odds = payout / 100.0
                # One race = 5,000 yen total.  The amount is divided equally
                # across every selected combination.  Decimal-yen differences
                # are rounded only after calculating the winning return.
                total_stake = 5000
                stake_per_pick = total_stake / len(picks)
                returned = round(stake_per_pick * (official_odds or 0)) if hit else 0
                decision = stage.get("bet_decision") or _bet_recommendation(
                    stage,
                    post_ready=bool(snap.get("post_ready")),
                    stage_name="post" if stage_label == "POST" else "pre",
                )
                records.append({
                    "date": row["date"],
                    "jcd": str(row["jcd"]).zfill(2),
                    "rno": int(row["rno"]),
                    "stage": stage_label,
                    "mode": mode,
                    "mode_label": mode_label,
                    "actual": actual,
                    "picks": picks,
                    "hit": hit,
                    "stake_yen": total_stake,
                    "stake_per_pick_yen": round(stake_per_pick, 2),
                    "return_yen": returned,
                    "payout_yen": payout,
                    "odds": official_odds,
                    "recommended": bool(decision.get("recommended")),
                    "bet_decision": decision,
                })
    return records


def _metric(rows, stage, mode, recommended_only=False):
    selected = [x for x in rows if x["stage"] == stage and x["mode"] == mode]
    if recommended_only:
        selected = [x for x in selected if x.get("recommended")]
    races = len(selected)
    hits = sum(1 for x in selected if x["hit"])
    stake = sum(x["stake_yen"] for x in selected)
    returned = sum(x["return_yen"] for x in selected)
    return {
        "races": races,
        "hits": hits,
        "hit_rate": round(hits / races * 100, 1) if races else None,
        "stake_yen": stake,
        "return_yen": returned,
        "return_rate": round(returned / stake * 100, 1) if stake else None,
    }


def _period_summary(rows, end_date):
    output = []
    for key, months, label in PERIODS:
        # 「本日」は表示中の日付だけを対象にする。過去日を表示している
        # 場合も、その選択日の1日分として正しく再現できる。
        start = end_date if key == "today" else _month_start(end_date, months)
        part = [x for x in rows if start <= x["date"] <= end_date]
        metrics = {}
        for _, stage in STAGES:
            for mode, _ in MODES:
                metrics[f"{stage}_{mode}"] = _metric(part, stage, mode)
                metrics[f"RECOMMENDED_{stage}_{mode}"] = _metric(
                    part, stage, mode, recommended_only=True
                )
        output.append({"key": key, "label": label, "start": start, "end": end_date, "metrics": metrics})
    return output


def _rankings(records, venue_names):
    # Rank a race only once even if PRE/POST or both strategies hit it.
    hits = {}
    for x in records:
        if not x["hit"]:
            continue
        key = (x["date"], x["jcd"], x["rno"])
        item = hits.setdefault(key, {
            "date": x["date"], "jcd": x["jcd"], "venue": venue_names.get(x["jcd"], x["jcd"]),
            "rno": x["rno"], "actual": x["actual"], "odds": x["odds"],
            "payout_yen": x["payout_yen"], "hits": [],
        })
        stage_name = "事前" if x["stage"] == "PRE" else "直前"
        label = f'{stage_name}・{x["mode_label"]}'
        if label not in item["hits"]:
            item["hits"].append(label)
    ranked = sorted(
        hits.values(),
        key=lambda x: (float(x["odds"] or 0), x["date"], x["rno"]),
        reverse=True,
    )
    return ranked[:10]


def _official_payout_rankings(db, end_date, venue_names, jcd=None):
    """Top 10 official trifecta payouts across every saved confirmed race.

    This is a true historical ranking, so it must not be limited by the date
    currently selected in the UI. AI hit status and odds are intentionally
    irrelevant; only the official payout amount is used for ordering.
    """
    sql = """
        SELECT date,jcd,rno,trifecta,payout_yen
        FROM race_results
        WHERE trifecta IS NOT NULL AND payout_yen IS NOT NULL AND payout_yen>0
    """
    params = []
    if jcd is not None:
        sql += " AND jcd=?"
        params.append(str(jcd).zfill(2))
    sql += " ORDER BY payout_yen DESC, date DESC, rno DESC LIMIT 10"
    with db.connect() as con:
        rows = con.execute(sql, params).fetchall()
    return [{
        "date": x["date"],
        "jcd": str(x["jcd"]).zfill(2),
        "venue": venue_names.get(str(x["jcd"]).zfill(2), str(x["jcd"]).zfill(2)),
        "rno": int(x["rno"]),
        "actual": combo(x["trifecta"]) or str(x["trifecta"] or ""),
        "payout_yen": int(x["payout_yen"] or 0),
    } for x in rows]


def _daily_series(records):
    """Daily hit/return history for the chart shown in AI予想と結果."""
    points = []
    for day in sorted({x["date"] for x in records}):
        rows = [x for x in records if x["date"] == day]
        metrics = {}
        for _, stage in STAGES:
            for mode, _ in MODES:
                metrics[f"{stage}_{mode}"] = _metric(rows, stage, mode)
                metrics[f"RECOMMENDED_{stage}_{mode}"] = _metric(
                    rows, stage, mode, recommended_only=True
                )
        points.append({"date": day, "metrics": metrics})
    return points


def build_statistics(db, end_date: str, venues):
    records = _prediction_records(db, end_date)
    names = {str(x["code"]).zfill(2): x["name"] for x in venues}
    venue_rows = []
    for code, name in names.items():
        part = [x for x in records if x["jcd"] == code]
        if not part:
            continue
        venue_rows.append({
            "code": code,
            "name": name,
            "periods": _period_summary(part, end_date),
            "top10": _rankings(part, names),
            "payout_top10": _official_payout_rankings(db, end_date, names, code),
            "daily_series": _daily_series(part),
        })
    return {
        "end_date": end_date,
        "simulation": "1レース合計5,000円を予想出目へ均等配分した固定資金シミュレーション",
        "overall_periods": _period_summary(records, end_date),
        "venues": venue_rows,
        "top10": _rankings(records, names),
        "payout_top10": _official_payout_rankings(db, end_date, names),
        "daily_series": _daily_series(records),
    }
