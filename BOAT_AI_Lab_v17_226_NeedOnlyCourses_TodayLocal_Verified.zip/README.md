BOAT AI Lab v17.226

Main change: remove unnecessary official result confirmations without changing the actual-entry-course rules.

Initial collection for a racer appearing today:
- Read that racer's own history newest -> oldest, down to 2020-01-01 only when needed.
- Nationwide: collect actual-entry 1C..6C, newest 10 each across all venues.
- When a nationwide course reaches 10, older races of that course are ignored for nationwide.
- Local: only today's venue(s) are historical local targets during this initialization.
- Local is filtered from the racer's own history by venue first, then actual-entry course, newest 10 each.
- When a local course reaches 10, older races of that local course are ignored.
- Ambiguous history rows use BOAT RACE official result verification.
- Strict archive rows are audited, but a mismatch no longer causes a full historical official-page crawl. Only still-needed buckets fall back.

After initialization:
- Confirmed daily results update nationwide and the actual race venue local history.
- Both retain only the newest 10 per actual-entry course.

See VALIDATION_v17_226_NEED_ONLY_TODAY_LOCAL.txt.
