import json, tempfile
from pathlib import Path
from db import BoatDB

p=Path(tempfile.mkdtemp())/'test.db'
db=BoatDB(str(p))
cur='20261001'; jcd='03'
# Proven same-meeting day numbers.
for d,n in [('20260927',1),('20260928',2),('20260929',3),('20260930',4),(cur,5)]:
    db.save_meeting_day(d,jcd,n,f'{n}日目',f'{n}日目',source='test')
regs=[f'{4000+i}' for i in range(1,7)]
# Prior confirmed results: one race/day is enough to prove finish/ST reconstruction.
with db.connect() as con:
    for day_no,d in enumerate(['20260927','20260928','20260929','20260930'], start=1):
        fins=[]; starts=[]
        for lane,reg in enumerate(regs, start=1):
            fins.append({'lane':lane,'registration_no':reg,'name':f'R{lane}','finish':str(lane),'st_raw':f'.{10+lane:02d}'})
            starts.append({'lane':lane,'course':lane,'st_raw':f'.{10+lane:02d}'})
        payload={'rno':day_no,'result_confirmed':True,'finishers':fins,'start_courses':starts}
        con.execute("INSERT INTO race_results(date,jcd,rno,trifecta,payout_yen,payload) VALUES(?,?,?,?,?,?)",
                    (d,jcd,day_no,'1-2-3',1000,json.dumps(payload,ensure_ascii=False)))
# Broken today's racelist: R/course only, no ST/finish; current-day planned slot preserved.
racers=[]
for lane,reg in enumerate(regs, start=1):
    slots=[]
    for day in range(1,5):
        slots.extend([{'rno':day,'course':lane,'st':None,'finish':None,'boat_lane':lane},{}])
    slots.extend([{'rno':1,'course':lane,'st':None,'finish':None,'boat_lane':lane},{}])
    racers.append({'lane':lane,'registration_no':reg,'name':f'R{lane}',
                   'meeting_results':{'slots':slots,'entries':[x for x in slots if x.get('rno') is not None]}})
for rno in range(1,13):
    db.save_snapshot(cur,jcd,rno,'racelist',{'date':cur,'jcd':jcd,'rno':rno,'racers':racers})

before=db.get_snapshot(cur,jcd,1,'racelist')['data']
assert all(not any((e or {}).get('finish') not in (None,'') for e in (r['meeting_results'].get('entries') or [])) for r in before['racers'])
res=db.rebuild_meeting_results_from_saved_results(cur,jcd)
assert res['updated_snapshots']==12, res
snap=db.get_snapshot(cur,jcd,1,'racelist')['data']
for i,r in enumerate(snap['racers'], start=1):
    m=r['meeting_results']; slots=m['slots']
    # Days 1-4 now have authoritative finish/ST.
    for base in [0,2,4,6]:
        assert slots[base]['finish']==str(i), (i,base,slots[base])
        assert slots[base]['st']==f'.{10+i:02d}'
        assert slots[base]['course']==i
    # Current day planned slot remains, not overwritten by an old result.
    assert slots[8]['rno']==1 and slots[8]['finish'] is None
    assert m['source']=='saved-official-results-rebuild-v17.229'
    assert any(e.get('finish') not in (None,'') for e in m['entries'])
# This is exactly what the completion checker needs: all six racers have finish data.
assert sum(1 for r in snap['racers'] if any(e.get('finish') not in (None,'') for e in r['meeting_results']['entries']))==6
print('v17.229 meeting-results DB rebuild validation: PASS')
