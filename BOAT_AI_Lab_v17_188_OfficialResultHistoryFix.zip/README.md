# BOAT AI Lab v17.181 コース履歴収集安定化版

## 今回の範囲
全国・当地の「実進入コース別 直近最大10走」は、まず **収集 → 反映 → SQLite保存 → 画面表示** までに限定しています。
この履歴は **まだAI予想の点数・買い目には使いません**。収集結果を確認した後、次版でAI反映を行う前提です。

## 過去履歴の収集ルール
- 外部の過去履歴取得は **0:00〜23:59 JST**。
- 0:00に、BOAT AI Labが既に把握している選手のうち初期履歴が未完了の選手だけを対象化。
- 完了済み選手は翌日以降の過去収集対象にしない。
- 公式の日別競走成績Kファイルを新しい日から過去へ1日ずつ確認し、対象選手の行だけ保存。
- 1日処理後は30秒待機。通信/展開エラーは60秒間隔で最大3回。
- 3回失敗したらその回の過去収集を止め、対象選手名・登録番号・失敗日・エラーをトップ画面に表示。次回0:00に同じ位置から再試行。
- 23:59まで初期収集を継続可能。進捗カーソルは常時保存し、再起動時も続きから再開。
- 過去確認の下限は2002-01-01。そこまで確認して10走未満なら「存在する分だけ」で初期収集完了扱い。
- 3連単組番は収集・保存しない。

## 開催時間中
- コース履歴のための追加外部アクセスはしない。
- 通常のレース結果が確定・保存された時、その同じ結果から6選手の登録番号・艇番・実進入・本番ST・ST順位・着順を取り出す。
- 全国コース履歴と当地コース履歴へ同時に反映・保存。
- 登録番号＋艇番で照合し、L/F/欠場などで後ろの艇データをずらさない。

## 保存量
`racer_course_runs` は選手×場×実進入コースごとに最新10走だけ保持します。全国の最新10走は、保存済みの各場最新10走から再構成します。


## v17.183 Official racer data resilience
- Official course page is now the only mandatory request for the player Official Data / Course ST card.
- Profile and season endpoints are optional; a transient failure there no longer blocks saving valid course data.
- Empty official course samples (`-`) remain valid `dataなし`, important for new racers such as 5404.
- No AI weighting change in this version.


## v17.184 course-history target optimization
- Historical backfill targets only racers in today's saved racelists.
- Required local history is only the venue where that racer is racing today, plus nationwide 1-6 course history.
- Other 23 venues are not completion targets.
- One nationwide daily result file is shared across all active targets; no per-racer/per-venue duplicate download.
- Live confirmed results continue to update nationwide/local history without extra web requests.


## v17.185
- Course-history progress now shows racers with any saved history separately from fully scanned racers.
- Shows national/local course-bucket progress and current scan date.
- Successful daily K-file scan pause reduced from 30s to 10s; failures remain 60s x max 3.
- AI prediction weighting is unchanged; this release is collection/reflection/storage only.


## v17.186 Course History Start Fix
- Removed pre-backfill per-racer profile web requests; saved registration-term data only.
- K-file scan now starts immediately for today's targets.
- K parser recognizes official NN KBGN venue blocks and broader result headers.
- Top screen shows last K fetch date/state, parsed rows, and matched target rows.


## v17.186 label correction
- Backend version: 1.0.186
- UI label: v17.186 履歴収集開始修正版
- No collection-logic changes from v17.186 StartFix.


## v17.187 K data parser fix
- Fix official K LZH parsing: read fixed-length T0/TH/T1-T6 records instead of human-readable result layout.
- Replay today's incomplete cursors from yesterday once, because older builds may have advanced while parsing 0 rows.
- Keep nationwide + today's venue only; no AI scoring changes.
- No trifecta combination storage.


## v17.188 official result-page history fix
- Initial course-history backfill no longer uses K downloads.
- Uses BOAT RACE official result-list + per-race result detail pages, the same detail parser as live confirmed results.
- Actual entry course is taken from official start order; ST, ST rank, finish and registration number are saved.
- Only today's target racers are retained; venue details are opened only when the result list mentions a target racer.
- Incomplete v17.187 targets replay from yesterday once after deployment.
