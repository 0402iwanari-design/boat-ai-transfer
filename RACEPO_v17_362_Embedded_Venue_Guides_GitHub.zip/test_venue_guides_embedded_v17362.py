"""Regression checks for the in-app venue guide panel (v17.362)."""
import unittest
from pathlib import Path
from bs4 import BeautifulSoup
from fastapi.testclient import TestClient
from app import app
ROOT=Path(__file__).resolve().parent
DOC=BeautifulSoup((ROOT/'static/index.html').read_text(encoding='utf-8'),'html.parser')
class EmbeddedGuideTests(unittest.TestCase):
    def test_sidebar_is_button_without_outbound_page_navigation(self):
        sidebar=DOC.select_one('#leftSidebar')
        button=sidebar.select_one('#sideVenueGuidesBtn')
        self.assertEqual(button.name,'button')
        self.assertIsNone(button.get('href'))
        self.assertNotIn('onclick',button.attrs)
        ids=[node.get('id') for node in sidebar.find_all(recursive=False)]
        self.assertEqual(ids.index('sideVenueGuidesBtn'),ids.index('sideTodayResultsBtn')+1)

    def test_native_panel_and_24_cards_match_public_route(self):
        panel=DOC.select_one('#venueGuidesScreen')
        self.assertIn('hidden',panel.get('class',[]))
        buttons=panel.select('button[data-venue-path]')
        expected=[a['href'] for a in BeautifulSoup((ROOT/'static/venues.html').read_text(encoding='utf-8'),'html.parser').select('.venue-entry')]
        self.assertEqual(len(buttons),24)
        self.assertEqual([b['data-venue-path'] for b in buttons],expected)
        self.assertEqual(len(set(expected)),24)
        self.assertIsNotNone(panel.select_one('#venueGuidesBack'))
        self.assertIsNotNone(panel.select_one('#venueGuidesFrame'))

    def test_all_24_detail_pages_are_public_and_html(self):
        urls=[b['data-venue-path'] for b in DOC.select('#venueGuidesScreen button[data-venue-path]')]
        with TestClient(app) as client:
            for url in urls:
                with self.subTest(url=url):
                    r=client.get(url)
                    self.assertEqual(r.status_code,200)
                    self.assertIn('<article',r.text)
            self.assertEqual(client.get('/venues').status_code,200)
            self.assertEqual(client.get('/api/health').json()['version'],'17.362')

    def test_public_seo_routes_and_data_engine_retained(self):
        html=str(DOC)
        self.assertIn('id="knowledgeScreen"',html)
        self.assertIn('id="venueGuidesScreen"',html)
        self.assertIn('function openVenueKnowledge(code)',html)
        self.assertIn('venueGuidesScreen',html)
        with TestClient(app) as client:
            self.assertEqual(client.get('/sitemap.xml').status_code,200)
            self.assertEqual(client.get('/ads.txt').status_code,200)

if __name__=='__main__':unittest.main()
