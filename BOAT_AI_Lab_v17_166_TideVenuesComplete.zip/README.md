# BOAT AI Lab v17.163 Clean Deploy

Clean deployment package rebuilt with ASCII-only archive paths to avoid Linux Errno 36 (File name too long).
Includes tide foundation, tide monitor/manual collection UI, PC tide navigation, and mobile horizontal navigation scrolling from v17.163.

## v17.166 潮対象場完成版
- 下関: 気象庁 長府(CF) を潮専用Collectorへ追加。
- 若松: 気象庁 日明(N1) を潮専用Collectorへ追加。
- 大村: BOAT RACE大村公式「今節の潮見」専用Providerを追加。公式が公開する満潮/干潮時刻を使用し、公開されていない潮位cmは捏造しない。
- 大村公式取得失敗はJMA各場の潮保存を壊さない独立処理。
- 潮を使わない場の表示を「潮影響なし・収集不要」に変更。
- AI予想への潮補正は引き続きOFF。既存15分前収集/30秒再試行/締切+1分オッズには未接続。
