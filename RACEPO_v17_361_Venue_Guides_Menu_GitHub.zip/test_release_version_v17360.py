import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import auto_deploy
from release_version import deployed_version

class VersionTests(unittest.TestCase):
    def test_release_version_file_is_current(self):
        self.assertEqual(deployed_version(), '17.361')

    def test_zip_updates_stamp_version(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)
            auto_deploy._stamp_release_version(p, 'RACEPO_v17_361_Future_GitHub_Release.zip')
            self.assertEqual(deployed_version(p), '17.361')

    def test_invalid_zip_version_refused(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError, 'ZIPファイル名'):
                auto_deploy._stamp_release_version(Path(d), 'other.zip')

    def test_legacy_release_path_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'20261109-120000_RACEPO_v17_359_Old_Release'
            p.mkdir()
            self.assertEqual(deployed_version(p), '17.359')

    def test_unknown_does_not_claim_new_version(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(deployed_version(Path(d)), 'unknown')

    def test_api_uses_actual_marker(self):
        from fastapi.testclient import TestClient
        from app import app
        with TestClient(app) as client:
            response=client.get('/api/health')
            self.assertEqual(response.status_code,200)
            self.assertEqual(response.json()['version'],'17.361')
            self.assertIn('no-store',client.get('/').headers.get('cache-control',''))
            html=client.get('/').text
            self.assertIn('id="releaseVersion"',html)
            self.assertNotIn('RACEPO · v17.300 MOBILE UX',html)

if __name__ == '__main__': unittest.main()
