from __future__ import annotations

from ai_predictor import predict as ai_predict, build_venue_profile
from tide_system import TideCollector
from datetime import datetime, timezone, timedelta
import threading
import re
import hashlib
import json
import os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any

import requests
from bs4 import BeautifulSoup

from cache import FileCache
from db import BoatDB, _official_split_complete
from venue_comments import fetch_venue_comments
from parser import (
    parse_meeting_day, parse_race_index, parse_race_list, parse_race_deadline, parse_deadline_from_saved_text, parse_venue_meta, parse_day_venue_event_meta, grade_markup_diagnostic,
    parse_before_info, parse_odds3t, parse_odds3t_recovery, parse_odds3t_for_active_lanes, parse_odds3t_matrix, parse_result_list,
    parse_result_detail, parse_heiwajima_original_exhibition,
    parse_wakamatsu_original_exhibition, parse_boatcast_original_exhibition,
)

BASE = "https://www.boatrace.jp"
BOATCAST_BASE = "https://race.boatcast.jp"


def _safe_lane(value):
    """Return an official boat number, never a status label such as 欠場."""
    try:
        lane = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return lane if 1 <= lane <= 6 else None

# Officially verified fallback for dates where the BOAT RACE daily index omits
# grade markup from the HTML returned to the collector.  The automatic parser
# remains primary for every other meeting/date.
# Amagasaki official schedule: SG 73rd Boat Race Derby (2026-10-27–11-01).
# Some race-list responses do not carry the grade icon, so use a verified,
# narrowly scoped date+venue override.  Never infer a grade for other venues.
VERIFIED_EVENT_GRADES = {
    **{
        date: {
            "13": {
                "event_grade": "SG",
                "event_title": "SG第73回ボートレースダービー",
            },
        }
        for date in (
            "20261027", "20261028", "20261029",
            "20261030", "20261031", "20261101",
        )
    },
    **{
        date: {
            "17": {"event_grade": "G3", "event_title": "GIIIマンスリーBOATRACE杯争奪宮島プリンセスカップ"},
        }
        for date in ("20260918", "20260919", "20260920", "20260921", "20260922", "20260923")
    },
    **{
        date: {
            **({
                "17": {"event_grade": "G3", "event_title": "GIIIマンスリーBOATRACE杯争奪宮島プリンセスカップ"},
            } if date in {"20260922", "20260923"} else {}),
            "20": {"event_grade": "PG1", "event_title": "プレミアムG1 第13回ヤングダービー"},
        }
        for date in ("20260922", "20260923", "20260924", "20260925", "20260926", "20260927")
    },
}


class BoatRaceSource:
    def __init__(self):
        self.cache = FileCache()
        self.db = BoatDB()
        self._local = threading.local()
        self._local_frame_stats_cache = {}
        self._racer_course_stats_cache = {}
        self._day_event_meta_cache = {}
        self._day_event_meta_lock = threading.Lock()
        # v17.274: player pages must never wait on an external racer-page fetch.
        # Repair stale/missing course-breakdown data in the background instead.
        self._racer_repair_lock = threading.Lock()
        self._racer_repair_inflight = set()

        names = [
            "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
            "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村"
        ]
        self.venues = [
            {"code": f"{i:02d}", "name": name}
            for i, name in enumerate(names, start=1)
        ]

    def _save_grade_diagnostic(self, yyyymmdd: str, venue: dict, html: str, meta: dict):
        """Keep markup evidence locally; it helps fix an official layout change without guessing."""
        local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
        directory = Path(local_app) / "BOAT_AI_Lab" / "diagnostics" / "grade_markup"
        directory.mkdir(parents=True, exist_ok=True)
        payload = {
            "date": yyyymmdd, "jcd": venue.get("code"), "venue": venue.get("name"),
            "parsed_grade": meta.get("event_grade"), "parsed_title": meta.get("event_title"),
            **grade_markup_diagnostic(html),
        }
        (directory / f"{yyyymmdd}_{str(venue.get('code')).zfill(2)}.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    def _session(self):
        session = getattr(self._local, "session", None)
        if session is None:
            session = requests.Session()
            session.headers.update({
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36"
            })
            self._local.session = session
        return session

    def _decode_response_like_diagnostic(self, response) -> tuple[str, str]:
        candidates = []
        seen = set()

        for enc in [
            response.encoding,
            response.apparent_encoding,
            "utf-8",
            "cp932",
            "shift_jis",
            "euc_jp",
        ]:
            if not enc:
                continue
            key = str(enc).lower()
            if key in seen:
                continue
            seen.add(key)
            try:
                text = response.content.decode(enc, errors="replace")
                candidates.append((enc, text))
            except Exception:
                pass

        def score(item):
            enc, text = item
            s = 0
            for token in ["締切予定時刻", "締切", "戸田", "1R", "12R"]:
                if token in text:
                    s += 20
            s += min(
                len(re.findall(r"(?<!\d)\d{1,2}:\d{2}(?!\d)", text)),
                30,
            )
            return s

        candidates.sort(key=score, reverse=True)
        if candidates:
            return candidates[0][1], str(candidates[0][0])

        return response.text, str(response.encoding or "unknown")

    def _get(
        self,
        url: str,
        ttl: int = 300,
        *,
        fresh: bool = False,
        diagnostic_label: str | None = None,
    ) -> str:
        key = "html_v13_" + hashlib.sha256(
            url.encode("utf-8")
        ).hexdigest()

        if not fresh:
            cached = self.cache.get(key, ttl)
            if cached is not None:
                return cached

        response = self._session().get(url, timeout=(5.0, 15.0))
        response.raise_for_status()

        html, selected_encoding = self._decode_response_like_diagnostic(response)

        if diagnostic_label:
            print(
                f"[HTTP] {diagnostic_label} OK "
                f"status={response.status_code} bytes={len(response.content)} "
                f"encoding={selected_encoding}",
                flush=True,
            )

        self.cache.set(key, html)
        return html

    def _parse_boatnavi_course_breakdown(self, html: str, official_totals: dict[int, float | None] | None = None):
        """Parse BOATNAVI's six-course 1st/2nd/3rd-place split robustly.

        v17.269 assumed this section lived in a literal HTML <table>.  The
        current BOATNAVI page renders it with non-table markup, although the
        visible text still has a stable shape::

            コース別3連対率
            1着率2着率3着率
            1 77.8 5.6 5.6 88.9%
            ...

        Parse only the text between the ``コース別3連対率`` heading and the
        next ``コース別スタート順`` heading.  Each row is accepted only when
        its three parts agree with the official BOAT RACE total.  This keeps
        the fallback period-safe and prevents unrelated percentages elsewhere
        on the page from being mixed in.
        """
        soup = BeautifulSoup(html or "", "html.parser")
        text = soup.get_text(" ", strip=True)
        start = text.find("コース別3連対率")
        if start < 0:
            return {}
        section = text[start + len("コース別3連対率"):]
        end = section.find("コース別スタート順")
        if end >= 0:
            section = section[:end]

        # Normalise headers so they cannot be mistaken for data rows.
        section = re.sub(r"1着率\s*2着率\s*3着率", " ", section)
        result = {}
        # A valid row consists of course number + exactly the three split
        # percentages + the total 3-place percentage.  Separators may be
        # spaces, pipes, line breaks, or surrounding markup.
        row_re = re.compile(
            r"(?:^|\s|[|｜])([1-6])(?:コース)?\s*(?:[|｜]\s*)?"
            r"(\d+(?:\.\d+)?)\s+"
            r"(\d+(?:\.\d+)?)\s+"
            r"(\d+(?:\.\d+)?)\s*(?:[|｜]\s*)?"
            r"(\d+(?:\.\d+)?)\s*%"
        )
        for m in row_re.finditer(section):
            course = int(m.group(1))
            parts = [float(m.group(2)), float(m.group(3)), float(m.group(4))]
            page_total = float(m.group(5))
            official_total = None if not official_totals else official_totals.get(course)
            # First validate the source row itself (allow one-decimal rounding),
            # then validate against the BOAT RACE official total when available.
            if abs(sum(parts) - page_total) > 0.35:
                continue
            if official_total is not None and abs(page_total - float(official_total)) > 0.35:
                continue
            result[course] = parts

        # v17.271: some BOATNAVI responses flatten the section into separate
        # text nodes in a way that does not satisfy the row-shaped regex above.
        # The section is already tightly bounded by the two headings, so a
        # sequential numeric-token parser is both safer and more tolerant:
        # after removing the 1着率/2着率/3着率 header the expected stream is
        #   1, first, second, third, total, 2, first, ... 6, ...
        # Validate every reconstructed row against both its own total and the
        # BOAT RACE official total before accepting it.
        if len(result) < 6:
            compact = re.sub(r"1\s*着率\s*2\s*着率\s*3\s*着率", " ", section)
            numbers = [float(x) for x in re.findall(r"(?<![0-9.])([0-9]+(?:\.[0-9]+)?)(?![0-9.])", compact)]
            rebuilt = {}
            i = 0
            expected_course = 1
            while i < len(numbers) and expected_course <= 6:
                if int(numbers[i]) != expected_course or abs(numbers[i] - expected_course) > 1e-9:
                    i += 1
                    continue
                if i + 4 >= len(numbers):
                    break
                parts = [numbers[i + 1], numbers[i + 2], numbers[i + 3]]
                page_total = numbers[i + 4]
                official_total = None if not official_totals else official_totals.get(expected_course)
                plausible = all(0.0 <= value <= 100.0 for value in parts + [page_total])
                own_total_ok = abs(sum(parts) - page_total) <= 0.35
                official_ok = official_total is None or abs(page_total - float(official_total)) <= 0.35
                if plausible and own_total_ok and official_ok:
                    rebuilt[expected_course] = parts
                    expected_course += 1
                    i += 5
                else:
                    i += 1
            if len(rebuilt) > len(result):
                result = rebuilt
        return result

    def _repair_missing_course_breakdown(self, registration_no: str, official_totals: dict[int, float | None]):
        reg = str(registration_no)
        url = f"https://boatnavi.hochi.co.jp/racer/{reg}/course"
        try:
            html = self._get(url, ttl=24 * 60 * 60, fresh=True, diagnostic_label=f"racer {reg} course breakdown fallback")
            return self._parse_boatnavi_course_breakdown(html, official_totals)
        except Exception as exc:
            print(f"[COURSE BREAKDOWN] racer={reg} fallback failed: {exc}", flush=True)
            return {}

    def fetch_official_racer_course_data(self, registration_no: str, expected_name: str | None = None):
        """Fetch the official racer-search pages needed by the AI.

        This is intentionally limited to a racer who already appears in the
        current day's racelist.  Complete data is reused for six months; no
        bulk crawl of inactive/retired racers is performed.
        """
        reg = str(registration_no)
        urls = {
            "profile": f"{BASE}/owpc/pc/data/racersearch/profile?toban={reg}",
            "season": f"{BASE}/owpc/pc/data/racersearch/season?toban={reg}",
            "course": f"{BASE}/owpc/pc/data/racersearch/course?toban={reg}",
        }
        # The course page is the only required request for the course-ST panel.
        # It already contains the racer's basic profile header as well as all
        # four course tables.  Previously profile + season + course were all
        # mandatory, so one transient failure on the non-essential profile or
        # season endpoint prevented the entire official-data card from being
        # saved (this was especially visible when only one racer remained).
        pages = {}
        pages["course"] = self._get(
            urls["course"], ttl=24 * 60 * 60, fresh=True,
            diagnostic_label=f"racer {reg} course",
        )
        optional_errors = {}
        for key in ("profile", "season"):
            try:
                pages[key] = self._get(
                    urls[key], ttl=24 * 60 * 60, fresh=True,
                    diagnostic_label=f"racer {reg} {key}",
                )
            except Exception as exc:
                optional_errors[key] = str(exc)[:300]
                # Course page has the same racer header.  Use it as the
                # profile fallback; season details are optional for this card.
                pages[key] = pages["course"] if key == "profile" else ""

        def page_text(key):
            return BeautifulSoup(pages.get(key) or "", "html.parser").get_text(" ", strip=True)

        def labelled(text, labels):
            for label in labels:
                m = re.search(re.escape(label) + r"\s*[:：]?\s*([^\s]+)", text)
                if m:
                    return m.group(1)
            return None

        profile_soup = BeautifulSoup(pages["profile"], "html.parser")
        profile_text, season_text, course_text = page_text("profile"), page_text("season"), page_text("course")
        title_name = None
        for tag in profile_soup.select("h1,h2,h3,th,td"):
            text = tag.get_text(" ", strip=True)
            if re.fullmatch(r"[ァ-ヶー一-龠々]{2,12}", text or ""):
                title_name = text
                break
        photo_url = None
        # Official racer portraits use /racerphoto/{registration_no}.jpg.
        # Match that exact asset first so a logo/navigation image containing
        # a coincidental "racer" string is never saved as the portrait.
        photo_tag = profile_soup.find(
            "img",
            src=re.compile(
                rf"(?:^|/)racerphoto/{re.escape(reg)}\.(?:jpe?g|png)(?:\?.*)?$",
                re.I,
            ),
        )
        if photo_tag:
            src = photo_tag.get("src") or ""
            if src.startswith("http"):
                photo_url = src
            elif src.startswith("//"):
                photo_url = "https:" + src
            elif src:
                photo_url = BASE + (src if src.startswith("/") else "/" + src)

        # The official page has four separate six-row tables: entry rate,
        # 3-in-the-money rate, average ST and ST rank.  They are not one
        # combined table, which is why each series is read separately here.
        series = []
        course_soup = BeautifulSoup(pages["course"], "html.parser")
        for table in course_soup.find_all("table"):
            values = {}
            for tr in table.find_all("tr"):
                cells = [x.get_text(" ", strip=True) for x in tr.find_all(["th", "td"])]
                if len(cells) < 2:
                    continue
                lane_match = re.fullmatch(r"\s*([1-6])(?:コース)?\s*", cells[0])
                value_match = re.search(r"-?\d+(?:\.\d+)?", cells[1])
                if lane_match:
                    # The official page explicitly displays "-" when that
                    # racer has no sample for a course.  It is a valid empty
                    # value, not a failure of the entire four-table response.
                    values[int(lane_match.group(1))] = (
                        float(value_match.group()) if value_match else None
                    )
            if len(values) == 6:
                series.append(values)
        # Entry rate and three-in-the-money rate are the essential tables.
        # A small number of official pages omit the average-ST or ST-rank table
        # when the aggregation period has no sample.  Keep those optional
        # fields as None instead of rejecting the racer's useful course data.
        if len(series) < 2:
            raise RuntimeError(f"公式コース別成績の主要表を取得できませんでした（{len(series)}/2）")
        entry_rate, trio_rate = series[:2]
        avg_st = series[2] if len(series) >= 3 else {x: None for x in range(1, 7)}
        start_rank = series[3] if len(series) >= 4 else {x: None for x in range(1, 7)}

        # The visible 3連対率 bar is made of three separate outer spans.
        # Their inline widths are the official 1着率 / 2着率 / 3着率.
        # Text extraction exposes only the total, so preserve these widths
        # explicitly instead of trying to derive a split from the total.
        finish_breakdown = {}
        for table in course_soup.find_all("table"):
            # Some official responses put the title immediately before the
            # table, while others include it inside the table wrapper.
            has_breakdown_class = bool(table.select('[class*="is-progress1"], [class*="is-progress2"], [class*="is-progress3"]'))
            if "コース別3連対率" not in table.get_text(" ", strip=True) and not has_breakdown_class:
                continue
            for tr in table.find_all("tr"):
                first_cell = tr.find(["th", "td"])
                lane_match = re.fullmatch(
                    r"\s*([1-6])(?:コース)?\s*",
                    first_cell.get_text(" ", strip=True) if first_cell else "",
                )
                if not lane_match:
                    continue
                lane_no = int(lane_match.group(1))
                # A 0% category is omitted from the official DOM entirely.
                # Identify the finish place from the nested color class,
                # never from the remaining spans' left-to-right positions.
                # Do NOT prefill 0.0 here. If BOAT RACE changes the colour-bar
                # DOM and we fail to decode every segment, [0,0,0] would look
                # like a complete split and prevent the BOATNAVI repair from
                # ever running. Start as unknown; after at least one real
                # coloured segment is decoded, omitted categories can safely be
                # treated as 0.0 because the official DOM omits zero-width bars.
                parts = [None, None, None]
                decoded_places = set()
                # Do not depend on one exact wrapper hierarchy.  The official
                # page normally puts ``width: 100%`` on the coloured inner
                # span and the real finish-rate width on its outer
                # ``span.is-progress``.  Always prefer that outer width;
                # otherwise every non-zero 1st/2nd/3rd rate becomes 100%.
                for inner in tr.find_all(class_=re.compile(r"(?:^|[-_\s])(?:is-)?progress[-_]?[123](?:[-_\s]|$)", re.I)):
                    class_text = " ".join(inner.get("class") or [])
                    place_match = re.search(r"(?:is-)?progress[-_]?([123])", class_text, re.I)
                    styled = None
                    parent = getattr(inner, "parent", None)
                    if (
                        parent is not None
                        and parent is not tr
                        and "is-progress" in (parent.get("class") or [])
                        and re.search(r"width\s*:", parent.get("style") or "", re.I)
                    ):
                        styled = parent
                    elif re.search(r"width\s*:", inner.get("style") or "", re.I):
                        styled = inner
                    width_match = re.search(
                        r"width\s*:\s*([0-9]+(?:\.[0-9]+)?)%",
                        (styled.get("style") or "") if styled is not None else "",
                        re.I,
                    )
                    if place_match and width_match:
                        place_index = int(place_match.group(1)) - 1
                        parts[place_index] = float(width_match.group(1))
                        decoded_places.add(place_index)
                if decoded_places:
                    # A category omitted from an otherwise decoded official row
                    # is a genuine 0% segment. Only infer zero after we know the
                    # row itself was successfully decoded.
                    parts = [0.0 if value is None else value for value in parts]
                finish_breakdown[lane_no] = parts
            break

        # When a racer has no breakdown sample, the official page can omit the
        # coloured bars altogether.  Preserve the published total 3連対率 and
        # represent the unavailable 1/2/3 split honestly as None.
        for course in range(1, 7):
            finish_breakdown.setdefault(course, [None, None, None])
        breakdown_courses = [
            course for course in range(1, 7)
            if trio_rate.get(course) is not None
        ]
        breakdown_complete = bool(breakdown_courses) and all(
            any(value is not None for value in finish_breakdown[course])
            for course in breakdown_courses
        )

        # v17.273: always prefer an explicit numeric 1着/2着/3着 split from
        # BOATNAVI over widths decoded from BOAT RACE's coloured DOM.  Older
        # builds could save a visually plausible but wrong [0, 0, total] row;
        # because all three values were non-null, later repair code considered
        # that row complete and never revisited it.  The mirror publishes the
        # three percentages as text, so use it whenever a row validates against
        # the official BOAT RACE 3連対率.  The official DOM remains a fallback
        # only when the textual mirror cannot be read.
        repaired = self._repair_missing_course_breakdown(reg, trio_rate)
        repaired_courses = set()
        for course, parts in repaired.items():
            if course in finish_breakdown and len(parts) == 3 and all(v is not None for v in parts):
                finish_breakdown[course] = [float(v) for v in parts]
                repaired_courses.add(course)
        # An official '-' (no sample) has no finish-rate split by definition.
        # Validate only sampled courses, and do not treat missing samples as a
        # fetch failure that should be retried forever.
        breakdown_complete = _official_split_complete({"course_stats": [{
            "course": course,
            "trio_rate": trio_rate.get(course),
            "first_rate": finish_breakdown[course][0],
            "second_rate": finish_breakdown[course][1],
            "third_rate": finish_breakdown[course][2],
        } for course in range(1, 7)]})
        breakdown_source = (
            "boatnavi-hochi-text+boatrace-total"
            if breakdown_courses and all(course in repaired_courses for course in breakdown_courses)
            else ("mixed-text-and-boatrace-dom" if repaired_courses else "boatrace-dom")
        )

        courses = [{
            "course": course,
            "entry_rate": entry_rate.get(course),
            "first_rate": finish_breakdown[course][0],
            "second_rate": finish_breakdown[course][1],
            "third_rate": finish_breakdown[course][2],
            "quinella_rate": (
                round(finish_breakdown[course][0] + finish_breakdown[course][1], 1)
                if finish_breakdown[course][0] is not None
                and finish_breakdown[course][1] is not None
                else None
            ),
            "trio_rate": trio_rate.get(course),
            "avg_st": avg_st.get(course),
            "start_rank": start_rank.get(course),
            "source": "official-racersearch-course",
        } for course in range(1, 7)]

        name = expected_name or title_name or reg
        return {
            "registration_no": reg,
            "name": name,
            "profile": {
                "name": name, "registration_no": reg,
                "class": labelled(profile_text, ["級別"]),
                "branch": labelled(profile_text, ["支部"]),
                "origin": labelled(profile_text, ["出身地"]),
                "period": labelled(profile_text, ["登録期", "期別"]),
                "photo_url": photo_url,
                "official_profile_url": urls["profile"],
            },
            "season": {
                "raw_summary": season_text,
                "official_url": urls["season"],
            },
            "course_stats": courses,
            "course_stats_version": 4,
            # v17.273 marker: existing v17.268-v17.272 snapshots are refreshed
            # once so stale [0,0,total] colour data cannot survive for 6 months.
            # v17.275: keep the parser version, but the DB freshness check now
            # requires course_breakdown_complete plus six validated numeric rows.
            # An incomplete split therefore stays in the bulk repair queue instead
            # of being incorrectly treated as finished for six months.
            "course_breakdown_version": 5,
            "course_breakdown_complete": breakdown_complete,
            "course_breakdown_source": breakdown_source,
            "official_course_url": urls["course"],
            "source": "boatrace.jp/racersearch",
            "optional_fetch_errors": optional_errors,
        }

    def _course_breakdown_needs_repair(self, current: dict) -> bool:
        official = (current.get("official_data") or {}).get("data") or {}
        courses = official.get("course_stats") or []
        breakdown_version = int(official.get("course_breakdown_version") or 0)

        def _suspicious_legacy_split(row):
            try:
                first = row.get("first_rate")
                second = row.get("second_rate")
                third = row.get("third_rate")
                total = row.get("trio_rate")
                if None in (first, second, third, total):
                    return False
                first, second, third, total = map(float, (first, second, third, total))
                return total > 0.0 and first == 0.0 and second == 0.0 and abs(third - total) <= 0.35
            except (TypeError, ValueError):
                return False

        return len(courses) == 6 and (
            breakdown_version < 5
            or not bool(official.get("course_breakdown_complete"))
            or not _official_split_complete({"course_stats": courses})
            or sum(1 for row in courses if _suspicious_legacy_split(row)) >= 2
        )

    def _repair_racer_course_breakdown_background(self, registration_no: str):
        reg = str(registration_no)
        try:
            current = self.db.get_racer_public_data(reg)
            if not self._course_breakdown_needs_repair(current):
                return
            name = (current.get("profile") or {}).get("name") or current.get("name") or reg
            repaired = self.fetch_official_racer_course_data(reg, name)
            self.db.save_official_racer_search_data(datetime.now().strftime("%Y%m%d"), repaired)
            self._racer_course_stats_cache.clear()
        except Exception as exc:
            print(f"[COURSE BREAKDOWN] background repair racer={reg} failed: {exc}", flush=True)
        finally:
            with self._racer_repair_lock:
                self._racer_repair_inflight.discard(reg)

    def get_racer_public_data_fast(self, registration_no: str):
        """Return saved player data immediately; network repair is asynchronous.

        Before v17.274, opening a racer could synchronously call BOAT RACE /
        BOATNAVI and block the HTTP response for tens of seconds.  The player
        page is a read view, so it now returns SQLite data first and starts at
        most one background repair for that racer.
        """
        reg = str(registration_no)
        current = self.db.get_racer_public_data(reg)
        needs_repair = self._course_breakdown_needs_repair(current)
        started = False
        if needs_repair:
            with self._racer_repair_lock:
                if reg not in self._racer_repair_inflight:
                    self._racer_repair_inflight.add(reg)
                    started = True
            if started:
                thread = threading.Thread(
                    target=self._repair_racer_course_breakdown_background,
                    args=(reg,),
                    name=f"racer-course-repair-{reg}",
                    daemon=True,
                )
                thread.start()
        current["course_breakdown_refreshing"] = bool(needs_repair)
        return current

    def get_racer_public_data_with_course_breakdown(self, registration_no: str):
        """Compatibility wrapper; player pages use the non-blocking path."""
        return self.get_racer_public_data_fast(registration_no)

    def collect_today_official_racer_course_data(self, yyyymmdd: str, progress=None):
        """Collect only today's entrants with missing or six-month-old data."""
        targets = self.db.official_racer_collection_pending(yyyymmdd)
        total = len(self.db.daily_official_racer_targets(yyyymmdd))
        for index, racer in enumerate(targets, start=1):
            reg, name = racer["registration_no"], racer["name"]
            self.db.mark_official_racer_collection(yyyymmdd, reg, status="collecting")
            if progress:
                progress(index, len(targets), name)
            try:
                data = self.fetch_official_racer_course_data(reg, name)
                self.db.save_official_racer_search_data(yyyymmdd, data)
                # One read-back only.  The user deliberately does not want a
                # second retry/check after this verification.
                saved = self.db.get_racer_public_data(reg).get("official_data") or {}
                courses = (saved.get("data") or {}).get("course_stats") or []
                if len(courses) != 6 or not _official_split_complete({"course_stats": courses}):
                    raise RuntimeError("保存後のコース別成績確認に失敗しました（着順内訳を確認）")
                if not bool((saved.get("data") or {}).get("course_breakdown_complete")):
                    raise RuntimeError("公式コース別1〜3着率の収集が未完了です")
                self.db.mark_official_racer_collection(yyyymmdd, reg, status="complete", verified=True)
            except Exception as exc:
                # Preserve the failing racer, exact stage and exception type for
                # the owner dashboard. Never replace missing rates with guesses.
                stage = "公式取得・解析・保存確認"
                detail = f"{stage} / {type(exc).__name__}: {exc}"
                self.db.mark_official_racer_collection(
                    yyyymmdd, reg, status="failed", error=detail[:900], verified=False
                )
                print(f"[OFFICIAL RACER] date={yyyymmdd} reg={reg} name={name} failure={detail}", flush=True)
            finally:
                self._racer_course_stats_cache.clear()
        return {"total": total, "processed": len(targets)}

    def _get_day_event_meta(self, yyyymmdd: str) -> dict:
        cached = self._day_event_meta_cache.get(yyyymmdd)
        if cached is not None:
            return cached
        with self._day_event_meta_lock:
            cached = self._day_event_meta_cache.get(yyyymmdd)
            if cached is not None:
                return cached
            try:
                url = f"{BASE}/owpc/pc/race/index?hd={yyyymmdd}"
                html = self._get(
                    url, ttl=1800,
                    diagnostic_label=f"{yyyymmdd} daily grade index",
                )
                cached = parse_day_venue_event_meta(html)
                # Do not mark an unparsed layout as verified.  On a day where
                # the index parser found no venue-grade evidence, keep the
                # records provisional so the next server start retries.
                cached["_index_available"] = bool(cached)
            except Exception as exc:
                print(f"[GRADE] daily index unavailable: {exc}", flush=True)
                cached = {"_index_available": False}
            self._day_event_meta_cache[yyyymmdd] = cached
            return cached

    def refresh_day_event_meta_from_official_index(self, yyyymmdd: str,
                                                   venue_codes: list[str] | None = None) -> int:
        """Refresh exact venue grades from the official all-venues index.

        This is safe to run when fixed daily data is reused: it touches only
        venue/date pairs explicitly present in the official index, and it does
        not re-fetch racelists, odds, before-info, or AI inputs.
        """
        indexed = self._get_day_event_meta(yyyymmdd)
        wanted = {str(code).zfill(2) for code in venue_codes} if venue_codes else None
        # The verified date+venue source is independent of the daily index.
        # Even if the official index fetch/parse fails, repair stale DB grades
        # before the cached venue list is rendered.
        verified_by_code = VERIFIED_EVENT_GRADES.get(yyyymmdd) or {}
        candidates = {}
        if indexed.get("_index_available"):
            candidates.update({code: meta for code, meta in indexed.items()
                               if not code.startswith("_")})
        candidates.update(verified_by_code)
        updated = 0
        for code, meta in candidates.items():
            if wanted is not None and code not in wanted:
                continue
            if self.db.replace_venue_event_meta_from_daily_index(
                yyyymmdd, code, meta.get("event_grade"), meta.get("event_title")
            ):
                updated += 1
        return updated

    def _probe_venue(self, yyyymmdd: str, venue: dict):
        """
        One official racelist page contains the whole 1R-12R schedule.
        Use that page as the single source for venue-open + deadlines.
        """
        jcd = venue["code"]
        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )

        try:
            html = self._get(url, ttl=1800)
            races = parse_race_index(html)
            venue_meta = parse_venue_meta(html)
            # The individual racelist often contains only a race name such as
            # 予選.  Use the official daily index as the authoritative fallback
            # for explicit PG1/G1/G2/G3/SG meetings.
            day_index = self._get_day_event_meta(yyyymmdd)
            indexed = day_index.get(jcd) or {}
            index_available = bool(day_index.get("_index_available"))
            verified = (VERIFIED_EVENT_GRADES.get(yyyymmdd) or {}).get(jcd) or {}
            if verified:
                indexed = verified
            if indexed.get("event_grade"):
                venue_meta["event_grade"] = indexed["event_grade"]
                venue_meta["event_title"] = indexed.get("event_title") or venue_meta.get("event_title")
            if not venue_meta.get("event_grade"):
                self._save_grade_diagnostic(yyyymmdd, venue, html, venue_meta)
            meeting_day = parse_meeting_day(html, yyyymmdd)
            is_open = len(races) == 12

            if is_open:
                # Save under this exact official venue code/date pair.  The UI
                # never infers a grade from another venue or from navigation.
                self.db.save_venue_event_meta(
                    yyyymmdd, jcd,
                    venue_meta.get("event_grade") or "一般戦",
                    venue_meta.get("event_title"),
                    source=(
                        "official-verified-schedule-v5" if verified
                        else "official-day-index-grade-v5" if index_available
                        else "official-title-grade-v5-provisional"
                    ),
                )
                self.db.save_race_schedule(
                    yyyymmdd,
                    jcd,
                    races,
                    source="racelist-schedule",
                )
                if meeting_day:
                    self.db.save_meeting_day(
                        yyyymmdd, jcd, meeting_day.get("number"),
                        meeting_day.get("label"), meeting_day.get("official_label"),
                        source="racelist-schedule-and-grade",
                    )

            return {
                **venue,
                "event_grade": (venue_meta.get("event_grade") or "一般戦") if is_open else None,
                "event_title": venue_meta.get("event_title"),
                "meeting_day_number": (meeting_day or {}).get("number"),
                "meeting_day_label": (meeting_day or {}).get("label"),
                "meeting_day_official_label": (meeting_day or {}).get("official_label"),
                "open": is_open,
                "races": races if is_open else [],
                "source_url": url,
            }

        except Exception as e:
            return {
                **venue,
                "open": False,
                "races": [],
                "error": str(e),
                "source_url": url,
            }

    def _validate_requested_racelist_date(
        self,
        html: str,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Guard against the official site's UI/default date being the previous
        day during the early-morning window.

        Requests always carry hd=YYYYMMDD explicitly. We additionally verify
        that the returned racelist exposes the requested month/day somewhere
        in its official date navigation/text before saving it.
        """
        if not html or len(yyyymmdd) != 8:
            raise RuntimeError("出走表の日付検証に必要なHTML/日付がありません")

        month = int(yyyymmdd[4:6])
        day = int(yyyymmdd[6:8])
        text = BeautifulSoup(html, "html.parser").get_text(" ")
        text = text.translate(
            str.maketrans("０１２３４５６７８９", "0123456789")
        )
        text = re.sub(r"\\s+", "", text)

        wanted = f"{month}月{day}日"
        if wanted not in text:
            raise RuntimeError(
                f"公式出走表の日付検証失敗: "
                f"要求={yyyymmdd} 場={str(jcd).zfill(2)} {int(rno)}R "
                f"（前日等のページを保存しません）"
            )
        return True


    def ensure_meeting_day(
        self,
        yyyymmdd: str,
        jcd: str,
        force: bool = False,
    ):
        """
        Ensure current meeting-day metadata exists for one venue.

        This is intentionally independent from the saved 1R-12R deadlines.
        Older versions returned early once deadlines existed, which meant a
        venue could stay "開催日数取得中" forever.
        """
        jcd = str(jcd).zfill(2)

        saved = self.db.get_day_meeting_days(yyyymmdd).get(jcd)
        if (
            not force
            and saved
            and saved.get("number") is not None
            and saved.get("label")
        ):
            return {
                "ok": True,
                "jcd": jcd,
                **saved,
                "source": saved.get("source") or "db",
                "stage": "verified",
            }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )
        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} meeting-day racelist 1R",
        )

        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, 1
        )
        parsed = parse_meeting_day(html, yyyymmdd)
        if not parsed:
            # Keep diagnostics useful without falsely writing day 1.
            sample = re.sub(
                r"\s+", " ",
                BeautifulSoup(html, "html.parser").get_text(" ")
            )
            date_token = (
                f"{int(yyyymmdd[4:6])}月"
                f"{int(yyyymmdd[6:8])}日"
            )
            pos = sample.find(date_token)
            snippet = sample[max(0, pos-100):pos+220] if pos >= 0 else ""
            raise RuntimeError(
                f"開催日数解析失敗: {jcd} {yyyymmdd}"
                + (f" / date周辺={snippet[:300]}" if snippet else "")
            )

        self.db.save_meeting_day(
            yyyymmdd,
            jcd,
            parsed.get("number"),
            parsed.get("label"),
            parsed.get("official_label"),
            source="boatrace-official-racelist-v17.43",
        )

        print(
            f"[MEETING-DAY] {jcd} "
            f"{parsed.get('label')} saved",
            flush=True,
        )

        return {
            "ok": True,
            "jcd": jcd,
            **parsed,
            "source": "boatrace.jp",
            "source_url": url,
            "stage": "saved",
        }


    def ensure_venue_schedule(self, yyyymmdd: str, jcd: str):
        """
        Ensure the venue has all 12 deadlines persisted.
        One racelist page (rno=1) contains the venue's 1R-12R schedule.
        This is independent from race-finished status.
        """
        jcd = str(jcd).zfill(2)
        saved = self.db.get_race_schedule(yyyymmdd, jcd)
        saved_by_rno = {
            int(x["rno"]): x.get("deadline")
            for x in saved
            if x.get("deadline")
        }

        if len(saved_by_rno) >= 12:
            return {
                "complete": True,
                "saved": len(saved_by_rno),
                "source": "db",
            }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )
        html = self._get(url, ttl=300)
        races = parse_race_index(html)

        if len(races) == 12:
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                races,
                source="racelist-page-schedule-backfill",
            )
            return {
                "complete": True,
                "saved": 12,
                "source": "official-racelist",
            }

        return {
            "complete": False,
            "saved": len(saved_by_rno),
            "parsed": len(races),
            "source": "official-racelist",
        }

    def get_day_fast(self, yyyymmdd: str) -> Dict[str, Any]:
        """
        UI向け高速開催情報。
        締切時刻は共通DBのrace_scheduleを最優先で利用する。
        """
        db_presence = self.db.get_racelist_presence(yyyymmdd)
        db_schedule = self.db.get_day_schedule(yyyymmdd)
        db_meeting_days = self.db.get_day_meeting_days(yyyymmdd)
        db_event_meta = self.db.get_day_venue_event_meta(yyyymmdd)
        cached = self.cache.get(f"day_v16_{yyyymmdd}", 3600)

        by_code = {}
        if cached:
            for v in cached.get("venues", []):
                by_code[str(v.get("code")).zfill(2)] = dict(v)

        items = []

        for venue in self.venues:
            code = venue["code"]
            saved_rnos = sorted(set(db_presence.get(code, [])))
            schedule_rows = db_schedule.get(code, [])
            schedule_by_rno = {int(r["rno"]): r for r in schedule_rows}

            item = by_code.get(code, {
                **venue,
                "open": False,
                "races": [],
            })

            cached_races = {
                int(r.get("rno")): dict(r)
                for r in (item.get("races") or [])
                if r.get("rno") is not None
            }

            known_rnos = sorted(
                set(saved_rnos)
                | set(schedule_by_rno.keys())
                | set(cached_races.keys())
            )

            if known_rnos:
                races = []
                for rno in known_rnos:
                    deadline = None
                    if rno in schedule_by_rno:
                        deadline = schedule_by_rno[rno].get("deadline")
                    if not deadline and rno in cached_races:
                        deadline = cached_races[rno].get("deadline")

                    races.append({
                        "rno": rno,
                        "deadline": deadline,
                        "source": "db-schedule" if rno in schedule_by_rno else "cache",
                    })

                item = {
                    **item,
                    "open": True,
                    "races": races,
                    "restored_from_db": True,
                }

            meeting = db_meeting_days.get(code)
            if meeting:
                item["meeting_day_number"] = meeting.get("number")
                item["meeting_day_label"] = meeting.get("label")
                item["meeting_day_official_label"] = meeting.get("official_label")

            event_meta = db_event_meta.get(code)
            if event_meta:
                item.update(event_meta)

            items.append(item)

        return {
            "date": yyyymmdd,
            "open_count": sum(1 for x in items if x.get("open")),
            "venues": items,
            "fast": True,
            "official_cached": bool(cached),
            "db_restored_count": sum(1 for x in items if x.get("restored_from_db")),
            "deadline_saved_count": sum(len(v) for v in db_schedule.values()),
        }

    def get_day(self, yyyymmdd: str) -> Dict[str, Any]:
        """
        Day/open-venue detection with DB fallback.

        Rules:
        1) Try official-site venue detection.
        2) If official parsing says "closed" but the shared DB already has
           racelists for that venue/date, restore it as open.
        3) Never persist an obviously broken "all 24 venues closed" result
           when the DB proves races exist.
        """
        # Correct stale grade records before reading either cache or DB.  The
        # index is cached for 30 minutes, so this is a very small request and
        # does not restart the heavy daily collection.
        self.refresh_day_event_meta_from_official_index(yyyymmdd)

        cache_key = f"day_v16_{yyyymmdd}"
        cached = self.cache.get(cache_key, 120)

        db_presence = self.db.get_racelist_presence(yyyymmdd)
        db_event_meta = self.db.get_day_venue_event_meta(yyyymmdd)

        # Cached result is acceptable only if it is not contradicted by DB.
        if cached is not None:
            cached_open = {
                str(v.get("code")).zfill(2)
                for v in cached.get("venues", [])
                if v.get("open")
            }
            db_open = set(db_presence.keys())

            if not db_open or db_open.issubset(cached_open):
                for item in cached.get("venues", []):
                    code = str(item.get("code") or "").zfill(2)
                    if code in db_event_meta:
                        item.update(db_event_meta[code])
                return cached

        by_code = {}

        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="boat-day") as pool:
            futures = {
                pool.submit(self._probe_venue, yyyymmdd, venue): venue["code"]
                for venue in self.venues
            }

            for future in as_completed(futures):
                code = futures[future]
                try:
                    by_code[code] = future.result()
                except Exception as e:
                    venue = next(v for v in self.venues if v["code"] == code)
                    by_code[code] = {
                        **venue,
                        "open": False,
                        "races": [],
                        "error": str(e),
                    }

        items = []

        for venue in self.venues:
            code = venue["code"]
            item = by_code.get(code, {
                **venue,
                "open": False,
                "races": [],
            })

            saved_rnos = sorted(set(db_presence.get(code, [])))

            # Official parser failed / returned closed, but DB proves this venue
            # has today's racelists. Restore it as open.
            if saved_rnos and not item.get("open"):
                existing_races = item.get("races") or []
                by_rno = {
                    int(r.get("rno")): dict(r)
                    for r in existing_races
                    if r.get("rno") is not None
                }

                restored = []
                for rno in range(1, 13):
                    if rno in by_rno:
                        restored.append(by_rno[rno])
                    elif rno in saved_rnos:
                        restored.append({
                            "rno": rno,
                            "deadline": None,
                            "source": "db-fallback",
                        })

                item = {
                    **item,
                    "open": True,
                    "races": restored,
                    "restored_from_db": True,
                }

            # If official detection succeeded but omitted some saved race cards,
            # merge the DB-known races rather than hiding them.
            elif item.get("open") and saved_rnos:
                existing_races = item.get("races") or []
                by_rno = {
                    int(r.get("rno")): dict(r)
                    for r in existing_races
                    if r.get("rno") is not None
                }
                for rno in saved_rnos:
                    by_rno.setdefault(rno, {
                        "rno": rno,
                        "deadline": None,
                        "source": "db-fallback",
                    })
                item["races"] = [by_rno[r] for r in sorted(by_rno)]

            # DB fallback is always joined by this venue's own code and date.
            # It cannot borrow a grade from a neighboring venue card.
            event_meta = db_event_meta.get(code)
            if event_meta:
                item.update(event_meta)
            elif item.get("open") and not item.get("event_grade"):
                item["event_grade"] = "一般戦"

            items.append(item)

        open_count = sum(1 for x in items if x.get("open"))

        # 締切予定時刻は当日の固定基本データとして共通DBへ保存。
        for item in items:
            if not item.get("open"):
                continue

            fixed_schedule = [
                {
                    "rno": int(r["rno"]),
                    "deadline": r.get("deadline"),
                }
                for r in (item.get("races") or [])
                if r.get("rno") is not None and r.get("deadline")
            ]

            if fixed_schedule:
                self.db.save_race_schedule(
                    yyyymmdd,
                    item["code"],
                    fixed_schedule,
                    source="boatrace-official",
                )

        data = {
            "date": yyyymmdd,
            "open_count": open_count,
            "venues": items,
            "db_restored_count": sum(1 for x in items if x.get("restored_from_db")),
        }

        # Save only meaningful day data. Do not poison shared cache with
        # "all closed" when DB contains today's racelists.
        if open_count > 0 or not db_presence:
            self.cache.set(cache_key, data)

        return data

    def load_official_venue_schedule(
        self,
        yyyymmdd: str,
        jcd: str,
        force: bool = False,
    ):
        jcd = str(jcd).zfill(2)

        if not force:
            saved = self.db.get_race_schedule(yyyymmdd, jcd)
            saved_map = {
                int(x["rno"]): x.get("deadline")
                for x in saved
                if x.get("deadline")
            }
            if len(saved_map) == 12:
                print(
                    f"[SCHEDULE] {jcd} DB already has 12/12 deadlines",
                    flush=True,
                )
                return {
                    "ok": True,
                    "jcd": jcd,
                    "races": [
                        {"rno": rno, "deadline": saved_map[rno]}
                        for rno in range(1, 13)
                    ],
                    "source": "db",
                    "stage": "verified",
                }

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno=1"
        )

        print(f"[SCHEDULE] {jcd} 1-12R deadline HTML fetching...", flush=True)

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} racelist 1R",
        )

        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, 1
        )
        meeting_day = parse_meeting_day(html, yyyymmdd)
        if meeting_day:
            self.db.save_meeting_day(
                yyyymmdd,
                jcd,
                meeting_day.get("number"),
                meeting_day.get("label"),
                meeting_day.get("official_label"),
                source="boatrace-official-racelist",
            )
            print(
                f"[MEETING] {jcd} {meeting_day.get('label')} saved",
                flush=True,
            )

        keyword_found = "締切予定時刻" in html
        print(
            f"[SCHEDULE] {jcd} keyword "
            f"'締切予定時刻'={'FOUND' if keyword_found else 'NOT FOUND'}",
            flush=True,
        )

        pos = html.find("締切予定時刻")
        raw_times = []
        if pos >= 0:
            window = html[pos:pos + 5000]
            raw_times = re.findall(
                r"(?<!\d)(\d{1,2}:\d{2})(?!\d)",
                window,
            )

        print(
            f"[SCHEDULE] {jcd} raw time candidates after label={len(raw_times)}",
            flush=True,
        )

        races = parse_race_index(html)

        print(
            f"[SCHEDULE] {jcd} parser={len(races)}/12 "
            f"{[x.get('deadline') for x in races]}",
            flush=True,
        )

        if len(races) != 12:
            raise RuntimeError(
                f"締切解析失敗: keyword={keyword_found}, "
                f"raw_times={len(raw_times)}, parser={len(races)}/12"
            )

        actual_rnos = [int(x["rno"]) for x in races]
        if actual_rnos != list(range(1, 13)):
            raise RuntimeError(f"R番号対応失敗: {actual_rnos}")

        print(f"[SCHEDULE] {jcd} DB saving 12 deadlines...", flush=True)

        self.db.save_race_schedule(
            yyyymmdd,
            jcd,
            races,
            source="boatrace-official-diagnostic-path",
        )

        saved = self.db.get_race_schedule(yyyymmdd, jcd)
        saved_map = {
            int(x["rno"]): x.get("deadline")
            for x in saved
            if x.get("deadline")
        }

        print(f"[SCHEDULE] {jcd} DB readback={len(saved_map)}/12", flush=True)

        if len(saved_map) != 12:
            raise RuntimeError(f"締切DB保存後検証失敗: {len(saved_map)}/12")

        for rno in range(1, 13):
            if not saved_map.get(rno):
                raise RuntimeError(f"締切DB検証失敗: {rno}R missing")

        print(f"[SCHEDULE] {jcd} COMPLETE 12/12", flush=True)

        return {
            "ok": True,
            "jcd": jcd,
            "races": [
                {"rno": rno, "deadline": saved_map[rno]}
                for rno in range(1, 13)
            ],
            "source": "boatrace.jp",
            "source_url": url,
            "stage": "verified",
        }

    def fetch_basic_race_atomic(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        logic_version: str,
    ):
        """
        BOAT RACE公式一本化。

        事前条件:
          その場の1R〜12R締切が race_schedule に保存済み。

        そのRでは:
          racelistページ取得
          -> 6艇解析
          -> 事前保存済み締切とセット
          -> atomic save
          -> read-back verify
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        # Ensure venue schedule first.
        schedule = self.load_official_venue_schedule(
            yyyymmdd, jcd, force=False
        )
        by_rno = {
            int(x["rno"]): x["deadline"]
            for x in schedule["races"]
        }

        deadline = by_rno.get(rno)
        if not deadline:
            raise RuntimeError(
                f"{jcd}-{rno}R 締切時刻が保存されていません"
            )

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(url, ttl=120, diagnostic_label=f"{jcd} {rno}R racelist")
        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, rno
        )
        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )
        racers = parsed.get("racers") or []

        if len(racers) != 6:
            raise ValueError(
                f"基本データ未完成: 出走表 {len(racers)}/6艇"
            )

        # Cross-check schedule from current race page too.
        page_deadline = parse_race_deadline(html, rno)
        if page_deadline and page_deadline != deadline:
            # Current page is more recent; update schedule and use it.
            deadline = page_deadline
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                [{"rno": rno, "deadline": deadline}],
                source="boatrace-official-racelist-crosscheck",
            )

        race_data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
            "deadline": deadline,
            "basic_source": "boatrace.jp",
        }

        self.db.save_basic_race_atomic(
            yyyymmdd,
            jcd,
            rno,
            race_data,
            deadline,
            logic_version,
        )

        verified = self.db.verify_basic_race(
            yyyymmdd,
            jcd,
            rno,
            deadline,
            logic_version,
        )

        if not verified:
            raise RuntimeError(
                "保存後の基本データ検証に失敗"
            )

        return {
            "ok": True,
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "deadline": deadline,
            "racers": 6,
            "saved": True,
            "verified": True,
            "data": race_data,
            "source": "boatrace.jp",
            "source_url": url,
        }

    def _meeting_day_number_from_db(self, yyyymmdd: str, jcd: str):
        try:
            with self.db.connect() as con:
                row = con.execute("""
                    SELECT day_number
                    FROM venue_meeting_day
                    WHERE date=? AND jcd=?
                """, (yyyymmdd, str(jcd).zfill(2))).fetchone()
            if row and row["day_number"] is not None:
                return int(row["day_number"])
        except Exception:
            pass
        return None

    def _meeting_results_racer_count(self, data):
        racers = (data or {}).get("racers") or []
        count = 0
        for x in racers:
            if not isinstance(x, dict):
                continue
            m = x.get("meeting_results")
            if not isinstance(m, dict):
                continue
            if m.get("entries") or m.get("display"):
                count += 1
        return count

    def _meeting_results_complete_racer_count(self, data):
        """Count racers whose current-meeting history includes an actual result.

        Older snapshots created by the broken parser could contain only
        race-number/course rows.  Those snapshots looked non-empty, so the old
        completeness check incorrectly skipped a fresh official fetch and the UI
        showed only ``R`` and ``進C`` with no ST/finish.

        For day 2+ a usable current-meeting record must contain at least one
        completed run (finish present).  ST may legitimately be F/L text, so the
        finish field is the reliable completion marker.
        """
        racers = (data or {}).get("racers") or []
        count = 0
        for x in racers:
            if not isinstance(x, dict):
                continue
            m = x.get("meeting_results")
            if not isinstance(m, dict):
                continue
            entries = [e for e in (m.get("entries") or []) if isinstance(e, dict)]
            slots = [e for e in (m.get("slots") or []) if isinstance(e, dict)]
            rows = entries or slots
            if any(e.get("rno") is not None and e.get("finish") not in (None, "") for e in rows):
                count += 1
        return count

    def _racelist_has_meeting_results(self, data):
        # A snapshot is reusable only when all six racers have at least one
        # actual finish result.  Merely having race/course cells is NOT enough.
        # This deliberately invalidates old broken snapshots and makes the
        # meeting-results phase fetch the official racelist once to repair them.
        racers = (data or {}).get("racers") or []
        return (
            len(racers) == 6
            and self._meeting_results_complete_racer_count(data) == 6
        )


    def _meeting_result_detail_complete(self, yyyymmdd: str, jcd: str, rno: int) -> bool:
        """Return True only when one saved result has full 6-racer course/ST/finish detail."""
        row = self.db.get_result_for_race_db(yyyymmdd, str(jcd).zfill(2), int(rno))
        if not isinstance(row, dict):
            return False
        finishers = [x for x in (row.get("finishers") or []) if isinstance(x, dict)]
        starts = [x for x in (row.get("start_courses") or []) if isinstance(x, dict)]
        if len(finishers) < 6 or len(starts) < 6:
            return False
        st_by_lane = {int(x.get("lane") or 0): x.get("st_raw") for x in starts}
        for fin in finishers:
            try:
                lane = int(fin.get("lane") or 0)
            except Exception:
                return False
            if not (1 <= lane <= 6):
                return False
            if fin.get("finish") in (None, ""):
                return False
            if fin.get("course") in (None, ""):
                return False
            if (fin.get("st_raw") or st_by_lane.get(lane)) in (None, ""):
                return False
        return True

    def repair_meeting_results_from_official_history(self, yyyymmdd: str, jcd: str):
        """Self-heal today's meeting grid from prior official race results.

        This path is intentionally independent from the current racelist's
        meeting-result subtable.  For day 2+ it first proves the previous
        meeting dates using official meeting-day metadata, then ensures the
        BOAT RACE result pages for those dates have full 6-racer
        lane/course/ST/finish detail, and finally rebuilds today's 12 saved
        racelist snapshots by registration number.

        It is the v17.230 verification path requested for the missing ST/finish
        issue: source data -> saved result detail -> today's meeting snapshot.
        """
        jcd = str(jcd).zfill(2)
        current = self._meeting_day_number_from_db(yyyymmdd, jcd)
        try:
            current = int(current)
        except Exception:
            current = None
        diag = {
            "ok": False,
            "jcd": jcd,
            "today": yyyymmdd,
            "meeting_day": current,
            "matched_dates": [],
            "result_days_checked": 0,
            "result_races_complete_before": 0,
            "result_races_fetched": 0,
            "result_races_complete_after": 0,
            "updated_snapshots": 0,
            "meeting_result_rows": 0,
            "reason": None,
        }
        if current is None or current < 2:
            diag["reason"] = "meeting-day<2-or-unknown"
            return diag

        wanted = set(range(1, current))
        matched = {}
        today_dt = datetime.strptime(yyyymmdd, "%Y%m%d")

        # Meetings are normally consecutive, but scan a wider calendar window
        # and accept only dates whose official meeting-day number exactly
        # matches 1..N-1. This prevents mixing an older meeting at the same venue.
        for back in range(1, 15):
            if not wanted:
                break
            d = (today_dt - timedelta(days=back)).strftime("%Y%m%d")
            saved = self.db.get_day_meeting_days(d).get(jcd)
            number = (saved or {}).get("number")
            if number is None:
                try:
                    info = self.ensure_meeting_day(d, jcd, force=False)
                    number = info.get("number")
                except Exception:
                    continue
            try:
                number = int(number)
            except Exception:
                continue
            if number in wanted and number not in matched:
                matched[number] = d
                wanted.discard(number)

        diag["matched_dates"] = [matched[k] for k in sorted(matched)]
        if wanted:
            diag["reason"] = "missing-proven-meeting-dates:" + ",".join(map(str, sorted(wanted)))
            return diag

        for day_no in sorted(matched):
            d = matched[day_no]
            diag["result_days_checked"] += 1
            before = sum(1 for rno in range(1, 13) if self._meeting_result_detail_complete(d, jcd, rno))
            diag["result_races_complete_before"] += before
            if before < 12:
                try:
                    fetched = self.fetch_results_atomic(d, jcd)
                    diag["result_races_fetched"] += int((fetched or {}).get("confirmed_count") or 0)
                except Exception as ex:
                    # Keep diagnostics explicit. Rebuild still uses whatever
                    # complete official rows are already saved.
                    diag.setdefault("fetch_errors", []).append(f"{d}:{type(ex).__name__}:{ex}")
            after = sum(1 for rno in range(1, 13) if self._meeting_result_detail_complete(d, jcd, rno))
            diag["result_races_complete_after"] += after

        rebuilt = self.db.rebuild_meeting_results_from_saved_results(yyyymmdd, jcd) or {}
        diag["updated_snapshots"] = int(rebuilt.get("updated_snapshots") or 0)
        diag["meeting_result_rows"] = int(rebuilt.get("result_rows") or 0)
        diag["rebuild_dates"] = list(rebuilt.get("meeting_dates") or [])
        diag["ok"] = bool(diag["updated_snapshots"] > 0 and diag["meeting_result_rows"] > 0)
        if not diag["ok"] and not diag.get("reason"):
            diag["reason"] = "official-results-present-but-no-snapshot-update"
        return diag

    def refresh_meeting_results_race(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Dedicated fresh fetch for current-meeting results.

        Used only in the venue-by-venue meeting-results phase so stale
        racelist snapshots/cache cannot hide newly published series results.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R meeting-results fresh",
        )
        self._validate_requested_racelist_date(
            html, yyyymmdd, jcd, rno
        )
        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )

        racers = parsed.get("racers") or []
        if len(racers) != 6:
            raise ValueError(
                f"節間成績用出走表が6艇揃っていません: "
                f"{jcd}-{rno} ({len(racers)}艇)"
            )

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        deadline = parse_race_deadline(html, rno)
        if deadline:
            data["deadline"] = deadline
            self.db.save_race_schedule(
                yyyymmdd,
                jcd,
                [{"rno": rno, "deadline": deadline}],
                source="meeting-results-racelist",
            )

        # Persist parser diagnostics with the fresh snapshot. These fields
        # make it possible to distinguish HTTP success from actual extraction.
        data["meeting_results_racer_count"] = self._meeting_results_racer_count(data)
        data["meeting_results_parser_ok"] = (
            data["meeting_results_racer_count"] == 6
        )

        self.db.save_snapshot(
            yyyymmdd, jcd, rno, "racelist", data
        )

        return data


    def get_race(self, yyyymmdd: str, jcd: str, rno: int):
        """
        出走表は一度6艇そろって保存できたら、そのDBスナップショットを優先利用。
        直前情報・オッズ・結果の取得では絶対に上書きしない。
        大村(24)のみ、通常取得失敗時に予備URLを1回試す。
        """
        jcd = str(jcd).zfill(2)

        # 既に6艇そろって保存済みなら、そのまま返す。
        existing = self.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
        if existing:
            existing_data = existing.get("data") or {}
            racers = existing_data.get("racers") or []

            if len(racers) == 6:
                # First check persistent schedule DB.
                saved_schedule = self.db.get_race_schedule(yyyymmdd, jcd)
                saved_deadline = next(
                    (
                        x.get("deadline")
                        for x in saved_schedule
                        if int(x.get("rno", 0)) == int(rno)
                    ),
                    None
                )

                if saved_deadline:
                    existing_data["deadline"] = saved_deadline

                    # 初日以外は節間成績を重要データとして扱う。
                    # 古いスナップショットに節間成績が無ければ、ここでは
                    # 早期returnせず公式出走表を1回取り直して補完する。
                    meeting_day = self._meeting_day_number_from_db(
                        yyyymmdd, jcd
                    )
                    needs_meeting_refresh = (
                        meeting_day is not None
                        and meeting_day >= 2
                        and not self._racelist_has_meeting_results(existing_data)
                    )

                    if not needs_meeting_refresh:
                        return existing_data

                # Old snapshots contain raw_text from the original official page.
                recovered = parse_deadline_from_saved_text(
                    existing_data.get("raw_text") or "",
                    rno,
                )
                if recovered:
                    existing_data["deadline"] = recovered
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        [{"rno": int(rno), "deadline": recovered}],
                        source="old-racelist-raw-text",
                    )
                    self.db.save_snapshot(
                        yyyymmdd, jcd, rno, "racelist", existing_data
                    )
                    return existing_data

                # If neither DB nor old raw_text has the deadline, do NOT
                # return early. Continue below and fetch the official
                # racelist page once to repair the schedule.

        urls = [
            f"{BASE}/owpc/pc/race/racelist?jcd={jcd}&hd={yyyymmdd}&rno={rno}",
        ]

        # 大村専用フォールバック。公式側でページ遷移や応答差がある場合に備える。
        if jcd == "24":
            urls.append(
                f"{BASE}/owpc/pc/race/pcexpect?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            )

        errors = []

        for idx, url in enumerate(urls):
            try:
                meeting_day = self._meeting_day_number_from_db(
                    yyyymmdd, jcd
                )
                existing_snap = self.db.get_snapshot(
                    yyyymmdd, jcd, rno, "racelist"
                )
                existing_data_for_refresh = (
                    (existing_snap or {}).get("data") or {}
                )
                force_meeting_refresh = (
                    meeting_day is not None
                    and meeting_day >= 2
                    and not self._racelist_has_meeting_results(
                        existing_data_for_refresh
                    )
                )

                html = self._get(
                    url,
                    ttl=900 if idx == 0 else 120,
                    fresh=force_meeting_refresh,
                    diagnostic_label=(
                        f"{jcd} {rno}R racelist meeting-results"
                        if force_meeting_refresh else None
                    ),
                )
                self._validate_requested_racelist_date(
                    html, yyyymmdd, jcd, rno
                )
                meeting_day_info = parse_meeting_day(html, yyyymmdd)
                parsed = parse_race_list(
                    html,
                    meeting_day_no=(meeting_day_info or {}).get("number"),
                )
                data = {
                    "date": yyyymmdd,
                    "jcd": jcd,
                    "rno": rno,
                    "source_url": url,
                    **parsed,
                }

                racers = data.get("racers") or []
                if len(racers) != 6:
                    raise ValueError(
                        f"出走表が6艇揃っていません: {jcd}-{rno} ({len(racers)}艇)"
                    )

                # One racelist page contains the complete venue schedule.
                full_schedule = parse_race_index(html)
                if len(full_schedule) == 12:
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        full_schedule,
                        source="racelist-page-full-schedule",
                    )

                # The racelist page itself is now the primary source for this R's deadline.
                # This ties "racelist saved" and "deadline saved" together.
                deadline = data.get("deadline") or parse_race_deadline(html, rno)
                if deadline:
                    data["deadline"] = deadline
                    self.db.save_race_schedule(
                        yyyymmdd,
                        jcd,
                        [{"rno": int(rno), "deadline": deadline}],
                        source="racelist-page",
                    )

                self.db.save_snapshot(yyyymmdd, jcd, rno, "racelist", data)
                return data

            except Exception as e:
                errors.append(f"{url}: {e}")

        raise RuntimeError(" / ".join(errors))


    def apply_scratch_lanes_to_saved_racelist(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        scratch_lanes,
        source_name: str = "official-odds-matrix",
    ):
        jcd=str(jcd).zfill(2)
        rno=int(rno)
        scratch_set={int(x) for x in (scratch_lanes or [])}

        snap=self.db.get_snapshot(yyyymmdd,jcd,rno,"racelist")
        if not snap:
            return False

        data=snap.get("data") or {}
        racers=data.get("racers") or []
        if len(racers)!=6:
            return False

        updated=[]
        for racer in racers:
            row=dict(racer)
            lane=int(row.get("lane",0))
            row["scratched"]=lane in scratch_set
            row["status"]="欠場" if row["scratched"] else "出走"
            updated.append(row)

        data["racers"]=updated
        data["scratch_lanes"]=sorted(scratch_set)
        data["has_scratch"]=bool(scratch_set)
        data["scratch_source"]=source_name
        data["scratch_checked"]=True

        self.db.save_snapshot(yyyymmdd,jcd,rno,"racelist",data)

        # A scratch has no valid original-exhibition measurement.  Remove
        # only that lane from the exact race's saved before-info snapshot so
        # a value collected before the scratch announcement cannot remain.
        before_snap = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "beforeinfo"
        ) or {}
        before_data = before_snap.get("data") or {}
        if before_data and scratch_set:
            before_data["original_exhibition"] = (
                self._filter_original_exhibition_for_scratch(
                    before_data.get("original_exhibition") or [], scratch_set
                )
            )
            before_data["original_exhibition_scratch_cleared"] = sorted(
                scratch_set
            )
            self.db.save_snapshot(
                yyyymmdd, jcd, rno, "beforeinfo", before_data
            )

        check=self.db.get_snapshot(yyyymmdd,jcd,rno,"racelist")
        cdata=(check or {}).get("data") or {}
        saved=sorted(int(x.get("lane")) for x in (cdata.get("racers") or []) if x.get("scratched"))
        ok=saved==sorted(scratch_set)

        print(
            f"[SCRATCH-OVERWRITE] {jcd} {rno}R "
            f"requested={sorted(scratch_set)} saved={saved} verified={ok}",
            flush=True,
        )
        return ok


    def refresh_scratch_status(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Freshly re-check the official racelist when odds are incomplete.

        If a scratched boat is found:
          - update the saved racelist snapshot
          - preserve richer previously saved racer fields
          - mark the boat as scratched
          - return active lanes and expected odds count
        """
        import time as _time

        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/racelist"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            f"&_scratchcheck={int(_time.time() * 1000)}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R scratch-check",
        )

        meeting_day_info = parse_meeting_day(html, yyyymmdd)
        parsed = parse_race_list(
            html,
            meeting_day_no=(meeting_day_info or {}).get("number"),
        )
        fresh_racers = parsed.get("racers") or []

        existing = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "racelist"
        )
        old_data = (
            (existing or {}).get("data")
            or {}
        )
        old_racers = old_data.get("racers") or []
        old_by_lane = {
            int(x.get("lane", 0)): x
            for x in old_racers
        }

        merged = []
        fresh_by_lane = {
            int(x.get("lane", 0)): x
            for x in fresh_racers
        }

        # Preserve all six saved rows, but refresh scratch flags and any
        # official fields we successfully parsed now.
        for lane in range(1, 7):
            old = dict(old_by_lane.get(lane) or {})
            fresh = dict(fresh_by_lane.get(lane) or {})

            if old and fresh:
                old.update({
                    k: v
                    for k, v in fresh.items()
                    if v is not None
                })
                row = old
            elif fresh:
                row = fresh
            else:
                row = old

            if row:
                # Once a scratch has been confirmed and persisted for this exact
                # race, never clear it merely because a later official racelist
                # no longer carries the scratch marker after the race closes.
                # A confirmed scratch is monotonic for a race: the boat did not
                # start, so its historical display must remain 欠場 forever.
                old_scratched = bool(old.get("scratched", False)) or str(old.get("status") or "") == "欠場"
                fresh_scratched = bool(fresh.get("scratched", False)) or str(fresh.get("status") or "") == "欠場"
                row["scratched"] = bool(old_scratched or fresh_scratched)
                row["status"] = "欠場" if row["scratched"] else "出走"
                merged.append(row)

        scratch_lanes = sorted([
            int(x["lane"])
            for x in merged
            if x.get("scratched")
        ])

        active_lanes = [
            lane for lane in range(1, 7)
            if lane not in scratch_lanes
        ]

        n = len(active_lanes)
        expected_count = (
            n * (n - 1) * (n - 2)
            if n >= 3
            else 0
        )

        updated = {
            **old_data,
            **parsed,
            "racers": merged,
            "scratch_lanes": scratch_lanes,
            "has_scratch": bool(scratch_lanes),
            "scratch_checked": True,
            "deadline": old_data.get("deadline"),
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
        }

        if len(merged) == 6:
            self.db.save_snapshot(
                yyyymmdd,
                jcd,
                rno,
                "racelist",
                updated,
            )

        if scratch_lanes:
            before_snap = self.db.get_snapshot(
                yyyymmdd, jcd, rno, "beforeinfo"
            ) or {}
            before_data = before_snap.get("data") or {}
            if before_data:
                before_data["original_exhibition"] = (
                    self._filter_original_exhibition_for_scratch(
                        before_data.get("original_exhibition") or [],
                        scratch_lanes,
                    )
                )
                before_data["original_exhibition_scratch_cleared"] = list(
                    scratch_lanes
                )
                self.db.save_snapshot(
                    yyyymmdd, jcd, rno, "beforeinfo", before_data
                )

        print(
            f"[SCRATCH] {jcd} {rno}R "
            f"scratch={scratch_lanes} "
            f"active={active_lanes} "
            f"expected_odds={expected_count}",
            flush=True,
        )

        return {
            "scratch_lanes": scratch_lanes,
            "active_lanes": active_lanes,
            "expected_count": expected_count,
            "racelist": updated,
        }


    def audit_scratch_from_odds(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        """
        Dedicated scratch audit.
        Runs independently from odds completeness.

        1) Fresh official odds3t fetch
        2) Parse official odds matrix, including literal "欠場"
        3) Detect scratched lane(s)
        4) Force-overwrite saved racelist
        5) Stamp scratch_audit_version
        6) Read back and verify
        """
        import time as _time

        jcd = str(jcd).zfill(2)
        rno = int(rno)

        url = (
            f"{BASE}/owpc/pc/race/odds3t"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
            f"&_scratchaudit={int(_time.time() * 1000)}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R scratch-audit",
        )

        matrix = parse_odds3t_matrix(html)

        records = int(matrix.get("matrix_records") or 0)
        scratch_lanes = [
            int(x)
            for x in (matrix.get("scratch_lanes") or [])
        ]

        print(
            f"[SCRATCH-AUDIT] {jcd} {rno}R "
            f"records={records} "
            f"scratch={scratch_lanes} "
            f"parsed={matrix.get('count')}/"
            f"{matrix.get('expected_count')}",
            flush=True,
        )

        # If the matrix parser couldn't map most of the official board,
        # don't stamp the audit as successful.
        if records < 100:
            raise RuntimeError(
                f"欠場監査用オッズ表の解析不足: records={records}/120"
            )

        snap = self.db.get_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
        )
        if not snap:
            raise RuntimeError("保存済み出走表がありません")

        data = snap.get("data") or {}
        racers = data.get("racers") or []

        if len(racers) != 6:
            raise RuntimeError(
                f"保存済み出走表が6艇ではありません: {len(racers)}/6"
            )

        scratch_set = set(scratch_lanes)
        updated = []

        for racer in racers:
            row = dict(racer)
            lane = int(row.get("lane", 0))
            scratched = lane in scratch_set
            row["scratched"] = scratched
            row["status"] = "欠場" if scratched else "出走"
            updated.append(row)

        data["racers"] = updated
        data["scratch_lanes"] = sorted(scratch_set)
        data["has_scratch"] = bool(scratch_set)
        data["scratch_checked"] = True
        data["scratch_source"] = "official-odds-matrix-audit"
        data["scratch_audit_version"] = "scratch-audit-v1"
        data["scratch_audited_at"] = int(_time.time())

        # Force overwrite even if the racelist was saved long ago.
        self.db.save_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
            data,
        )

        before_snap = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "beforeinfo"
        ) or {}
        before_data = before_snap.get("data") or {}
        if before_data and scratch_set:
            before_data["original_exhibition"] = (
                self._filter_original_exhibition_for_scratch(
                    before_data.get("original_exhibition") or [], scratch_set
                )
            )
            before_data["original_exhibition_scratch_cleared"] = sorted(
                scratch_set
            )
            self.db.save_snapshot(
                yyyymmdd, jcd, rno, "beforeinfo", before_data
            )

        check = self.db.get_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "racelist",
        )
        cdata = (check or {}).get("data") or {}
        cracers = cdata.get("racers") or []

        saved_scratch = sorted([
            int(x.get("lane"))
            for x in cracers
            if x.get("scratched")
        ])

        verified = (
            cdata.get("scratch_audit_version") == "scratch-audit-v1"
            and saved_scratch == sorted(scratch_lanes)
        )

        if not verified:
            raise RuntimeError(
                f"欠場監査保存後検証失敗: "
                f"expected={sorted(scratch_lanes)} saved={saved_scratch}"
            )

        print(
            f"[SCRATCH-AUDIT-SAVED] {jcd} {rno}R "
            f"scratch={saved_scratch} verified=True",
            flush=True,
        )

        return {
            "ok": True,
            "jcd": jcd,
            "rno": rno,
            "scratch_lanes": saved_scratch,
            "has_scratch": bool(saved_scratch),
            "matrix_records": records,
            "expected_count": matrix.get("expected_count"),
            "odds_count": matrix.get("count"),
            "verified": True,
        }


    def fetch_odds_atomic(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        recovery_level: int = 0,
    ):
        import time as _time
        jcd=str(jcd).zfill(2)
        rno=int(rno)
        base_url=f"{BASE}/owpc/pc/race/odds3t?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        url=base_url
        if recovery_level>=1:
            url=base_url+f"&_recover={int(_time.time()*1000)}"

        if recovery_level>=2:
            s=requests.Session()
            s.headers.update({
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36",
                "Cache-Control":"no-cache",
                "Pragma":"no-cache",
            })
            resp=s.get(url,timeout=(5.0,15.0))
            resp.raise_for_status()
            html,enc=self._decode_response_like_diagnostic(resp)
            print(f"[HTTP-RECOVERY] {jcd} {rno}R level=2 status={resp.status_code} bytes={len(resp.content)} encoding={enc}",flush=True)
        else:
            html=self._get(
                url,ttl=0,fresh=True,
                diagnostic_label=f"{jcd} {rno}R odds3t recovery={recovery_level}",
            )

        matrix=parse_odds3t_matrix(html)
        print(
            f"[ODDS-MATRIX] {jcd} {rno}R "
            f"records={matrix.get('matrix_records')} "
            f"scratch={matrix.get('scratch_lanes')} "
            f"parsed={matrix.get('count')}/{matrix.get('expected_count')} "
            f"diag={matrix.get('matrix_diagnostics')}",
            flush=True,
        )

        data=matrix
        odds=data.get("odds") or []
        scratch_lanes=data.get("scratch_lanes") or []
        expected=int(data.get("expected_count") or 120)

        if scratch_lanes:
            if not self.apply_scratch_lanes_to_saved_racelist(
                yyyymmdd,jcd,rno,scratch_lanes,
                source_name="official-odds-matrix",
            ):
                raise RuntimeError(f"欠場フラグの出走表上書き検証に失敗: {scratch_lanes}")

        if len(odds)!=expected and not scratch_lanes:
            if recovery_level==0:
                data=parse_odds3t(html)
                data["parser_method"]="primary"
            else:
                data=parse_odds3t_recovery(html)
            odds=data.get("odds") or []
            expected=120

        combos=[str(x.get("combo") or "") for x in odds]
        if len(odds)!=expected:
            raise ValueError(
                f"3連単オッズ未完成: {len(odds)}/{expected} "
                f"scratch={scratch_lanes} level={recovery_level} "
                f"parser={data.get('parser_method')}"
            )
        if len(set(combos))!=expected:
            raise ValueError(f"3連単オッズ組合せ重複: unique={len(set(combos))}/{expected}")

        scratch_set={str(x) for x in scratch_lanes}
        invalid=[c for c in combos if scratch_set.intersection(c.split("-"))]
        if invalid:
            raise ValueError(f"欠場艇を含む有効オッズを検出: {invalid[:5]}")

        active=[lane for lane in range(1,7) if lane not in set(scratch_lanes)]
        payload={
            "date":yyyymmdd,"jcd":jcd,"rno":rno,
            "source_url":base_url,
            "recovery_level":recovery_level,
            **data,
        }
        payload["expected_count"]=expected
        payload["scratch_lanes"]=scratch_lanes
        payload["active_lanes"]=active
        payload["has_scratch"]=bool(scratch_lanes)
        payload["odds"]=odds
        payload["count"]=len(odds)
        payload["odds_validation_version"]="scratch-matrix-v2"
        payload["scratch_revalidated"]=True

        self.db.save_odds_atomic(yyyymmdd,jcd,rno,payload)
        verified=self.db.verify_odds_snapshot(yyyymmdd,jcd,rno)
        if not verified:
            raise RuntimeError("オッズ保存後のDB検証に失敗")

        return {
            "ok":True,"date":yyyymmdd,"jcd":jcd,"rno":rno,
            "count":len(odds),"expected_count":expected,
            "saved":True,"verified":True,
            "recovery_level":recovery_level,
            "parser_method":payload.get("parser_method"),
            "scratch_lanes":scratch_lanes,
            "active_lanes":active,
            "data":payload,
        }


    def fetch_venue_comments_for_race(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
    ):
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        race = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "racelist"
        )
        racers = ((race or {}).get("data") or {}).get("racers") or []

        result = fetch_venue_comments(
            yyyymmdd,
            jcd,
            rno,
            racers,
        )

        before = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "beforeinfo"
        )
        data = ((before or {}).get("data") or {})

        # Save explicit comment status even when no comment is available.
        data["comments"] = result.get("comments") or []
        data["comments_source_url"] = result.get("source_url")
        data["comments_source_reason"] = result.get("reason")
        data["comments_source_jcd"] = jcd

        # Keep the rest of beforeinfo untouched.
        self.db.save_snapshot(
            yyyymmdd,
            jcd,
            rno,
            "beforeinfo",
            data,
        )

        return result


    def _saved_scratch_lanes_for_race(self, yyyymmdd: str, jcd: str, rno: int):
        """Return scratch lanes already verified for this exact race."""
        snap = self.db.get_snapshot(
            yyyymmdd, str(jcd).zfill(2), int(rno), "racelist"
        ) or {}
        data = snap.get("data") or {}
        lanes = set()
        for value in data.get("scratch_lanes") or []:
            try:
                lane = int(value)
            except (TypeError, ValueError):
                continue
            if 1 <= lane <= 6:
                lanes.add(lane)
        for row in data.get("racers") or []:
            try:
                lane = int(row.get("lane"))
            except (TypeError, ValueError):
                continue
            if row.get("scratched") or str(row.get("status") or "") == "欠場":
                lanes.add(lane)
        return lanes

    @staticmethod
    def _filter_original_exhibition_for_scratch(rows, scratch_lanes):
        scratch = {int(x) for x in (scratch_lanes or [])}
        filtered = []
        for row in rows or []:
            try:
                lane = int(row.get("lane"))
            except (TypeError, ValueError):
                continue
            if lane not in scratch:
                filtered.append(row)
        return filtered

    @staticmethod
    def _original_exhibition_is_complete(rows, scratch_lanes):
        """Six boats normally; only active boats when a scratch is known."""
        expected = max(0, 6 - len({int(x) for x in (scratch_lanes or [])}))
        return expected >= 3 and len(rows or []) == expected

    def fetch_before_atomic(
        self,
        yyyymmdd: str,
        jcd: str,
        rno: int,
        collect_original: bool = True,
    ):
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        url = (
            f"{BASE}/owpc/pc/race/beforeinfo"
            f"?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} {rno}R beforeinfo",
        )

        parsed = parse_before_info(html)
        existing_before = self.db.get_snapshot(
            yyyymmdd, jcd, rno, "beforeinfo"
        ) or {}
        existing_data = existing_before.get("data") or {}
        existing_original = existing_data.get("original_exhibition") or []
        scratch_lanes = self._saved_scratch_lanes_for_race(
            yyyymmdd, jcd, rno
        )

        # Once a complete original-exhibition payload has been saved, later
        # ordinary before-info refreshes must not request it again.  They keep
        # the exact saved rows for this race instead.
        if not collect_original:
            parsed["original_exhibition"] = self._filter_original_exhibition_for_scratch(
                existing_original, scratch_lanes
            )
            parsed["original_exhibition_source_url"] = (
                existing_data.get("original_exhibition_source_url")
            )
            parsed["original_exhibition_source"] = (
                existing_data.get("original_exhibition_source")
            )
            parsed["original_exhibition_status"] = (
                existing_data.get("original_exhibition_status")
                if self._original_exhibition_is_complete(
                    parsed["original_exhibition"], scratch_lanes
                )
                else "collection_error"
            )

        # The official BOATRACE before-info page is parsed for every venue.
        # BOATCAST is the common race-specific source used first for the
        # original-exhibition measurements. If it fails, the already-fetched
        # official before-info result is retained when it contains six active
        # boats; venue-specific official adapters are then tried where known.
        # A timeout here must never block the normal before-info save.
        original_url = (
            f"{BOATCAST_BASE}/txt/{jcd}/"
            f"bc_oriten_{yyyymmdd}_{jcd}_{rno:02d}.txt"
        )
        if collect_original:
            parsed["original_exhibition_source_url"] = original_url
            parsed["original_exhibition_source"] = "boatcast"
            parsed["original_exhibition_status"] = "waiting"
        if collect_original and (parsed.get("racers") or parsed.get("start_display")):
            try:
                original_response = self._session().get(
                    original_url, timeout=(5.0, 10.0)
                )
                original_response.raise_for_status()
                original_body = original_response.content.decode(
                    "utf-8-sig", errors="replace"
                )
                original_payload = parse_boatcast_original_exhibition(original_body)
                parsed["original_exhibition_status"] = {
                    "0": "measuring", "1": "published", "2": "unavailable",
                }.get(original_payload.get("status"), "waiting")
                parsed["original_exhibition_labels"] = (
                    original_payload.get("labels") or []
                )
                original = self._filter_original_exhibition_for_scratch(
                    original_payload.get("rows") or [], scratch_lanes
                )
                print(
                    f"[HTTP] {jcd} {rno}R boatcast-original-exhibition "
                    f"status={original_response.status_code} "
                    f"state={parsed['original_exhibition_status']} "
                    f"rows={len(original)}/"
                    f"{max(0, 6 - len(scratch_lanes))} "
                    f"labels={len(parsed['original_exhibition_labels'])}",
                    flush=True,
                )
                if self._original_exhibition_is_complete(original, scratch_lanes):
                    parsed["original_exhibition"] = original
                elif original:
                    parsed["original_exhibition_error"] = (
                        f"BOATCAST rows={len(original)}/"
                        f"{max(0, 6 - len(scratch_lanes))}"
                    )
            except Exception as exc:
                parsed["original_exhibition_error"] = str(exc)[:300]
                print(
                    f"[HTTP] {jcd} {rno}R boatcast-original-exhibition "
                    f"failed={parsed['original_exhibition_error']}",
                    flush=True,
                )

        # Some venues publish an additional official table. Use the adapter
        # only when BOATCAST and the common official before-info page did not
        # return a complete active-boat set.
        if (
            collect_original
            and jcd == "20"
            and not self._original_exhibition_is_complete(
                parsed.get("original_exhibition") or [], scratch_lanes
            )
        ):
            official_url = (
                "https://www.wmb.jp/modules/yosou/group-cyokuzen.php"
                f"?day={yyyymmdd}&race={rno}&kind=2&if=1"
            )
            try:
                official_html = self._get(
                    official_url, ttl=0, fresh=True,
                    diagnostic_label=f"20 {rno}R official-original-exhibition",
                )
                official_original = parse_wakamatsu_original_exhibition(official_html)
                official_original = self._filter_original_exhibition_for_scratch(
                    official_original, scratch_lanes
                )
                if self._original_exhibition_is_complete(
                    official_original, scratch_lanes
                ):
                    parsed["original_exhibition"] = official_original
                    parsed["original_exhibition_source_url"] = official_url
                    parsed["original_exhibition_source"] = "official-wakamatsu"
                    parsed["original_exhibition_status"] = "official-wakamatsu"
                    print(
                        f"[HTTP] {jcd} {rno}R official-original-exhibition "
                        f"rows={len(official_original)}/"
                        f"{max(0, 6 - len(scratch_lanes))}",
                        flush=True,
                    )
            except Exception as exc:
                parsed["original_exhibition_official_error"] = str(exc)[:300]

        # A before-info refresh may temporarily omit a venue-original table
        # even after it has been published.  Keep the last complete official
        # measurement for this exact race rather than replacing it with an
        # empty list.  The next successful fetch still replaces it normally.
        parsed["original_exhibition"] = self._filter_original_exhibition_for_scratch(
            parsed.get("original_exhibition") or [], scratch_lanes
        )
        if collect_original and self._original_exhibition_is_complete(
            parsed.get("original_exhibition") or [], scratch_lanes
        ):
            if parsed.get("original_exhibition_status") not in {
                "published", "official-heiwajima"
            }:
                parsed["original_exhibition_status"] = "official-beforeinfo"
                parsed["original_exhibition_source_url"] = url
                parsed["original_exhibition_source"] = "official-beforeinfo"
        # Heiwajima publishes original exhibition measurements on its own
        # official page, not on the nationwide before-info page.
        if collect_original and jcd == "04":
            original_url = (
                "https://www.heiwajima.gr.jp/asp/kyogi/04/pc/"
                f"yoso05{int(rno):02d}.htm"
            )
            try:
                original_html = self._get(
                    original_url, ttl=0, fresh=True,
                    diagnostic_label=f"04 {rno}R original-exhibition",
                )
                original = parse_heiwajima_original_exhibition(original_html)
                original = self._filter_original_exhibition_for_scratch(
                    original, scratch_lanes
                )
                if self._original_exhibition_is_complete(
                    original, scratch_lanes
                ):
                    parsed["original_exhibition"] = original
                    parsed["original_exhibition_source_url"] = original_url
                    parsed["original_exhibition_source"] = "official-heiwajima"
                    parsed["original_exhibition_status"] = "official-heiwajima"
                    by_lane = {int(x.get("lane") or 0): x for x in parsed.get("racers") or []}
                    for item in original:
                        racer = by_lane.get(int(item["lane"]))
                        if racer is not None:
                            if item.get("parts_replacement"):
                                racer["parts_replacement"] = item["parts_replacement"]
                            if item.get("tilt") is not None:
                                racer["tilt"] = item["tilt"]
            except Exception:
                # Nationwide before-info is still saved; retry on next 30/60s cycle.
                pass
        if (
            not self._original_exhibition_is_complete(
                parsed.get("original_exhibition") or [], scratch_lanes
            )
            and self._original_exhibition_is_complete(
                existing_original, scratch_lanes
            )
        ):
            parsed["original_exhibition"] = self._filter_original_exhibition_for_scratch(
                existing_original, scratch_lanes
            )
            parsed["original_exhibition_source_url"] = (
                (existing_before.get("data") or {}).get("original_exhibition_source_url")
            )
            parsed["original_exhibition_source"] = (
                (existing_before.get("data") or {}).get("original_exhibition_source")
            )
            parsed["original_exhibition_status"] = "saved-official-fallback"
        # A missing/incomplete original-exhibition payload is a collection
        # failure from the app's point of view. Keep the legitimate
        # "measuring" state, but do not expose ambiguous "waiting" or
        # provider-specific "unavailable" labels to the UI/API.
        if (
            not self._original_exhibition_is_complete(
                parsed.get("original_exhibition") or [], scratch_lanes
            )
            and parsed.get("original_exhibition_status")
            in {"waiting", "unavailable", "not_provided"}
        ):
            parsed["original_exhibition_status"] = "collection_error"
        racers = parsed.get("racers") or []
        starts = parsed.get("start_display") or []
        weather = parsed.get("weather") or {}
        wf = sum(1 for v in weather.values() if v is not None and v != "")

        if not racers and not starts and wf == 0:
            raise ValueError("直前情報未発表または取得不可")

        payload = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        self.db.save_before_atomic(yyyymmdd, jcd, rno, payload)

        quality = self.db.before_snapshot_quality(
            yyyymmdd, jcd, rno
        )
        if not quality.get("meaningful"):
            raise RuntimeError("直前情報保存後のDB検証に失敗")

        return {
            "ok": True,
            "saved": True,
            "verified": True,
            "quality": quality,
            "data": payload,
        }

    def get_before_info(self, yyyymmdd: str, jcd: str, rno: int):
        """
        直前情報専用。出走表には一切触れない。
        未発表ならDB保存しない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/beforeinfo?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        html = self._get(url, ttl=75)
        parsed = parse_before_info(html)

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        weather = data.get("weather") or {}
        has_weather = any(v is not None for v in weather.values())
        racers = data.get("racers") or []
        starts = data.get("start_display") or []

        published = bool(racers) or bool(starts) or has_weather

        if published:
            self.db.save_snapshot(yyyymmdd, jcd, rno, "beforeinfo", data)

        return data

    def get_odds3t(self, yyyymmdd: str, jcd: str, rno: int):
        """
        3連単オッズ専用。120通り揃った場合のみDB保存。
        出走表・直前情報には一切触れない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/odds3t?jcd={jcd}&hd={yyyymmdd}&rno={rno}"
        html = self._get(url, ttl=40)
        parsed = parse_odds3t(html)

        data = {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "source_url": url,
            **parsed,
        }

        odds = data.get("odds") or []
        if len(odds) == 120:
            self.db.save_snapshot(yyyymmdd, jcd, rno, "odds3t", data)

        return data


    def fetch_results_atomic(self, yyyymmdd: str, jcd: str, requested_rno: int | None = None):
        """
        One venue result-list fetch:
          fresh official resultlist
          -> parse 1R-12R
          -> keep confirmed rows only
          -> save all confirmed rows
          -> DB readback verification
        """
        jcd = str(jcd).zfill(2)
        url = (
            f"{BASE}/owpc/pc/race/resultlist"
            f"?jcd={jcd}&hd={yyyymmdd}"
        )

        html = self._get(
            url,
            ttl=0,
            fresh=True,
            diagnostic_label=f"{jcd} resultlist",
        )

        # Save the official result-list immediately.  Per-race detail pages
        # (popularity / winning method) are fetched lazily only when needed.
        # This avoids waiting for up to twelve extra requests before a result
        # appears in the app.
        parsed = parse_result_list(html)

        # If a later race is already official but an earlier race is missing
        # from the venue list parser (for example 8R,10R are present but 9R is
        # absent), recover only that hole from the official per-race page.
        parsed_by_rno = {int(x.get("rno") or 0): x for x in parsed}
        confirmed_numbers = [
            rno for rno, row in parsed_by_rno.items()
            if row.get("trifecta") and row.get("payout_yen") is not None
        ]
        recovery_end = max(confirmed_numbers + ([int(requested_rno)] if requested_rno else []), default=0)
        if recovery_end:
            for missing_rno in range(1, recovery_end + 1):
                row = parsed_by_rno.get(missing_rno) or {}
                if row.get("trifecta") and row.get("payout_yen") is not None:
                    continue
                detail_url = (
                    f"{BASE}/owpc/pc/race/raceresult"
                    f"?rno={missing_rno}&jcd={jcd}&hd={yyyymmdd}"
                )
                try:
                    detail_html = self._get(
                        detail_url, ttl=0, fresh=True,
                        diagnostic_label=f"{jcd} {missing_rno}R result-hole",
                    )
                    recovered = parse_result_detail(detail_html, missing_rno)
                    if (
                        recovered.get("trifecta") and recovered.get("payout_yen") is not None
                    ) or recovered.get("result_confirmed"):
                        recovered["recovered_from_detail"] = True
                        recovered["detail_source_url"] = detail_url
                        parsed_by_rno[missing_rno] = recovered
                except Exception:
                    # Keep the venue loop alive; the same hole is retried in 20s.
                    pass
        parsed = [parsed_by_rno[x] for x in sorted(parsed_by_rno) if x]

        confirmed = []
        for row in parsed:
            if (
                row.get("trifecta")
                and row.get("payout_yen") is not None
            ) or row.get("result_confirmed"):
                confirmed.append(row)

        if confirmed:
            # v17.178: result-list confirms the race; immediately fetch the
            # official per-race result detail once so actual entry course and
            # race ST are saved together with the result. Existing complete
            # details are reused, so later 20-second polls do not re-fetch them.
            confirmed = self._enrich_result_details(yyyymmdd, jcd, confirmed)
            self.db.save_results(
                yyyymmdd,
                jcd,
                confirmed,
            )
            for item in confirmed:
                self.db.merge_result_into_meeting_snapshots(yyyymmdd, jcd, item)
            self.db.sync_trial_racer_tracker(yyyymmdd, jcd, confirmed)

        saved_keys = self.db.get_result_complete_keys(
            yyyymmdd
        )
        venue_saved = sorted(
            rno for code, rno in saved_keys
            if str(code).zfill(2) == jcd
        )

        # Every confirmed parsed row must exist after save.
        parsed_rnos = sorted(
            int(x["rno"]) for x in confirmed
        )

        missing = [
            rno for rno in parsed_rnos
            if rno not in venue_saved
        ]

        if missing:
            raise RuntimeError(
                f"結果保存後検証失敗 missing={missing}"
            )

        return {
            "ok": True,
            "date": yyyymmdd,
            "jcd": jcd,
            "confirmed_count": len(venue_saved),
            "confirmed_rnos": venue_saved,
            "parsed_confirmed_count": len(confirmed),
            "source_url": url,
        }

    def get_results(self, yyyymmdd: str, jcd: str):
        """
        結果専用。確定条件を満たす結果だけ保存。
        出走表/直前/オッズには一切触れない。
        """
        jcd = str(jcd).zfill(2)
        url = f"{BASE}/owpc/pc/race/resultlist?jcd={jcd}&hd={yyyymmdd}"
        # Every collector retry must consult the official list again.  A 90s
        # HTML cache here delayed a scheduled 30-second retry in practice.
        html = self._get(url, ttl=0, fresh=True, diagnostic_label=f"{jcd} resultlist")
        # Result visibility must not wait for detail-page enrichment.
        parsed = parse_result_list(html)

        confirmed = []
        for row in parsed:
            trifecta = row.get("trifecta")
            payout = row.get("payout_yen")
            if trifecta and payout:
                confirmed.append(row)

        if confirmed:
            confirmed = self._enrich_result_details(yyyymmdd, jcd, confirmed)
            self.db.save_results(yyyymmdd, jcd, confirmed)
            for item in confirmed:
                self.db.merge_result_into_meeting_snapshots(yyyymmdd, jcd, item)
            self.db.sync_trial_racer_tracker(yyyymmdd, jcd, confirmed)

        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "source_url": url,
            "results": confirmed,
        }

    def _enrich_result_details(self, yyyymmdd: str, jcd: str, rows: list[dict]):
        """Add official popularity and winning method from per-race pages."""
        enriched = []
        for row in rows:
            item = dict(row)
            rno = int(item.get("rno") or 0)
            existing = self.db.get_result_for_race_db(yyyymmdd, jcd, rno)
            if existing:
                for key in (
                    "popularity", "odds", "kimarite", "finishers",
                    "start_courses", "event_grade", "event_title", "race_name",
                ):
                    if item.get(key) is None and existing.get(key) is not None:
                        item[key] = existing.get(key)

            enriched.append(item)

        pending = [
            (index, item) for index, item in enumerate(enriched)
            if (
                item.get("popularity") is None
                or item.get("kimarite") is None
                or len(item.get("finishers") or []) < 6
                or len(item.get("start_courses") or []) < 6
            )
        ]

        def fetch_detail(index, item):
            rno = int(item["rno"])
            url = (
                f"{BASE}/owpc/pc/race/raceresult"
                f"?rno={rno}&jcd={str(jcd).zfill(2)}&hd={yyyymmdd}"
            )
            detail_html = self._get(url, ttl=21600)
            return index, url, parse_result_detail(detail_html, rno)

        if pending:
            with ThreadPoolExecutor(max_workers=min(4, len(pending))) as pool:
                futures = [pool.submit(fetch_detail, index, item) for index, item in pending]
                for future in as_completed(futures):
                    try:
                        index, url, detail = future.result()
                    except Exception:
                        # The venue-level confirmed result remains valid. A
                        # later poll retries only the missing detail fields.
                        continue
                    item = enriched[index]
                    if detail.get("trifecta") != item.get("trifecta"):
                        continue
                    for key in (
                        "popularity", "odds", "kimarite", "finishers",
                        "start_courses", "event_grade", "event_title", "race_name",
                    ):
                        if detail.get(key) is not None:
                            item[key] = detail[key]
                    item["detail_source_url"] = url
        return enriched

    def get_saved_result_detail(self, yyyymmdd: str, jcd: str, rno: int):
        """Read a saved result and lazily fill official detail fields."""
        jcd = str(jcd).zfill(2)
        existing = self.db.get_result_for_race_db(yyyymmdd, jcd, rno)
        if not existing or not existing.get("trifecta"):
            return existing
        if (
            existing.get("popularity") is not None
            and existing.get("kimarite")
            and len(existing.get("finishers") or []) >= 6
            and len(existing.get("start_courses") or []) >= 6
        ):
            return existing
        row = {**existing, "rno": int(rno)}
        enriched = self._enrich_result_details(yyyymmdd, jcd, [row])[0]
        self.db.save_results(yyyymmdd, jcd, [enriched])
        self.db.sync_trial_racer_tracker(yyyymmdd, jcd, [enriched])
        return self.db.get_result_for_race_db(yyyymmdd, jcd, rno)


    def get_result_for_race(self, yyyymmdd: str, jcd: str, rno: int):
        """
        Confirm one race result.
        The official result-list page is venue-level, so fetch it once,
        then return only the requested R.

        Final/confirmed condition:
        - requested rno exists
        - trifecta exists
        - payout_yen exists
        """
        data = self.get_results(yyyymmdd, jcd)
        rows = data.get("results") or []

        target = next(
            (row for row in rows if int(row.get("rno", 0)) == int(rno)),
            None
        )

        confirmed = bool(
            target
            and target.get("trifecta")
            and target.get("payout_yen")
        )

        return {
            "date": yyyymmdd,
            "jcd": str(jcd).zfill(2),
            "rno": int(rno),
            "confirmed": confirmed,
            "result": target,
        }

    def get_bundle(self, yyyymmdd: str, jcd: str, rno: int, include_odds=True):
        race = self.get_race(yyyymmdd, jcd, rno)
        self._attach_local_frame_stats(yyyymmdd, jcd, race)
        data = {
            "race": race,
            "before": self.get_before_info(yyyymmdd, jcd, rno),
        }
        if include_odds:
            data["odds3t"] = self.get_odds3t(yyyymmdd, jcd, rno)
        return data

    def save_prediction(self, yyyymmdd: str, jcd: str, rno: int, data: dict):
        self.db.save_prediction(yyyymmdd, jcd, rno, data)
        return self.db.get_prediction(yyyymmdd, jcd, rno)

    def get_current_venue_profile(self, jcd: str):
        """
        Venue characteristics are reference data, not a frozen part of an old
        race prediction. Always rebuild this display profile from the latest
        saved venue documents.
        """
        jcd = str(jcd).zfill(2)
        docs = self.db.get_venue_knowledge_text(jcd, 600)
        profile = build_venue_profile(docs, jcd)
        profile["jcd"] = jcd
        return profile

    def get_prediction(self, yyyymmdd: str, jcd: str, rno: int):
        pred = self.db.get_prediction(
            yyyymmdd, str(jcd).zfill(2), rno
        )
        if not pred:
            return pred

        # Old prediction rows may contain an old venue-profile message.
        # Keep the historical race prediction itself, but replace only the
        # venue-reference display with the latest saved material.
        snap = dict(pred.get("source_snapshot") or {})
        snap["venue_profile"] = self.get_current_venue_profile(jcd)
        pred["source_snapshot"] = snap
        return pred

    def save_comments(self, yyyymmdd: str, jcd: str, rno: int, comments: list[dict]):
        self.db.save_comments(yyyymmdd, jcd, rno, comments)
        return self.db.get_comments(yyyymmdd, jcd, rno)

    def get_comments(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.get_comments(yyyymmdd, jcd, rno)

    def compare(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.compare_prediction(yyyymmdd, jcd, rno)

    def get_cached_bundle(self, yyyymmdd: str, jcd: str, rno: int):
        race = self.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
        before = self.db.get_snapshot(yyyymmdd, jcd, rno, "beforeinfo")
        odds = self.db.get_snapshot(yyyymmdd, jcd, rno, "odds3t")
        result = self.db.get_result_for_race_db(
            yyyymmdd, jcd, rno
        )

        race_data = race["data"] if race else None
        self._attach_local_frame_stats(yyyymmdd, jcd, race_data)

        # v17.172: enrich the UI's saved before-info with the already-saved tide
        # race context.  This is DB-only: opening the screen never triggers tide
        # or weather web collection.  It also keeps Stage 3/4 and the visible
        # pre-race panel on the exact same date/venue/race context.
        before_data = dict(before["data"] or {}) if before else None
        if before_data is not None:
            weather = dict(before_data.get("weather") or {})
            try:
                with self.db.connect() as con:
                    tr = con.execute(
                        "SELECT context_json FROM tide_race_context WHERE date=? AND jcd=? AND rno=?",
                        (yyyymmdd, str(jcd).zfill(2), int(rno)),
                    ).fetchone()
                if tr and tr["context_json"]:
                    tc = json.loads(tr["context_json"])
                    weather["tide_phase"] = tc.get("tide_phase")
                    nh = tc.get("nearest_high") or {}
                    nl = tc.get("nearest_low") or {}
                    weather["high_tide_time"] = nh.get("time")
                    weather["low_tide_time"] = nl.get("time")
                    weather["estimated_tide_level_cm"] = tc.get("estimated_level_cm")
                    wc = tc.get("water_condition") or {}
                    # Stage 3 may have derived the relative class from a saved
                    # direction. Surface that same result in the UI.
                    if not weather.get("wind_relation") and wc.get("wind_course_type"):
                        weather["wind_relation"] = wc.get("wind_course_type")
                    before_data["tide_race_context"] = tc
            except Exception:
                pass
            before_data["weather"] = weather
        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": rno,
            "race": race_data,
            "before": before_data,
            "odds3t": odds["data"] if odds else None,
            "result": result,
            "captured_at": {
                "race": race["captured_at"] if race else None,
                "before": before["captured_at"] if before else None,
                "odds3t": odds["captured_at"] if odds else None,
                "result": result.get("updated_at") if result else None,
            }
        }

    def _attach_local_frame_stats(self, yyyymmdd: str, jcd: str, race_data):
        """Attach historical local-frame figures without rewriting snapshots."""
        if not isinstance(race_data, dict):
            return race_data
        racers = race_data.get("racers") or []
        valid_racers = [x for x in racers if _safe_lane(x.get("lane")) is not None]
        self.db.save_racer_profiles_from_racelist(yyyymmdd, valid_racers)
        # PRE prediction uses the current official racelist values.  Keep a
        # immutable racelist snapshot as the audit/history source while the
        # richer official course data follows its separate six-month policy.
        self.db.save_monthly_official_racer_data(yyyymmdd, valid_racers)
        signature = tuple(sorted(
            (str(x.get("registration_no") or ""), _safe_lane(x.get("lane")))
            for x in valid_racers
        ))
        cache_key = (yyyymmdd, str(jcd).zfill(2), signature)
        stats = self._local_frame_stats_cache.get(cache_key)
        if stats is None:
            stats = self.db.get_local_frame_stats(
                yyyymmdd, str(jcd).zfill(2), valid_racers
            )
            if len(self._local_frame_stats_cache) > 2000:
                self._local_frame_stats_cache.clear()
            self._local_frame_stats_cache[cache_key] = stats
        for racer in racers:
            lane = _safe_lane(racer.get("lane"))
            if lane is None:
                racer["local_frame_stats"] = None
                continue
            key = (
                str(racer.get("registration_no") or ""),
                lane,
            )
            racer["local_frame_stats"] = stats.get(key)
        registrations = tuple(sorted(
            str(x.get("registration_no") or "") for x in racers
            if x.get("registration_no")
        ))
        course_cache_key = (yyyymmdd, registrations)
        course_stats = self._racer_course_stats_cache.get(course_cache_key)
        if course_stats is None:
            course_stats = self.db.get_racer_course_stats(yyyymmdd, valid_racers)
            if len(self._racer_course_stats_cache) > 2000:
                self._racer_course_stats_cache.clear()
            self._racer_course_stats_cache[course_cache_key] = course_stats
        # v17.180: nationwide/local recent-course history is collected, saved
        # and displayed only.  It is deliberately NOT attached to AI input yet.
        # AI integration will be implemented as the next separate step after
        # collection/reflect/save is verified in production.
        for racer in racers:
            reg = str(racer.get("registration_no") or "")
            player = self.db.get_racer_public_data(reg) if reg else {}
            official_block = player.get("official_data") or {}
            official_data = official_block.get("data")
            official_courses = (official_data or {}).get("course_stats") or []
            if official_courses:
                racer["course_stats"] = {str(x.get("course")): {**x, "source": "official-racersearch-course"} for x in official_courses}
                racer["official_course_stats_updated"] = official_block.get("month")
                continue
            # v17.271: official racer-search is the only source of course
            # rates.  Do not rebuild rates from this app's saved race history.
            # While a legacy official snapshot is being upgraded, preserve only
            # its official course-average ST values.
            fallback = {}
            for course, avg_st in (player.get("legacy_course_st") or {}).items():
                fallback.setdefault(str(course), {})["avg_st"] = avg_st
                fallback[str(course)]["source"] = "official-racersearch-course-st-legacy"
            racer["course_stats"] = fallback
        return race_data

    def get_local_frame_history(self, yyyymmdd: str, jcd: str, rno: int):
        jcd = str(jcd).zfill(2)
        snap = self.db.get_snapshot(yyyymmdd, jcd, int(rno), "racelist")
        race = (snap or {}).get("data") or {}
        racers = race.get("racers") or []
        data = self.db.get_local_frame_history(yyyymmdd, jcd, racers, 10)
        pending = data.get("missing_details") or []
        if pending:
            with ThreadPoolExecutor(max_workers=min(4, len(pending))) as pool:
                futures = [
                    pool.submit(self.get_saved_result_detail, x["date"], jcd, x["rno"])
                    for x in pending[:60]
                ]
                for future in as_completed(futures):
                    try:
                        future.result()
                    except Exception:
                        pass
            data = self.db.get_local_frame_history(yyyymmdd, jcd, racers, 10)
        data.update({"date": yyyymmdd, "jcd": jcd, "rno": int(rno)})
        return data

    def get_course_history_for_race(self, yyyymmdd: str, jcd: str, rno: int):
        """Nationwide + current-venue recent runs for the actual expected entry course."""
        jcd = str(jcd).zfill(2)
        snap = self.db.get_snapshot(yyyymmdd, jcd, int(rno), "racelist")
        race = (snap or {}).get("data") or {}
        racers = race.get("racers") or []
        before = self.db.get_snapshot(yyyymmdd, jcd, int(rno), "beforeinfo")
        starts = ((before or {}).get("data") or {}).get("start_display") or []
        course_by_lane = {}
        for x in starts:
            try:
                lane, course = int(x.get("lane") or 0), int(x.get("course") or 0)
            except (TypeError, ValueError):
                continue
            if 1 <= lane <= 6 and 1 <= course <= 6 and not x.get("entry_inferred"):
                course_by_lane[lane] = course
        return {
            "date": yyyymmdd, "jcd": jcd, "rno": int(rno),
            "racers": self.db.get_race_course_histories(yyyymmdd, jcd, racers, course_by_lane),
            "entry_source": "start_exhibition" if course_by_lane else "frame_assumption",
            "backfill": self.db.get_course_history_backfill_state(),
        }

    def get_day_racelists(self, yyyymmdd: str):
        rows = self.db.get_day_snapshots(yyyymmdd, "racelist")
        return {"date": yyyymmdd, "count": len(rows), "races": rows}

    def get_venue_racelists(self, yyyymmdd: str, jcd: str):
        jcd = str(jcd).zfill(2)
        races = self.db.get_venue_racelists(yyyymmdd, jcd)
        return {"date": yyyymmdd, "jcd": jcd, "count": len(races), "races": races}


    def build_ai_prediction(
        self, yyyymmdd: str, jcd: str, rno: int,
        mode: str = "balanced", save: bool = False, preview: bool = False
    ):
        jcd = str(jcd).zfill(2)
        existing = self.db.get_prediction(yyyymmdd, jcd, rno)
        deadline = next((x.get("deadline") for x in self.db.get_race_schedule(yyyymmdd, jcd)
                         if int(x["rno"]) == int(rno)), None)
        cutoff = None
        if deadline:
            try:
                cutoff = datetime.strptime(yyyymmdd + " " + deadline, "%Y%m%d %H:%M").replace(tzinfo=timezone(timedelta(hours=9)))
            except ValueError:
                pass
        if save and (cutoff is None or datetime.now(timezone.utc) >= cutoff or
                     self.db.get_result_for_race_db(yyyymmdd, jcd, rno)):
            if existing:
                return existing
            return {"source_snapshot": {}, "main_picks": [], "judgement": "締切前の保存なし"}
        bundle = self.get_cached_bundle(yyyymmdd, jcd, rno)
        docs = self.db.get_venue_knowledge_text(jcd, 300)
        insight = self.db.get_user_insight(yyyymmdd, jcd, rno)
        day_venue_trend = self.db.get_today_venue_tendency(
            yyyymmdd, jcd, rno
        )
        from prediction_learning import feedback_before
        learning_feedback = feedback_before(self.db, yyyymmdd, jcd, rno)
        tilt_performance = self.db.get_tilt_outcome_stats(yyyymmdd)

        # v17.171 Stage 4. Build/read the saved diagnostic context only; this
        # never performs a web tide fetch and therefore cannot block AI on a
        # provider failure.  Before-info weather is already persisted.
        water_condition = None
        try:
            tide = TideCollector(self.db)
            tide.build_race_contexts(yyyymmdd, jcd)
            with self.db.connect() as con:
                row = con.execute(
                    "SELECT context_json FROM tide_race_context WHERE date=? AND jcd=? AND rno=?",
                    (yyyymmdd, jcd, int(rno)),
                ).fetchone()
            if row and row["context_json"]:
                water_ctx = json.loads(row["context_json"])
                water_condition = (water_ctx or {}).get("water_condition")
            if water_condition is None:
                # Tide-OFF venues still use saved wind evidence.  Tide-enabled
                # venues with a temporary tide gap also keep wind-only scoring
                # rather than inventing a tide value.
                water_condition = tide._water_condition({
                    "date": yyyymmdd, "jcd": jcd, "rno": int(rno),
                    "tide_phase": None,
                })
                water_condition["source"] = "saved beforeinfo (wind-only; tide unavailable/off)"
        except Exception:
            # Water data is optional evidence. Prediction must continue safely.
            water_condition = None

        data = ai_predict(
            yyyymmdd, jcd, rno,
            bundle.get("race"),
            bundle.get("before"),
            bundle.get("odds3t"),
            docs,
            mode=mode,
            preview=preview,
            user_insight=(insight or {}).get("note") or "",
            day_venue_trend=day_venue_trend,
            learning_feedback=learning_feedback,
            tilt_performance=tilt_performance,
            water_condition=water_condition,
        )

        if save:
            # Calculation may cross the deadline; recheck immediately before saving.
            if datetime.now(timezone.utc) >= cutoff:
                return existing or {"source_snapshot": {}, "main_picks": [], "judgement": "締切前の保存なし"}
            snap = data["source_snapshot"]
            snap.setdefault("generated_at", datetime.now(timezone(timedelta(hours=9))).isoformat())
            old = (existing or {}).get("source_snapshot") or {}
            preserve_pre = bool((old.get("pre_prediction") or {}).get("picks")) and len((snap.get("pre_prediction") or {}).get("missing", [])) >= len((old.get("pre_prediction") or {}).get("missing", []))
            if preserve_pre:
                # Preserve the saved PRE score and picks; add current odds strategies to
                # these original PRE scores, without using later meeting/result inputs.
                from ai_predictor import _combo_list, _extract_odds, strategy_options
                pre = old["pre_prediction"]
                scores = {}
                for k, x in (pre.get("lane_scores", {}) or {}).items():
                    lane = _safe_lane(k)
                    if lane is not None and isinstance(x, dict):
                        scores[lane] = x.get("score")
                racers = (bundle.get("race") or {}).get("racers", [])
                active = [lane for x in racers if (lane := _safe_lane(x.get("lane"))) is not None
                          and not x.get("scratched") and x.get("status") != "欠場"]
                scores = {k: v for k, v in scores.items() if k in active}
                if len(scores) >= 3:
                    race_map = {lane: x for x in racers if (lane := _safe_lane(x.get("lane"))) is not None}
                    _, candidates = _combo_list(
                        scores, list(scores), _extract_odds(bundle.get("odds3t")),
                        venue_profile=old.get("venue_profile") or snap.get("venue_profile"),
                        race_map=race_map,
                        day_venue_trend=old.get("day_venue_trend") or {},
                    )
                    pre["strategies"] = strategy_options(candidates)
                    pre["strategies_saved_at"] = snap["generated_at"]
                snap["pre_prediction"] = pre
            snap["pre_saved_at"] = (old.get("pre_saved_at") or old.get("generated_at") or snap["generated_at"]) if preserve_pre else snap["generated_at"]
            snap["saved_before_deadline"] = True
            self.db.save_prediction(yyyymmdd, jcd, rno, data)
            return self.db.get_prediction(yyyymmdd, jcd, rno)

        return {
            "date": yyyymmdd,
            "jcd": jcd,
            "rno": int(rno),
            **data,
        }

    def refresh_prediction_odds(self, yyyymmdd: str, jcd: str, rno: int):
        """Replace displayed odds after the deadline without changing picks."""
        from ai_predictor import _extract_odds

        pred = self.db.get_prediction(yyyymmdd, str(jcd).zfill(2), int(rno))
        odds_snap = self.db.get_snapshot(yyyymmdd, str(jcd).zfill(2), int(rno), "odds3t")
        if not pred or not odds_snap:
            return {"ok": False, "reason": "予想または最終オッズ未保存"}
        odds_map = _extract_odds((odds_snap or {}).get("data") or {})
        if not odds_map:
            return {"ok": False, "reason": "最終オッズが空"}

        def update_rows(rows):
            for row in rows or []:
                if isinstance(row, dict) and row.get("combo") in odds_map:
                    row["odds"] = odds_map[row["combo"]]

        snap = pred.get("source_snapshot") or {}
        for stage_name in ("pre_prediction", "post_prediction"):
            stage = snap.get(stage_name) or {}
            update_rows(stage.get("picks"))
            for option in (stage.get("strategies") or {}).values():
                picks = option.get("picks") or []
                update_rows(picks)
                valid = [float(x["odds"]) for x in picks if isinstance(x.get("odds"), (int, float)) and x["odds"] > 0]
                option["synthetic_odds"] = (
                    1 / sum(1 / x for x in valid)
                    if valid and len(valid) == len(picks) else None
                )
            stage["final_odds_reflected"] = True
            stage["final_odds_captured_at"] = (odds_snap or {}).get("captured_at")
        update_rows(pred.get("main_picks"))
        update_rows(pred.get("value_picks"))
        snap["final_odds_reflected"] = True
        snap["final_odds_captured_at"] = (odds_snap or {}).get("captured_at")
        pred["source_snapshot"] = snap
        self.db.update_prediction_final_odds(yyyymmdd, str(jcd).zfill(2), int(rno), pred)
        return {"ok": True, "count": len(odds_map), "captured_at": (odds_snap or {}).get("captured_at")}

    def prediction_summary(self, date: str | None = None):
        return self.db.prediction_summary(date)


    def get_race_revision(self, yyyymmdd: str, jcd: str, rno: int):
        return self.db.get_race_revision(
            yyyymmdd, str(jcd).zfill(2), rno
        )
