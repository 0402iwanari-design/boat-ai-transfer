"""Regression for official 2026 Amagasaki SG and generic-grade fallback."""
from boat_source import BoatRaceSource, VERIFIED_EVENT_GRADES
from parser import parse_day_venue_event_meta

DATES = ('20261027','20261028','20261029','20261030','20261031','20261101')
for date in DATES:
    assert VERIFIED_EVENT_GRADES[date]['13']['event_grade'] == 'SG'
    assert 'ボートレースダービー' in VERIFIED_EVENT_GRADES[date]['13']['event_title']
for date in ('20261026', '20261102', '20271028'):
    assert '13' not in VERIFIED_EVENT_GRADES.get(date, {})
for date in DATES:
    assert '12' not in VERIFIED_EVENT_GRADES[date]
    assert '14' not in VERIFIED_EVENT_GRADES[date]

class FakeDB:
    def __init__(self): self.entries = {}
    def replace_venue_event_meta_from_daily_index(self, date, code, grade, title):
        if grade is None: return False
        self.entries[(date,code)] = (grade, title)
        return True

obj = BoatRaceSource.__new__(BoatRaceSource)
obj.db = FakeDB()
obj._get_day_event_meta = lambda date: {'_index_available': False}
for date in DATES:
    assert obj.refresh_day_event_meta_from_official_index(date) == 1
    assert obj.db.entries[(date,'13')][0] == 'SG'
assert obj.refresh_day_event_meta_from_official_index('20261102') == 0

# Even an erroneous general-grade result from the index cannot override
# the verified SG at venue 13; other venues retain their independent grades.
obj._get_day_event_meta = lambda date: {
    '_index_available': True,
    '13': {'event_grade':'一般戦','event_title':'予選'},
    '12': {'event_grade':'一般戦','event_title':'一般競走'},
}
assert obj.refresh_day_event_meta_from_official_index('20261028') == 2
assert obj.db.entries[('20261028','13')][0] == 'SG'
assert obj.db.entries[('20261028','12')][0] == '一般戦'

# Generic title markup still resolves as SG when the page spells it out.
html = '<div class="heading2_title"><span class="heading2_titleName">SG第73回ボートレースダービー</span></div>'
from parser import parse_venue_meta
assert parse_venue_meta(html)['event_grade'] == 'SG'
print('PASS v17.311 Amagasaki SG regressions')
