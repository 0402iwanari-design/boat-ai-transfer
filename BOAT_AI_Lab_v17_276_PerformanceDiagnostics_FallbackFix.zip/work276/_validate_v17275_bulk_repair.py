import tempfile, types
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from db import BoatDB
from boat_source import BoatRaceSource

DATE='20261008'
TOTALS={1:88.9,2:83.3,3:72.7,4:85.7,5:62.5,6:38.5}
PARTS={1:[77.8,5.6,5.6],2:[22.2,33.3,27.8],3:[18.2,36.4,18.2],4:[28.6,50.0,7.1],5:[25.0,12.5,25.0],6:[0.0,15.4,23.1]}

def payload(reg, complete):
    rows=[]
    for c in range(1,7):
        if complete:
            a,b,d=PARTS[c]
        else:
            a,b,d=None,None,None
        rows.append({'course':c,'first_rate':a,'second_rate':b,'third_rate':d,'trio_rate':TOTALS[c],'avg_st':0.14})
    return {'registration_no':reg,'name':reg,'course_stats_version':4,'course_breakdown_version':5,
            'course_breakdown_complete':complete,'profile':{'name':reg},'course_stats':rows}

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    # 10 entrants: two already fully colored, eight have v5 marker but no split.
    racers=[{'registration_no':str(5000+i),'name':str(5000+i)} for i in range(10)]
    db.save_basic_race_atomic(DATE,'12',1,{'racers':racers},'12:00','test')
    for i,r in enumerate(racers):
        db.save_official_racer_search_data(DATE,payload(r['registration_no'], i<2))
    pending=db.official_racer_collection_pending(DATE)
    ids={x['registration_no'] for x in pending}
    assert ids=={str(5000+i) for i in range(2,10)}, ids

    src=BoatRaceSource.__new__(BoatRaceSource)
    src.db=db
    src._racer_course_stats_cache={}
    def fake_fetch(self,reg,name=None):
        return payload(str(reg), True)
    src.fetch_official_racer_course_data=types.MethodType(fake_fetch,src)
    out=src.collect_today_official_racer_course_data(DATE)
    assert out['processed']==8, out
    pending2=db.official_racer_collection_pending(DATE)
    assert pending2==[], pending2
    for r in racers:
        d=db.get_racer_public_data(r['registration_no'])['official_data']['data']
        assert d['course_breakdown_complete'] is True
        assert all(all(row[k] is not None for k in ('first_rate','second_rate','third_rate')) for row in d['course_stats'])
print('PASS v17.275: v5-but-incomplete racers are bulk-requeued; complete racers are reused; after repair all six-course 3-color splits persist and queue is empty')
