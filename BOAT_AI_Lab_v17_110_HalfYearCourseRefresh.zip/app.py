from __future__ import annotations

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from boat_source import BoatRaceSource
from collector import BackgroundCollector
from venue_knowledge import VenueKnowledgeCollector
from virtual_bets import VirtualBetGame
from trial_backfill import MineInitialScan
import auto_deploy

app = FastAPI(title="BOAT AI Lab Backend", version="1.0.110")
# PCでの確認版（localhost）から、ConoHaに蓄積した共通の集計履歴を読めるようにする。
# 許可するのはローカル確認用のURLだけで、外部サイトからの読取りは許可しない。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

class PredictionPayload(BaseModel):
    confidence: float | None = None
    judgement: str | None = None
    scenario: str | None = None
    main_picks: list = []
    value_picks: list = []
    leaks: list = []
    source_snapshot: dict = {}
    ai_comment: str | None = None

class CommentItem(BaseModel):
    lane: int
    comment: str
    source: str | None = None

class CommentsPayload(BaseModel):
    comments: list[CommentItem]

class UserInsightPayload(BaseModel):
    note: str = ""

source = BoatRaceSource()
collector = BackgroundCollector(source)
knowledge_collector = VenueKnowledgeCollector(source.db)
game = VirtualBetGame(source.db)
mine_initial_scan = MineInitialScan(source)

class GameBetPayload(BaseModel):
    date: str
    jcd: str
    rno: int
    combo: str
    amount_yen: int
    odds: float

class GameBatchBetItem(BaseModel):
    combo: str
    amount_yen: int
    odds: float

class GameBatchBetPayload(BaseModel):
    date: str
    jcd: str
    rno: int
    bets: list[GameBatchBetItem]

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/api/deploy/status")
def deploy_status():
    """秘密の値は返さず、GitHub自動更新の準備状態だけを返す。"""
    status = {"configured": auto_deploy.configured(), "state": "not_started"}
    if auto_deploy.STATUS_FILE.is_file():
        try:
            status.update(__import__("json").loads(auto_deploy.STATUS_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return status


@app.post("/api/deploy/github")
async def github_deploy(request: Request, x_hub_signature_256: str | None = Header(default=None)):
    """GitHub push だけを、HMAC署名が一致した場合に限って受け付ける。"""
    payload = await request.body()
    if not auto_deploy.configured():
        raise HTTPException(503, "自動更新の初期設定がまだです")
    if not auto_deploy.verify_signature(payload, x_hub_signature_256):
        raise HTTPException(401, "GitHub署名を確認できません")
    if request.headers.get("x-github-event", "").lower() == "ping":
        return {"ok": True, "message": "GitHub連携を確認しました"}
    try:
        data = __import__("json").loads(payload.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "GitHubの送信内容を読めません")
    if request.headers.get("x-github-event", "").lower() != "push" or data.get("ref") != "refs/heads/main":
        return {"ok": True, "message": "mainブランチのZIP更新ではないため何もしません"}
    if not auto_deploy.queue_deploy():
        return {"ok": True, "message": "すでに更新処理中です"}
    return {"ok": True, "message": "自動更新を開始しました"}

@app.get("/")
def index():
    return FileResponse(
        "static/index.html",
        headers={"Cache-Control":"no-store, no-cache, must-revalidate, max-age=0"}
    )

@app.on_event("startup")
async def start_background_collector():
    collector.start()
    knowledge_collector.start()

@app.get("/api/background/status")
def background_status():
    return collector.status

@app.get("/api/venues")
def venues():
    return {"venues": source.venues}

@app.get("/api/day/{yyyymmdd}")
def day(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_fast(yyyymmdd)

@app.get("/api/day-status/{yyyymmdd}")
def day_status(yyyymmdd: str):
    validate_date(yyyymmdd)
    cached = source.cache.get(f"day_v16_{yyyymmdd}", 3600)
    return {
        "official_cached": bool(cached),
        "last_day_scan": collector.status.get("last_day_scan"),
        "collector_message": collector.status.get("last_message"),
    }

@app.get("/api/schedule/{yyyymmdd}/{jcd}")
def race_schedule(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return {
        "date": yyyymmdd,
        "jcd": jcd.zfill(2),
        "races": source.db.get_race_schedule(yyyymmdd, jcd.zfill(2)),
    }

@app.get("/api/race/{yyyymmdd}/{jcd}/{rno}")
def race(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_race(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/game-race/{yyyymmdd}/{jcd}/{rno}")
def game_race(yyyymmdd: str, jcd: str, rno: int):
    """Small DB-only payload for the virtual betting screen.

    It deliberately never fetches/rechecks the official racelist while a
    user is choosing odds, keeping the game screen responsive.
    """
    validate(yyyymmdd, rno)
    jcd = jcd.zfill(2)
    saved = source.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
    data = (saved or {}).get("data") or {}
    racers = data.get("racers") or []
    return {
        "date": yyyymmdd,
        "jcd": jcd,
        "rno": rno,
        "racers": [
            {"lane": row.get("lane"), "name": row.get("name")}
            for row in racers
        ],
    }

@app.get("/api/before/{yyyymmdd}/{jcd}/{rno}")
def before(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_before_info(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/odds3t/{yyyymmdd}/{jcd}/{rno}")
def odds3t(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_odds3t(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/game/{yyyymmdd}")
def game_dashboard(yyyymmdd: str):
    validate_date(yyyymmdd)
    return game.dashboard(yyyymmdd)

@app.post("/api/game/bet")
def game_bet(payload: GameBetPayload):
    validate_date(payload.date)
    try:
        return {"wallet": game.place(payload.date, payload.jcd, payload.rno, payload.combo, payload.amount_yen, payload.odds)}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/game/bets")
def game_bets(payload: GameBatchBetPayload):
    """Place a deduplicated set of virtual 3連単 bets in one operation."""
    validate_date(payload.date)
    try:
        rows = [x.model_dump() for x in payload.bets]
        return {"wallet": game.place_many(payload.date, payload.jcd, payload.rno, rows)}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/bundle/{yyyymmdd}/{jcd}/{rno}")
def bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/ui/{yyyymmdd}/{jcd}/{rno}")
def ui_bundle(yyyymmdd: str, jcd: str, rno: int):
    """
    フロント表示用。bundle をそのまま返す薄いエンドポイント。
    将来ここでAI予想・コメント等を統合する。
    """
    validate(yyyymmdd, rno)
    return source.get_bundle(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/cached/{yyyymmdd}/{jcd}/{rno}")
def cached_bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_cached_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/cached-day/{yyyymmdd}")
def cached_day_racelists(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_racelists(yyyymmdd)

@app.get("/api/results/{yyyymmdd}/{jcd}")
def results(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return source.get_results(yyyymmdd,jcd.zfill(2))

@app.get("/api/history/{jcd}")
def history(jcd: str, limit: int = 100):
    return {"rows": source.db.result_history(jcd.zfill(2), min(max(limit,1),1000))}



@app.get("/api/ai-preview/{yyyymmdd}/{jcd}/{rno}")
def ai_preview(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=False, preview=True,
    )

@app.post("/api/ai-generate/{yyyymmdd}/{jcd}/{rno}")
def ai_generate(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=True, preview=False,
    )


@app.post("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def save_prediction(yyyymmdd: str, jcd: str, rno: int, payload: PredictionPayload):
    validate(yyyymmdd,rno)
    return source.save_prediction(yyyymmdd,jcd.zfill(2),rno,payload.model_dump())

@app.get("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def get_prediction(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_prediction(yyyymmdd,jcd.zfill(2),rno)

@app.post("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def save_comments(yyyymmdd: str, jcd: str, rno: int, payload: CommentsPayload):
    validate(yyyymmdd,rno)
    return source.save_comments(
        yyyymmdd,jcd.zfill(2),rno,
        [x.model_dump() for x in payload.comments]
    )

@app.get("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def get_comments(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return {"comments": source.get_comments(yyyymmdd,jcd.zfill(2),rno)}

@app.get("/api/user-insight/{yyyymmdd}/{jcd}/{rno}")
def get_user_insight(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.db.get_user_insight(yyyymmdd, jcd.zfill(2), rno)

@app.post("/api/user-insight/{yyyymmdd}/{jcd}/{rno}")
def save_user_insight(yyyymmdd: str, jcd: str, rno: int, payload: UserInsightPayload):
    validate(yyyymmdd, rno)
    source.db.save_user_insight(yyyymmdd, jcd.zfill(2), rno, payload.note)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode="balanced", save=False, preview=True,
    )

@app.get("/api/compare/{yyyymmdd}/{jcd}/{rno}")
def compare_prediction_result(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.compare(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/prediction-summary")
def prediction_summary(date: str | None = None):
    return source.prediction_summary(date)


@app.get("/api/diagnostic/ohmura")
def diagnostic_ohmura():
    return {
        "errors": collector.status.get("ohmura_errors", []),
        "current_state": collector.status.get("current_state"),
        "current_kind": collector.status.get("current_kind"),
        "current_venue": collector.status.get("current_venue"),
        "current_rno": collector.status.get("current_rno"),
    }


@app.get("/api/revision/{yyyymmdd}/{jcd}/{rno}")
def race_revision(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_race_revision(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/venue-knowledge/status")
def venue_knowledge_status():
    return {
        **knowledge_collector.status,
        "db_summary": source.db.venue_knowledge_summary(),
        "venues": source.db.venue_knowledge_monitor(),
    }

@app.get("/api/venue-profile/{jcd}")
def venue_profile(jcd: str):
    return source.get_current_venue_profile(str(jcd).zfill(2))


@app.get("/api/venue-knowledge/{jcd}")
def venue_knowledge(jcd: str, limit: int = 500):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "sources": source.db.get_venue_knowledge(code, limit),
    }

@app.get("/api/venue-knowledge-text/{jcd}")
def venue_knowledge_text(jcd: str, limit: int = 300):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "documents": source.db.get_venue_knowledge_text(code, limit),
    }


@app.get("/api/health")
def health():
    return {"ok": True, "version": "1.0.67", "background": collector.status["running"]}

def validate_date(yyyymmdd: str):
    if len(yyyymmdd) != 8 or not yyyymmdd.isdigit():
        raise HTTPException(400,"日付はYYYYMMDD形式")

def validate(yyyymmdd: str, rno: int):
    validate_date(yyyymmdd)
    if not 1 <= rno <= 12:
        raise HTTPException(400,"rnoは1〜12")


@app.get("/api/ai-results/{yyyymmdd}")
def ai_results(yyyymmdd: str):
    validate_date(yyyymmdd)
    from review_results import build_review
    return build_review(source.db, yyyymmdd, source.venues)

@app.get("/api/ai-statistics/{yyyymmdd}")
def ai_statistics(yyyymmdd: str):
    validate_date(yyyymmdd)
    from review_statistics import build_statistics
    return build_statistics(source.db, yyyymmdd, source.venues)

@app.get("/api/result-detail/{yyyymmdd}/{jcd}/{rno}")
def result_detail(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_saved_result_detail(yyyymmdd, jcd.zfill(2), rno)

@app.get("/api/completion/{yyyymmdd}")
def completion(yyyymmdd: str):
    validate_date(yyyymmdd)
    return {"date": yyyymmdd, "completed": [list(x) for x in sorted(source.db.get_confirmed_result_races(yyyymmdd))]}

@app.get("/api/local-frame-history/{yyyymmdd}/{jcd}/{rno}")
def local_frame_history(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_local_frame_history(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/trial-racer/4320")
def trial_racer_mine():
    """Safe status endpoint for the 峰竜太-only collection trial."""
    return source.db.get_trial_racer_tracker("4320")

@app.get("/api/racer/{registration_no}")
def racer_data(registration_no: str):
    return source.db.get_racer_public_data(registration_no)

@app.get("/api/racer-collection-status/{yyyymmdd}")
def racer_collection_status(yyyymmdd: str):
    """Progress monitor only; never starts another collection pass."""
    validate_date(yyyymmdd)
    return source.db.get_daily_racer_collection_status(yyyymmdd)


@app.get("/api/trial-racer/4320/start")
def start_trial_racer_mine(days: int = 7):
    """Start the capped, one-racer initial scan from a browser link."""
    return mine_initial_scan.start(days)


@app.get("/api/trial-racer/4320/scan-status")
def trial_racer_mine_scan_status():
    return mine_initial_scan.status


@app.get("/api/official-coverage")
def official_coverage():
    return {"venues": knowledge_collector.coverage, "status": knowledge_collector.status}

@app.post("/api/official-rescan")
def official_rescan():
    return knowledge_collector.request_rescan()
