"""Result-based prediction review and bounded, leakage-safe feedback."""
from collections import Counter
from review_results import build_review


def _lane_rank(pred, actual):
    snap = (pred or {}).get("source_snapshot") or {}
    ranks = []
    for key, label in (("pre_prediction", "事前"), ("post_prediction", "直前")):
        stage = snap.get(key) or {}
        scores = stage.get("lane_scores") or {}
        ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
        rank = next((i + 1 for i, x in enumerate(ordered) if int(x.get("lane") or 0) == int(actual)), None)
        if rank:
            ranks.append({"stage": label, "rank": rank})
    return ranks


def analyze_race(db, date, code, venue, race):
    actual = race.get("actual")
    if not actual:
        return None
    pred = db.get_prediction(date, code, race["rno"]) or {}
    hits = race.get("ai_hits") or []
    first = int(actual.split("-")[0])
    ranks = _lane_rank(pred, first)
    best_rank = min((x["rank"] for x in ranks), default=None)
    evaluated = [x for x in race.get("stages", []) if x.get("evaluated")]
    all_picks = {p for x in evaluated for p in x.get("picks", [])}
    if hits:
        category = "的中"
        analysis = "確定出目を締切前の買い目に含められました。"
    elif actual in all_picks:
        category = "買い目選択漏れ"
        analysis = "確定出目は候補内にありましたが、最終的な買い方から漏れました。"
    elif best_rank is not None and best_rank <= 2:
        category = "相手構成漏れ"
        analysis = "1着艇は上位評価できていましたが、2・3着の組み合わせを拾えませんでした。"
    else:
        category = "1着評価不足"
        analysis = f"実際の1着・{first}号艇を十分高く評価できませんでした。"
    kimarite = race.get("kimarite") or "不明"
    lesson = {
        "逃げ": "1コース本人実績と当日イン状況の重みを再確認",
        "差し": "2コース差しと内側のST差を再確認",
        "まくり": "外側のST・チルト・攻め実績を再確認",
        "まくり差し": "3〜6コースの攻め足と展開相手を再確認",
    }.get(kimarite, "着順別評価と組み合わせ範囲を再確認")
    return {
        "date": date, "jcd": code, "venue": venue, "rno": race["rno"],
        "actual": actual, "odds": race.get("result_odds"),
        "popularity": race.get("popularity"), "kimarite": kimarite,
        "hit": bool(hits), "hit_methods": hits, "category": category,
        "analysis": analysis, "lesson": lesson, "first_lane": first,
        "first_lane_ranks": ranks, "evaluated_methods": len(evaluated),
    }


def build_learning_report(db, date, venues):
    review = build_review(db, date, venues)
    rows = []
    for venue in review.get("venues", []):
        for race in venue.get("races", []):
            item = analyze_race(db, date, venue["code"], venue["name"], race)
            if item:
                rows.append(item)
    categories = Counter(x["category"] for x in rows)
    misses = [x for x in rows if not x["hit"]]
    return {
        "date": date, "summary": {"analyzed": len(rows), "hits": len(rows)-len(misses),
        "misses": len(misses), "categories": dict(categories)},
        "records": sorted(rows, key=lambda x: (x["jcd"], x["rno"])),
        "policy": "予想時点より前に確定した結果だけを使い、十分な件数がある傾向のみ小幅補正します。",
    }


def feedback_before(db, date, jcd, rno):
    """Aggregate only earlier confirmed races. Never reads a future result."""
    with db.connect() as con:
        rows = con.execute("""
          SELECT rr.date,rr.jcd,rr.rno,rr.trifecta,rr.kimarite,p.source_snapshot
          FROM race_results rr JOIN predictions p
            ON p.date=rr.date AND p.jcd=rr.jcd AND p.rno=rr.rno
          WHERE rr.trifecta IS NOT NULL AND
            (rr.date < ? OR (rr.date=? AND rr.jcd=? AND rr.rno < ?))
          ORDER BY rr.date DESC,rr.rno DESC LIMIT 120
        """, (date,date,str(jcd).zfill(2),int(rno))).fetchall()
    misses = Counter(); selection = 0; total = 0
    import json, re
    for row in rows:
        nums = re.findall(r"[1-6]", str(row["trifecta"] or ""))
        if len(nums) != 3: continue
        total += 1; first = int(nums[0])
        try: snap = json.loads(row["source_snapshot"] or "{}")
        except Exception: snap = {}
        stage = snap.get("post_prediction") or snap.get("pre_prediction") or {}
        picks = {str(x.get("combo") if isinstance(x,dict) else x) for x in stage.get("picks", [])}
        if "-".join(nums) not in picks:
            scores = stage.get("lane_scores") or {}
            ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
            rank = next((i+1 for i,x in enumerate(ordered) if int(x.get("lane") or 0)==first), 9)
            if rank <= 2: selection += 1
            else: misses[first] += 1
    if total < 8:
        return {"sample_size": total, "score_adjustments": {}, "coverage_bonus": 0, "active": False}
    adjustments = {lane: round(min(1.5, count / total * 5), 2) for lane,count in misses.items() if count >= 2}
    return {"sample_size": total, "score_adjustments": adjustments,
            "coverage_bonus": round(min(.08, selection / total * .12), 3), "active": bool(adjustments or selection >= 2)}
