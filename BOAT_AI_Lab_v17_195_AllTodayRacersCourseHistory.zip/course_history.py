from __future__ import annotations
"""v17.195 本日出走選手全員・年別全出走データ直接取得。

当日の出走表にいる選手だけを対象に、全国＋その選手が本日出走する当地を収集。
各 scope×実進入コースは直近10走で終了し、足りない場合だけ年を遡る。
2023年まで確認して10走未満/0走なら正常完了。取得済み選手は再収集しない。
"""
import re, threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup

JST=ZoneInfo('Asia/Tokyo'); FLOOR_YEAR=2023; FLOOR='20230101'
VENUES=['桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村']
VENUE_CODE={n:f'{i:02d}' for i,n in enumerate(VENUES,1)}
def _norm(s): return re.sub(r'[\s\u3000]+','',str(s or ''))
def _venue_code(s):
    n=_norm(s)
    return next((code for name,code in VENUE_CODE.items() if _norm(name)==n),None)
def _date_token(s,year):
    m=re.search(r'(\d{1,2})/(\d{1,2})',str(s or '')); return f'{year}{int(m.group(1)):02d}{int(m.group(2)):02d}' if m else None
def _race_token(s):
    m=re.fullmatch(r'\s*(\d{1,2})R\s*',str(s or '')); return int(m.group(1)) if m else None
def _st_token(s):
    t=_norm(s); return t if re.fullmatch(r'[FL]?\.?\d{1,2}',t) else None
def _rank_token(s):
    m=re.fullmatch(r'\(?([1-6])\)?',_norm(s)); return int(m.group(1)) if m else None
def _finish_token(s):
    t=_norm(s).replace('着',''); return t if re.fullmatch(r'[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠',t) else None

class OfficialCourseHistoryCollector:
    def __init__(self,db):
        self.db=db; self._thread=None; self._stop=threading.Event(); self.status={'phase':'本日の出走表待ち','validation_mode':'本日出走選手全員'}
    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,daemon=True,name='today-racers-yearly-history'); self._thread.start()
    def _scheduler(self):
        while not self._stop.is_set():
            today=datetime.now(JST).strftime('%Y%m%d')
            try:self._run(today)
            except Exception as e:
                self.status={**self.db.get_course_history_target_status(today),'phase':'収集処理エラー','scheduler_error':f'{type(e).__name__}: {e}','validation_mode':'本日出走選手全員'}
            self._stop.wait(10)
    def _counts(self,reg,jcd):
        with self.db.connect() as con:
            n=con.execute('SELECT course,COUNT(*) n FROM racer_course_runs WHERE registration_no=? AND date>=? GROUP BY course',(reg,FLOOR)).fetchall()
            l=con.execute('SELECT course,COUNT(*) n FROM racer_course_runs WHERE registration_no=? AND jcd=? AND date>=? GROUP BY course',(reg,jcd,FLOOR)).fetchall()
        return ({int(x['course']):min(10,int(x['n'])) for x in n},{int(x['course']):min(10,int(x['n'])) for x in l})
    def _done(self,nm,lm): return all(nm.get(c,0)>=10 and lm.get(c,0)>=10 for c in range(1,7))
    def _parse_year(self,html,year,reg):
        soup=BeautifulSoup(html,'html.parser'); out=[]
        for table in soup.find_all('table'):
            rows=[]
            for tr in table.find_all('tr'):
                cells=[' '.join(x.stripped_strings) for x in tr.find_all(['th','td'])]
                if cells: rows.append(cells)
            if not rows: continue
            jcd=None
            for row in rows:
                for c in row:
                    jcd=_venue_code(c)
                    if jcd: break
                if jcd: break
            if not jcd: continue
            dates={}
            for row in rows:
                for i,c in enumerate(row):
                    d=_date_token(c,year)
                    if d: dates[i]=d
            for ri,row in enumerate(rows):
                race_cols={i:_race_token(c) for i,c in enumerate(row) if _race_token(c)}
                if not race_cols: continue
                followers=rows[ri+1:ri+8]
                for col,rno in race_cols.items():
                    date=dates.get(col)
                    if not date or date<FLOOR: continue
                    vals=[r[col] if col<len(r) else '' for r in followers]
                    course=next((int(_norm(v)) for v in vals if re.fullmatch(r'[1-6]',_norm(v))),None)
                    st=next((_st_token(v) for v in vals if _st_token(v) is not None),None)
                    rank=None; finish=None
                    if st is not None:
                        si=next((k for k,v in enumerate(vals) if _st_token(v) is not None),None)
                        if si is not None:
                            for v in vals[si+1:]:
                                rr=_rank_token(v)
                                if rr is not None: rank=rr; break
                    for v in reversed(vals):
                        f=_finish_token(v)
                        if f is not None: finish=f; break
                    if not course or st is None or finish is None or finish=='欠': continue
                    out.append({'date':date,'jcd':jcd,'rno':rno,'registration_no':reg,'lane':None,'course':course,'finish':finish,'st_raw':st,'st_rank':rank,'source':f'racer-yearly:boatfrontier:{year}'})
        uniq={(x['date'],x['jcd'],x['rno']):x for x in out}
        return sorted(uniq.values(),key=lambda x:(x['date'],x['jcd'],x['rno']),reverse=True)
    def _fetch_year(self,reg,name,year,jcd):
        url=f'https://boatfrontier.jp/racer/{reg}/allraces/{year}'
        self.status.update({'phase':'選手別年データ取得中','crawl_stage':f'{name}（{reg}） {year}年 全出走データ取得中','scan_date':str(year),'crawl_jcd':jcd,'last_fetch_state':'fetching','last_fetch_error':None})
        s=requests.Session(); s.headers.update({'User-Agent':'Mozilla/5.0 BOAT-AI-Lab/1.0'}); last=None
        for attempt in range(1,4):
            try:
                r=s.get(url,timeout=(5,15)); r.raise_for_status(); return self._parse_year(r.text,year,reg),{'url':url,'http':r.status_code,'attempt':attempt}
            except Exception as e:
                last=f'{type(e).__name__}: {e}'; self.status.update({'last_fetch_error':last,'last_fetch_state':f'retry {attempt}/3'})
                if attempt<3:self._stop.wait(2)
        raise RuntimeError(last or f'{year}年データ取得失敗')
    def _run(self,today):
        self.db.ensure_course_history_today_targets(today,(datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d'),FLOOR)
        pending=self.db.get_course_history_pending_targets(today)
        if not pending:
            self.status={**self.db.get_course_history_target_status(today),'phase':'本日出走選手の初期履歴完了','validation_mode':'本日出走選手全員'}; return
        t=pending[0]; reg=str(t['registration_no']); jcd=str(t['jcd']).zfill(2); name=str(t.get('name') or reg)
        nm,lm=self._counts(reg,jcd)
        if self._done(nm,lm):
            self.db.complete_course_history_targets([(reg,jcd)]); return
        total=0; checked=[]; lastdiag={}; reached_floor=False
        try:
            for year in range(datetime.now(JST).year,FLOOR_YEAR-1,-1):
                nm,lm=self._counts(reg,jcd)
                if self._done(nm,lm): break
                rows,lastdiag=self._fetch_year(reg,name,year,jcd); checked.append(year)
                useful=[]
                for x in rows:
                    c=int(x['course'])
                    if nm.get(c,0)<10 or (x['jcd']==jcd and lm.get(c,0)<10): useful.append(x)
                if useful:
                    self.db.save_course_history_runs(useful,keep_per_local_course=10); total+=len(useful)
            reached_floor=bool(checked and checked[-1]==FLOOR_YEAR)
            nm,lm=self._counts(reg,jcd)
            if self._done(nm,lm) or reached_floor: self.db.complete_course_history_targets([(reg,jcd)])
            self.status={**self.db.get_course_history_target_status(today),'phase':f'{name} 完全確認' if (self._done(nm,lm) or reached_floor) else '選手別年データ保存中','validation_mode':'本日出走選手全員','current_racer':name,'current_registration_no':reg,'local_jcd':jcd,'last_fetch_state':'ok','last_parsed_rows':total,'last_matched_rows':total,'last_fetch_date':today,'crawl_stage':f'{reg}本人→年別全出走→全国/当地（確認年 {checked}）','national_counts':nm,'local_counts':lm,'checked_years':checked,'floor_reached':reached_floor,'direct_source':lastdiag.get('url'),'note':'本日出走選手を1人ずつ処理。各コース直近10走で即終了し、10走未満でも2023年まで確認できれば正常完了。'}
        except Exception as e:
            self.db.mark_course_history_target_errors([(reg,jcd)],str(self.status.get('scan_date') or ''),f'{type(e).__name__}: {e}',3)
            self.status={**self.db.get_course_history_target_status(today),'phase':'選手単位の収集エラー・次選手へ','validation_mode':'本日出走選手全員','current_racer':name,'current_registration_no':reg,'scheduler_error':f'{type(e).__name__}: {e}'}
