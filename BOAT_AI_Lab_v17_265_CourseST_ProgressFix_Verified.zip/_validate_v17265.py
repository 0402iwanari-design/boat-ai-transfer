import json, tempfile
from datetime import datetime
from db import BoatDB

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(td+'/t.db')
    now=datetime.utcnow().strftime('%Y%m')
    legacy={"course_stats_version":3,"course_stats":[{"course":i,"avg_st":round(.10+i*.01,2),"trio_rate":50.0} for i in range(1,7)]}
    with db.connect() as con:
        con.execute("INSERT INTO tracked_racer_profiles(registration_no,name,active,profile_json) VALUES('9999','TEST',1,'{}')")
        con.execute("INSERT INTO racer_official_monthly(registration_no,month,name,payload,saved_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)",('9999',now,'TEST',json.dumps(legacy)))
    out=db.get_racer_public_data('9999')
    assert out['official_data'] is None, 'v3 must remain invalid for v4 breakdown'
    assert len(out['legacy_course_st'])==6
    assert out['legacy_course_st']['1']==.11 and out['legacy_course_st']['6']==.16
print('PASS: legacy official avg_st survives v4 breakdown recollection without validating old breakdown')
