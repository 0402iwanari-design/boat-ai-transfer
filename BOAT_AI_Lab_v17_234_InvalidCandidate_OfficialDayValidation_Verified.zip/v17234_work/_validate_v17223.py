from pathlib import Path
from datetime import date, timedelta
import tempfile, time
from db import BoatDB
from course_history import OfficialCourseHistoryCollector


def mkdb():
    td=tempfile.TemporaryDirectory(); db=BoatDB(str(Path(td.name)/'t.db')); return td,db

def strict(d,j,c,rno=1,st='.10',sr=1,fn='1'):
    return {'date':d,'jcd':str(j).zfill(2),'rno':rno,'course_hint':c,'st_hint':st,
            'st_rank_hint':sr,'finish_hint':fn,'hint_confidence':'strict-matrix-v1'}

def official(cand,reg,course=None):
    c=int(course if course is not None else cand['course_hint'])
    return {'date':cand['date'],'jcd':str(cand['jcd']).zfill(2),'rno':int(cand['rno']),
            'registration_no':str(reg),'lane':c,'course':c,'finish':str(cand['finish_hint']),
            'st_raw':str(cand['st_hint']),'st_rank':int(cand['st_rank_hint']),'source':'official-test'}

# 1. Massive multi-venue history: web audit is bounded while exact retained rows are selected.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
cands=[]
base=date(2026,9,1)
for venue in range(1,9):
    for course in range(1,7):
        for k in range(12):
            # unique chronological dates per venue/course/k
            d=(base-timedelta(days=(venue-1)*90+(course-1)*13+k)).strftime('%Y%m%d')
            cands.append(strict(d,venue,course,rno=(k%12)+1,st=f'.{10+(k%8):02d}',sr=(k%6)+1,fn=str((k%6)+1)))
strict_rows,amb,skip=c._strict_archive_plan('9001',cands)
assert not amb
# 8 venues x 6 courses x newest 10 local rows; nationwide top10 are subset of that union.
assert len(strict_rows) <= 8*6*10 and len(strict_rows) >= 8*6*9, len(strict_rows)
audit=c._choose_archive_audit(strict_rows)
assert len(audit) <= 8+6+3, len(audit)
assert len(audit) < len(strict_rows)//10, (len(audit),len(strict_rows))

# 2. Matching audit permits direct archive save; official calls only audit sample.
calls=[]
def fake_fetch(sess,cand,reg):
    calls.append((cand['date'],cand['jcd'],cand['rno']))
    return official(cand,reg)
c._fetch_official_run=fake_fetch
ok,audit_rows,checked=c._audit_strict_archive(None,'9001','T',strict_rows,time.monotonic())
assert ok and checked==len(audit)==len(calls)
saved=c._save_audited_archive_rows('9001',strict_rows,audit_rows)
with db.connect() as con:
    # nationwide progress must report 10 each course (DB deliberately keeps local top10 buckets).
    nat,_loc=c._summary_counts('9001')
    assert nat=={1:10,2:10,3:10,4:10,5:10,6:10}, nat
    # every venue/course represented by 10 retained rows
    bad=con.execute("select jcd,course,count(*) n from racer_local_course_runs where registration_no='9001' group by jcd,course having n<>10").fetchall()
    assert not bad, [dict(x) for x in bad]
    ln=con.execute("select count(*) n from racer_local_course_runs where registration_no='9001'").fetchone()['n']
    assert ln==8*6*10, ln
assert len(calls) <= 17 and len(calls) < 50, len(calls)
td.cleanup()

# 3. One audit mismatch disables fast path (safety).
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
rows=[strict((date(2026,8,1)-timedelta(days=i)).strftime('%Y%m%d'),'16',1,rno=(i%12)+1) for i in range(12)]
plan,amb,sk=c._strict_archive_plan('9002',rows)
count={'n':0}
def mismatch_fetch(sess,cand,reg):
    count['n']+=1
    return official(cand,reg,course=2 if count['n']==1 else 1)
c._fetch_official_run=mismatch_fetch
ok,_,_=c._audit_strict_archive(None,'9002','M',plan,time.monotonic())
assert ok is False
with db.connect() as con:
    assert con.execute("select count(*) n from racer_course_runs where registration_no='9002'").fetchone()['n']==0
# mismatch must not silently save archive rows

td.cleanup()

# 4. Ambiguous row is never archive-direct and remains official-only.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
ambrow={'date':'20260901','jcd':'16','rno':12,'candidate_source':'ambiguous'}
ss,aa,kk=c._strict_archive_plan('9003',[ambrow])
assert ss==[] and len(aa)==1 and kk==[]
td.cleanup()

# 5. F/L and special finish are preserved in direct strict conversion.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
for st,fn in [('F.01','F'),('L.02','L'),('.12','転')]:
    row=c._archive_row_from_candidate(strict('20260901','16',4,st=st,sr=2,fn=fn),'9004')
    assert row and row['st_raw']==st and row['finish']==fn and row['course']==4

td.cleanup()

# 6. Existing rows reduce strict plan and are never deleted.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
seed=[]
for i in range(10):
    seed.append({'date':(date(2026,9,20)-timedelta(days=i)).strftime('%Y%m%d'),'jcd':'16','rno':1,
                 'registration_no':'9005','lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(seed,10); db.save_local_course_history_runs(seed,10)
older=[strict((date(2025,9,20)-timedelta(days=i)).strftime('%Y%m%d'),'16',1) for i in range(20)]
ss,aa,kk=c._strict_archive_plan('9005',older)
assert len(ss)==0 and len(aa)==0 and len(kk)==20
with db.connect() as con:
    assert con.execute("select count(*) n from racer_course_runs where registration_no='9005' and course=1").fetchone()['n']==10
    assert con.execute("select count(*) n from racer_local_course_runs where registration_no='9005' and jcd='16' and course=1").fetchone()['n']==10

td.cleanup()
print('v17.223 validation: ALL PASS')

# 7. Integrated initialize_racer fast path: hundreds of strict candidates finish with bounded official calls.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
allc=[]
base=date(2026,9,20)
for venue in range(1,5):
    for course in range(1,7):
        for k in range(12):
            d=(base-timedelta(days=(venue-1)*180+(course-1)*15+k)).strftime('%Y%m%d')
            allc.append(strict(d,venue,course,rno=(k%12)+1,st=f'.{10+(k%7):02d}',sr=(k%6)+1,fn=str((k%6)+1)))
c._fetch_recent_racer_candidates=lambda *a,**k: []
c._fetch_year_racer_candidates=lambda sess,reg,name,year: list(allc) if year==2026 else []
icalls=[]
def ifetch(sess,cand,reg):
    icalls.append((cand['date'],cand['jcd'],cand['rno']))
    return official(cand,reg)
c._fetch_official_run=ifetch
racer={'registration_no':'9010','name':'Integration','today_venues':['01'],'_today_index':1}
c._register_today_targets('20260930',[racer])
ok=c._initialize_racer(racer,'20260930')
assert ok is True
state=c._state('9010'); assert state['status']=='complete',state
# 4 venues + 6 course audits, with overlap, must stay tiny compared with 288 source rows.
assert len(icalls) <= 10, len(icalls)
nat,loc=c._summary_counts('9010')
assert all(nat.get(i)==10 for i in range(1,7)),nat
for j in ['01','02','03','04']:
    assert all(loc.get((j,i))==10 for i in range(1,7)),(j,loc)
td.cleanup()
print('v17.223 integration fast-path: PASS')

# 8. Partial legacy state heals missing local table instead of skipping an existing nationwide race.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
row={'date':'20260915','jcd':'16','rno':7,'registration_no':'9011','lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed-national-only'}
db.save_course_history_runs([row],10)
cand=strict('20260915','16',1,rno=7)
ss,aa,kk=c._strict_archive_plan('9011',[cand])
assert len(ss)==1 and not aa, (ss,aa,kk)
c._save_audited_archive_rows('9011',ss,{})
with db.connect() as con:
    n=con.execute("select count(*) n from racer_local_course_runs where registration_no='9011' and jcd='16' and course=1").fetchone()['n']
    assert n==1,n
td.cleanup()
print('v17.223 partial-state heal: PASS')
