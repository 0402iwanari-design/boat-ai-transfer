import threading
from course_history import OfficialCourseHistoryCollector


def build_collector(last_error, failed_rows, retry_clears=True):
    c = OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
    c.status = {}
    c._stop = threading.Event()
    c._worker_progress = {}
    c._prefilter_hint_mismatch_regs = set()
    calls = {"recent":0,"year":0,"retry":0,"complete":0,"error":0,"progress":[]}
    state = {"status":"pending","started_at":"x","retry_count":3,"last_error":last_error}
    c._state = lambda reg: dict(state)
    c._mark_started = lambda reg,name,today: None
    c._set_worker_progress = lambda reg, **kw: calls["progress"].append(kw)
    c._session = lambda: object()
    c._summary_counts = lambda reg: ({i:10 for i in range(1,7)}, {})
    c._today_local_progress = lambda local, venues: []
    pending = [dict(x) for x in failed_rows]
    c._failed_candidates = lambda reg: [dict(x) for x in pending]
    def retry(session, reg, name, started, venues):
        calls["retry"] += 1
        if retry_clears:
            pending.clear()
            return (len(failed_rows), len(failed_rows), 0)
        return (0,0,len(pending))
    c._retry_failed_candidates = retry
    c._add_progress = lambda reg,cand=0,verified=0,saved=0: calls["progress"].append({"add":(cand,verified,saved)})
    c._mark_recent_done = lambda reg: None
    c._mark_complete = lambda reg: calls.__setitem__("complete", calls["complete"]+1)
    c._mark_error = lambda reg,err: (calls.__setitem__("error", calls["error"]+1), state.update(last_error=err))
    def recent(*a,**k):
        calls["recent"] += 1
        raise RuntimeError("SENTINEL_RECENT")
    def year(*a,**k):
        calls["year"] += 1
        raise RuntimeError("SENTINEL_YEAR")
    c._fetch_recent_racer_candidates = recent
    c._fetch_year_racer_candidates = year
    return c,calls,state

failed=[{"date":"20210803","jcd":"09","rno":5,"error":"parse0","retry_count":10}]
racer={"registration_no":"3430","name":"角浜修","today_venues":["09"],"_today_index":31}

# A terminal individual-race retry state must bypass every archive/year fetch.
c,calls,state=build_collector("個別レース再試行待ち 1件（全履歴の再走査はしません）", failed, True)
assert c._initialize_racer(racer,"20261001") is True
assert calls["retry"]==1
assert calls["recent"]==0 and calls["year"]==0, calls
assert calls["complete"]==1 and calls["error"]==0
assert c.status.get("retry_only_mode") is True
assert c.status.get("retry_only_candidate_count")==1
assert "archive history was not fetched" in c.status.get("last_fetch_state","")

# If a deferred race still fails, only it is retried and the racer remains pending.
c,calls,state=build_collector("個別レース再試行待ち 1件（全履歴の再走査はしません）", failed, False)
assert c._initialize_racer(racer,"20261001") is False
assert calls["retry"]==1
assert calls["recent"]==0 and calls["year"]==0
assert calls["complete"]==0 and calls["error"]==1
assert state["last_error"].startswith("個別レース再試行待ち 1件")

# Safety guard: a crash/other error that happens to have a failed-candidate row must NOT
# skip the normal initial scan.  Only the explicit terminal retry state can use fast path.
c,calls,state=build_collector("並行処理例外: RuntimeError: crash", failed, True)
assert c._initialize_racer(racer,"20261001") is False
assert calls["retry"]==0
assert calls["recent"]==1 and calls["year"]==1, calls
assert calls["error"]==1

# Queue priority remains: unstarted -> clean pending -> retry pending.
c = OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
states={
 '1': {'status':'complete','started_at':'x','retry_count':0,'last_error':None},
 '2': {'status':'pending','started_at':None,'retry_count':0,'last_error':None},
 '3': {'status':'pending','started_at':'x','retry_count':0,'last_error':None},
 '4': {'status':'pending','started_at':'x','retry_count':2,'last_error':'個別レース再試行待ち 2件'},
}
c._state=lambda reg: states.get(str(reg))
racers=[{'registration_no':str(i)} for i in range(1,5)]
q,mode=c._priority_pending_today(racers)
assert mode=='未着手優先' and [x['registration_no'] for x in q]==['2']
states['2']['started_at']='x'
q,mode=c._priority_pending_today(racers)
assert mode=='通常未完了優先' and [x['registration_no'] for x in q]==['2','3']
states['2']['status']='complete'; states['3']['status']='complete'
q,mode=c._priority_pending_today(racers)
assert mode=='エラー再試行フェーズ' and [x['registration_no'] for x in q]==['4']

print('v17.231 retry-only validation: ALL PASS')
