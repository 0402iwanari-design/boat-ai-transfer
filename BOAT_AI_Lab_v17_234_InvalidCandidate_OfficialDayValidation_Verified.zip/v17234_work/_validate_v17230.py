import os, tempfile
from pathlib import Path
os.environ['LOCALAPPDATA']=tempfile.mkdtemp(prefix='boat_v17230_')

from boat_source import BoatRaceSource
from db import BoatDB

src=BoatRaceSource()
src.db=BoatDB(Path(os.environ['LOCALAPPDATA'])/'test.db')
db=src.db
TODAY='20261001'; JCD='03'
db.save_meeting_day(TODAY,JCD,3,'3日目','3日目','test')
db.save_meeting_day('20260930',JCD,2,'2日目','2日目','test')
db.save_meeting_day('20260929',JCD,1,'初日','初日','test')

racers=[]
for lane in range(1,7):
    racers.append({'lane':lane,'registration_no':f'{4000+lane}','name':f'R{lane}','meeting_results':{'slots':[{}, {}, {}, {}, {}, {}]}})
for rno in range(1,13):
    db.save_snapshot(TODAY,JCD,rno,'racelist',{'date':TODAY,'jcd':JCD,'rno':rno,'racers':[dict(x) for x in racers]})

# Fake official history fetch. It intentionally starts with no saved results so
# repair_meeting_results_from_official_history must call this method.
def fake_fetch(date,jcd,requested_rno=None):
    rows=[]
    for rno in range(1,13):
        starts=[]; finishers=[]
        for course,lane in enumerate([1,2,3,4,5,6], start=1):
            st=f'.{(rno+lane)%20:02d}'
            starts.append({'lane':lane,'course':course,'st_raw':st})
            finishers.append({'lane':lane,'registration_no':f'{4000+lane}','name':f'R{lane}',
                              'finish':lane,'course':course,'st_raw':st})
        rows.append({'rno':rno,'trifecta':'1-2-3','payout_yen':1000,'odds':10.0,
                     'kimarite':'逃げ','finishers':finishers,'start_courses':starts})
    db.save_results(date,jcd,rows)
    return {'ok':True,'confirmed_count':12,'confirmed_rnos':list(range(1,13))}
src.fetch_results_atomic=fake_fetch

out=src.repair_meeting_results_from_official_history(TODAY,JCD)
assert out['ok'], out
assert out['matched_dates']==['20260929','20260930'], out
assert out['result_races_complete_after']==24, out
assert out['updated_snapshots']==12, out

snap=db.get_snapshot(TODAY,JCD,1,'racelist')['data']
assert len(snap['racers'])==6
for racer in snap['racers']:
    m=racer.get('meeting_results') or {}
    entries=m.get('entries') or []
    # Two previous meeting days, max two races/day => four restored entries.
    assert len(entries)==4, (racer, entries)
    for e in entries:
        assert e.get('rno') is not None
        assert e.get('course') in range(1,7)
        assert e.get('st') not in (None,'')
        assert e.get('finish') not in (None,'')

# Second run must reuse saved complete results and not require fresh fetches.
def no_fetch(*a,**k):
    raise AssertionError('complete saved official results should be reused')
src.fetch_results_atomic=no_fetch
out2=src.repair_meeting_results_from_official_history(TODAY,JCD)
assert out2['ok'], out2
assert out2['result_races_complete_before']==24, out2

print('v17.230 official-history meeting-result verification/rebuild: PASS')
