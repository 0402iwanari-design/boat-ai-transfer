import tempfile, threading
from pathlib import Path
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

class Resp:
    def __init__(self, text, code=200, url='x'):
        self.content=text.encode('utf-8')
        self.encoding='utf-8'; self.apparent_encoding='utf-8'; self.text=text
        self.status_code=code; self.url=url
    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f'HTTP {self.status_code}')

class Session:
    def __init__(self, mapping): self.mapping=mapping; self.calls=[]
    def get(self,url,**kw):
        self.calls.append(url)
        return self.mapping[url]

with tempfile.TemporaryDirectory() as td:
    c=OfficialCourseHistoryCollector(BoatDB(str(Path(td)/'t.db')))

    # 1) exact race link must override a wrong surrounding matrix venue/date.
    html='''<html><body><h3>津 一般</h3><table>
    <tr><th>選手</th><th>7月14日</th></tr>
    <tr><td>4411</td><td><a href="https://www.boatrace.jp/owpc/pc/race/raceresult?hd=20230714&jcd=06&rno=8">8R</a></td></tr>
    <tr><td></td><td>2</td></tr><tr><td></td><td>.12</td></tr><tr><td></td><td>(3)</td></tr><tr><td></td><td>1</td></tr>
    </table></body></html>'''
    rows=c._parse_year_archive_candidates(html,2023)
    assert rows, rows
    assert any(x['date']=='20230714' and x['jcd']=='06' and x['rno']==8 for x in rows), rows

    # 2) official daily result list with no race rows => invalid candidate (False).
    cand={'date':'20230714','jcd':'09','rno':8}
    day_url=c._official_resultlist_url(cand)
    no_race='''<html><body><h1>結果一覧</h1><h2>本日の開催はありません</h2><div>勝式・払戻金・結果</div></body></html>'''
    s=Session({day_url:Resp(no_race,url=day_url)})
    assert c._candidate_exists_on_official_day(s,cand) is False
    assert len(s.calls)==1
    # same date/venue is cached: no second HTTP request
    assert c._candidate_exists_on_official_day(s,cand) is False
    assert len(s.calls)==1

    # 3) valid result list containing 8R => candidate exists.
    cand2={'date':'20230715','jcd':'09','rno':8}
    day_url2=c._official_resultlist_url(cand2)
    valid='''<html><body><h1>結果一覧</h1><div>勝式・払戻金・結果</div>
       <table><tr><th>レース</th></tr><tr><td><a href="/owpc/pc/race/raceresult?hd=20230715&jcd=09&rno=8">8R</a></td></tr></table></body></html>'''
    s2=Session({day_url2:Resp(valid,url=day_url2)})
    assert c._candidate_exists_on_official_day(s2,cand2) is True

    # 4) retry queue: invalid candidate is cleared, not re-added forever.
    reg='4411'
    c._record_failed_candidate(cand,reg,'RuntimeError: 公式結果ページ解析0件')
    # monkeypatch _fetch_official_run to emulate v17.234 invalid-day drop
    def fake_fetch(session,candidate,regno):
        exists=c._candidate_exists_on_official_day(session,candidate)
        if exists is False:
            return None
        raise RuntimeError('should not happen')
    c._fetch_official_run=fake_fetch
    # use same cached invalid day; no network needed now
    rv,sv,fl=c._retry_failed_candidates(s,reg,'沢田昭宏',0,['09'])
    assert fl==0 and c._failed_candidates(reg)==[], (rv,sv,fl,c._failed_candidates(reg))

print('PASS v17.234 invalid archive candidate validation + exact-link override')
