from pathlib import Path
import tempfile
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

HTML='''<!doctype html><html><head><meta charset="Shift_JIS"></head><body>
<table><tr><th>着</th><th>枠</th><th>ボートレーサー</th><th>レースタイム</th></tr>
<tr><td>1</td><td>1</td><td>4320 峰竜太</td><td>1'48\"0</td></tr>
<tr><td>2</td><td>2</td><td>5002 選手二</td><td>1'49\"0</td></tr>
<tr><td>3</td><td>4</td><td>5004 選手四</td><td>1'50\"0</td></tr>
<tr><td>4</td><td>3</td><td>5003 選手三</td><td>1'51\"0</td></tr>
<tr><td>5</td><td>6</td><td>5006 選手六</td><td>1'52\"0</td></tr>
<tr><td>6</td><td>5</td><td>5005 選手五</td><td>1'53\"0</td></tr>
</table>
<h3>スタート情報</h3>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">1</span> .18</div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">2</span> .12</div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">4</span> .10</div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">3</span> .15</div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">6</span> .08</div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">5</span> .20</div>
<table><tr><th>勝式</th><th>組番</th><th>払戻金</th><th>人気</th></tr><tr><td>3連単</td><td>1-2-4</td><td>1,230円</td><td>4</td></tr></table>
<table><tr><th>決まり手</th></tr><tr><td>逃げ</td></tr></table>
</body></html>'''

class FakeResponse:
    def __init__(self, b, encoding='ISO-8859-1', apparent='SHIFT_JIS'):
        self.content=b
        self.encoding=encoding
        self.apparent_encoding=apparent
        self.text=b.decode(encoding, errors='replace')

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'test.db'))
    c=OfficialCourseHistoryCollector(db)
    raw=HTML.encode('cp932')
    resp=FakeResponse(raw)
    # Reproduce old bug: response.text is mojibake, Japanese semantic headers disappear.
    old_rows=c._parsed_official_detail(resp.text, {'date':'20260929','jcd':'16','rno':12})
    assert old_rows == [], f'old path unexpectedly parsed {len(old_rows)} rows'
    decoded, enc, score=c._decode_official_response(resp)
    assert 'スタート情報' in decoded and 'ボートレーサー' in decoded, (enc,score)
    rows=c._parsed_official_detail(decoded, {'date':'20260929','jcd':'16','rno':12})
    assert len(rows)==6, rows
    mine=[r for r in rows if r['registration_no']=='4320'][0]
    assert mine['course']==1 and mine['st_raw']=='.18' and mine['finish']=='1', mine
    # Entry change: lane 4 is third actual course.
    r4=[r for r in rows if r['registration_no']=='5004'][0]
    assert r4['lane']==4 and r4['course']==3 and r4['st_raw']=='.10', r4
    diag=c._official_html_diagnostic(decoded, enc, len(raw))
    assert diag['has_start'] and diag['has_racer'] and diag['reg_tokens']>=6 and diag['st_tokens']>=6, diag
print('PASS v17.233 encoding recovery + official parser regression')
