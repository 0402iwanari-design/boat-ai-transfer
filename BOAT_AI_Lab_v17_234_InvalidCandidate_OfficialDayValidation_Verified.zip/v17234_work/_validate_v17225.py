from course_history import OfficialCourseHistoryCollector

# Use parser methods without starting collector/db.
c = OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)


def result_table(rows):
    body=''.join(f'<tr><td>{fin}</td><td>{lane}</td><td>{reg}　{name}</td><td>1:50.0</td></tr>' for fin,lane,reg,name in rows)
    return f'<table><tr><th>着</th><th>枠</th><th>ボートレーサー</th><th>レースタイム</th></tr>{body}</table>'

# Modern official DOM shape used by the shared application parser.
html_modern = '''<html><body>''' + result_table([
    ('１',1,'4320','峰 竜太'),('２',3,'4371','西山 貴浩'),('３',5,'4205','山口 剛'),
    ('４',4,'3960','菊地 孝平'),('５',6,'4851','関 浩哉'),('６',2,'3415','松井 繁')]) + '''
<h3>スタート情報</h3>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">1</span><span>.18</span></div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">2</span><span>.16</span></div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">3</span><span>.12</span></div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">4</span><span>.12</span></div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">5</span><span>.14</span></div>
<div class="table1_boatImage1"><span class="table1_boatImage1Number">6</span><span>.27</span></div>
<table><tr><th>勝式</th><th>組番</th><th>払戻金</th><th>人気</th></tr></table>
</body></html>'''
cand={'date':'20260929','jcd':'16','rno':12}
rows=c._parsed_official_detail(html_modern,cand)
assert len(rows)==6, rows
mine=next(x for x in rows if x['registration_no']=='4320')
assert (mine['lane'],mine['course'],mine['st_raw'],mine['st_rank'],mine['finish']) == (1,1,'.18',5,'1'), mine

# Older/different wrapper: no table1_* CSS classes. The stable visible labels/text
# still suffice and actual entry order 1,2,4,3,6,5 must be preserved.
html_fallback = '''<html><body>''' + result_table([
    ('1',4,'4320','峰竜太'),('2',1,'1001','A'),('3',2,'1002','B'),('4',3,'1003','C'),('5',6,'1006','F'),('6',5,'1005','E')]) + '''
<section><strong>スタート情報</strong>
<div>1 <span>.10</span></div><div>2 <span>.11</span></div><div>4 <span>.17</span></div>
<div>3 <span>.19</span></div><div>6 <span>.13</span></div><div>5 <span>.21</span></div></section>
<div>勝式 3連単 4-1-2</div></body></html>'''
rows=c._parsed_official_detail(html_fallback,{'date':'20260812','jcd':'23','rno':6})
assert len(rows)==6, rows
mine=next(x for x in rows if x['registration_no']=='4320')
assert (mine['lane'],mine['course'],mine['st_raw'],mine['finish']) == (4,3,'.17','1'), mine

# 欠場 must not become a historical start. F/L and accident-like result must remain.
html_special = '''<html><body><table><tr><th>着</th><th>枠</th><th>ボートレーサー</th></tr>
<tr><td>欠</td><td>1</td><td>1111 欠場艇</td></tr><tr><td>F</td><td>2</td><td>2222 F艇</td></tr>
<tr><td>転</td><td>3</td><td>3333 転覆艇</td></tr></table>
<div>スタート情報 2 F.01 3 .09 勝式</div></body></html>'''
rows=c._parsed_official_detail(html_special,{'date':'20250101','jcd':'01','rno':1})
assert all(x['registration_no']!='1111' for x in rows), rows
f=next(x for x in rows if x['registration_no']=='2222')
t=next(x for x in rows if x['registration_no']=='3333')
assert f['finish']=='F' and f['st_raw']=='F.01', f
assert t['finish']=='転' and t['st_raw']=='.09', t

print('v17.225 parser validation PASS')
print('modern rows',len(c._parsed_official_detail(html_modern,cand)))
print('fallback entry-change',mine)
