import tempfile
from pathlib import Path

from db import BoatDB
from course_history import OfficialCourseHistoryCollector, PREFILTER_RESERVE_PER_BUCKET


def mkdb():
    td = tempfile.TemporaryDirectory()
    db = BoatDB(str(Path(td.name)/'t.db'))
    return td, db

# 1) stale running state cleanup
_td, db = mkdb()
c0 = OfficialCourseHistoryCollector(db)
with db.connect() as con:
    con.execute("INSERT INTO course_history_initial_racers(registration_no,name,status) VALUES('9999','T','running')")
c = OfficialCourseHistoryCollector(db)
with db.connect() as con:
    row = con.execute("SELECT status FROM course_history_initial_racers WHERE registration_no='9999'").fetchone()
assert row['status'] == 'pending', row['status']
_td.cleanup()

# 2) year archive 404 is normal zero rows, not exception/retry failure
_td, db = mkdb(); c = OfficialCourseHistoryCollector(db)
class Resp404:
    status_code = 404
    text = ''
    url = 'https://boatrace-db.net/racer/yall/regno/9999/year/2025/'
    def raise_for_status(self):
        raise AssertionError('raise_for_status must not be called for allowed 404')
class Sess404:
    calls = 0
    def get(self,*a,**k):
        self.calls += 1
        return Resp404()
sess = Sess404()
rows = c._fetch_year_racer_candidates(sess, '9999', 'T', 2025)
assert rows == []
assert sess.calls == 1, sess.calls
assert '404正常' in c.status.get('crawl_stage','')
_td.cleanup()

# 3) primary 10 + reserve 3 + older skipped for one strict bucket
_td, db = mkdb(); c = OfficialCourseHistoryCollector(db)
cands=[]
for i in range(15):
    # newest first unique descending date-ish keys
    cands.append({'date': f'202601{31-i:02d}', 'jcd':'16', 'rno':1,
                  'course_hint':1,'st_hint':'.10','st_rank_hint':1,'finish_hint':'1',
                  'hint_confidence':'strict-matrix-v1'})
primary,reserve,skipped=c._prefilter_needed_candidates('9999',cands)
assert len(primary)==10, len(primary)
assert len(reserve)==PREFILTER_RESERVE_PER_BUCKET==3, len(reserve)
assert len(skipped)==2, len(skipped)
_td.cleanup()

# 4) ambiguous rows are never discarded
_td, db = mkdb(); c = OfficialCourseHistoryCollector(db)
amb=[{'date':'20260101','jcd':'16','rno':1,'candidate_source':'amb'}]
p,r,s=c._prefilter_needed_candidates('9999',amb)
assert len(p)==1 and not r and not s
_td.cleanup()

# 5) reserve backfills when one primary candidate is unusable, retained top10 still reaches 10
_td, db = mkdb(); c = OfficialCourseHistoryCollector(db)
cands=[]
for i in range(13):
    cands.append({'date': f'202602{28-i:02d}', 'jcd':'16', 'rno':1,
                  'course_hint':1,'st_hint':'.10','st_rank_hint':1,'finish_hint':'1',
                  'hint_confidence':'strict-matrix-v1'})
primary,reserve,skipped=c._prefilter_needed_candidates('9999',cands)
first_key=(primary[0]['date'],'16',1)
def fake_fetch(session,cand,reg):
    key=(cand['date'],str(cand['jcd']).zfill(2),int(cand['rno']))
    if key==first_key:
        return None  # e.g. scratch/unusable
    return {'date':cand['date'],'jcd':'16','rno':1,'registration_no':str(reg),
            'lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,
            'source':'test-official'}
c._fetch_official_run=fake_fetch
seen=set()
v,saved,failed=c._process_candidates(None,'9999','T',primary,seen,0.0)
# exactly 9 useful primary rows should be retained
with db.connect() as con:
    n=con.execute("SELECT COUNT(*) n FROM racer_course_runs WHERE registration_no='9999' AND course=1").fetchone()['n']
assert n==9, n
v2,s2,f2=c._process_candidates(None,'9999','T',reserve,seen,0.0)
with db.connect() as con:
    n=con.execute("SELECT COUNT(*) n FROM racer_course_runs WHERE registration_no='9999' AND course=1").fetchone()['n']
    ln=con.execute("SELECT COUNT(*) n FROM racer_local_course_runs WHERE registration_no='9999' AND jcd='16' AND course=1").fetchone()['n']
assert n==10 and ln==10, (n,ln)
# reserve processing must stop being useful once both buckets are full
assert s2==1, s2
_td.cleanup()

# 6) existing saved rows reduce the amount of primary work on restart/resume
_td, db = mkdb(); c = OfficialCourseHistoryCollector(db)
seed=[]
for i in range(8):
    seed.append({'date':f'202603{20-i:02d}','jcd':'16','rno':1,'registration_no':'9999',
                 'lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(seed,10); db.save_local_course_history_runs(seed,10)
cands=[]
for i in range(8):
    cands.append({'date':f'202602{20-i:02d}','jcd':'16','rno':2,
                  'course_hint':1,'st_hint':'.11','st_rank_hint':2,'finish_hint':'2',
                  'hint_confidence':'strict-matrix-v1'})
p,r,s=c._prefilter_needed_candidates('9999',cands)
# 8 rows already occupy the kept top10, so only 2 new rows are primary; next 3 reserve.
assert len(p)==2, len(p)
assert len(r)==3, len(r)
assert len(s)==3, len(s)
_td.cleanup()

print('v17.222 validation: ALL PASS')
