from pathlib import Path
from datetime import date, timedelta
import tempfile, time
from db import BoatDB
from course_history import OfficialCourseHistoryCollector


def mkdb():
    td=tempfile.TemporaryDirectory(); db=BoatDB(str(Path(td.name)/'t.db')); return td,db

def strict(d,j,c,rno=1,st='.10',sr=1,fn='1'):
    return {'date':d,'jcd':str(j).zfill(2),'rno':rno,'course_hint':c,'st_hint':st,
            'st_rank_hint':sr,'finish_hint':fn,'hint_confidence':'strict-matrix-v1'}

def off(cand,reg,course=None,lane=None):
    c=int(course if course is not None else cand.get('course_hint') or 1)
    return {'date':cand['date'],'jcd':str(cand['jcd']).zfill(2),'rno':int(cand['rno']),
            'registration_no':str(reg),'lane':int(lane or c),'course':c,'finish':'1',
            'st_raw':'.10','st_rank':1,'source':'official-test'}

# 1) Nationwide storage is GLOBAL newest 10/course, not 10 per venue.
td,db=mkdb()
runs=[]
base=date(2026,9,30)
for i in range(14):
    runs.append({'date':(base-timedelta(days=i)).strftime('%Y%m%d'),'jcd':'16' if i%2==0 else '24','rno':(i%12)+1,
                 'registration_no':'7001','lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(runs,10)
with db.connect() as con:
    rows=con.execute("select date,jcd from racer_course_runs where registration_no='7001' and course=1 order by date desc").fetchall()
assert len(rows)==10, len(rows)
assert [r['date'] for r in rows]==sorted([r['date'] for r in rows],reverse=True)
# local remains independently per venue
db.save_local_course_history_runs(runs,10)
with db.connect() as con:
    c16=con.execute("select count(*) n from racer_local_course_runs where registration_no='7001' and jcd='16' and course=1").fetchone()['n']
    c24=con.execute("select count(*) n from racer_local_course_runs where registration_no='7001' and jcd='24' and course=1").fetchone()['n']
assert (c16,c24)==(7,7),(c16,c24)
td.cleanup()

# 2) Initial local storage is today's venue only; nationwide always stores.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
a=strict('20260929','16',2,11); b=strict('20260908','24',2,12)
c._save_confirmed(off(a,'7002'),local_target_venues=['16'])
c._save_confirmed(off(b,'7002'),local_target_venues=['16'])
with db.connect() as con:
    n=con.execute("select count(*) n from racer_course_runs where registration_no='7002'").fetchone()['n']
    l16=con.execute("select count(*) n from racer_local_course_runs where registration_no='7002' and jcd='16'").fetchone()['n']
    l24=con.execute("select count(*) n from racer_local_course_runs where registration_no='7002' and jcd='24'").fetchone()['n']
assert (n,l16,l24)==(2,1,0),(n,l16,l24)
td.cleanup()

# 3) Completed C is ignored newest->oldest. If national AND today's local 1C are full,
# all older strict 1C candidates are skipped before official web confirmation.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
seed=[]
for i in range(10):
    seed.append({'date':(date(2026,9,20)-timedelta(days=i)).strftime('%Y%m%d'),'jcd':'16','rno':(i%12)+1,
                 'registration_no':'7003','lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(seed,10); db.save_local_course_history_runs(seed,10)
older=[strict((date(2025,1,31)-timedelta(days=i)).strftime('%Y%m%d'),'16',1,(i%12)+1) for i in range(30)]
ss,aa,kk=c._strict_archive_plan('7003',older,['16'])
assert not ss and not aa and len(kk)==30,(len(ss),len(aa),len(kk))
calls=[]
c._fetch_official_run=lambda sess,cand,reg: calls.append(cand) or off(cand,reg)
c._process_candidates(None,'7003','X',older,set(),time.monotonic(),['16'])
assert len(calls)==0,len(calls)
td.cleanup()

# 4) National course full but today's local same C incomplete -> only today's venue candidate is needed.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
seed=[]
for i in range(10):
    seed.append({'date':(date(2026,9,20)-timedelta(days=i)).strftime('%Y%m%d'),'jcd':'24','rno':(i%12)+1,
                 'registration_no':'7004','lane':2,'course':2,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(seed,10)
cs=[strict('20260804','24',2,1),strict('20260803','16',2,2),strict('20260802','24',2,3),strict('20260801','16',2,4)]
ss,aa,kk=c._strict_archive_plan('7004',cs,['16'])
assert [x['jcd'] for x in ss]==['16','16'],ss
assert [x['jcd'] for x in kk]==['24','24'],kk
td.cleanup()

# 5) Ambiguous/no-hint candidate is official-checked only while some national or TODAY-local bucket is incomplete.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
amb={'date':'20260701','jcd':'16','rno':7}
ss,aa,kk=c._strict_archive_plan('7005',[amb],['16'])
assert len(aa)==1 and not ss and not kk
# Fill national and today's local all courses -> same ambiguous candidate becomes skippable.
for course in range(1,7):
    rows=[]
    for i in range(10):
        rows.append({'date':(date(2026,9,30)-timedelta(days=course*20+i)).strftime('%Y%m%d'),'jcd':'16','rno':(i%12)+1,
                     'registration_no':'7005','lane':course,'course':course,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
    db.save_course_history_runs(rows,10); db.save_local_course_history_runs(rows,10)
ss,aa,kk=c._strict_archive_plan('7005',[amb],['16'])
assert not ss and not aa and len(kk)==1,(ss,aa,kk)
td.cleanup()

# 6) Official actual course overrides archive hint; only actual course is stored.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
c._clear_failed_candidate=lambda *a,**k: None
c._record_failed_candidate=lambda *a,**k: None
wrong=strict('20260812','23',4,6)
c._fetch_official_run=lambda sess,cand,reg: off(cand,reg,course=3,lane=4)
v,s,f=c._process_candidates(None,'7006','峰', [wrong], set(), time.monotonic(), ['23'])
with db.connect() as con:
    got=con.execute("select course,lane from racer_course_runs where registration_no='7006'").fetchone()
assert got and (got['course'],got['lane'])==(3,4),dict(got) if got else None
td.cleanup()

# 7) Partial state healing does not falsely mark national/local both full.
td,db=mkdb(); c=OfficialCourseHistoryCollector(db)
r={'date':'20260505','jcd':'16','rno':5,'registration_no':'7007','lane':3,'course':3,'finish':'1','st_raw':'.11','st_rank':1,'source':'seed'}
db.save_course_history_runs([r],10)
c._save_confirmed(dict(r),local_target_venues=['16'])
nat,loc=c._summary_counts('7007')
assert nat.get(3)==1 and loc.get(('16',3))==1,(nat,loc)
td.cleanup()

# 8) Live result maintenance updates nationwide global top10 and actual venue local top10.
td,db=mkdb()
# seed 10 old nationwide/local rows for racer 7008 course1 at venue16
old=[]
for i in range(10):
    old.append({'date':(date(2026,8,20)-timedelta(days=i)).strftime('%Y%m%d'),'jcd':'16','rno':1,
                'registration_no':'7008','lane':1,'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'seed'})
db.save_course_history_runs(old,10); db.save_local_course_history_runs(old,10)
result={'rno':12,'finishers':[{'lane':1,'registration_no':'7008','finish':'2'}],
        'start_courses':[{'lane':1,'course':1,'st_raw':'.08'}]}
db.sync_course_history_from_result('20260930','16',result)
with db.connect() as con:
    nr=con.execute("select date from racer_course_runs where registration_no='7008' and course=1 order by date desc").fetchall()
    lr=con.execute("select date from racer_local_course_runs where registration_no='7008' and jcd='16' and course=1 order by date desc").fetchall()
assert len(nr)==10 and nr[0]['date']=='20260930', [x['date'] for x in nr]
assert len(lr)==10 and lr[0]['date']=='20260930', [x['date'] for x in lr]
td.cleanup()

print('v17.226 validation: ALL PASS')
