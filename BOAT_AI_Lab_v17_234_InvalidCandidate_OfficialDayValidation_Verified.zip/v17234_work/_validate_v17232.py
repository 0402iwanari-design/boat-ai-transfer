import tempfile, threading, time
from pathlib import Path
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

# ---------- retry-only routing ----------
def build_collector(last_error, failed_rows, initial_pass_done=0, retry_clears=True):
    c = OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
    c.status = {}
    c._stop = threading.Event()
    c._worker_progress = {}
    c._prefilter_hint_mismatch_regs = set()
    calls = {"recent":0,"year":0,"retry":0,"complete":0,"error":0,"progress":[],"initial_done":0}
    state = {"status":"pending","started_at":"x","retry_count":3,"last_error":last_error,"initial_pass_done":initial_pass_done}
    c._state = lambda reg: dict(state)
    c._mark_started = lambda reg,name,today: None
    c._set_worker_progress = lambda reg, **kw: calls["progress"].append(kw)
    c._session = lambda: object()
    c._summary_counts = lambda reg: ({i:10 for i in range(1,7)}, {})
    c._today_local_progress = lambda local, venues: []
    pending = [dict(x) for x in failed_rows]
    c._failed_candidates = lambda reg: [dict(x) for x in pending]
    def retry(session, reg, name, started, venues):
        calls["retry"] += 1
        if retry_clears:
            pending.clear(); return (len(failed_rows),len(failed_rows),0)
        return (0,0,len(pending))
    c._retry_failed_candidates = retry
    c._add_progress = lambda reg,cand=0,verified=0,saved=0: calls["progress"].append({"add":(cand,verified,saved)})
    c._mark_recent_done = lambda reg: None
    c._mark_initial_pass_done = lambda reg: calls.__setitem__("initial_done", calls["initial_done"]+1)
    c._mark_complete = lambda reg: calls.__setitem__("complete", calls["complete"]+1)
    c._mark_error = lambda reg,err: (calls.__setitem__("error", calls["error"]+1), state.update(last_error=err))
    def recent(*a,**k):
        calls["recent"] += 1
        raise RuntimeError("SENTINEL_RECENT")
    def year(*a,**k):
        calls["year"] += 1
        raise RuntimeError("SENTINEL_YEAR")
    c._fetch_recent_racer_candidates = recent
    c._fetch_year_racer_candidates = year
    return c,calls,state

failed=[{"date":"20210803","jcd":"09","rno":5,"error":"parse0","retry_count":10}]
racer={"registration_no":"3430","name":"角浜修","today_venues":["09"],"_today_index":31,"_queue_mode":"エラー再試行フェーズ"}

# Legacy terminal retry state bypasses archive/year fetch.
c,calls,state=build_collector("個別レース再試行待ち 1件（全履歴の再走査はしません）", failed, 0, True)
assert c._initialize_racer(racer,"20261001") is True
assert calls["retry"]==1 and calls["recent"]==0 and calls["year"]==0
assert calls["complete"]==1

# New persistent marker bypasses archive even if later error text was overwritten.
c,calls,state=build_collector("OperationalError: database is locked", failed, 1, True)
assert c._initialize_racer(racer,"20261001") is True
assert calls["retry"]==1 and calls["recent"]==0 and calls["year"]==0

# Generic error with NO completed-pass marker must resume normal scan; do not falsely complete.
c,calls,state=build_collector("OperationalError: database is locked", failed, 0, True)
assert c._initialize_racer(racer,"20261001") is False
assert calls["retry"]==0 and calls["recent"]==1 and calls["year"]==1
assert calls["complete"]==0

# ---------- schema migration / old terminal backfill ----------
with tempfile.TemporaryDirectory() as td:
    dbp=Path(td)/"x.db"
    db=BoatDB(str(dbp))
    # emulate pre-v17.232 table before collector migration
    with db.connect() as con:
        con.execute("DROP TABLE IF EXISTS course_history_initial_racers")
        con.execute('''CREATE TABLE course_history_initial_racers (
            registration_no TEXT PRIMARY KEY,name TEXT,status TEXT NOT NULL DEFAULT 'pending',
            recent_done INTEGER NOT NULL DEFAULT 0,cursor_year INTEGER,floor_date TEXT NOT NULL DEFAULT '20200101',
            target_date TEXT,candidate_count INTEGER NOT NULL DEFAULT 0,verified_count INTEGER NOT NULL DEFAULT 0,
            saved_count INTEGER NOT NULL DEFAULT 0,retry_count INTEGER NOT NULL DEFAULT 0,last_error TEXT,
            started_at TEXT,completed_at TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        con.execute("INSERT INTO course_history_initial_racers(registration_no,last_error) VALUES('3430','個別レース再試行待ち 4件（全履歴の再走査はしません）')")
    c=OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
    c.db=db; c._db_write_lock=threading.RLock(); c._status_lock=threading.RLock(); c._race_lock_guard=threading.Lock(); c._race_locks={}
    c._ensure_tables()
    with db.connect() as con:
        cols={r['name'] for r in con.execute('PRAGMA table_info(course_history_initial_racers)')}
        row=con.execute("SELECT initial_pass_done FROM course_history_initial_racers WHERE registration_no='3430'").fetchone()
    assert 'initial_pass_done' in cols and int(row['initial_pass_done'])==1

# ---------- SQLite lock tolerance ----------
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/"lock.db"))
    with db.connect() as con:
        con.execute("CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)")
        con.execute("INSERT INTO t(v) VALUES('a')")
    holder=db.connect(); holder.execute("BEGIN IMMEDIATE"); holder.execute("UPDATE t SET v='hold' WHERE id=1")
    result={"ok":False,"err":None,"elapsed":0}
    def writer():
        st=time.monotonic()
        try:
            with db.connect() as con2:
                con2.execute("UPDATE t SET v='writer' WHERE id=1")
            result['ok']=True
        except Exception as e:
            result['err']=repr(e)
        result['elapsed']=time.monotonic()-st
    th=threading.Thread(target=writer); th.start(); time.sleep(0.35); holder.commit(); holder.close(); th.join(5)
    assert result['ok'], result
    assert result['elapsed'] >= 0.25, result
    with db.connect() as con:
        mode=con.execute('PRAGMA journal_mode').fetchone()[0]
        val=con.execute('SELECT v FROM t WHERE id=1').fetchone()[0]
    assert str(mode).lower()=='wal', mode
    assert val=='writer', val

print('v17.232 validation: ALL PASS')
