from pathlib import Path
import tempfile, time, subprocess, sys
from db import BoatDB
from course_history import OfficialCourseHistoryCollector, _st_token, _archive_finish_token


def eq(a,b,msg):
    if a != b:
        raise AssertionError(f"{msg}: {a!r} != {b!r}")


def official_row(cand, reg, course=None):
    c = int(course if course is not None else cand.get('course_hint') or 1)
    return {
        'date': str(cand['date']), 'jcd': str(cand['jcd']).zfill(2), 'rno': int(cand['rno']),
        'registration_no': str(reg), 'lane': c, 'course': c,
        'finish': str(cand.get('finish_hint') or '1'), 'st_raw': str(cand.get('st_hint') or '.10'),
        'st_rank': int(cand.get('st_rank_hint') or 1), 'source': 'official-test'
    }

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    c=OfficialCourseHistoryCollector(db)

    # 1. Strict archive matrix extraction. This is the only shape eligible for prefilter skipping.
    html = """<html><body><h3>児島 一般 2025年 4月3日 ～</h3><table>
    <tr><td>4320 峰竜太</td><td>4月3日</td><td>4月4日</td></tr>
    <tr><td></td><td>12R</td><td>5R</td></tr>
    <tr><td></td><td>2</td><td>4</td></tr>
    <tr><td></td><td>.13</td><td>F.01</td></tr>
    <tr><td></td><td>(3)</td><td>(1)</td></tr>
    <tr><td></td><td>1</td><td>F</td></tr>
    </table></body></html>"""
    rows=c._parse_year_archive_candidates(html,2025)
    eq(len(rows),2,'strict matrix count')
    r={(x['date'],x['rno']):x for x in rows}
    eq((r[('20250403',12)]['course_hint'],r[('20250403',12)]['st_hint'],r[('20250403',12)]['st_rank_hint'],r[('20250403',12)]['finish_hint']), (2,'.13',3,'1'),'strict row1')
    eq((r[('20250404',5)]['course_hint'],r[('20250404',5)]['st_hint'],r[('20250404',5)]['st_rank_hint'],r[('20250404',5)]['finish_hint']), (4,'F.01',1,'F'),'strict row2 F')
    eq(_st_token('L.02'),'L.02','L preserve')
    eq(_archive_finish_token('転'),'転','special finish preserve')

    # 2. Ambiguous matrix is retained for official verification and never silently skipped.
    bad="""<html><body><h3>児島 2025年4月3日</h3><table>
    <tr><td>4月3日</td></tr><tr><td>12R</td></tr><tr><td>2</td></tr>
    <tr><td>BAD_ST</td></tr><tr><td>(3)</td></tr><tr><td>1</td></tr></table></body></html>"""
    br=c._parse_year_archive_candidates(bad,2025)
    eq(len(br),1,'ambiguous retained')
    assert 'course_hint' not in br[0]
    sel,skip=c._prefilter_needed_candidates('7001',br)
    eq((len(sel),len(skip)),(1,0),'ambiguous always selected')

    # 3. Core speed regression: 72 old candidates -> only newest 60 need official verify,
    #    and final retained DB is identical to verifying all 72.
    candidates=[]
    day=1
    for course in range(1,7):
        for k in range(12):
            # unique dates newest order within each course; all same venue.
            d=f"2025{course:02d}{12-k:02d}"
            candidates.append({'date':d,'jcd':'16','rno':1,'course_hint':course,'st_hint':'.10','st_rank_hint':1,'finish_hint':'1','hint_confidence':'strict-matrix-v1'})
    candidates=sorted(candidates,key=lambda x:(x['date'],x['rno']),reverse=True)
    sel,skip=c._prefilter_needed_candidates('7002',candidates)
    eq(len(sel),60,'prefilter selected 60')
    eq(len(skip),12,'prefilter skipped 12')

    # baseline DB verifies/saves all 72
    db2=BoatDB(str(Path(td)/'baseline.db'))
    base=OfficialCourseHistoryCollector(db2)
    for x in candidates:
        row=official_row(x,'7002')
        base._save_confirmed(row)
    # optimized DB saves only selected official-confirmed rows
    for x in sel:
        c._save_confirmed(official_row(x,'7002'))
    def keys(dbobj, table):
        with dbobj.connect() as con:
            return [(z['date'],z['jcd'],z['rno'],z['course']) for z in con.execute(f"select date,jcd,rno,course from {table} where registration_no='7002' order by course,date desc,rno desc").fetchall()]
    eq(keys(db,'racer_course_runs'),keys(db2,'racer_course_runs'),'national retained keys identical')
    eq(keys(db,'racer_local_course_runs'),keys(db2,'racer_local_course_runs'),'local retained keys identical')

    # 4. Existing saved rows reduce work further and are never deleted by prefilter.
    more=[]
    for k in range(5):
        more.append({'date':f'202407{20-k:02d}','jcd':'16','rno':2,'course_hint':1,'st_hint':'.11','st_rank_hint':2,'finish_hint':'2','hint_confidence':'strict-matrix-v1'})
    s2,k2=c._prefilter_needed_candidates('7002',more)
    eq(len(s2),0,'already-full old bucket should require zero web detail pages')

    # 5. Safety fallback: if official contradicts one strict hint, skipped rows are all verified.
    db3=BoatDB(str(Path(td)/'mismatch.db'))
    m=OfficialCourseHistoryCollector(db3)
    m._clear_failed_candidate=lambda *a,**k: None
    m._record_failed_candidate=lambda *a,**k: None
    mm=[]
    for k in range(11):
        mm.append({'date':f'202503{(31-k):02d}','jcd':'16','rno':3,'course_hint':1,'st_hint':'.10','st_rank_hint':1,'finish_hint':'1','hint_confidence':'strict-matrix-v1'})
    ms,mk=m._prefilter_needed_candidates('7003',mm)
    eq((len(ms),len(mk)),(10,1),'mismatch setup')
    calls=[]
    def mf(sess,cand,reg):
        calls.append((cand['date'],cand['jcd'],cand['rno']))
        # newest selected row contradicts archive -> activates safe fallback.
        return official_row(cand,reg,2 if len(calls)==1 else 1)
    m._fetch_official_run=mf
    m._prefilter_hint_mismatch_regs.discard('7003')
    seen=set(); started=time.monotonic()
    m._process_candidates(None,'7003','test',ms,seen,started)
    if '7003' in m._prefilter_hint_mismatch_regs:
        m._process_candidates(None,'7003','test',mk,seen,started)
    eq(len(calls),11,'hint mismatch must trigger full skipped verification')

    # 6. Nationwide/local max-10 retention remains intact.
    with db.connect() as con:
        n=con.execute("select count(*) n from racer_course_runs where registration_no='7002' and jcd='16' and course=1").fetchone()['n']
        l=con.execute("select count(*) n from racer_local_course_runs where registration_no='7002' and jcd='16' and course=1").fetchone()['n']
    eq((n,l),(10,10),'retention 10')

print('v17.221 validation: ALL PASS')
