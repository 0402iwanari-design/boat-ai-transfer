import sys, json
sys.path.insert(0, '/mnt/data/v17228_work')
from parser import parse_race_list
from boat_source import BoatRaceSource

# 1) Old broken snapshot with only R/course must NOT be considered complete.
old = {'racers': []}
for lane in range(1,7):
    old['racers'].append({'lane': lane, 'meeting_results': {
        'entries': [{'rno': 1, 'course': lane, 'st': None, 'finish': None}],
        'slots': [{'rno': 1, 'course': lane, 'st': None, 'finish': None}],
    }})
obj = BoatRaceSource.__new__(BoatRaceSource)
assert obj._meeting_results_racer_count(old) == 6
assert obj._meeting_results_complete_racer_count(old) == 0
assert obj._racelist_has_meeting_results(old) is False

# 2) Complete snapshot must remain reusable.
complete = {'racers': []}
for lane in range(1,7):
    complete['racers'].append({'lane': lane, 'meeting_results': {
        'entries': [{'rno': 1, 'course': lane, 'st': '0.12', 'finish': str((lane%6)+1)}],
    }})
assert obj._meeting_results_complete_racer_count(complete) == 6
assert obj._racelist_has_meeting_results(complete) is True

# 3) Synthetic official four-row blocks: parser must preserve R/course/ST/finish.
rows=[]
for lane in range(1,7):
    reg = 4000+lane
    # Main racer row contains profile cells, then meeting race-number visual cells.
    rows.append(f'''<tr>
      <td>{lane}</td><td>{reg} / B1 選手{lane}</td><td>東京/東京</td><td>40歳/52.0kg</td>
      <td>{lane}R</td><td>{lane+1 if lane<6 else 7}R</td><td>6R</td>
    </tr>''')
    rows.append(f'<tr><td>{lane}</td><td>{(lane%6)+1}</td><td>2</td></tr>')
    rows.append(f'<tr><td>.0{lane}</td><td>.1{lane}</td><td>.20</td></tr>')
    rows.append(f'<tr><td>{(lane%6)+1}</td><td>{lane}</td><td>3</td></tr>')
html = '<html><body><table>' + ''.join(rows) + '</table></body></html>'
parsed = parse_race_list(html, meeting_day_no=3)
assert len(parsed['racers']) == 6, len(parsed['racers'])
for racer in parsed['racers']:
    m = racer.get('meeting_results') or {}
    assert m.get('entries'), racer
    assert any(x.get('finish') not in (None,'') for x in m['entries']), m
    assert any(x.get('st') not in (None,'') for x in m['entries']), m

# 4) UI still renders four rows, including finish.
text=open('/mnt/data/v17228_work/static/index.html',encoding='utf-8').read()
assert 'row("finish",v=>`<span class="meeting-finish">${v}着</span>`)' in text
assert 'row("st",v=>' in text
assert 'v17.228' in text

print('v17.228 validation: ALL PASS')
