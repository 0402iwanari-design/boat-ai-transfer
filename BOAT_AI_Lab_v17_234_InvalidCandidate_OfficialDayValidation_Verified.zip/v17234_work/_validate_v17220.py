from pathlib import Path
import tempfile, time
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

def assert_eq(a,b,msg):
    if a!=b:
        raise AssertionError(f"{msg}: {a!r} != {b!r}")

with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    c=OfficialCourseHistoryCollector(db)

    html = """<html><body><h3>児島一般テスト2025年 4月3日 ～</h3><table>
    <tr><td>4320 峰竜太</td><td>4月3日</td><td>4月4日</td></tr>
    <tr><td></td><td>12R</td><td>5R</td></tr>
    <tr><td></td><td>2</td><td>4</td></tr>
    <tr><td></td><td>.13</td><td>.09</td></tr>
    <tr><td></td><td>(3)</td><td>(1)</td></tr>
    <tr><td></td><td>1</td><td>3</td></tr>
    </table></body></html>"""
    rows=c._parse_year_archive_candidates(html,2025)
    assert_eq(len(rows),2,'strict matrix candidate count')
    got={(x['date'],x['rno']):(x.get('course_hint'),x.get('st_hint'),x.get('st_rank_hint'),x.get('finish_hint')) for x in rows}
    assert_eq(got[('20250403',12)],(2,'.13',3,'1'),'strict hint race1')
    assert_eq(got[('20250404',5)],(4,'.09',1,'3'),'strict hint race2')
    assert all(x.get('hint_confidence')=='strict-matrix-v1' for x in rows)

    bad = """<html><body><h3>児島一般テスト2025年 4月3日 ～</h3><table>
    <tr><td>4月3日</td></tr><tr><td>12R</td></tr><tr><td>2</td></tr>
    <tr><td>NOT_ST</td></tr><tr><td>(3)</td></tr><tr><td>1</td></tr></table></body></html>"""
    br=c._parse_year_archive_candidates(bad,2025)
    assert_eq(len(br),1,'ambiguous candidate retained')
    assert 'course_hint' not in br[0], 'ambiguous structure incorrectly got skip hint'

    c._clear_failed_candidate=lambda *a,**k: None
    c._record_failed_candidate=lambda *a,**k: None
    c._stop.clear()

    c._summary_counts=lambda reg: ({i:(10 if i==2 else 0) for i in range(1,7)}, {('16',2):10})
    fetch_calls=[]
    c._fetch_official_run=lambda sess,cand,reg: fetch_calls.append(cand) or None
    c._save_confirmed=lambda row: 0
    cand={'date':'20250403','jcd':'16','rno':12,'course_hint':2,'hint_confidence':'strict-matrix-v1'}
    c._process_candidates(None,'4320','峰竜太',[cand],set(),time.monotonic())
    assert_eq(len(fetch_calls),0,'full strict hinted bucket should skip official')

    c._summary_counts=lambda reg: ({i:(10 if i==2 else 0) for i in range(1,7)}, {('16',2):9})
    fetch_calls=[]
    c._fetch_official_run=lambda sess,cand,reg: fetch_calls.append(cand) or None
    c._process_candidates(None,'4320','峰竜太',[cand],set(),time.monotonic())
    assert_eq(len(fetch_calls),1,'local shortage must fetch official')

    c._summary_counts=lambda reg: ({i:10 for i in range(1,7)}, {('16',i):(10 if i!=6 else 9) for i in range(1,7)})
    fetch_calls=[]
    nohint={'date':'20250403','jcd':'16','rno':12}
    c._fetch_official_run=lambda sess,cand,reg: fetch_calls.append(cand) or None
    c._process_candidates(None,'4320','峰竜太',[nohint],set(),time.monotonic())
    assert_eq(len(fetch_calls),1,'no hint must fall back to official')

    c._summary_counts=lambda reg: ({i:0 for i in range(1,7)}, {})
    saved=[]
    c._fetch_official_run=lambda sess,cand,reg: {'date':cand['date'],'jcd':cand['jcd'],'rno':cand['rno'],
        'registration_no':reg,'lane':4,'course':3,'finish':'1','st_raw':'.17','st_rank':2,'source':'official-test'}
    c._save_confirmed=lambda row: saved.append(dict(row)) or 1
    wronghint={'date':'20250812','jcd':'23','rno':6,'course_hint':4,'hint_confidence':'strict-matrix-v1'}
    c._process_candidates(None,'4320','峰竜太',[wronghint],set(),time.monotonic())
    assert_eq(saved[0]['course'],3,'official course must override archive hint')

    runs=[]
    for i in range(12):
        runs.append({'date':f'202501{(i+1):02d}','jcd':'16','rno':1,'registration_no':'9999','lane':1,
                     'course':1,'finish':'1','st_raw':'.10','st_rank':1,'source':'test'})
    db.save_course_history_runs(runs,keep_per_local_course=10)
    db.save_local_course_history_runs(runs,keep_per_course=10)
    with db.connect() as con:
        n=con.execute("select count(*) from racer_course_runs where registration_no='9999' and course=1").fetchone()[0]
        l=con.execute("select count(*) from racer_local_course_runs where registration_no='9999' and jcd='16' and course=1").fetchone()[0]
    assert_eq(n,10,'national retention')
    assert_eq(l,10,'local retention')

print('v17.220 validation: ALL PASS')
