from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from course_history import OfficialCourseHistoryCollector

# Test queue priority without touching DB.
c=OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
states={
 '1': {'status':'complete','started_at':'x','retry_count':0,'last_error':None},
 '2': {'status':'pending','started_at':None,'retry_count':0,'last_error':None},
 '3': {'status':'pending','started_at':None,'retry_count':0,'last_error':None},
 '4': {'status':'pending','started_at':'x','retry_count':2,'last_error':'boom'},
 '5': {'status':'pending','started_at':'x','retry_count':0,'last_error':None},
}
c._state=lambda reg: states.get(str(reg))
racers=[{'registration_no':str(i)} for i in range(1,6)]
q,mode=c._priority_pending_today(racers)
assert mode=='未着手優先'
assert [x['registration_no'] for x in q]==['2','3']
# After all never-started racers are gone, clean pending must still beat retry racers.
states['2']['started_at']='x'; states['3']['started_at']='x'
q,mode=c._priority_pending_today(racers)
assert mode=='通常未完了優先'
assert [x['registration_no'] for x in q]==['2','3','5']
# Then retries are last.
for k in ('2','3','5'): states[k]['status']='complete'
q,mode=c._priority_pending_today(racers)
assert mode=='エラー再試行フェーズ'
assert [x['registration_no'] for x in q]==['4']

html=(ROOT/'static'/'index.html').read_text()
assert 'v17.227 未着手優先＋エラー最後回し版' in html
assert '<details style=' in html
assert 'エラー・再試行待ち ${errCount}人（詳細を開く）' in html
assert '現在フェーズ：${escapeHtml(String(s.today_queue_mode||""))}' in html
app=(ROOT/'app.py').read_text()
assert 'version="1.0.227"' in app
assert '"version": "1.0.227"' in app
print('v17.227 validation: ALL PASS')
