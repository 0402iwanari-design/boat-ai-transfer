BOAT AI Lab v17.234

公式結果ページ解析0件の根本原因として、古い日本語HTMLを requests.Response.text の推定文字コードだけで読んでいた問題を修正。
公式結果HTMLは複数文字コード候補から BOAT RACE 固有ラベルを最も正しく復元できるデコードを自動選択してから解析する。

v17.232 の「失敗個別レースだけ再試行」「SQLite WAL + busy_timeout」は維持。
解析失敗時には enc / bytes / スタート情報 / ボートレーサー / 登録番号数 / ST数をエラー詳細へ付加する。

詳細: VALIDATION_v17_233_OFFICIAL_ENCODING_FIX.txt
