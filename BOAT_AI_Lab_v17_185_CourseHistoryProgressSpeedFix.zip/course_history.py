from __future__ import annotations

"""Nationwide/current-venue actual-entry-course history collection (v17.185).

Collection plan
---------------
* 00:00-23:59 JST: only racers appearing in today's saved official racelists are targets.
* For each racer, only nationwide 1-6 course history + the venue they are racing at today
  is required for completion. The other 23 venues are never completion targets.
* One official nationwide daily K file is fetched, then shared across every active target.
  A racer's row is saved once and can simultaneously contribute to nationwide and local history.
* Each target stops as soon as all required nationwide/current-venue course buckets reach 10.
  If a course has fewer than 10 lifetime starts, the scan stops at that racer's debut-term floor
  and the available number is accepted as complete.
* Success/no-data day: 10-second pause. Fetch failure: 60-second retry, max 3 attempts.
  After 3 failures that racer/venue target is shown as an error and is not retried again that day.
* Confirmed live race results continue to update the same history table with no extra web access.
* The scheduler's periodic checks are SQLite-only. It accesses the official history source only
  when a new/incomplete target actually exists.
"""

import io
import re
import threading
import time
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
HISTORY_FLOOR = "20020101"
SUCCESS_PAUSE_SECONDS = 10
RETRY_PAUSE_SECONDS = 60
MAX_FETCH_ATTEMPTS = 3
LOCAL_TARGET_CHECK_SECONDS = 300  # SQLite-only check; no web request when there is no target.

VENUES = [
    "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
    "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村",
]
VENUE_CODE = {name: f"{i:02d}" for i, name in enumerate(VENUES, 1)}


def _registration_term_floor(period: int) -> str:
    period = int(period)
    reference_period = 136
    reference_month_index = 2025 * 12 + 4  # May 2025
    month_index = reference_month_index - (reference_period - period) * 6
    year, month0 = divmod(month_index, 12)
    return f"{year:04d}{month0 + 1:02d}01"


def _norm(s: str) -> str:
    return re.sub(r"[\s　]+", "", str(s or "")).replace("ボートレース", "")


def _st_number(raw: str):
    s = str(raw or "").strip().upper().replace("０", "0")
    if not s:
        return None
    m = re.fullmatch(r"F\s*([0-9]*\.?[0-9]+)", s)
    if m:
        try: return -float(m.group(1))
        except ValueError: return None
    if s.startswith("L"):
        return None
    try:
        v = float(s)
        return v if -1 < v < 2 else None
    except ValueError:
        return None


def parse_k_text(text: str, yyyymmdd: str) -> list[dict]:
    """Parse official K text. 3連単 is intentionally not stored."""
    rows, race_rows = [], []
    jcd = rno = None
    in_result_rows = False

    def flush_race():
        nonlocal race_rows
        if not race_rows: return
        numeric = [(i, _st_number(x.get("st_raw"))) for i, x in enumerate(race_rows)]
        numeric = [(i,v) for i,v in numeric if v is not None]
        numeric.sort(key=lambda z:z[1])
        last, rank = None, 0
        for pos,(idx,value) in enumerate(numeric,1):
            if last is None or abs(value-last)>1e-9:
                rank, last = pos, value
            race_rows[idx]["st_rank"] = rank
        rows.extend(race_rows); race_rows=[]

    for raw_line in text.splitlines():
        line=raw_line.rstrip("\r\n"); compact=_norm(line)
        for name,code in sorted(VENUE_CODE.items(),key=lambda kv:len(kv[0]),reverse=True):
            if name in compact and ("成績" in compact or "ボートレース" in line):
                flush_race(); jcd=code; rno=None; in_result_rows=False; break
        m_race=re.match(r"^\s*(\d{1,2})R\s+.*H\s*\d+",line,re.I)
        if m_race:
            flush_race(); rno=int(m_race.group(1)); in_result_rows=False; continue
        if "スタートタイミンク" in line or "スタートタイミング" in line:
            in_result_rows=True; continue
        if not in_result_rows or not jcd or not rno: continue
        if not line.strip() or set(line.strip()) <= {"-"}:
            if race_rows and not line.strip(): flush_race(); in_result_rows=False
            continue
        finish=lane=reg=entry=st_raw=None
        if len(line)>=48:
            finish=line[2:4].strip(); lane=line[6:7].strip(); reg=line[8:12].strip()
            entry=line[38:39].strip(); st_raw=line[43:47].strip()
        if not (lane and lane.isdigit() and reg and reg.isdigit() and entry and entry.isdigit()):
            m=re.match(r"^\s*(\S{1,2})\s+([1-6])\s+(\d{4})\s+(.+?)\s+(\d{1,2})\s+(\d{1,2})\s+(\d\.\d{2})\s+([1-6])\s+(\S+)",line)
            if not m: continue
            finish,lane,reg,entry,st_raw=m.group(1),m.group(2),m.group(3),m.group(8),m.group(9)
        try: lane_i,course_i=int(lane),int(entry)
        except (TypeError,ValueError): continue
        if not (1<=lane_i<=6 and 1<=course_i<=6): continue
        race_rows.append({"date":yyyymmdd,"jcd":jcd,"rno":rno,"registration_no":str(reg),
                          "lane":lane_i,"course":course_i,"finish":str(finish or "").lstrip("0") or "0",
                          "st_raw":str(st_raw or "").strip(),"st_rank":None,
                          "source":"official-k-download-backfill"})
    flush_race(); return rows


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db=db; self._thread=None; self._stop=threading.Event()
        self.status={"phase":"本日の出走表待ち","total_racers":0,"pending_racers":0,"stored_runs":0,"errors":[]}

    @staticmethod
    def _in_window(now: datetime) -> bool:
        return dt_time(0,0) <= now.time() <= dt_time(23,59,59,999999)

    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,name="course-history-target-backfill",daemon=True)
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            now=datetime.now(JST)
            today=now.strftime("%Y%m%d")
            if self._in_window(now):
                try: self._run_target_window(today)
                except Exception as exc:
                    self.status={**self.db.get_course_history_target_status(today),"phase":"収集処理エラー","scheduler_error":f"{type(exc).__name__}: {exc}"}
                # This wait only re-checks today's SQLite racelists for newly discovered targets.
                # No official history request occurs unless an incomplete target exists.
                self._stop.wait(LOCAL_TARGET_CHECK_SECONDS)
            else:
                self._stop.wait(60)

    def _fetch_day(self, session: requests.Session, cursor):
        ymd=cursor.strftime("%Y%m%d"); yy=cursor.strftime("%y%m%d")
        url=f"https://www1.mbrace.or.jp/od2/K/{cursor:%Y%m}/k{yy}.lzh"
        last_error=None
        for attempt in range(1,MAX_FETCH_ATTEMPTS+1):
            if self._stop.is_set() or not self._in_window(datetime.now(JST)): return "window_end",[],None
            try:
                r=session.get(url,timeout=20)
                if r.status_code==404: return "no_data",[],None
                r.raise_for_status()
                try: import lhafile
                except ImportError as exc: raise RuntimeError("lhafile が未導入です。requirements.txt から再デプロイしてください") from exc
                archive=lhafile.Lhafile(io.BytesIO(r.content)); names=archive.namelist()
                if not names: raise RuntimeError("公式Kファイルを展開できませんでした")
                raw=archive.read(names[0])
                return "ok",parse_k_text(raw.decode("cp932",errors="replace"),ymd),None
            except Exception as exc:
                last_error=f"{type(exc).__name__}: {exc}"
                if attempt<MAX_FETCH_ATTEMPTS: self._stop.wait(RETRY_PAUSE_SECONDS)
        return "error",[],last_error

    def _resolve_target_floor(self, session: requests.Session, target: dict) -> str:
        reg=str(target.get("registration_no") or ""); jcd=str(target.get("jcd") or "").zfill(2)
        existing=str(target.get("floor_date") or HISTORY_FLOOR)
        if existing!=HISTORY_FLOOR: return existing
        period=self.db.get_course_history_profile_period(reg)
        if period is None:
            try:
                r=session.get(f"https://www.boatrace.jp/owpc/pc/data/racersearch/profile?toban={reg}",timeout=20)
                r.raise_for_status(); text=BeautifulSoup(r.content,"html.parser").get_text(" ",strip=True)
                m=re.search(r"登録期\s*[:：]?\s*(\d{2,3})\s*期",text)
                if m: period=int(m.group(1))
            except Exception: period=None
        if period is None: return existing
        floor=_registration_term_floor(period)
        self.db.set_course_history_target_floor(reg,jcd,floor,period)
        return floor

    def _finish_ready_or_floor(self, today: str):
        pending=self.db.get_course_history_pending_targets(today); done=[]
        for x in pending:
            key=(str(x["registration_no"]),str(x["jcd"]).zfill(2))
            cursor=str(x.get("cursor_date") or ""); floor=str(x.get("floor_date") or HISTORY_FLOOR)
            if self.db.course_history_target_has_ten(*key) or (cursor and cursor<floor): done.append(key)
        self.db.complete_course_history_targets(done)
        return done

    def _run_target_window(self, today: str):
        now=datetime.now(JST); start_date=(now.date()-timedelta(days=1)).strftime("%Y%m%d")
        self.db.ensure_course_history_today_targets(today,start_date,HISTORY_FLOOR)
        self.status=self.db.get_course_history_target_status(today)
        targets=self.db.get_course_history_pending_targets(today)
        if not targets: return

        session=requests.Session(); session.headers.update({"User-Agent":"BOAT-AI-Lab/1.0 official-result-history-current-racers"})
        for target in targets:
            if self._stop.is_set() or not self._in_window(datetime.now(JST)): return
            self._resolve_target_floor(session,target)
        self._finish_ready_or_floor(today)

        while self._in_window(datetime.now(JST)) and not self._stop.is_set():
            self._finish_ready_or_floor(today)
            current=self.db.get_course_history_pending_targets(today)
            if not current: break
            cursor_text=max(str(x.get("cursor_date") or start_date) for x in current)
            cursor=datetime.strptime(cursor_text,"%Y%m%d").date(); ymd=cursor.strftime("%Y%m%d")
            active=[x for x in current if str(x.get("cursor_date") or start_date)==ymd and ymd>=str(x.get("floor_date") or HISTORY_FLOOR)]
            if not active:
                self._finish_ready_or_floor(today); continue
            active_regs={str(x["registration_no"]) for x in active}
            active_keys=[(str(x["registration_no"]),str(x["jcd"]).zfill(2)) for x in active]
            state,rows,error=self._fetch_day(session,cursor)
            if state=="window_end": break
            if state=="error":
                self.db.mark_course_history_target_errors(active_keys,ymd,error or "取得失敗",MAX_FETCH_ATTEMPTS)
                self.status=self.db.get_course_history_target_status(today)
                # Other targets with a different cursor may continue on the next local scheduler pass;
                # these failed keys themselves are not retried again today.
                return
            if state=="ok" and rows:
                filtered=[x for x in rows if str(x.get("registration_no") or "") in active_regs]
                self.db.save_course_history_runs(filtered,keep_per_local_course=10)
            # Targets that now have all 10x(全国+本日の場) finish immediately.
            ready=[k for k in active_keys if self.db.course_history_target_has_ten(*k)]
            self.db.complete_course_history_targets(ready)
            ready_set=set(ready)
            remaining=[k for k in active_keys if k not in ready_set]
            next_date=(cursor-timedelta(days=1)).strftime("%Y%m%d")
            self.db.advance_course_history_targets(remaining,next_date)
            self._finish_ready_or_floor(today)
            self.status=self.db.get_course_history_target_status(today)
            self._stop.wait(SUCCESS_PAUSE_SECONDS)
        self.status=self.db.get_course_history_target_status(today)
