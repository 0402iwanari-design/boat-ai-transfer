from __future__ import annotations

from datetime import date, timedelta
import tempfile
import json
from pathlib import Path
import sqlite3
import unittest

from statistical_ai import (Store, formation, parse_combo, positive_yen, _coverage,
                            feature_map, import_csv_day, analyze_venue, sync_days,
                            import_local_db, inspect_formation)


class StatisticalAITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'new.db')

    def tearDown(self):
        self.temp.cleanup()

    def test_exact_formation_expansion(self):
        self.assertEqual(formation([1], [2, 3], [2, 3, 4]),
                         {'1-2-3', '1-2-4', '1-3-2', '1-3-4'})
        self.assertEqual(len(formation([1], [2, 3, 4], [2, 3, 4])), 6)
        with self.assertRaises(ValueError):
            formation([1], [1], [1])
        with self.assertRaises(ValueError):
            formation([1], [2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6], maximum=13)

    def test_bad_combo_and_payoff(self):
        self.assertIsNone(parse_combo('1-1-3'))
        self.assertIsNone(parse_combo('1-2-7'))
        self.assertIsNone(parse_combo('1-2-3;DROP'))
        self.assertEqual(parse_combo('１－２－３'), '1-2-3')
        self.assertIsNone(positive_yen('abc'))
        self.assertEqual(positive_yen('1,250円'), 1250)

    def test_formation_roi_is_group_whole(self):
        rows = [{'combo': '1-2-3', 'payout_yen': 1600},
                {'combo': '2-3-1', 'payout_yen': 999999}]
        report = _coverage(rows, formation([1], [2, 3], [2, 3, 4]))
        self.assertEqual(report['races'], 2)
        self.assertEqual(report['hits'], 1)
        self.assertEqual(report['hit_rate'], 50)
        self.assertEqual(report['total_stake_yen'], 800)
        self.assertEqual(report['total_payout_yen'], 1600)
        self.assertEqual(report['roi'], 200)

    def one_day(self, day='2026-11-01', combo='1-2-3', payout='2000', scratched=False):
        key = day.replace('-', '') + '1209'
        race = {'レースコード': key, 'レース日': day,
                '締切時刻': '19:25', '1着_艇番': '1', '2着_艇番': '2', '3着_艇番': '3'}
        race.update({f'{i}着_艇番': str(i) for i in range(4, 7)})
        if scratched: race['6着_艇番'] = ''
        return {
            'results/realtime': [race],
            'results/payouts': [{'レースコード': key, '3連単_組番': combo, '3連単_払戻金': payout}],
            'programs/race_cards': [{'レースコード': key, '艇1_級別': 'A1', '艇2_級別': 'B1', '艇1_全国平均ST': '0.12'}],
            'programs/title': [{'レースコード': key, 'グレード': 'G1'}],
            'previews/sui': [{'レースコード': key, 'レース日': day, '取得日時': f'{day}T19:20:00+09:00',
                              '天候':'1', '風速(m)': '4', '風向':'2', '波の高さ(cm)': '3'}],
        }

    def test_pre_race_join_and_provenance(self):
        out = import_csv_day(self.store, '2026-11-01', self.one_day())
        self.assertEqual(out['imported'], 1)
        r = self.store.read_venue('12')[0]
        self.assertEqual(r['features']['season'], '11-03')
        self.assertEqual(r['features']['race_band'], '9-12')
        self.assertEqual(r['features']['lane1_class'], 'A1')
        self.assertEqual(r['features']['wind_speed'], '4-5')
        self.assertEqual(r['payout_yen'], 2000)

    def test_after_deadline_weather_not_leaked(self):
        day = self.one_day()
        day['previews/sui'][0]['取得日時'] = '2026-11-01T19:30:00+09:00'
        import_csv_day(self.store, '2026-11-01', day)
        self.assertNotIn('wind_speed', self.store.read_venue('12')[0]['features'])

    def test_missing_or_mismatched_payout_refused(self):
        day = self.one_day(combo='1-2-4')
        out = import_csv_day(self.store, '2026-11-01', day)
        self.assertEqual(out['imported'], 0)
        self.assertEqual(out['skipped']['invalid_result_payout'], 1)
        day = self.one_day(scratched=True)
        out = import_csv_day(self.store, '2026-11-01', day)
        self.assertEqual(out['imported'], 0)
        self.assertEqual(out['skipped']['incomplete_six_boats'], 1)

    def test_import_is_idempotent_and_payout_corrections(self):
        d = self.one_day()
        import_csv_day(self.store, '2026-11-01', d)
        d['results/payouts'][0]['3連単_払戻金'] = '3300'
        import_csv_day(self.store, '2026-11-01', d)
        rows = self.store.read_venue('12')
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['payout_yen'], 3300)

    def test_separate_db_and_only_validated_candidates(self):
        records = []
        for k in range(40):
            day = (date(2026, 1, 1) + timedelta(days=k)).isoformat()
            for rno in range(1, 9):
                key = f"{day.replace('-', '')}12{rno:02d}"
                features = feature_map(day, rno, grade='一般', racers={1: {'class': 'A1'}})
                records.append({'key': key, 'day': day, 'venue': '12', 'rno': rno,
                                'combo': '1-2-3', 'payout_yen': 1400,
                                'features': json.dumps(features), 'source': 'fixture'})
        self.store.upsert(records)
        result = analyze_venue(self.store, '12', min_train=60, min_test=24)
        self.assertEqual(result['status'], 'analyzed')
        self.assertGreater(len(result['candidates']), 0)
        self.assertTrue(all(x['train']['hits'] > 0 and x['validation']['hits'] > 0
                            for x in result['candidates']))
        self.assertTrue(all(x['validation']['total_payout_yen'] / x['validation']['total_stake_yen'] >= 1
                            for x in result['candidates']))
        self.assertEqual(self.store.report('12')['venue'], '12')
        self.assertEqual(analyze_venue(self.store, '10', min_train=60, min_test=24)['status'], 'not_enough_data')

    def test_manual_formation_with_conditions(self):
        day = self.one_day()
        import_csv_day(self.store, '2026-11-01', day)
        result = inspect_formation(self.store, '12', '1-23-234',
                                   {'season': '11-03', 'race_band': '9-12'})
        self.assertEqual(result['historical']['hits'], 1)
        self.assertEqual(result['historical']['total_stake_yen'], 400)
        self.assertEqual(result['historical']['total_payout_yen'], 2000)
        self.assertEqual(result['historical']['roi'], 500)
        no_data = inspect_formation(self.store, '12', '1-23-234', {'season': '04-10'})
        self.assertEqual(no_data['historical']['races'], 0)
        self.assertIsNone(no_data['historical']['roi'])
        with self.assertRaises(ValueError):
            inspect_formation(self.store, '12', '1-23-234', {'result': '1-2-3'})

    def test_local_db_read_only(self):
        path = Path(self.temp.name) / 'original.db'
        with sqlite3.connect(path) as con:
            con.executescript('''
            CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,payload TEXT);
            CREATE TABLE race_snapshots(date TEXT,jcd TEXT,rno INTEGER,kind TEXT,payload TEXT,captured_at TEXT);
            CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER,deadline TEXT);
            CREATE TABLE venue_event_meta(date TEXT,jcd TEXT,event_grade TEXT);
            CREATE TABLE tide_race_context(date TEXT,jcd TEXT,rno INTEGER,tide_phase TEXT,created_at TEXT);
            ''')
            con.execute('INSERT INTO race_results VALUES (?,?,?,?,?,?)', ('2026-11-01','12',9,'1-2-3',1500,
                        json.dumps({'finishers':[{'lane':n,'finish':n} for n in range(1,7)]})))
            con.execute('INSERT INTO race_schedule VALUES (?,?,?,?)', ('2026-11-01','12',9,'19:25'))
            con.execute('INSERT INTO venue_event_meta VALUES (?,?,?)', ('2026-11-01','12','G1'))
            con.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',
                        ('2026-11-01','12',9,'racelist',json.dumps({'racers':[
                            {'lane':1,'class':'A1','avg_st':0.12}]}),'2026-11-01 09:30:00'))
            con.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',
                        ('2026-11-01','12',9,'beforeinfo',json.dumps({'weather':{
                            'wind_speed_m':3}}),'2026-11-01 10:15:00'))
        con.close()
        result = import_local_db(self.store, path)
        self.assertEqual(result['imported'], 1)
        self.assertEqual(self.store.read_venue('12')[0]['features']['lane1_class'], 'A1')
        self.assertEqual(self.store.read_venue('12')[0]['features']['wind_speed'], '2-3')
        with sqlite3.connect(path) as con:
            self.assertEqual(con.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0],5)
        con.close()

if __name__ == '__main__':
    unittest.main(verbosity=2)
