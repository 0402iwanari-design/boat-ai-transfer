from __future__ import annotations
"""v17.216: all-today-racers one-time historical initialization + live result maintenance.

UI progress enhancement: expose the current racer's local-course counts for today's venue(s) alongside nationwide counts.

Fixed collection flow (same racer-first flow validated with 峰竜太4320):
  1) Target ONLY racers appearing in today's saved official racelists.
  2) For a racer not initialized before, open that RACER'S OWN history first.
  3) For each candidate race, open the BOAT RACE official result page.
  4) Determine actual entry course from official スタート情報 order.
  5) Save the same confirmed run into:
       - nationwide history (racer_course_runs)
       - that venue's local history (racer_local_course_runs)
     Each venue/course keeps at most newest 10 rows; nationwide display reconstructs
     the newest 10 across all venues.
  6) Continue newest -> oldest through 2020-01-01 so every venue/course can be
     initialized as far as the agreed floor allows.
  7) Mark the racer initialized. That racer is NEVER historically crawled again.
  8) After initialization, newly confirmed official race results maintain both
     nationwide + local histories incrementally; DB trimming removes the oldest row.

One failed race does not abort the whole racer scan. A source/year fetch failure leaves
that racer unfinished so the scheduler can retry later. No all-racer/all-venue reset is done.
"""

import json
import re
import threading
import time
import unicodedata
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
FLOOR_DATE = "20200101"
FLOOR_YEAR = 2020
VENUES = [
    "桐生", "戸田", "江戸川", "平和島", "多摩川", "浜名湖", "蒲郡", "常滑", "津", "三国", "びわこ", "住之江",
    "尼崎", "鳴門", "丸亀", "児島", "宮島", "徳山", "下関", "若松", "芦屋", "福岡", "唐津", "大村",
]
VENUE_CODE = {n: f"{i:02d}" for i, n in enumerate(VENUES, 1)}


def _nfkc(s):
    return unicodedata.normalize("NFKC", str(s or ""))


def _norm(s):
    return re.sub(r"[\s\u3000]+", "", _nfkc(s))


def _venue_code(s):
    n = _norm(s)
    for name, code in VENUE_CODE.items():
        if _norm(name) == n:
            return code
    for name, code in VENUE_CODE.items():
        if _norm(name) in n:
            return code
    return None


def _date_token(s, year):
    text = _nfkc(s)
    m = re.search(r"(?<!\d)(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})(?!\d)", text)
    if not m:
        m = re.search(r"(?<!\d)(?:(\d{4})年)?\s*(\d{1,2})月\s*(\d{1,2})日", text)
    if not m:
        return None
    y = int(m.group(1) or year)
    return f"{y:04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def _race_token(s):
    m = re.fullmatch(r"\s*(\d{1,2})\s*R\s*", _nfkc(s), re.I)
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 12 else None


def _st_value(s):
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return float("0" + t)
    m = re.fullmatch(r"F\.(\d{1,2})", t)
    if m:
        return -float("0." + m.group(1))
    m = re.fullmatch(r"L\.(\d{1,2})", t)
    if m:
        return float("0." + m.group(1))
    return None


def _finish_token(s):
    t = _norm(s).replace("着", "")
    return t if re.fullmatch(r"[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠", t) else None


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = {
            "phase": "本日の出走選手待ち",
            "validation_mode": "v17.216 当日出走選手のみ・初回1度だけ履歴構築→以後は結果差分更新・全体進捗＋当地進捗表示",
        }
        self._ensure_tables()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._scheduler, daemon=True, name="course-history-today-racers-once")
        self._thread.start()

    def _ensure_tables(self):
        with self.db.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS racer_local_course_runs (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, lane INTEGER, course INTEGER NOT NULL,
                finish TEXT, st_raw TEXT, st_rank INTEGER, source TEXT,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_racer_local_course_runs_lookup
                           ON racer_local_course_runs(registration_no,jcd,course,date DESC)""")
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_initial_racers (
                registration_no TEXT PRIMARY KEY,
                name TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                recent_done INTEGER NOT NULL DEFAULT 0,
                cursor_year INTEGER,
                floor_date TEXT NOT NULL DEFAULT '20200101',
                target_date TEXT,
                candidate_count INTEGER NOT NULL DEFAULT 0,
                verified_count INTEGER NOT NULL DEFAULT 0,
                saved_count INTEGER NOT NULL DEFAULT 0,
                retry_count INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                started_at TEXT,
                completed_at TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_course_history_initial_status
                           ON course_history_initial_racers(status,registration_no)""")

    def _scheduler(self):
        while not self._stop.is_set():
            today = datetime.now(JST).strftime("%Y%m%d")
            try:
                self._run(today)
            except Exception as e:
                self.status.update({
                    "phase": "コース履歴初期構築エラー",
                    "scheduler_error": f"{type(e).__name__}: {e}",
                })
            self._stop.wait(20)

    def _today_racers(self, today):
        """Read only today's already-saved official racelists; no web access here."""
        racers = {}
        with self.db.connect() as con:
            rows = con.execute(
                "SELECT jcd,payload FROM race_snapshots WHERE date=? AND kind='racelist'",
                (str(today),),
            ).fetchall()
        for row in rows:
            jcd = str(row["jcd"] or "").zfill(2)
            try:
                payload = json.loads(row["payload"] or "{}")
            except Exception:
                continue
            for x in payload.get("racers") or []:
                reg = str(x.get("registration_no") or "").strip()
                name = str(x.get("name") or "").strip()
                if not reg:
                    continue
                item = racers.setdefault(reg, {"registration_no": reg, "name": name, "today_venues": set()})
                if name:
                    item["name"] = name
                if jcd:
                    item["today_venues"].add(jcd)
        out = []
        for x in racers.values():
            x["today_venues"] = sorted(x["today_venues"])
            out.append(x)
        return sorted(out, key=lambda z: z["registration_no"])

    def _register_today_targets(self, today, racers):
        current_year = datetime.now(JST).year
        with self.db.connect() as con:
            for x in racers:
                con.execute("""
                    INSERT INTO course_history_initial_racers
                    (registration_no,name,status,recent_done,cursor_year,floor_date,target_date)
                    VALUES(?,?,'pending',0,?,?,?)
                    ON CONFLICT(registration_no) DO UPDATE SET
                      name=CASE WHEN excluded.name!='' THEN excluded.name ELSE course_history_initial_racers.name END,
                      target_date=excluded.target_date,
                      updated_at=CURRENT_TIMESTAMP
                """, (x["registration_no"], x.get("name") or "", current_year, FLOOR_DATE, str(today)))

    def _state(self, reg):
        with self.db.connect() as con:
            row = con.execute("SELECT * FROM course_history_initial_racers WHERE registration_no=?", (str(reg),)).fetchone()
        return dict(row) if row else None

    def _pending_today(self, racers):
        out = []
        for x in racers:
            s = self._state(x["registration_no"])
            if not s or s.get("status") != "complete":
                out.append(x)
        return out


    def _today_status_overview(self, racers):
        regs = [str(x.get("registration_no") or "").strip() for x in (racers or []) if str(x.get("registration_no") or "").strip()]
        if not regs:
            return {"complete": 0, "running": 0, "error": 0, "unstarted": 0, "queued": 0, "errors": []}
        placeholders = ",".join("?" for _ in regs)
        with self.db.connect() as con:
            rows = con.execute(f"""SELECT registration_no,name,status,retry_count,last_error,started_at,completed_at
                                  FROM course_history_initial_racers
                                  WHERE registration_no IN ({placeholders})""", regs).fetchall()
        by = {str(r["registration_no"]): dict(r) for r in rows}
        complete = running = error = unstarted = queued = 0
        errors = []
        for x in racers:
            reg = str(x.get("registration_no") or "")
            r = by.get(reg)
            if not r or not r.get("started_at"):
                unstarted += 1
                continue
            if r.get("status") == "complete":
                complete += 1
            elif r.get("status") == "running":
                running += 1
            elif r.get("last_error") or int(r.get("retry_count") or 0) > 0:
                error += 1
                errors.append({"registration_no": reg, "name": r.get("name") or x.get("name") or reg,
                               "error": str(r.get("last_error") or "再試行待ち")[:160],
                               "retry_count": int(r.get("retry_count") or 0)})
            else:
                queued += 1
        return {"complete": complete, "running": running, "error": error, "unstarted": unstarted,
                "queued": queued, "errors": errors[-8:]}

    def _mark_started(self, reg, name, today):
        with self.db.connect() as con:
            con.execute("""UPDATE course_history_initial_racers
                           SET name=?,status='running',target_date=?,started_at=COALESCE(started_at,CURRENT_TIMESTAMP),
                               last_error=NULL,updated_at=CURRENT_TIMESTAMP
                           WHERE registration_no=?""", (name or "", str(today), str(reg)))

    def _mark_recent_done(self, reg):
        with self.db.connect() as con:
            con.execute("UPDATE course_history_initial_racers SET recent_done=1,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?", (str(reg),))

    def _advance_year(self, reg, next_year, add_candidates=0, add_verified=0, add_saved=0):
        with self.db.connect() as con:
            con.execute("""UPDATE course_history_initial_racers SET cursor_year=?,
                           candidate_count=candidate_count+?,verified_count=verified_count+?,saved_count=saved_count+?,
                           last_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (int(next_year), int(add_candidates), int(add_verified), int(add_saved), str(reg)))

    def _add_progress(self, reg, cand=0, verified=0, saved=0):
        with self.db.connect() as con:
            con.execute("""UPDATE course_history_initial_racers SET
                           candidate_count=candidate_count+?,verified_count=verified_count+?,saved_count=saved_count+?,
                           updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (int(cand), int(verified), int(saved), str(reg)))

    def _mark_error(self, reg, err):
        with self.db.connect() as con:
            con.execute("""UPDATE course_history_initial_racers SET status='pending',retry_count=retry_count+1,
                           last_error=?,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (str(err)[:1200], str(reg)))

    def _mark_complete(self, reg):
        with self.db.connect() as con:
            con.execute("""UPDATE course_history_initial_racers SET status='complete',cursor_year=?,
                           completed_at=CURRENT_TIMESTAMP,last_error=NULL,updated_at=CURRENT_TIMESTAMP
                           WHERE registration_no=?""", (FLOOR_YEAR-1, str(reg)))

    def _summary_counts(self, reg):
        with self.db.connect() as con:
            nrows = con.execute("""SELECT course,COUNT(*) n FROM racer_course_runs
                                   WHERE registration_no=? GROUP BY course""", (str(reg),)).fetchall()
            lrows = con.execute("""SELECT jcd,course,COUNT(*) n FROM racer_local_course_runs
                                   WHERE registration_no=? AND date>=? GROUP BY jcd,course""",
                                (str(reg), FLOOR_DATE)).fetchall()
        national = {int(x["course"]): min(10, int(x["n"])) for x in nrows}
        local_buckets = {(str(x["jcd"]).zfill(2), int(x["course"])): min(10, int(x["n"])) for x in lrows}
        return national, local_buckets

    def _today_local_progress(self, local_buckets, venue_codes):
        """JSON-safe local 1C-6C counts for the current racer's venue(s) today."""
        out = []
        for code in [str(x).zfill(2) for x in (venue_codes or [])]:
            venue = VENUES[int(code)-1] if code.isdigit() and 1 <= int(code) <= len(VENUES) else code
            counts = {c: int(local_buckets.get((code, c), 0)) for c in range(1, 7)}
            out.append({"jcd": code, "venue": venue, "counts": counts,
                        "total": sum(counts.values()),
                        "full_courses": sum(1 for v in counts.values() if v >= 10)})
        return out

    def _session(self):
        s = requests.Session()
        s.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ja,en-US;q=0.8,en;q=0.6",
            "Cache-Control": "no-cache",
        })
        return s

    def _get_html(self, session, urls, label):
        last = None
        for url in urls:
            for attempt in range(1, 4):
                try:
                    self.status.update({"phase": label, "direct_source": url,
                                        "last_fetch_state": f"fetch {attempt}/3", "last_fetch_error": None})
                    r = session.get(url, timeout=(6, 25), allow_redirects=True)
                    if r.status_code == 404:
                        last = f"HTTP 404: {url}"
                        break
                    r.raise_for_status()
                    if len(r.text) < 500:
                        raise RuntimeError(f"HTML too short ({len(r.text)})")
                    return r.text, {"url": r.url, "http": r.status_code, "attempt": attempt}
                except Exception as e:
                    last = f"{type(e).__name__}: {e}"
                    self.status.update({"last_fetch_error": last})
                    if attempt < 3:
                        self._stop.wait(1)
        raise RuntimeError(last or f"{label} 取得失敗")

    def _parse_recent_racer_page(self, html, today_year):
        soup = BeautifulSoup(html, "html.parser")
        out = []
        for table in soup.find_all("table"):
            heads = [" ".join(x.stripped_strings) for x in table.find_all("th")]
            h = "|".join(_norm(x) for x in heads)
            if not ("日付" in h and "場" in h and "R" in h and ("進入" in h or "枠" in h)):
                continue
            for tr in table.find_all("tr"):
                cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
                if len(cells) < 3:
                    continue
                d = _date_token(cells[0], today_year)
                jcd = _venue_code(cells[1]) if len(cells) > 1 else None
                rno = _race_token(cells[2]) if len(cells) > 2 else None
                if d and jcd and rno and d >= FLOOR_DATE:
                    out.append({"date": d, "jcd": jcd, "rno": rno, "candidate_source": "boatracedata-racer-recent"})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_recent_racer_candidates(self, session, reg, name):
        url = f"https://boatracedata.com/racer/{reg}"
        html, diag = self._get_html(session, [url], f"{name or reg} 本人の近走履歴を取得中")
        rows = self._parse_recent_racer_page(html, datetime.now(JST).year)
        self.status.update({"phase": f"{name or reg} 本人の近走履歴を取得",
                            "crawl_stage": f"選手{reg}本人の近走 → 候補 {len(rows)}走",
                            "candidate_races": len(rows), "direct_source": diag.get("url")})
        return rows

    def _expand_table(self, table):
        grid, spans = [], {}
        for r, tr in enumerate(table.find_all("tr")):
            row, c = [], 0
            cells = tr.find_all(["th", "td"], recursive=False)
            i = 0
            while i < len(cells) or any(k[0] == r for k in spans):
                while (r, c) in spans:
                    val = spans.pop((r, c))
                    row.append(val); c += 1
                if i >= len(cells):
                    break
                cell = cells[i]; i += 1
                val = " ".join(cell.stripped_strings)
                rs, cs = int(cell.get("rowspan", 1) or 1), int(cell.get("colspan", 1) or 1)
                for dc in range(cs):
                    row.append(val)
                    if rs > 1:
                        for dr in range(1, rs):
                            spans[(r + dr, c + dc)] = val
                c += cs
            grid.append(row)
        width = max((len(x) for x in grid), default=0)
        return [x + [""] * (width - len(x)) for x in grid]

    def _nearest_table_venue(self, table):
        node, checked = table, 0
        while node is not None and checked < 60:
            node = node.find_previous()
            if node is None:
                break
            if getattr(node, "name", None) in {"table", "tr", "td", "th"}:
                continue
            txt = " ".join(node.stripped_strings) if hasattr(node, "stripped_strings") else ""
            if not txt or len(txt) > 240:
                continue
            checked += 1
            jcd = _venue_code(txt)
            if jcd:
                return jcd
        return None

    def _parse_year_archive_candidates(self, html, year):
        soup = BeautifulSoup(html, "html.parser")
        out = []
        today = datetime.now(JST).strftime("%Y%m%d")
        for table in soup.find_all("table"):
            jcd = self._nearest_table_venue(table)
            if not jcd:
                continue
            rows = self._expand_table(table)
            if not rows:
                continue
            dates = {}
            for row in rows:
                for i, c in enumerate(row):
                    d = _date_token(c, year)
                    if d and FLOOR_DATE <= d <= today:
                        dates[i] = d
            if not dates:
                continue
            for row in rows:
                for col, cell in enumerate(row):
                    rno = _race_token(cell)
                    if rno and dates.get(col):
                        out.append({"date": dates[col], "jcd": jcd, "rno": rno,
                                    "candidate_source": f"boatrace-db-racer-yall-{year}"})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_year_racer_candidates(self, session, reg, name, year):
        url = f"https://boatrace-db.net/racer/yall/regno/{reg}/year/{year}/"
        html, diag = self._get_html(session, [url], f"{name or reg} 本人の{year}年全出走履歴を取得中")
        rows = self._parse_year_archive_candidates(html, year)
        self.status.update({"phase": f"{name or reg} {year}年本人履歴を取得",
                            "crawl_stage": f"選手{reg} {year}年全出走 → 候補 {len(rows)}走",
                            "candidate_races": len(rows), "direct_source": diag.get("url")})
        return rows

    def _official_result_url(self, x):
        return ("https://www.boatrace.jp/owpc/pc/race/raceresult"
                f"?hd={x['date']}&jcd={str(x['jcd']).zfill(2)}&rno={int(x['rno'])}")

    def _parse_official_result(self, html, candidate, reg):
        soup = BeautifulSoup(html, "html.parser")
        lane = finish = None
        for tr in soup.find_all("tr"):
            cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
            if not cells:
                continue
            joined = _nfkc(" ".join(cells))
            if not re.search(rf"(?<!\d){re.escape(str(reg))}(?!\d)", joined):
                continue
            fs = [_finish_token(c) for c in cells]
            fs = [x for x in fs if x is not None]
            if fs:
                finish = fs[0]
            for idx, c in enumerate(cells):
                t = _norm(c)
                if re.fullmatch(r"[1-6]", t):
                    if idx == 0 and len(cells) > 1 and re.fullmatch(r"[1-6]", _norm(cells[1])):
                        continue
                    lane = int(t); break
            if lane:
                break
        if not lane or finish in {None, "欠"}:
            return None

        start_rows, start_header = [], None
        for tag in soup.find_all(["h2", "h3", "h4", "dt", "th", "div", "p"]):
            if "スタート情報" in _norm(tag.get_text(" ", strip=True)):
                start_header = tag; break
        search_root = start_header.parent if start_header is not None else soup
        for node in search_root.find_all(["tr", "li", "div"], recursive=True):
            text = _nfkc(" ".join(node.stripped_strings))
            if len(text) > 120:
                continue
            lm = re.search(r"(?<!\d)([1-6])(?!\d)", text)
            sm = re.search(r"(?<![A-Z0-9])([FL]?\.\d{1,2}|F|L)(?!\d)", _norm(text).upper())
            if lm and sm:
                pair = (int(lm.group(1)), sm.group(1))
                if pair[0] not in [x[0] for x in start_rows]:
                    start_rows.append(pair)
            if len(start_rows) >= 6:
                break
        if lane not in [x[0] for x in start_rows]:
            start_rows = []
            for node in soup.find_all(["tr", "li", "div"]):
                text = _nfkc(" ".join(node.stripped_strings))
                if len(text) > 100:
                    continue
                lm = re.search(r"(?<!\d)([1-6])(?!\d)", text)
                sm = re.search(r"([FL]?\.\d{1,2}|F|L)", _norm(text).upper())
                if lm and sm:
                    pair = (int(lm.group(1)), sm.group(1))
                    if pair[0] not in [x[0] for x in start_rows]:
                        start_rows.append(pair)
                if len(start_rows) >= 6:
                    break
        if lane not in [x[0] for x in start_rows] or len(start_rows) < 2:
            return None

        course_by_lane = {slane: pos for pos, (slane, _st) in enumerate(start_rows, 1)}
        st_by_lane = {slane: st for slane, st in start_rows}
        course, st_raw = course_by_lane.get(lane), st_by_lane.get(lane)
        if not course or st_raw is None:
            return None
        numeric = []
        for slane, st in start_rows:
            v = _st_value(st)
            if v is not None:
                numeric.append((slane, v))
        numeric.sort(key=lambda z: z[1])
        ranks, last, rank = {}, None, 0
        for pos, (slane, v) in enumerate(numeric, 1):
            if last is None or abs(v-last) > 1e-9:
                rank = pos; last = v
            ranks[slane] = rank
        return {"date": str(candidate["date"]), "jcd": str(candidate["jcd"]).zfill(2),
                "rno": int(candidate["rno"]), "registration_no": str(reg), "lane": lane,
                "course": int(course), "finish": str(finish), "st_raw": str(st_raw),
                "st_rank": ranks.get(lane), "source": "boatrace-official-result:initial-racer-flow-v17214"}

    def _fetch_official_run(self, session, candidate, reg):
        url = self._official_result_url(candidate)
        last = None
        for attempt in range(1, 4):
            try:
                self.status.update({"phase": "BOAT RACE公式結果で実進入確認中",
                                    "direct_source": url, "last_fetch_state": f"official {attempt}/3"})
                r = session.get(url, timeout=(6, 25)); r.raise_for_status()
                return self._parse_official_result(r.text, candidate, reg)
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                self.status.update({"last_fetch_error": last})
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or "公式レース結果取得失敗")

    def _save_confirmed(self, row):
        if not row:
            return 0
        a = self.db.save_course_history_runs([row], keep_per_local_course=10)
        b = self.db.save_local_course_history_runs([row], keep_per_course=10)
        return 1 if (a or b) else 0

    def _process_candidates(self, session, reg, name, candidates, seen, started):
        verified = saved = failed = 0
        venue_name_by_code = {v: k for k, v in VENUE_CODE.items()}
        for cand in candidates:
            if self._stop.is_set():
                break
            key = (cand["date"], cand["jcd"], int(cand["rno"]))
            if key in seen:
                continue
            seen.add(key)
            try:
                row = self._fetch_official_run(session, cand, reg)
                verified += 1
            except Exception as e:
                failed += 1
                self.status.update({"last_nonfatal_error": f"{key}: {type(e).__name__}: {e}"})
                continue
            if row:
                saved += self._save_confirmed(row)
                vname = venue_name_by_code.get(str(row["jcd"]).zfill(2), str(row["jcd"]))
                self.status.update({
                    "crawl_stage": f"{name or reg} / {row['date']} {vname}{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "last_verified_run": f"{row['date']} {vname}{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                })
            self._stop.wait(0.05)
        return verified, saved, failed

    def _initialize_racer(self, racer, today):
        reg, name = racer["registration_no"], racer.get("name") or racer["registration_no"]
        self._mark_started(reg, name, today)
        state = self._state(reg) or {}
        session, seen, started = self._session(), set(), time.monotonic()
        total_candidates = total_verified = total_saved = 0

        _n0, _l0 = self._summary_counts(reg)
        _venues0 = racer.get("today_venues") or []
        self.status.update({
            "phase": f"{name} 初回コース履歴を構築中",
            "current_racer": name, "current_registration_no": reg,
            "current_today_venues": _venues0,
            "national_counts": _n0,
            "current_local_counts": self._today_local_progress(_l0, _venues0),
            "flow": "選手本人履歴→公式結果→全国＋24場へ実進入別保存→2020/01/01まで",
        })

        if not int(state.get("recent_done") or 0):
            try:
                rows = self._fetch_recent_racer_candidates(session, reg, name)
                total_candidates += len(rows)
                v, s, f = self._process_candidates(session, reg, name, rows, seen, started)
                total_verified += v; total_saved += s
                self._add_progress(reg, len(rows), v, s)
                if f:
                    self._mark_error(reg, f"近走公式確認失敗 {f}件")
                    return False
                self._mark_recent_done(reg)
            except Exception as e:
                self._mark_error(reg, f"近走履歴取得失敗: {type(e).__name__}: {e}")
                return False

        state = self._state(reg) or {}
        cursor = int(state.get("cursor_year") or datetime.now(JST).year)
        for year in range(cursor, FLOOR_YEAR - 1, -1):
            try:
                rows = self._fetch_year_racer_candidates(session, reg, name, year)
            except Exception as e:
                self._mark_error(reg, f"{year}年履歴取得失敗: {type(e).__name__}: {e}")
                return False
            total_candidates += len(rows)
            v, s, f = self._process_candidates(session, reg, name, rows, seen, started)
            total_verified += v; total_saved += s
            if f:
                self._add_progress(reg, len(rows), v, s)
                self._mark_error(reg, f"{year}年公式確認失敗 {f}件。年全体は継続済み、次回同年を再確認")
                return False
            self._advance_year(reg, year - 1, len(rows), v, s)
            national, local = self._summary_counts(reg)
            self.status.update({
                "current_year": year,
                "national_counts": national,
                "current_local_counts": self._today_local_progress(local, racer.get("today_venues") or []),
                "local_bucket_count": len(local),
                "full_local_bucket_count": sum(1 for x in local.values() if x >= 10),
                "candidate_races": total_candidates,
                "last_matched_rows": total_verified,
                "last_parsed_rows": total_saved,
                "crawl_elapsed_seconds": int(time.monotonic() - started),
            })

        self._mark_complete(reg)
        national, local = self._summary_counts(reg)
        self.status.update({
            "phase": f"{name} 初回履歴構築完了",
            "national_counts": national,
            "current_local_counts": self._today_local_progress(local, racer.get("today_venues") or []),
            "local_bucket_count": len(local),
            "full_local_bucket_count": sum(1 for x in local.values() if x >= 10),
            "last_fetch_state": "initial complete; future updates are result-only",
        })
        return True

    def _run(self, today):
        racers = self._today_racers(today)
        if not racers:
            self.status.update({
                "phase": "本日の出走選手待ち",
                "today": today,
                "today_target_count": 0,
                "message": "本日の公式出走表がDBへ保存された後に、当日出走選手だけを対象にします。",
            })
            return
        self._register_today_targets(today, racers)
        pending = self._pending_today(racers)
        complete = len(racers) - len(pending)
        overview = self._today_status_overview(racers)
        self.status.update({
            "today": today,
            "today_target_count": len(racers),
            "today_complete_count": complete,
            "today_pending_count": len(pending),
            "today_running_count": overview["running"],
            "today_error_count": overview["error"],
            "today_unstarted_count": overview["unstarted"],
            "today_queued_count": overview["queued"],
            "today_recent_errors": overview["errors"],
            "phase": "当日出走選手の初回履歴を確認中" if pending else "本日出走選手は全員初回構築済み",
            "validation_mode": "v17.216 当日出走選手のみ・初回1度だけ履歴構築→以後は結果差分更新・全体進捗＋当地進捗表示",
            "message": "初回完了済み選手は歴史ページへ再アクセスしません。以後は確定レース結果だけで全国＋その場を更新します。",
        })
        if not pending:
            return
        order_map = {str(x.get("registration_no")): idx for idx, x in enumerate(racers, 1)}
        for i, racer in enumerate(pending, 1):
            ov = self._today_status_overview(racers)
            self.status.update({"today_current_index": order_map.get(str(racer.get("registration_no")), i),
                                "today_current_pending_index": i,
                                "today_pending_count": len(pending),
                                "today_complete_count": ov["complete"],
                                "today_running_count": ov["running"],
                                "today_error_count": ov["error"],
                                "today_unstarted_count": ov["unstarted"],
                                "today_queued_count": ov["queued"],
                                "today_recent_errors": ov["errors"],
                                "current_racer": racer.get("name"),
                                "current_registration_no": racer.get("registration_no")})
            self._initialize_racer(racer, today)
            ov2 = self._today_status_overview(racers)
            self.status.update({"today_complete_count": ov2["complete"],
                                "today_running_count": ov2["running"],
                                "today_error_count": ov2["error"],
                                "today_unstarted_count": ov2["unstarted"],
                                "today_queued_count": ov2["queued"],
                                "today_recent_errors": ov2["errors"]})
            if self._stop.is_set():
                break
        pending2 = self._pending_today(racers)
        ov3 = self._today_status_overview(racers)
        self.status.update({
            "today_complete_count": ov3["complete"],
            "today_pending_count": len(pending2),
            "today_running_count": ov3["running"],
            "today_error_count": ov3["error"],
            "today_unstarted_count": ov3["unstarted"],
            "today_queued_count": ov3["queued"],
            "today_recent_errors": ov3["errors"],
            "phase": "本日出走選手は全員初回構築済み" if not pending2 else "未完了選手を次回再開",
        })
