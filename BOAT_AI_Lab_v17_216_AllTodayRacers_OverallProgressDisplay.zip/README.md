# BOAT AI Lab v17.215 - 当日出走選手 / 初回構築＋現在選手の当地進捗表示

## 初回履歴構築
- 対象は、その日の公式出走表にいる選手だけ。
- 選手本人の履歴を入口にする。
- 各候補レースを BOAT RACE 公式結果で再確認。
- 枠番ではなく、スタート情報の並びから実進入を確定。
- 同じ1走を「全国」と「そのレース場」の両方へ保存。
- 全国・24場ともコース1C〜6C、各場/各コースは最新最大10走を保持。
- 2020/01/01まで遡って初期構築。
- 初期構築完了を選手番号ごとにDB保存。完了した選手は歴史ページを二度と収集しない。

## 初回完了後
- 公式レース結果が確定した時だけ差分更新。
- 実進入コースの「全国」と「その場」へ新しい1走を追加。
- 10走を超えた場/コースは最古の1走を自動削除。
- 同一レースは主キー(date,jcd,rno,registration_no)で重複保存されない。

## 重要
- 全選手を無差別に初期収集しない。当日出走選手だけ。
- 既存の履歴テーブルを全削除しない。
- 1件の解析失敗で別選手の処理まで止めない。

## v17.216 progress display patch
The history collection algorithm is unchanged from v17.215. This patch fixes the visible version label and adds overall progress: current N/total, completed, error/retry, unstarted, running, remaining, and recent error names while preserving national/local course progress.
