from __future__ import annotations

import json
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import requests
from bs4 import BeautifulSoup

JST = timezone(timedelta(hours=9), name="JST")
JMA_URL = "https://www.data.jma.go.jp/kaiyou/db/tide/suisan/suisan.php"
OMURA_TIDE_URL = "https://omurakyotei.jp/sio/"


def _parse_omura_official(html: str, wanted_dates: set[str], now: datetime) -> dict[str, dict[str, Any]]:
    """Parse BOAT RACE大村「今節の潮見」. The page publishes times, not tide heights."""
    soup = BeautifulSoup(html, "html.parser")
    out = {d: {"hourly": None, "high": [], "low": []} for d in wanted_dates}
    md_re = re.compile(r"(\d{1,2})月(\d{1,2})日")
    tm_re = re.compile(r"^\d{1,2}:\d{2}$")
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
        if len(cells) < 3:
            continue
        m = md_re.search(cells[0])
        if not m:
            continue
        month, day = int(m.group(1)), int(m.group(2))
        year = now.year
        # Handle a meet crossing New Year without guessing from the page title.
        if now.month == 12 and month == 1:
            year += 1
        elif now.month == 1 and month == 12:
            year -= 1
        key = f"{year:04d}{month:02d}{day:02d}"
        if key not in out:
            continue
        # Official table order is: date / day label / low tide / high tide / tide name.
        times = [x for x in cells if tm_re.fullmatch(x)]
        if len(times) >= 2:
            out[key]["low"] = [{"time": times[0]}]
            out[key]["high"] = [{"time": times[1]}]
            out[key]["tide_name"] = cells[-1] if cells[-1] not in times else None
    return out

# Fixed venue knowledge. Daily web access is disabled for venues where tide is not
# useful enough to justify another collector. station_status=verified means the
# JMA station is suitable for automatic collection; candidate mappings remain
# replaceable without touching collector/AI code.

# v17.171: venue-specific compass -> relative wind conversion.
# ``tailwind_from_deg`` is the compass direction the wind COMES FROM when it is
# a home-stretch tailwind.  Directions within +/-22.5deg are tail/head winds;
# the two 90deg sectors are left/right crosswinds.  The values are fixed venue
# geometry, not learned race outcomes.  Karatsu changed pit layout in Dec-2025;
# its race-course axis did not require an unsafe historical guess here, so the
# current north/south water layout is treated conservatively with NE/SW axis.
WIND_VENUE_MASTER = {
    '01': {'name':'桐生',   'tailwind_from_deg':0},
    '02': {'name':'戸田',   'tailwind_from_deg':315},
    '03': {'name':'江戸川', 'tailwind_from_deg':202.5},
    '04': {'name':'平和島', 'tailwind_from_deg':180},
    '05': {'name':'多摩川', 'tailwind_from_deg':90},
    '06': {'name':'浜名湖', 'tailwind_from_deg':0},
    '07': {'name':'蒲郡',   'tailwind_from_deg':45},
    '08': {'name':'常滑',   'tailwind_from_deg':135},
    '09': {'name':'津',     'tailwind_from_deg':135},
    '10': {'name':'三国',   'tailwind_from_deg':0},
    '11': {'name':'びわこ', 'tailwind_from_deg':0},
    '12': {'name':'住之江', 'tailwind_from_deg':0},
    '13': {'name':'尼崎',   'tailwind_from_deg':45},
    '14': {'name':'鳴門',   'tailwind_from_deg':315},
    '15': {'name':'丸亀',   'tailwind_from_deg':180},
    '16': {'name':'児島',   'tailwind_from_deg':0},
    '17': {'name':'宮島',   'tailwind_from_deg':45},
    '18': {'name':'徳山',   'tailwind_from_deg':135},
    '19': {'name':'下関',   'tailwind_from_deg':90},
    '20': {'name':'若松',   'tailwind_from_deg':90},
    '21': {'name':'芦屋',   'tailwind_from_deg':315},
    '22': {'name':'福岡',   'tailwind_from_deg':270},
    '23': {'name':'唐津',   'tailwind_from_deg':45},
    '24': {'name':'大村',   'tailwind_from_deg':270},
}

_COMPASS_DEG = {
    '北':0,'北北東':22.5,'北東':45,'東北東':67.5,'東':90,'東南東':112.5,
    '南東':135,'南南東':157.5,'南':180,'南南西':202.5,'南西':225,
    '西南西':247.5,'西':270,'西北西':292.5,'北西':315,'北北西':337.5,
}

def _relative_wind_from_compass(jcd, raw):
    """Convert a saved compass wind to home-stretch relation for a venue."""
    if not raw: return None
    txt=str(raw).strip().replace('　','')
    # Official relative labels always win over conversion.
    if '向かい' in txt: return '向かい風'
    if '追い' in txt: return '追い風'
    if '左横' in txt: return '左横風'
    if '右横' in txt: return '右横風'
    if txt == '横風' or ('横' in txt and '風' in txt): return '横風'
    key=txt.replace('の風','').replace('風','')
    deg=_COMPASS_DEG.get(key)
    master=WIND_VENUE_MASTER.get(str(jcd).zfill(2))
    if deg is None or not master: return None
    tail=float(master['tailwind_from_deg'])
    # signed shortest angle from tailwind source direction to actual source.
    d=((float(deg)-tail+180.0)%360.0)-180.0
    ad=abs(d)
    if ad <= 45.0: return '追い風'
    if ad >= 135.0: return '向かい風'
    # Looking from start toward 1M, source rotated clockwise from tailwind axis
    # is treated as right crosswind; counter-clockwise as left crosswind.
    return '右横風' if d > 0 else '左横風'

TIDE_VENUE_MASTER = {
    "01": dict(name="桐生", enabled=False, importance="OFF", water="淡水"),
    "02": dict(name="戸田", enabled=False, importance="OFF", water="淡水"),
    "03": dict(name="江戸川", enabled=True, importance="VERY_HIGH", water="汽水", station="TK", station_name="東京", station_status="candidate", special="河川。潮向・流速と風の複合評価を優先"),
    "04": dict(name="平和島", enabled=True, importance="MEDIUM", water="海水", station="TK", station_name="東京", station_status="candidate"),
    "05": dict(name="多摩川", enabled=False, importance="OFF", water="淡水"),
    "06": dict(name="浜名湖", enabled=True, importance="LOW", water="汽水", station="MI", station_name="舞阪", station_status="candidate"),
    "07": dict(name="蒲郡", enabled=True, importance="LOW", water="汽水", station="G4", station_name="三河", station_status="candidate"),
    "08": dict(name="常滑", enabled=False, importance="OFF", water="海水", special="水位自動制御・潮位変化を予想補正に使わない"),
    "09": dict(name="津", enabled=False, importance="OFF", water="海水"),
    "10": dict(name="三国", enabled=False, importance="OFF", water="淡水"),
    "11": dict(name="びわこ", enabled=False, importance="OFF", water="淡水"),
    "12": dict(name="住之江", enabled=False, importance="OFF", water="淡水"),
    "13": dict(name="尼崎", enabled=False, importance="OFF", water="淡水"),
    "14": dict(name="鳴門", enabled=True, importance="HIGH", water="海水", station="KM", station_name="小松島", station_status="candidate"),
    "15": dict(name="丸亀", enabled=True, importance="VERY_HIGH", water="海水", station="TA", station_name="高松", station_status="candidate"),
    "16": dict(name="児島", enabled=True, importance="VERY_HIGH", water="海水", station="UN", station_name="宇野", station_status="verified", special="場公式潮汐表が宇野港基準を明記"),
    "17": dict(name="宮島", enabled=True, importance="VERY_HIGH", water="海水", station="Q8", station_name="広島", station_status="candidate"),
    "18": dict(name="徳山", enabled=True, importance="VERY_HIGH", water="海水", station="QA", station_name="徳山", station_status="verified"),
    # 関門系は場公式との照合余地を残す。現段階では日次自動取得を無理に有効化しない。
    "19": dict(name="下関", enabled=True, importance="CONDITIONAL", water="海水", station="CF", station_name="長府", station_status="verified", special="通常の潮影響は小さめ。高潮位時の条件発動を重視"),
    "20": dict(name="若松", enabled=True, importance="VERY_HIGH", water="海水", station="N1", station_name="日明", station_status="verified", special="若松公式潮見表との照合により日明を採用"),
    "21": dict(name="芦屋", enabled=False, importance="OFF", water="淡水"),
    "22": dict(name="福岡", enabled=True, importance="VERY_HIGH", water="海水", station="QF", station_name="博多", station_status="verified"),
    "23": dict(name="唐津", enabled=False, importance="OFF", water="海水"),
    "24": dict(name="大村", enabled=True, importance="MEDIUM", water="海水", station="OMURA_OFFICIAL", station_name="大村公式潮見", station_status="verified", special="BOAT RACE大村公式「今節の潮見」を使用。公式ページは潮位cmを掲載しないため位相中心"),
}


def _date_key(d: datetime) -> str:
    return d.strftime("%Y%m%d")


def _parse_jma_html(html: str, wanted_dates: set[str]) -> dict[str, dict[str, Any]]:
    """Parse JMA tide tables by row shape, independent of cosmetic HTML changes."""
    soup = BeautifulSoup(html, "html.parser")
    out: dict[str, dict[str, Any]] = {d: {"hourly": None, "high": [], "low": []} for d in wanted_dates}
    date_re = re.compile(r"(20\d{2})[/-](\d{1,2})[/-](\d{1,2})")
    time_re = re.compile(r"^\d{1,2}:\d{2}$")
    int_re = re.compile(r"^-?\d+$")
    for tr in soup.find_all("tr"):
        cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
        if not cells:
            continue
        m = date_re.search(cells[0])
        if not m:
            continue
        key = f"{int(m.group(1)):04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"
        if key not in out:
            continue
        rest = cells[1:]
        numeric = []
        for x in rest:
            s = x.replace("−", "-").strip()
            if int_re.fullmatch(s):
                numeric.append(int(s))
        # Hourly table has exactly/at least 24 consecutive numeric values after date.
        if len(numeric) >= 24 and out[key]["hourly"] is None:
            out[key]["hourly"] = numeric[:24]
            continue
        # High/low table: collect time+following numeric level. JMA order is highs then lows.
        pairs = []
        i = 0
        while i < len(rest) - 1:
            t = rest[i].strip()
            lv = rest[i + 1].replace("−", "-").replace("#", "").strip()
            if time_re.fullmatch(t) and int_re.fullmatch(lv):
                pairs.append({"time": t, "level_cm": int(lv)})
                i += 2
            else:
                i += 1
        if pairs:
            # JMA table exposes up to four high then up to four low columns. In ordinary
            # days 2+2 pairs are returned; split by local extrema against hourly values
            # when possible, otherwise use first half as high and second as low.
            hourly = out[key].get("hourly")
            if hourly:
                for p in pairs:
                    hh, mm = map(int, p["time"].split(":"))
                    prevv = hourly[(hh - 1) % 24]
                    nextv = hourly[(hh + 1) % 24]
                    (out[key]["high"] if p["level_cm"] >= max(prevv, nextv) else out[key]["low"]).append(p)
            else:
                half = (len(pairs) + 1) // 2
                out[key]["high"] = pairs[:half]
                out[key]["low"] = pairs[half:]
    return out


class TideCollector:
    """Independent daily tide collector. Never participates in 15m/30s/final-odds loops."""
    def __init__(self, db):
        self.db = db
        self.running = False
        self.thread = None
        self.stop_event = threading.Event()
        self.collect_lock = threading.Lock()
        self.status = {
            "running": False, "phase": "待機中", "last_run": None, "last_success": None,
            "last_error": None, "next_run": None, "days_ahead": 7,
            "enabled_venues": [v["name"] for v in TIDE_VENUE_MASTER.values() if v.get("enabled")],
            "pending_mapping": [v["name"] for v in TIDE_VENUE_MASTER.values() if v.get("station_status") == "pending"],
            "saved_rows": 0, "source": "気象庁 潮位表（天文潮位）",
        }
        self._sync_master()

    def _sync_master(self):
        with self.db.connect() as con:
            for jcd, v in TIDE_VENUE_MASTER.items():
                con.execute("""INSERT INTO tide_venue_master
                    (jcd,venue_name,enabled,importance,water_type,station_code,station_name,station_status,time_offset_minutes,special_rule,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(jcd) DO UPDATE SET venue_name=excluded.venue_name,enabled=excluded.enabled,
                    importance=excluded.importance,water_type=excluded.water_type,station_code=excluded.station_code,
                    station_name=excluded.station_name,station_status=excluded.station_status,special_rule=excluded.special_rule,updated_at=CURRENT_TIMESTAMP""",
                    (jcd,v["name"],1 if v.get("enabled") else 0,v.get("importance"),v.get("water"),v.get("station"),v.get("station_name"),v.get("station_status"),0,v.get("special")))

    def start(self):
        if self.running:
            return
        self.running = True
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._loop, name="tide-daily-collector", daemon=True)
        self.thread.start()

    def _next_0430(self, now: datetime) -> datetime:
        target = now.replace(hour=4, minute=30, second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)
        return target

    def _has_today(self, today: str) -> bool:
        # JMA venues are expected every day. Omura official publishes only the current
        # meet, so require Omura only when a race schedule exists for Omura that day.
        enabled = sum(1 for v in TIDE_VENUE_MASTER.values() if v.get("enabled") and v.get("station") and v.get("station") != "OMURA_OFFICIAL")
        with self.db.connect() as con:
            omura_race = con.execute("SELECT 1 FROM race_schedule WHERE date=? AND jcd='24' LIMIT 1", (today,)).fetchone()
            if omura_race:
                enabled += 1
            row = con.execute("SELECT COUNT(*) n FROM tide_daily WHERE date=? AND status='OK'", (today,)).fetchone()
        return int(row["n"] or 0) >= enabled

    def _loop(self):
        # Startup recovery: if today's cache is missing, collect immediately. This is
        # intentionally independent of BackgroundCollector.
        while not self.stop_event.is_set():
            now = datetime.now(JST)
            today = _date_key(now)
            if not self._has_today(today):
                ok = False
                for attempt in range(1, 7):
                    if self.stop_event.is_set(): return
                    self.status.update(phase=f"潮データ取得中 {attempt}/6", last_error=None)
                    try:
                        self.collect(days=7)
                        ok = True
                        break
                    except Exception as e:
                        self.status["last_error"] = f"{type(e).__name__}: {e}"
                        self.status["phase"] = f"取得失敗・5分後再試行 {attempt}/6"
                        if attempt < 6:
                            self.stop_event.wait(300)
                if not ok:
                    self.status["phase"] = "収集エラー（既存収集・AIは継続）"
            nxt = self._next_0430(datetime.now(JST))
            self.status["next_run"] = nxt.isoformat()
            if self.status.get("phase") != "収集エラー（既存収集・AIは継続）":
                self.status["phase"] = "取得済み・次回待機"
            wait = max(30, (nxt - datetime.now(JST)).total_seconds())
            self.stop_event.wait(wait)

    def collect_now(self, days: int = 7):
        """Manual check uses the exact same collector as the scheduled job."""
        if not self.collect_lock.acquire(blocking=False):
            return {"ok": False, "busy": True, "message": "潮データを収集中です"}
        try:
            self.status.update(phase="手動で潮データ取得中", last_error=None)
            saved = self._collect_impl(days)
            return {"ok": True, "busy": False, "saved_rows": saved, "message": "潮データを取得・保存しました"}
        except Exception as e:
            self.status.update(phase="手動取得エラー（既存収集・AIは継続）", last_error=f"{type(e).__name__}: {e}", last_run=datetime.now(JST).isoformat())
            return {"ok": False, "busy": False, "message": "潮データの取得に失敗しました", "error": self.status["last_error"]}
        finally:
            self.collect_lock.release()

    def collect(self, days: int = 7):
        with self.collect_lock:
            return self._collect_impl(days)

    def _collect_impl(self, days: int = 7):
        now = datetime.now(JST)
        dates = [now + timedelta(days=i) for i in range(days)]
        wanted = {_date_key(d) for d in dates}
        # One request per station, not per venue/race. Venues sharing a station share data.
        stations: dict[str, list[str]] = {}
        for jcd, v in TIDE_VENUE_MASTER.items():
            if v.get("enabled") and v.get("station") and v.get("station") != "OMURA_OFFICIAL":
                stations.setdefault(v["station"], []).append(jcd)
        saved = 0
        session = requests.Session()
        session.headers.update({"User-Agent": "BOAT-AI-Lab/17.160 tide-cache"})
        for station, jcds in stations.items():
            first, last = dates[0], dates[-1]
            params = {"LV":"DL","S_HILO":"on","S_HOUR":"on","stn":station,
                      "ys":first.year,"ms":f"{first.month:02d}","ds":f"{first.day:02d}",
                      "ye":last.year,"me":f"{last.month:02d}","de":f"{last.day:02d}"}
            r = session.get(JMA_URL, params=params, timeout=20)
            r.raise_for_status()
            r.encoding = r.apparent_encoding or "utf-8"
            parsed = _parse_jma_html(r.text, wanted)
            for jcd in jcds:
                v = TIDE_VENUE_MASTER[jcd]
                for date, data in parsed.items():
                    status = "OK" if data.get("hourly") and len(data["hourly"]) == 24 else "ERROR"
                    with self.db.connect() as con:
                        con.execute("""INSERT INTO tide_daily
                            (date,jcd,station_code,station_name,high_tides_json,low_tides_json,hourly_levels_json,source,fetched_at,status,error_message)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?)
                            ON CONFLICT(date,jcd) DO UPDATE SET station_code=excluded.station_code,station_name=excluded.station_name,
                            high_tides_json=excluded.high_tides_json,low_tides_json=excluded.low_tides_json,
                            hourly_levels_json=excluded.hourly_levels_json,source=excluded.source,fetched_at=excluded.fetched_at,
                            status=excluded.status,error_message=excluded.error_message""",
                            (date,jcd,station,v.get("station_name"),json.dumps(data.get("high") or [],ensure_ascii=False),
                             json.dumps(data.get("low") or [],ensure_ascii=False),json.dumps(data.get("hourly"),ensure_ascii=False),
                             "JMA astronomical tide",datetime.now(JST).isoformat(),status,None if status=="OK" else "毎時潮位24点を確認できませんでした"))
                    if status == "OK": saved += 1

        # 大村だけは場公式「今節の潮見」を独立取得。失敗してもJMA各場の保存結果を壊さない。
        try:
            r = session.get(OMURA_TIDE_URL, timeout=20)
            r.raise_for_status()
            r.encoding = r.apparent_encoding or "utf-8"
            parsed = _parse_omura_official(r.text, wanted, now)
            for date, data in parsed.items():
                ok = bool(data.get("high") and data.get("low"))
                if not ok:
                    continue
                status = "OK"
                with self.db.connect() as con:
                    con.execute("""INSERT INTO tide_daily
                        (date,jcd,station_code,station_name,high_tides_json,low_tides_json,hourly_levels_json,source,fetched_at,status,error_message)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(date,jcd) DO UPDATE SET station_code=excluded.station_code,station_name=excluded.station_name,
                        high_tides_json=excluded.high_tides_json,low_tides_json=excluded.low_tides_json,
                        hourly_levels_json=excluded.hourly_levels_json,source=excluded.source,fetched_at=excluded.fetched_at,
                        status=excluded.status,error_message=excluded.error_message""",
                        (date,"24","OMURA_OFFICIAL","大村公式潮見",json.dumps(data.get("high") or [],ensure_ascii=False),
                         json.dumps(data.get("low") or [],ensure_ascii=False),None,"BOAT RACE Omura official tide table",
                         datetime.now(JST).isoformat(),status,None if ok else "今節の潮見に対象日の満潮・干潮がありません"))
                if ok: saved += 1
        except Exception as e:
            self.status["last_error"] = f"大村公式潮見: {type(e).__name__}: {e}"

        try:
            self.build_race_contexts(_date_key(now))
        except Exception:
            pass
        self.status.update(running=True, phase="取得完了", last_run=now.isoformat(), last_success=datetime.now(JST).isoformat(), saved_rows=saved, last_error=None)
        return saved


    @staticmethod
    def _parse_clock(date: str, clock: str) -> datetime | None:
        try:
            c = str(clock or '').strip()
            hh, mm = [int(x) for x in c.split(':')[:2]]
            return datetime.strptime(date, "%Y%m%d").replace(tzinfo=JST, hour=hh, minute=mm)
        except Exception:
            return None

    def _build_race_context(self, date: str, jcd: str, rno: int, deadline: str) -> dict[str, Any] | None:
        jcd = str(jcd).zfill(2)
        with self.db.connect() as con:
            row = con.execute("SELECT * FROM tide_daily WHERE date=? AND jcd=? AND status='OK'", (date,jcd)).fetchone()
            master = con.execute("SELECT * FROM tide_venue_master WHERE jcd=?", (jcd,)).fetchone()
        if not row or not master or not int(master['enabled'] or 0):
            return None
        try:
            hourly = json.loads(row['hourly_levels_json'] or '[]')
            highs = json.loads(row['high_tides_json'] or '[]')
            lows = json.loads(row['low_tides_json'] or '[]')
        except Exception:
            return None
        target = self._parse_clock(date, deadline)
        if target is None:
            return None
        minute = target.hour * 60 + target.minute
        level = None
        change = None
        band = '—'
        phase = '—'
        if len(hourly) == 24:
            h0 = target.hour
            h1 = min(23, h0 + 1)
            frac = target.minute / 60.0 if h1 != h0 else 0.0
            v0, v1 = float(hourly[h0]), float(hourly[h1])
            level = v0 + (v1-v0)*frac
            change = v1-v0 if h1 != h0 else (v0-float(hourly[h0-1]) if h0 else 0.0)
            if change > 1.0:
                phase = '上げ潮'
            elif change < -1.0:
                phase = '下げ潮'
            else:
                phase = '潮止まり付近'
            lo, hi = min(map(float,hourly)), max(map(float,hourly))
            span = max(1.0, hi-lo)
            pos = (level-lo)/span
            band = '高' if pos >= 2/3 else ('低' if pos <= 1/3 else '中')

        def nearest(items):
            vals=[]
            for x in items:
                dt=self._parse_clock(date, x.get('time'))
                if dt is not None: vals.append((int(round((dt-target).total_seconds()/60)), x))
            if not vals: return None, None
            return min(vals, key=lambda z: abs(z[0]))
        dh, high = nearest(highs); dl, low = nearest(lows)
        if len(hourly) != 24 and (highs or lows):
            # Official Omura source gives extrema times only. Infer direction from the
            # nearest high/low event; do not fabricate centimetre values.
            events=[]
            for x in highs:
                dt=self._parse_clock(date,x.get('time'))
                if dt: events.append((dt,'high'))
            for x in lows:
                dt=self._parse_clock(date,x.get('time'))
                if dt: events.append((dt,'low'))
            events.sort()
            if events:
                nearest_event=min(events,key=lambda z:abs((z[0]-target).total_seconds()))
                if abs((nearest_event[0]-target).total_seconds()) <= 30*60:
                    phase='潮止まり付近'
                else:
                    before=[e for e in events if e[0] <= target]
                    after=[e for e in events if e[0] > target]
                    if before:
                        phase='下げ潮' if before[-1][1]=='high' else '上げ潮'
                    elif after:
                        phase='上げ潮' if after[0][1]=='high' else '下げ潮'
        ctx = {
            'date':date,'jcd':jcd,'rno':int(rno),'deadline':deadline,
            'estimated_level_cm':round(level,1) if level is not None else None,'estimated':True,'tide_phase':phase,
            'level_band':band,'change_cm_per_hour':round(change,1) if change is not None else None,
            'minutes_to_high':dh,'minutes_to_low':dl,
            'nearest_high':high,'nearest_low':low,
            'station_code':row['station_code'],'station_name':row['station_name'],
            'importance':master['importance'],'source':'tide_daily + race_schedule',
            'ai_applied':False
        }
        return ctx

    @staticmethod
    def _wind_speed_band(speed):
        try:
            v=float(speed)
        except (TypeError, ValueError):
            return None
        if v <= 0: return "無風"
        if v <= 2: return "弱"
        if v <= 4: return "中"
        return "強"

    def _before_weather(self, date: str, jcd: str, rno: int) -> dict[str, Any]:
        """Read only the saved 15-minute before-info snapshot. Never fetch the web here."""
        try:
            snap=self.db.get_snapshot(date,str(jcd).zfill(2),int(rno),"beforeinfo")
            return ((snap or {}).get("data") or {}).get("weather") or {}
        except Exception:
            return {}

    def _water_condition(self, ctx: dict[str, Any]) -> dict[str, Any]:
        """Stage 3 diagnostic judgement. It is deliberately NOT connected to AI scores."""
        jcd=str(ctx.get('jcd') or '').zfill(2)
        weather=self._before_weather(ctx['date'],jcd,int(ctx['rno']))
        raw=weather.get('wind_direction')
        relation=weather.get('wind_relation')
        # Prefer an official relative label.  If official before-info only saved a
        # compass direction (e.g. 北西), convert it with the 24-venue geometry master.
        if not relation and raw:
            relation=_relative_wind_from_compass(jcd, raw)
        speed=weather.get('wind_speed_m')
        band=self._wind_speed_band(speed)
        tide=ctx.get('tide_phase')
        importance=(TIDE_VENUE_MASTER.get(jcd) or {}).get('importance','OFF')
        tags=[]; reasons=[]; level='弱'
        wind_missing = speed is None
        if wind_missing:
            # 15分前の直前情報がまだ未取得なら複合判定は確定しない。
            # 潮だけで「中/強」と見せると第3段階が完成したように誤認するため保留。
            level='判定保留'
            reasons.append('風データ未取得（15分前の直前情報待ち）')
        else:
            reasons.append(f"風{float(speed):g}m {relation or raw or '風向不明'}")
            if band == '強': level='強'
            elif band == '中': level='中'
        if tide:
            reasons.append(str(tide))
        if (not wind_missing) and importance in ('VERY_HIGH','HIGH') and tide:
            if level == '弱': level='中'
        # Venue-specific *descriptive* tags only when the required inputs are present.
        if (not wind_missing) and jcd=='16' and relation=='追い風' and tide in ('上げ潮','潮止まり付近'):
            tags += ['差し注意','イン不安定要素']; level='強'; reasons.append('児島: 追い風×高水位側を重点確認')
        elif (not wind_missing) and jcd=='15' and relation=='向かい風' and tide=='下げ潮':
            tags += ['まくり注意']; level='強'; reasons.append('丸亀: 下げ潮×向かい風を重点確認')
        elif (not wind_missing) and jcd=='20':
            if tide=='下げ潮': tags += ['まくり注意']
            if relation=='追い風': tags += ['差し注意']
        elif (not wind_missing) and jcd=='22' and relation in ('向かい風','左横風','右横風','横風') and tide in ('上げ潮','潮止まり付近'):
            tags += ['うねり注意','ST難化注意']; level='強'; reasons.append('福岡: 潮位×風の複合条件を重点確認')
        elif (not wind_missing) and jcd=='17' and tide in ('上げ潮','潮止まり付近') and band in ('中','強'):
            tags += ['うねり注意','ST難化注意']; level='強'; reasons.append('宮島: 高水位側×風を重点確認')
        elif (not wind_missing) and jcd=='18' and tide=='上げ潮' and band in ('中','強'):
            tags += ['うねり注意']; level='強'; reasons.append('徳山: 上げ潮×風を重点確認')
        elif jcd=='03' and tide and speed is not None:
            tags += ['潮流×風確認']; level='強' if band in ('中','強') else '中'; reasons.append('江戸川: 河川潮流と風の複合条件')
        if raw and not relation:
            tags.append('相対風向未確定')
            reasons.append('風向文字を相対風向へ変換できず方向補正なし')
        elif raw and relation and not weather.get('wind_relation'):
            reasons.append(f'場別風向変換: {raw}→{relation}')
        if speed is None: tags.append('風データなし')
        return {
            'raw_wind_direction':raw,'wind_speed_m':speed,'wind_speed_band':band,
            'wind_course_type':relation,'water_condition_level':level,
            'water_effect_tags':list(dict.fromkeys(tags)),'water_condition_reason':' / '.join(reasons),
            'ai_applied':False,'source':'saved beforeinfo + tide_race_context'
        }

    def build_race_contexts(self, date: str, jcd: str | None = None) -> dict[str, Any]:
        date = str(date)
        with self.db.connect() as con:
            if jcd:
                schedules = con.execute("SELECT jcd,rno,deadline FROM race_schedule WHERE date=? AND jcd=? ORDER BY rno", (date,str(jcd).zfill(2))).fetchall()
            else:
                schedules = con.execute("SELECT jcd,rno,deadline FROM race_schedule WHERE date=? ORDER BY jcd,rno", (date,)).fetchall()
        saved=0
        for r in schedules:
            ctx=self._build_race_context(date,r['jcd'],int(r['rno']),r['deadline'])
            if not ctx: continue
            water=self._water_condition(ctx)
            ctx['water_condition']=water
            with self.db.connect() as con:
                con.execute("""INSERT INTO tide_race_context
                    (date,jcd,rno,deadline,estimated_level_cm,estimated,tide_phase,minutes_to_high,minutes_to_low,change_cm_per_hour,flow_direction,wind_direction,wind_speed,combined_effect,context_json,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(date,jcd,rno) DO UPDATE SET deadline=excluded.deadline,estimated_level_cm=excluded.estimated_level_cm,estimated=excluded.estimated,tide_phase=excluded.tide_phase,minutes_to_high=excluded.minutes_to_high,minutes_to_low=excluded.minutes_to_low,change_cm_per_hour=excluded.change_cm_per_hour,flow_direction=excluded.flow_direction,wind_direction=excluded.wind_direction,wind_speed=excluded.wind_speed,combined_effect=excluded.combined_effect,context_json=excluded.context_json,created_at=CURRENT_TIMESTAMP""",
                    (date,ctx['jcd'],ctx['rno'],ctx['deadline'],ctx['estimated_level_cm'],1,ctx['tide_phase'],ctx['minutes_to_high'],ctx['minutes_to_low'],ctx['change_cm_per_hour'],ctx['tide_phase'],water.get('raw_wind_direction'),water.get('wind_speed_m'),water.get('water_condition_level'),json.dumps(ctx,ensure_ascii=False)))
            saved += 1
        return {'ok':True,'date':date,'saved':saved}

    def race_contexts(self, date: str, jcd: str) -> dict[str, Any]:
        jcd=str(jcd).zfill(2)
        self.build_race_contexts(date,jcd)
        with self.db.connect() as con:
            rows=con.execute("SELECT * FROM tide_race_context WHERE date=? AND jcd=? ORDER BY rno", (date,jcd)).fetchall()
            schedule_count=con.execute("SELECT COUNT(*) n FROM race_schedule WHERE date=? AND jcd=? AND deadline IS NOT NULL AND deadline<>''",(date,jcd)).fetchone()['n']
            tide_row=con.execute("SELECT status,error_message FROM tide_daily WHERE date=? AND jcd=?",(date,jcd)).fetchone()
            master=con.execute("SELECT enabled,venue_name FROM tide_venue_master WHERE jcd=?",(jcd,)).fetchone()
        out=[]
        for r in rows:
            d=dict(r)
            try: d['context']=json.loads(d.get('context_json') or '{}')
            except Exception: d['context']={}
            out.append(d)
        return {'date':date,'jcd':jcd,'rows':out,'ai_applied':False,
                'schedule_count':int(schedule_count or 0),
                'tide_status':(tide_row['status'] if tide_row else 'NOT_FETCHED'),
                'tide_error':(tide_row['error_message'] if tide_row else None),
                'tide_enabled':bool(master and int(master['enabled'] or 0)),
                'venue_name':(master['venue_name'] if master else None)}

    def day_status(self, date: str) -> dict[str, Any]:
        with self.db.connect() as con:
            rows = con.execute("""SELECT d.*,m.venue_name,m.importance,m.station_status FROM tide_daily d
                LEFT JOIN tide_venue_master m ON m.jcd=d.jcd WHERE d.date=? ORDER BY d.jcd""", (date,)).fetchall()
            master = con.execute("SELECT * FROM tide_venue_master ORDER BY jcd").fetchall()
        return {"date":date,"rows":[dict(r) for r in rows],"master":[dict(r) for r in master]}
