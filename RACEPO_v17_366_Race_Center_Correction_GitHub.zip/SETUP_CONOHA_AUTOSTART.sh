#!/usr/bin/env bash
# One-time service configuration for the current-symlink deployment model.
# This script must only be run by an operator after reviewing backup/recovery.
set -euo pipefail
ROOT=/opt/boat-ai-lab
SERVICE=/etc/systemd/system/boat-ai-lab.service
CURRENT="$ROOT/current"

if [[ "${EUID}" -ne 0 ]]; then
  echo 'ERROR: root privileges required' >&2; exit 1
fi
if [[ ! -L "$CURRENT" || ! -d "$CURRENT" ]]; then
  echo "ERROR: $CURRENT must be a valid symlink to a verified release; no changes made" >&2; exit 1
fi
if [[ ! -f "$CURRENT/app.py" || ! -f "$CURRENT/requirements.txt" || ! -x "$CURRENT/.venv/bin/python" ]]; then
  echo 'ERROR: linked release is incomplete (app.py, requirements.txt, .venv/bin/python); no changes made' >&2; exit 1
fi
# Prevent silently replacing an existing production service definition.
if [[ -e "$SERVICE" ]]; then
  echo "ERROR: $SERVICE already exists; inspect it and take a backup before migration. No changes made" >&2
  exit 1
fi
install -d -m 755 "$ROOT"
cat > "$SERVICE" <<'UNIT'
[Unit]
Description=BOAT AI Lab
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/boat-ai-lab/current
ExecStart=/opt/boat-ai-lab/current/.venv/bin/python -m uvicorn app:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable boat-ai-lab.service
echo 'Service configuration installed. No service restart performed. Check and restart only during approved deployment.'
