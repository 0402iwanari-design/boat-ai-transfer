import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from collector import BackgroundCollector


class FakeDB:
    def __init__(self, path):
        self.path = Path(path)
        self.confirmed = {('12', 11), ('12', 12)}
        self.complete = {('12', 12)}
        self.valid = set(self.complete)

    def get_confirmed_result_races(self, day):
        return set(self.confirmed) if day == '20261110' else set()

    def get_odds_complete_keys(self, day):
        return set(self.complete) if day == '20261110' else set()

    def verify_odds_snapshot(self, day, jcd, rno):
        return (jcd, rno) in self.valid


class FakeSource:
    def __init__(self, db):
        self.db = db
        self.calls = []
        self.fail = False

    def fetch_odds_atomic(self, day, jcd, rno, level):
        self.calls.append((day, jcd, rno, level))
        if self.fail:
            raise TimeoutError('network unreachable')
        self.db.valid.add((jcd, rno))
        return dict(ok=True, saved=True, verified=True, count=120, expected_count=120)


class StageAIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.source = FakeSource(FakeDB(Path(self.tmp.name) / 'test.db'))
        self.collector = BackgroundCollector(self.source)

    def tearDown(self):
        self.tmp.cleanup()

    def start_day(self):
        self.collector._reset_for_date('20261111')
        self.collector.running = True

    def test_single_missing_11r_and_existing_12r_is_untouched(self):
        self.start_day()
        self.assertEqual(set(self.collector._stage_a_due), {('20261110', '12', 11)})
        asyncio.run(self.collector._stage_a_repair_one('20261111'))
        self.assertEqual(self.source.calls, [('20261110', '12', 11, 0)])
        self.assertFalse(self.collector._stage_a_due)
        self.assertIn('補完成功', self.collector.status['stage_a_last'])
        journal = (Path(self.tmp.name) / 'odds_repair_diagnostics.jsonl').read_text()
        self.assertIn('"verified"', journal)
        self.assertNotIn('network unreachable', journal)

    def test_failed_retries_are_bounded_and_manual_reviewed(self):
        self.start_day()
        self.source.fail = True
        key = ('20261110', '12', 11)
        for attempt in range(3):
            self.collector._stage_a_due[key] = 0
            asyncio.run(self.collector._stage_a_repair_one('20261111'))
        self.assertEqual([x[-1] for x in self.source.calls], [0, 1, 2])
        self.assertFalse(self.collector._stage_a_due)
        self.assertIn('20261110/12-11R', self.collector.status['stage_a_manual_review'])

    def test_date_rollover_stops_pending_work(self):
        self.start_day()
        asyncio.run(self.collector._stage_a_repair_one('20261112'))
        self.assertEqual(self.source.calls, [])

    def test_previous_verified_snapshot_skips_network(self):
        self.start_day()
        self.source.db.valid.add(('12', 11))
        asyncio.run(self.collector._stage_a_repair_one('20261111'))
        self.assertEqual(self.source.calls, [])
        self.assertFalse(self.collector._stage_a_due)

    def test_large_backlog_has_per_day_cap(self):
        self.source.db.get_confirmed_result_races = lambda day: {
            (str(j).zfill(2), r) for j in range(1, 25) for r in range(1, 13)
        } if day == '20261110' else set()
        self.source.db.get_odds_complete_keys = lambda day: set()
        self.start_day()
        self.assertEqual(len(self.collector._stage_a_due), 24)
        self.assertTrue(any('未検査' in str(x) for x in self.collector.status['errors']))

if __name__ == '__main__':
    unittest.main()
