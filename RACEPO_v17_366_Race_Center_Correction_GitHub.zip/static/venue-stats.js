(function(){
const box=document.getElementById('stats-cards');const status=document.getElementById('stats-status');
if(!box||!status)return;
const slug=box.dataset.venue;
if(!/^[a-z-]+$/.test(slug))return;
fetch('/api/public/'+slug+'/kimarite',{credentials:'omit'}).then(r=>{if(!r.ok)throw Error('response '+r.status);return r.json()}).then(d=>{
 const n=Number(d.sample_races)||0;
 if(!n){status.textContent='集計可能な確定結果がまだありません。数字を推測して表示しません。';return;}
 status.textContent='保存済み結果から実進入6艇分と決まり手を確認できた '+n.toLocaleString('ja-JP')+'レース（取得対象最大1,800件）。対象期間：'+(d.earliest_date||'不明')+'〜'+(d.latest_date||'不明')+'。';
 const rows=(d.courses||[]).map(x=>{const wins=Number(x.wins)||0;const methods=(x.methods||[]).slice(0,2).map(v=>String(v.name).replace(/[<>&"']/g,'')+': '+Number(v.count)+'件').join('／');return '<div class="stat-card"><strong>'+Number(x.course)+'コース</strong><p>'+wins+'勝／全対象中 '+(x.race_share_pct??'—')+'%</p><p>'+methods+'</p></div>';});
 box.innerHTML=rows.join('');
}).catch(()=>status.textContent='コース別実績の取得に失敗しました。時間をおいて再度確認してください。');
})();