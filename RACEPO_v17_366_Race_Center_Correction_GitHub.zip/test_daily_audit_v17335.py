import json, sqlite3, tempfile, unittest
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from daily_data_audit import audit_day

class MockDB:
    def __init__(self,path): self.path=path
    def connect(self):
        db=sqlite3.connect(self.path);db.row_factory=sqlite3.Row;return db

class AuditTests(unittest.TestCase):
    def test_missing_and_unsynced_per_venue(self):
        with tempfile.TemporaryDirectory() as tmp:
            main=Path(tmp)/'main.sqlite'; research=Path(tmp)/'research.sqlite'
            with sqlite3.connect(main) as c:
                c.execute('CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER,deadline TEXT)')
                c.execute('CREATE TABLE race_snapshots(date TEXT,jcd TEXT,rno INTEGER,kind TEXT,payload TEXT)')
                c.execute('CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,payload TEXT)')
                c.execute('CREATE TABLE tide_race_context(date TEXT,jcd TEXT,rno INTEGER,estimated_level_cm REAL,tide_phase TEXT)')
                c.executemany('INSERT INTO race_schedule VALUES (?,?,?,?)',[('20261108','02',1,'12:00'),('20261108','02',2,'12:30'),('20261108','05',1,'12:00')])
            with sqlite3.connect(research) as c:
                c.execute('CREATE TABLE pattern_races(venue TEXT,rno INTEGER,day TEXT,features TEXT)')
                c.executemany('INSERT INTO pattern_races VALUES (?,?,?,?)',[
                    ('02',1,'2026-11-08',json.dumps({'season':'autumn','month':'11','race_no':'1','wind_speed':'2-3','wind_speed_m':2.5,'wind_dir':'向かい風','wave':'0-2','wave_height_cm':1,'grade':'G1'})),
                    ('05',1,'2026-11-08',json.dumps({'season':'autumn','month':'11','race_no':'1','grade':'一般'}))])
            result=audit_day(MockDB(main),'20261108',now=datetime(2026,11,9,tzinfo=ZoneInfo('Asia/Tokyo')),research_path=research)
            toda=next(x for x in result['venues'] if x['code']=='02')['statistical']
            tamagawa=next(x for x in result['venues'] if x['code']=='05')['statistical']
            self.assertEqual(toda['unsynced_races'],[2]);self.assertEqual(toda['complete_races'],1)
            self.assertEqual(toda['missing_fields']['wind_dir'],[])
            self.assertEqual(tamagawa['missing_fields']['wind_speed'],[1]);self.assertEqual(tamagawa['missing_fields']['wave'],[1])
            self.assertEqual(tamagawa['missing_fields']['month'],[])
    def test_missing_research_db_does_not_create(self):
        with tempfile.TemporaryDirectory() as tmp:
            main=Path(tmp)/'main.sqlite';research=Path(tmp)/'nonexistent.sqlite'
            with sqlite3.connect(main) as c:
                c.execute('CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER,deadline TEXT)');c.execute("INSERT INTO race_schedule VALUES('20261108','01',1,'12:00')")
                c.execute('CREATE TABLE race_snapshots(date TEXT,jcd TEXT,rno INTEGER,kind TEXT,payload TEXT)')
                c.execute('CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,payload TEXT)')
                c.execute('CREATE TABLE tide_race_context(date TEXT,jcd TEXT,rno INTEGER,estimated_level_cm REAL,tide_phase TEXT)')
            result=audit_day(MockDB(main),'20261108',now=datetime(2026,11,9,tzinfo=ZoneInfo('Asia/Tokyo')),research_path=research)
            self.assertEqual(result['venues'][0]['statistical']['unsynced_races'],[1]);self.assertFalse(research.exists())
if __name__=='__main__': unittest.main()
