import unittest
from unittest.mock import patch
from venue_comments import parse_karatsu_comments, fetch_venue_comments, fetch_karatsu_comments, KARATSU_COMMENTS_URL
from collector import BackgroundCollector

HTML = '''<html><h2>全選手コメント</h2><table><tr><th>登番 / 級別 選手名</th><th>モーター評価</th><th>選手コメント（前日 / 直前）</th><th>履歴</th></tr><tr><td>3257 / A1 田頭　実</td><td>出足：◯ 伸び足：◎ 素性：D</td><td>調整の幅が狭い。少し乗りにくい。</td><td>履歴</td></tr><tr><td>3412 / A1 鈴木　博</td><td>伸び足：◎</td><td>回転を合わせたい。</td><td>履歴</td></tr><tr><td>4299 / B1 中島浩哉</td><td>素性：-</td><td>■■帰郷</td><td>履歴</td></tr></table></html>'''
RACERS=[{'lane':1,'registration_no':'3257','name':'田頭実'}, {'lane':2,'registration_no':'3412','name':'鈴木博'}, {'lane':3,'registration_no':'4299','name':'中島浩哉'}, {'lane':4,'registration_no':'9999','name':'不明'}]
class Tests(unittest.TestCase):
    def test_exact_registration_match(self):
        x=parse_karatsu_comments(HTML,RACERS)
        self.assertEqual([r['lane'] for r in x],[1,2]);self.assertEqual(x[0]['comment'],'調整の幅が狭い。少し乗りにくい。')
    def test_no_wrong_racer(self):
        self.assertEqual(parse_karatsu_comments(HTML,[{'lane':6,'registration_no':'9999','name':'田頭実'}]),[])
    def test_no_title(self):
        self.assertEqual(parse_karatsu_comments(HTML.replace('全選手コメント','別データ'),RACERS),[])
    def test_dispatch_karatsu(self):
        with patch('venue_comments.fetch_karatsu_comments') as m:
            m.return_value={'ok':True,'comments':[]}
            fetch_venue_comments('20261109','23',1,RACERS)
            m.assert_called_once()
    def test_old_day_rejected(self):
        self.assertFalse(fetch_karatsu_comments('19990101',1,RACERS)['ok'])
    def test_collector_targets(self):
        import inspect
        code=inspect.getsource(BackgroundCollector._comments_pilot_phase)
        self.assertIn('"23"',code)
if __name__=='__main__':unittest.main()
