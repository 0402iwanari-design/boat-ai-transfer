"""v17.334: race-relative wind filters and before-race archival tests."""
from datetime import date
from pathlib import Path
import json
import sqlite3
import tempfile
import unittest

from statistical_ai import (Store, feature_map, import_local_db,
                            normalize_wind_class, filtered_venue_comparisons)


class WindAndDetailedArchiveTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.original = Path(self.folder.name) / 'live.db'
        self.research = Store(Path(self.folder.name) / 'research.db')
        with sqlite3.connect(self.original) as con:
            con.executescript('''
                CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,payload TEXT);
                CREATE TABLE race_snapshots(date TEXT,jcd TEXT,rno INTEGER,kind TEXT,payload TEXT,captured_at TEXT);
                CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER,deadline TEXT);
                CREATE TABLE venue_event_meta(date TEXT,jcd TEXT,event_grade TEXT);
                CREATE TABLE tide_race_context(date TEXT,jcd TEXT,rno INTEGER,tide_phase TEXT,created_at TEXT);
            ''')
            finishers = {'finishers': [{'lane': n, 'finish': n} for n in range(1, 7)]}
            racer = {'racers': [{'lane': i, 'class': 'A1', 'avg_st': 0.13}
                                for i in range(1, 7)]}
            cases = [(9, '向かい風', 3.0, '2026-11-09 09:10:00'),
                     (10, '左横風', 4.0, '2026-11-09 09:10:00'),
                     (11, '北', 2.0, '2026-11-09 09:10:00'),
                     (12, '追い風', 2.0, '2026-11-09 09:30:00')]
            for rno, wind, speed, captured in cases:
                con.execute('INSERT INTO race_results VALUES (?,?,?,?,?,?)',
                            ('2026-11-09', '12', rno, '1-2-3', 1900, json.dumps(finishers)))
                con.execute('INSERT INTO race_schedule VALUES (?,?,?,?)',
                            ('2026-11-09', '12', rno, '19:20'))
                con.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',
                            ('2026-11-09', '12', rno, 'racelist', json.dumps(racer), '2026-11-09 08:00:00'))
                before = {'weather': {'wind_direction': wind, 'wind_speed_m': speed,
                                      'wave_height_cm': 4, 'air_temperature_c': 15.2},
                          'racers': [{'lane': n, 'exhibition_time': 6.60 + n / 100}
                                     for n in range(1,7)],
                          'original_exhibition': [{'lane': 1, 'straight': 7.00}],
                          'start_display': [{'lane': 1, 'st': 0.10}]}
                con.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',
                            ('2026-11-09', '12', rno, 'beforeinfo', json.dumps(before), captured))
            # Add another venue to confirm venue filtering is respected.
            con.execute('INSERT INTO race_results VALUES (?,?,?,?,?,?)',
                        ('2026-11-09', '02', 9, '1-2-3', 1900, json.dumps(finishers)))
        # Main DB must remain untouched by syncing.
        self.original_bytes = self.original.read_bytes()

    def test_normalization(self):
        examples = [
            ('向かい風', None, 3, '向かい風'), ('追い風', None, 3, '追い風'),
            ('右横風', None, 3, '横風'), ('左横風', None, 3, '横風'),
            ('北', '向かい風', 3, '向かい風'), ('南', None, 3, None),
            ('無風', None, 0, '無風'), ('北', None, 0, '無風'),
            ('無風', None, 2, None),
        ]
        for raw, relation, speed, expected in examples:
            with self.subTest(raw=raw, relation=relation, speed=speed):
                self.assertEqual(normalize_wind_class(raw, relation, speed), expected)

    def test_numeric_and_original_values_retained(self):
        features = feature_map('2026-11-09', 11, wind_dir='北', wind_relation='横風',
                               wind_speed=3.5, wave=7)
        self.assertEqual(features['wind_dir'], '横風')
        self.assertEqual(features['wind_raw'], '北')
        self.assertEqual(features['wind_speed'], '2-3')
        self.assertEqual(features['wind_speed_m'], 3.5)
        self.assertEqual(features['wave_height_cm'], 7)
        self.assertEqual(features['wave'], '6-10')
        self.assertNotIn('wind_dir', feature_map('2026-11-09', 5, wind_dir='北',wind_speed=3))

    def test_local_sync_scope_full_snapshot_and_missing_values(self):
        result = import_local_db(self.research, self.original, only_day='2026-11-09', only_venue='12')
        self.assertEqual(result['imported'], 4)
        records = self.research.read_venue('12')
        self.assertEqual(len(records), 4)
        features = {r['rno']: r['features'] for r in records}
        self.assertEqual(features[9]['wind_dir'], '向かい風')
        self.assertEqual(features[10]['wind_dir'], '横風')
        self.assertNotIn('wind_dir', features[11])
        self.assertEqual(features[12]['wind_dir'], '追い風')
        self.assertEqual(features[9]['wind_speed_m'], 3)
        self.assertEqual(features[9]['wave_height_cm'], 4)
        with self.research.connect() as con:
            snap = con.execute('SELECT beforeinfo,capture_time FROM pattern_race_details WHERE key=?',
                               ('202611091209',)).fetchone()
            self.assertEqual(json.loads(snap['beforeinfo'])['original_exhibition'][0]['straight'], 7.0)
            self.assertEqual(json.loads(snap['beforeinfo'])['start_display'][0]['st'], .1)
            self.assertEqual(con.execute('SELECT COUNT(*) FROM pattern_race_details').fetchone()[0], 4)
        self.assertEqual(self.original.read_bytes(), self.original_bytes)
        # If a later post-close snapshot overwrote the live field, retain the
        # earlier validated, already archived pre-close snapshot instead.
        with sqlite3.connect(self.original) as con:
            con.execute("UPDATE race_snapshots SET captured_at=? WHERE jcd='12' AND rno=12 AND kind='beforeinfo'",
                        ('2026-11-09 12:30:00',))
        import_local_db(self.research, self.original, only_day='2026-11-09', only_venue='12')
        self.assertEqual(next(r for r in self.research.read_venue('12') if r['rno']==12)
                         ['features']['wind_dir'], '追い風')
        # Scoped retries must be idempotent.
        import_local_db(self.research, self.original, only_day='2026-11-09', only_venue='12')
        self.assertEqual(len(self.research.read_venue('12')), 4)
        self.assertEqual(filtered_venue_comparisons(self.research,'12',{'wind_dir':'向かい風'})['matching_races'], 1)
        self.assertEqual(filtered_venue_comparisons(self.research,'12',{'wind_dir':'横風'})['matching_races'], 1)
        self.assertEqual(filtered_venue_comparisons(self.research,'12',{'wind_dir':'無風'})['matching_races'], 0)
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.research,'12',{'wind_dir':'北'})

    def test_existing_legacy_raw_wind_is_not_invented(self):
        self.research.upsert([{'key':'202611081209','day':'2026-11-08','venue':'12','rno':9,
                              'combo':'1-2-3','payout_yen':500,
                              'features': json.dumps({'wind_dir':'北','wind_speed':'2-3'}),
                              'source':'legacy'}])
        self.assertNotIn('wind_dir', self.research.read_venue('12')[0]['features'])


if __name__ == '__main__':
    unittest.main()
