import unittest
from unittest.mock import patch
from venue_comments import parse_ashiya_comments, fetch_ashiya_comments, fetch_venue_comments
from collector import BackgroundCollector

HTML = '''<html><h1>選手コメント</h1><p>※ コメントは前日のものになります。</p><table><tr><th>登録番号</th><th>選手名</th><th>級別</th><th>コメント</th></tr><tr><td>3381</td><td>滝沢　芳行</td><td>B1</td><td>悪くないが、しっくりきていない</td></tr><tr><td>3478</td><td>嶋田　貴支</td><td>B1</td><td>どちらかと言えば出足寄りかな</td></tr></table></html>'''
RACERS=[{'lane':1,'registration_no':'3381','name':'滝沢芳行'}, {'lane':2,'registration_no':'3478','name':'嶋田 貴支'}]

class TestAshiya(unittest.TestCase):
    def test_two_registered_racers(self):
        out=parse_ashiya_comments(HTML,RACERS)
        self.assertEqual([x['lane'] for x in out],[1,2])
        self.assertEqual(out[0]['comment'],'悪くないが、しっくりきていない')
        self.assertEqual(out[0]['comment_period'],'previous_day')
    def test_wrong_number_rejected(self):
        self.assertEqual(parse_ashiya_comments(HTML,[{'lane':1,'registration_no':'9999','name':'滝沢芳行'}]),[])
    def test_wrong_name_rejected(self):
        self.assertEqual(parse_ashiya_comments(HTML,[{'lane':1,'registration_no':'3381','name':'嶋田貴支'}]),[])
    def test_conflict_rejected(self):
        html=HTML.replace('</table>','<tr><td>3381</td><td>滝沢芳行</td><td>B1</td><td>別のコメント</td></tr></table>')
        self.assertEqual(parse_ashiya_comments(html,RACERS)[0]['registration_no'],'3478')
    def test_heading_missing_rejected(self):
        self.assertEqual(parse_ashiya_comments(HTML.replace('選手コメント','調整情報'),RACERS),[])
    def test_wrong_table_rejected(self):
        self.assertEqual(parse_ashiya_comments(HTML.replace('登録番号','番号'),RACERS),[])
    def test_historical_date_rejected(self):
        with patch('venue_comments.requests.get') as get:
            self.assertFalse(fetch_ashiya_comments('20200101',1,RACERS)['ok'])
            get.assert_not_called()
    def test_dispatch(self):
        with patch('venue_comments.fetch_ashiya_comments') as f:
            f.return_value={'ok':True,'comments':[]}
            fetch_venue_comments('20261109','21',1,RACERS)
            f.assert_called_once()
    def test_collector(self):
        import inspect
        self.assertIn('"21"',inspect.getsource(BackgroundCollector._comments_pilot_phase))

if __name__=='__main__': unittest.main()
