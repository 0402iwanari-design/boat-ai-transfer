"""Read-only coverage audit of race data saved by the existing collector.

Counts are evidence of storage, NOT claims that the publisher exposes all fields.
The report never triggers collection or modifies the prediction database.
"""
from __future__ import annotations

import json
import sqlite3
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

JST = ZoneInfo('Asia/Tokyo')
VENUES = ('桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村')
FIELDS = ('racelist', 'beforeinfo', 'odds3t', 'result', 'weather', 'original')


def _valid_snapshot(kind, raw):
    try:
        value = json.loads(raw or '{}')
        if not isinstance(value, dict):
            return False
        if kind == 'racelist':
            return len(value.get('racers') or []) == 6
        if kind == 'beforeinfo':
            return bool(value.get('racers') or value.get('start_display') or value.get('weather') or value.get('original_exhibition'))
        if kind == 'odds3t':
            return len(value.get('odds') or []) == 120
    except (TypeError, ValueError):
        pass
    return False


# The statistical research DB is separate from the operational SQLite DB.
# This audit reads it without creating a missing DB and without modifying rows.
STAT_FIELDS = ('season', 'month', 'race_no', 'wind_speed', 'wind_dir', 'wave', 'grade')


def _stat_feature_status(day, expected, research_path=None):
    from pathlib import Path
    from statistical_ai import default_store
    path = Path(research_path) if research_path is not None else default_store()
    existing = {}
    if path.is_file():
        try:
            con = sqlite3.connect(f'file:{path.resolve().as_posix()}?mode=ro', uri=True, timeout=5)
            con.row_factory = sqlite3.Row
            try:
                for row in con.execute('SELECT venue,rno,features FROM pattern_races WHERE REPLACE(day, "-", "")=?', (day,)):
                    try:
                        key = (str(row['venue']).zfill(2), int(row['rno']))
                        value = json.loads(row['features'])
                        if isinstance(value, dict): existing[key] = value
                    except (ValueError, TypeError, KeyError):
                        continue
            finally:
                con.close()
        except (sqlite3.Error, OSError) as exc:
            return {}, '研究DBの参照失敗：' + type(exc).__name__
    outcome = {}
    for venue, races in expected.items():
        missing = {field: [] for field in STAT_FIELDS}
        not_synced = []
        checked = 0
        for race in sorted(races):
            features = existing.get((venue,race))
            if features is None:
                not_synced.append(race)
                continue
            checked += 1
            # An absent categorical field is a missing observation, not 0 or calm.
            for field in STAT_FIELDS:
                value = features.get(field)
                valid = value is not None and value != ''
                if field in ('wind_speed','wave'):
                    numeric_key = 'wind_speed_m' if field == 'wind_speed' else 'wave_height_cm'
                    valid = valid and features.get(numeric_key) is not None
                if field == 'wind_dir':
                    valid = valid and value in ('無風','向かい風','追い風','横風')
                if field == 'race_no':
                    valid = valid and str(value) == str(race)
                if field == 'month':
                    valid = valid and str(value).zfill(2) == day[4:6]
                if field == 'season':
                    month = int(day[4:6])
                    wanted = 'spring' if month in (3,4,5) else 'summer' if month in (6,7,8) else 'autumn' if month in (9,10,11) else 'winter'
                    valid = valid and value == wanted
                if not valid:
                    missing[field].append(race)
        outcome[venue] = {
            'synced_races': checked, 'unsynced_races': not_synced,
            'missing_fields': missing,
            'complete_races': checked - len(set().union(*map(set, missing.values()))),
            'checked_fields': list(STAT_FIELDS),
        }
    return outcome, None


def audit_day(db, day, now=None, research_path=None):
    now = now or datetime.now(JST)
    if now.tzinfo is None:
        now = now.replace(tzinfo=JST)
    today = now.astimezone(JST).strftime('%Y%m%d')
    if len(day) != 8 or not day.isdigit() or day > today:
        raise ValueError('本日までの年月日（YYYYMMDD）を指定してください')
    try:
        datetime.strptime(day, '%Y%m%d')
    except ValueError as exc:
        raise ValueError('存在する日付を指定してください') from exc

    with db.connect() as con:
        schedules = con.execute('SELECT jcd,rno,deadline FROM race_schedule WHERE date=?', (day,)).fetchall()
        snapshots = con.execute('SELECT jcd,rno,kind,payload FROM race_snapshots WHERE date=? AND kind IN (\'racelist\',\'beforeinfo\',\'odds3t\')', (day,)).fetchall()
        results = con.execute('SELECT jcd,rno,trifecta,payout_yen,payload FROM race_results WHERE date=?', (day,)).fetchall()
    expected = defaultdict(set)
    deadline = {}
    valid = {f: defaultdict(set) for f in FIELDS}
    for row in schedules:
        venue = str(row['jcd']).zfill(2)
        if venue not in {f'{i:02d}' for i in range(1,25)} or not 1 <= int(row['rno']) <= 12:
            continue
        race = int(row['rno'])
        expected[venue].add(race)
        deadline[(venue,race)] = row['deadline']
    for row in snapshots:
        venue = str(row['jcd']).zfill(2)
        race = int(row['rno'])
        if 1 <= race <= 12 and _valid_snapshot(row['kind'], row['payload']):
            valid[row['kind']][venue].add(race)
            expected[venue].add(race)
        if row['kind'] == 'beforeinfo' and 1 <= race <= 12:
            try:
                before = json.loads(row['payload'] or '{}')
                weather = before.get('weather') or {}
                if isinstance(weather, dict) and any(v is not None and v != '' for v in weather.values()):
                    valid['weather'][venue].add(race)
                if before.get('original_exhibition'):
                    valid['original'][venue].add(race)
            except (TypeError, ValueError, AttributeError):
                pass
    for row in results:
        venue = str(row['jcd']).zfill(2)
        race = int(row['rno'])
        if not 1 <= race <= 12:
            continue
        expected[venue].add(race)
        try:
            payload = json.loads(row['payload'] or '{}')
        except (ValueError, TypeError):
            payload = {}
        # A result without official finishing order can still legitimately be
        # a cancellation. Only mark complete where result detail is present.
        if (row['trifecta'] and row['payout_yen'] is not None) or payload.get('is_cancelled'):
            valid['result'][venue].add(race)
    statistical, stat_error = _stat_feature_status(day, expected, research_path)
    venues = []
    total = {field: 0 for field in FIELDS}
    required = 0
    for venue in sorted(expected):
        ids = sorted(expected[venue])
        required += len(ids)
        sections = {}
        for field in FIELDS:
            have = sorted(set(ids) & valid[field][venue])
            missing = sorted(set(ids) - set(have))
            total[field] += len(have)
            sections[field] = {'saved': len(have), 'expected': len(ids), 'missing_races': missing}
        # Completion is based on results, not guessed closing times. Missing
        # results after a calendar day rolls over are marked as outstanding.
        done = all(r in valid['result'][venue] for r in ids)
        full = done and all(not sections[f]['missing_races'] for f in ('racelist', 'beforeinfo', 'odds3t', 'result'))
        status = 'complete' if full else ('incomplete' if day < today or done else 'ongoing')
        venues.append({'code': venue, 'name': VENUES[int(venue)-1], 'status': status,
                       'result_final': done, 'expected_races': len(ids), 'fields': sections,
                       'statistical': statistical.get(venue, {})})
    return {'date': day, 'generated_at': now.isoformat(), 'status': 'no_data' if not venues else
            ('complete' if all(v['status']=='complete' for v in venues) else 'incomplete'),
            'venue_count': len(venues), 'expected_races': required, 'field_totals': total,
            'venues': venues, 'statistical_error': stat_error, 'note': '保存済みデータの照合結果です。天候・オリジナル展示は参考項目で、未提供の場合もあります。予定未取得の開催場やレース、各項目内部の欠損は別途確認が必要です。'}
