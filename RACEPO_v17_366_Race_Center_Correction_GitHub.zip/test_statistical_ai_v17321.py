"""Regression tests for v17.321 interactive combined condition comparison."""
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest

from statistical_ai import (Store, _coverage, feature_map,
                            filtered_venue_comparisons, formation)


class CombinedConditionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.store = Store(Path(self.tmp.name)/'research.db')
        self.make_records()

    def make_records(self):
        records=[]
        start=date(2024,1,1)
        # Two consistently sampled conditions across the 70/30 chronological split.
        for i in range(240):
            day=(start + timedelta(days=i)).isoformat()
            good = i%4 != 3
            features=feature_map(day, 9 if good else 6, clock='19:10',
                     wind_dir='向かい風' if good else '追い風', wind_speed=2 if good else 5,
                     wave=3 if good else 12,
                     racers={1:{'class':'A1','avg_st':'.12'}})
            if i in (4, 8, 12):
                # Missing wind or wave must never count as matching.
                features.pop('wind_speed',None)
                features.pop('wave',None)
            combo = '1-2-3' if i%2 == 0 else '4-5-6'
            payout=1000 if combo=='1-2-3' else 20000
            records.append({'key':day.replace('-','')+'12'+f'{9 if good else 6:02d}',
                        'day':day,'venue':'12','rno':9 if good else 6,
                        'combo':combo,'payout_yen':payout,
                        'features':json.dumps(features,ensure_ascii=False), 'source':'test'})
        self.store.upsert(records)

    def test_ranges_exact_cutoffs(self):
        for speed, label in [(0,'0-1'),(1,'0-1'),(1.5,'0-1'),(2,'2-3'),
                             (3,'2-3'),(4,'4-5'),(5,'4-5'),(6,'6+')]:
            self.assertEqual(feature_map('2024-05-12',9,wind_speed=speed)['wind_speed'],label)
        for cm, label in [(0,'0-2'),(2,'0-2'),(3,'3-5'),(5,'3-5'),
                          (6,'6-10'),(10,'6-10'),(11,'11+')]:
            self.assertEqual(feature_map('2024-05-12',9,wave=cm)['wave'],label)
        self.assertNotIn('wind_speed',feature_map('2024-05-12',9,wind_speed='未取得'))

    def test_combined_filters_and_missing_pre_race_excluded(self):
        query={'race_band':'9-12','wind_speed':'2-3','wave':'3-5','wind_dir':'向かい風'}
        result=filtered_venue_comparisons(self.store,'12',query)
        self.assertEqual(result['total_venue_races'],240)
        self.assertEqual(result['matching_races'],177)
        self.assertEqual(result['train_races']+result['test_races'],177)
        self.assertEqual(result['status'],'ready')
        self.assertEqual(result['filters'],query)
        self.assertEqual(result['observed_wind_directions'][0]['value'],'向かい風')
        self.assertEqual(result['observed_wind_directions'][0]['races'],180)
        self.assertEqual(len(result['comparisons']),8)
        self.assertEqual(result['split_day'],(date(2024,1,1)+timedelta(days=168)).isoformat())
        self.assertFalse(self.store.report('12'))  # analysis does not write report or predictions

    def test_roi_stake_hit_payout_correct_even_when_unprofitable(self):
        res=filtered_venue_comparisons(self.store,'12',{'wind_speed':'2-3','race_no':'9'})
        a=next(x for x in res['comparisons'] if x['formation']=='1-23-234')
        rows=[r for r in self.store.read_venue('12') if
              r['features'].get('wind_speed')=='2-3' and r['features'].get('race_no')=='9']
        early=[r for r in rows if r['day']<res['split_day']]
        late=[r for r in rows if r['day']>=res['split_day']]
        self.assertEqual(a['train'],_coverage(early,formation([1],[2,3],[2,3,4])))
        self.assertEqual(a['validation'],_coverage(late,formation([1],[2,3],[2,3,4])))
        self.assertEqual(a['train']['total_stake_yen'], len(early)*400)
        self.assertEqual(a['validation']['total_stake_yen'],len(late)*400)
        self.assertEqual(a['status'],'historical_comparison_only')

    def test_one_race_or_overrestricted_data_is_not_recommended(self):
        res=filtered_venue_comparisons(self.store,'12',{'season':'summer','race_no':'6','wind_speed':'4-5','wave':'11+'})
        self.assertEqual(res['status'],'insufficient_data')
        self.assertTrue(0 < res['matching_races'] < 30)
        self.assertTrue(all(x['status']=='small_sample_reference' for x in res['comparisons']))
        none=filtered_venue_comparisons(self.store,'12',{'race_no':'12'})
        self.assertEqual(none['matching_races'],0)
        self.assertFalse(none['comparisons'])

    def test_explicit_season_month_window_race_and_invalid_requests(self):
        winter=filtered_venue_comparisons(self.store,'12',{'season':'winter'})
        self.assertEqual(winter['matching_races'],60)  # Jan/Feb 2024
        extended=filtered_venue_comparisons(self.store,'12',{'season_window':'11-03'})
        self.assertEqual(extended['matching_races'],91)  # Jan-Mar 2024
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'12',{'wind_speed':'7-8'})
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'12',{'race_band':'9-12','race_no':'9'})
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'12',{'season':'winter','season_window':'11-03'})
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'00',{})
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'12',{'other':'value'})
        with self.assertRaises(ValueError):
            filtered_venue_comparisons(self.store,'12',{'wind_dir':'N'*100})

    def test_venue_separation(self):
        other=filtered_venue_comparisons(self.store,'11',{'wind_speed':'2-3'})
        self.assertEqual(other['total_venue_races'],0)
        self.assertEqual(other['matching_races'],0)
        self.assertEqual(other['status'],'insufficient_data')


if __name__=='__main__':unittest.main(verbosity=2)
