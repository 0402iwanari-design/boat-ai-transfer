"""Privacy-minimal, bounded per-race diagnostic journal for odds recovery.

Records operational stages, not source URLs, odds values, exception messages,
request headers or authentication material.  Never changes the racing DB.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from pathlib import Path
import json
import os
import re
import threading

_JST = timezone(timedelta(hours=9))
_LOCK = threading.RLock()
_MAX_BYTES = 2_000_000


def classify_failure(exc):
    """Classify only stable, non-sensitive characteristics of failure."""
    name = type(exc).__name__
    message = str(exc)
    if name in ('Timeout', 'TimeoutError', 'ConnectTimeout', 'ReadTimeout', 'ConnectionError', 'HTTPError'):
        return 'network'
    if any(term in message for term in ('保存後のDB検証', 'DB検証に失敗')):
        return 'readback_failed'
    if name in ('OperationalError', 'IntegrityError', 'DatabaseError'):
        return 'db_operation'
    if any(term in message for term in ('組合せ', '未完成', 'オッズ', '欠場艇')):
        return 'odds_validation'
    if name in ('ValueError', 'TypeError', 'KeyError'):
        return 'parse_or_validation'
    return 'unexpected_exception'


def _safe_identity(day, jcd, rno):
    day, jcd = str(day), str(jcd)
    if not re.fullmatch(r'20\d{6}', day) or not re.fullmatch(r'\d{1,2}', jcd):
        raise ValueError('invalid race identity')
    jcd = jcd.zfill(2)
    race = int(rno)
    if not 1 <= int(jcd) <= 24 or not 1 <= race <= 12:
        raise ValueError('invalid race identity')
    datetime.strptime(day, '%Y%m%d')
    return day, jcd, race


def record_odds_event(db_path, *, day, jcd, rno, mode, stage, attempt=0,
                      level=None, reason=None, count=None, expected_count=None):
    """Append one sanitized event beside the DB; fail closed on unsafe paths.

    Journal failure must not interrupt live racing collection; callers may catch
    OSError, ValueError and report it in existing status errors.
    """
    day, jcd, rno = _safe_identity(day, jcd, rno)
    allowed_modes = {'today', 'historical'}
    allowed_stages = {'queued', 'already_valid', 'fetch_attempt', 'fetch_failed',
                      'validation_failed', 'verified', 'retry_scheduled', 'manual_review'}
    allowed_reasons = {'network', 'readback_failed', 'odds_validation',
                       'parse_or_validation', 'unexpected_exception', 'incomplete_response', 'db_operation'}
    if mode not in allowed_modes or stage not in allowed_stages:
        raise ValueError('invalid event category')
    if reason is not None and reason not in allowed_reasons:
        raise ValueError('invalid reason')
    event = {
        'time': datetime.now(_JST).isoformat(timespec='seconds'),
        'date': day, 'jcd': jcd, 'rno': rno,
        'mode': mode, 'stage': stage, 'attempt': int(attempt),
    }
    if level is not None:
        event['level'] = int(level)
    if reason is not None:
        event['reason'] = reason
    if count is not None:
        event['count'] = int(count)
    if expected_count is not None:
        event['expected_count'] = int(expected_count)
    location = Path(db_path)
    if location.is_symlink() or not location.parent.is_dir() or location.parent.is_symlink():
        raise OSError('unsafe diagnostics destination')
    target = location.parent / 'odds_repair_diagnostics.jsonl'
    old = location.parent / 'odds_repair_diagnostics.previous.jsonl'
    row = (json.dumps(event, ensure_ascii=False, sort_keys=True) + '\n').encode('utf-8')
    with _LOCK:
        if target.is_symlink() or old.is_symlink():
            raise OSError('unsafe diagnostic journal')
        if target.exists() and target.stat().st_size + len(row) > _MAX_BYTES:
            os.replace(target, old)
        flags = os.O_CREAT | os.O_APPEND | os.O_WRONLY
        if hasattr(os, 'O_NOFOLLOW'):
            flags |= os.O_NOFOLLOW
        fd = os.open(target, flags, 0o600)
        try:
            with os.fdopen(fd, 'ab') as stream:
                stream.write(row)
        except BaseException:
            raise
    return event
