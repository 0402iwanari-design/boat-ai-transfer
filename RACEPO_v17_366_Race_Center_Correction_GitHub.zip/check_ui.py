from pathlib import Path
from playwright.sync_api import sync_playwright
from bs4 import BeautifulSoup
s=Path('/mnt/data/racepo_v17332_build/static/index.html').read_text(encoding='utf-8')
soup=BeautifulSoup(s,'html.parser')
css='\n'.join(t.text for t in soup.find_all('style'))
rows=''.join(f'<tr><td><span>{i}</span></td><td class="racelist-photo-cell"><div class="racelist-photo-wrap"></div></td><td class="name"><button class="racer-link">村上遼</button></td><td class="racelist-class-cell"><span class="class-badge class-a1">A1</span></td><td class="racelist-bio-cell"><div class="racer-bio-line"><span>34歳</span><span>52kg</span></div><div class="racer-bio-line"><span>長崎</span><small>支部</small></div><div class="racer-bio-line"><span>長崎</span><small>出身</small></div></td><td>—</td><td>5.33</td><td>.12</td><td>0</td><td class="meeting-inline-racer-cell"><table class="meeting-racer-grid"><colgroup>{"<col>"*6}</colgroup><tbody>{"".join("<tr>"+"".join("<td>5R</td>" for _ in range(6))+"</tr>" for j in range(4))}</tbody></table></td><td>No.52<br><span class="muted">2連 32% / 3連 47%</span></td><td>No.33<br><span class="muted">2連 28% / 3連 51%</span></td></tr>' for i in range(1,7))
html=f'''<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>{css}</style><div class="table-wrap racelist-inline-meeting-wrap" style="width:390px;overflow-x:auto"><table class="racelist-inline-meeting"><colgroup>{''.join('<col class="'+x+'">' for x in ['rl-lane','rl-photo','rl-name','rl-class','rl-bio','rl-tilt','rl-local','rl-st','rl-fl','rl-meeting','rl-motor','rl-boat'])}</colgroup><thead><tr><th>艇</th><th>写真</th><th>選手</th><th>級別</th><th>年齢/体重<br>支部<br>出身</th><th>チルト</th><th>当地勝率</th><th>平均ST</th><th>F/L</th><th class="meeting-main-column-head"><div class="meeting-column-head-wrap"><div class="meeting-column-title">節間成績</div><table class="meeting-column-days"><colgroup>{'<col>'*6}</colgroup><tr><th colspan="2">初日</th><th colspan="2">2日目</th><th colspan="2">3日目</th></tr></table></div></th><th>モーター</th><th>ボート</th></tr></thead><tbody>{rows}</tbody></table></div>'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':850},device_scale_factor=1)
    page.set_content(html)
    result=page.evaluate('''() => { const $=s=>document.querySelector(s); const r=e=>{const b=$(e).getBoundingClientRect();return {width:b.width,height:b.height,x:b.x,y:b.y}}; return {table:r('.racelist-inline-meeting'),head:r('.meeting-column-head-wrap'),title:r('.meeting-column-title'),days:r('.meeting-column-days'),day:r('.meeting-column-days th'),bio:r('.racelist-bio-cell'),name:r('td.name'),nameFont:getComputedStyle($('td.name .racer-link')).fontSize,bioFont:getComputedStyle($('.racer-bio-line span')).fontSize,motorFont:getComputedStyle($('.racelist-inline-meeting > tbody > tr > td:nth-last-child(2)')).fontSize};}''')
    print(result)
    page.screenshot(path='/mnt/data/racepo_v17332_build/test_mobile.png')
    assert abs(result['title']['height']-result['days']['height'])<1.1
    assert result['nameFont']=='14px'
    assert result['motorFont']=='11px'
    browser.close()
