
import io
import re
import requests
from datetime import datetime
from zoneinfo import ZoneInfo
from bs4 import BeautifulSoup
from threading import Lock
from time import monotonic

KARATSU_JCD = "23"
KARATSU_COMMENTS_URL = "https://www.boatrace-karatsu.jp/modules/raceinfo/?page=index_racers_comment"
_KARATSU_CACHE = {}
_KARATSU_LOCK = Lock()

TODA_JCD = "02"
TODA_PDF_URL = "https://www.boatrace-toda.jp/pdf/{date}_kenkyu.pdf?ver=1"


def _clean(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _pdf_text_from_bytes(data: bytes) -> str:
    """
    Use pypdf when available.  The launcher already installs Python packages;
    this module fails softly if pypdf is unavailable.
    """
    try:
        from pypdf import PdfReader
    except Exception:
        return ""

    try:
        reader = PdfReader(io.BytesIO(data))
        parts = []
        for page in reader.pages:
            parts.append(page.extract_text() or "")
        return "\n".join(parts)
    except Exception:
        return ""


def _normalize_name(name: str) -> str:
    # PDFs frequently insert spaces between family/given name.
    return re.sub(r"[\s　]+", "", str(name or ""))


def _comment_candidates(text: str):
    """
    Pull short human-language lines from Toda's research paper.
    This deliberately avoids treating numeric/statistical rows as comments.
    """
    rows = []
    for raw in text.splitlines():
        line = _clean(raw)
        if not line:
            continue
        if len(line) < 4 or len(line) > 90:
            continue
        # Ignore lines dominated by figures/symbols.
        digit_ratio = sum(ch.isdigit() for ch in line) / max(1, len(line))
        if digit_ratio > 0.32:
            continue
        if re.fullmatch(r"[0-9０-９\s./%→←\-]+", line):
            continue
        rows.append(line)
    return rows


def parse_toda_comments(pdf_text: str, racers: list, rno: int):
    """
    Pilot parser.

    Toda's paper layout changes occasionally, so we anchor on racer names:
      racer name -> nearby short Japanese sentence -> comment

    We only accept a comment when a racer name is found in the extracted PDF
    text.  This prevents comments being attached to the wrong racer.
    """
    normalized_text = _normalize_name(pdf_text)
    lines = _comment_candidates(pdf_text)

    out = []

    for racer in racers or []:
        lane = racer.get("lane")
        name = _clean(racer.get("name"))
        compact_name = _normalize_name(name)

        if not compact_name or compact_name not in normalized_text:
            continue

        # Find lines around the name in extracted order.
        idxs = []
        for i, line in enumerate(lines):
            if compact_name in _normalize_name(line):
                idxs.append(i)

        best = None
        for idx in idxs:
            nearby = lines[max(0, idx - 4): min(len(lines), idx + 6)]
            for candidate in nearby:
                c = candidate
                ccompact = _normalize_name(c)
                if compact_name in ccompact:
                    # If same line contains text after the name, use tail.
                    pos = ccompact.find(compact_name)
                    # Work with original line approximately; safe fallback below.
                    tail = re.sub(
                        r"^.*?" + re.escape(name).replace(r"\ ", r"\s*"),
                        "",
                        c,
                        count=1
                    )
                    tail = _clean(tail).lstrip("：:・- ")
                    if len(tail) >= 4 and not re.match(r"^[0-9０-９]", tail):
                        best = tail[:160]
                        break
                    continue

                # Nearby sentence candidate: avoid headers/stat lines.
                if any(k in c for k in [
                    "勝率", "展示", "モーター", "ボート", "進入",
                    "ST", "着", "連率", "登録", "級別", "支部"
                ]):
                    continue
                if len(c) >= 5:
                    best = c[:160]
                    break
            if best:
                break

        if best:
            out.append({
                "lane": lane,
                "name": name,
                "comment": best,
                "source": "boatrace-toda.jp",
                "source_kind": "toda_kenkyu_pdf",
            })

    return out


def fetch_toda_comments(date: str, rno: int, racers: list):
    url = TODA_PDF_URL.format(date=date)
    try:
        resp = requests.get(
            url,
            timeout=(5.0, 18.0),
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 Chrome/140 Safari/537.36"
                )
            },
        )
        resp.raise_for_status()
    except Exception as e:
        return {
            "ok": False,
            "comments": [],
            "source_url": url,
            "reason": f"戸田公式コメントPDF取得失敗: {e}",
        }

    text = _pdf_text_from_bytes(resp.content)
    if not text:
        return {
            "ok": False,
            "comments": [],
            "source_url": url,
            "reason": "戸田公式PDFの文字抽出に失敗（pypdf未導入またはPDF構造非対応）",
        }

    comments = parse_toda_comments(text, racers, int(rno))

    return {
        "ok": bool(comments),
        "comments": comments,
        "source_url": url,
        "reason": None if comments else "戸田公式PDF内で選手コメントを対応付けできませんでした",
    }


def _compact_name(value):
    return re.sub(r"[\s　]+", "", str(value or ""))


def parse_karatsu_comments(html: str, racers: list):
    """Extract only rows with an unambiguous registered racer number.

    Karatsu publishes a current-series *all racers* table, rather than
    separate comments per race.  Never assign a comment by row order.
    """
    soup = BeautifulSoup(html, "html.parser")
    if "全選手コメント" not in soup.get_text(" ", strip=True):
        return []

    found = {}
    for tr in soup.select("tr"):
        cells = tr.find_all(["td", "th"], recursive=False)
        if len(cells) < 3:
            continue
        texts = [_clean(c.get_text(" ", strip=True)) for c in cells]
        reg = None
        reg_idx = None
        for idx, value in enumerate(texts[:2]):
            match = re.search(r"(?<!\d)([3-5]\d{3})(?!\d)", value)
            if match:
                reg = match.group(1)
                reg_idx = idx
                break
        if not reg:
            continue
        # The site's table uses [racer, motor rating, comment, history].
        # Some site versions split the racer id and name into two columns.
        comment_idx = (reg_idx or 0) + 2
        if comment_idx >= len(cells):
            continue
        candidate = texts[comment_idx]
        if candidate.startswith(("出足", "伸び足", "素性")) or len(candidate) < 4:
            continue
        if "■■" in candidate or "帰郷" in candidate:
            continue
        found[reg] = candidate[:600]

    comments = []
    for racer in racers or []:
        reg = str(racer.get("registration_no") or "").strip()
        value = found.get(reg)
        if not value:
            continue
        comments.append({
            "lane": racer.get("lane"),
            "registration_no": reg,
            "name": racer.get("name"),
            "comment": value,
            "source": "boatrace-karatsu.jp",
            "source_kind": "karatsu_official_all_racers",
            "comment_scope": "series_day_racer",  # not a race-specific quote
        })
    return comments


def fetch_karatsu_comments(date: str, rno: int, racers: list):
    url = KARATSU_COMMENTS_URL
    # This URL defaults to the live/current day.  Never attach the current
    # page to a historical or future race with a different date.
    today = datetime.now(ZoneInfo("Asia/Tokyo")).strftime("%Y%m%d")
    if str(date) != today:
        return {"ok": False, "comments": [], "source_url": url,
                "reason": "唐津の公式コメントは現在日のみ取得可能なため、指定日には紐づけません"}
    try:
        with _KARATSU_LOCK:
            record = _KARATSU_CACHE.get(date)
            if record and monotonic() - record[0] < 300:
                html = record[1]
            else:
                response = requests.get(url, timeout=(5, 15), headers={
                    "User-Agent": "Mozilla/5.0 (compatible; RACEPO/1.0)"})
                response.raise_for_status()
                response.encoding = response.apparent_encoding or response.encoding
                html = response.text
                _KARATSU_CACHE[date] = (monotonic(), html)
        comments = parse_karatsu_comments(html, racers)
        return {"ok": bool(comments), "comments": comments, "source_url": url,
                "reason": None if comments else "唐津公式ページの登録番号と出走選手を照合できませんでした"}
    except Exception as exc:
        return {"ok": False, "comments": [], "source_url": url,
                "reason": f"唐津公式コメント取得失敗: {exc}"}


ASHIYA_JCD = "21"
ASHIYA_COMMENTS_URL = "https://www.boatrace-ashiya.com/modules/raceinfo/?page=index_racers_comment"
_ASHIYA_CACHE = {}
_ASHIYA_LOCK = Lock()


def parse_ashiya_comments(html: str, racers: list):
    """The official table is 登録番号|選手名|級別|コメント.

    A registration number alone is not enough: verify the paired racer name,
    reject duplicates/conflicts, and never use row-order as a lane mapping.
    """
    soup = BeautifulSoup(html, "html.parser")
    if "選手コメント" not in soup.get_text(" ", strip=True):
        return []
    by_reg = {}
    conflicts = set()
    for table in soup.select("table"):
        header = _clean(" ".join(th.get_text(" ", strip=True) for th in table.select("th")))
        if not ("登録番号" in header and "コメント" in header):
            continue
        for tr in table.select("tr"):
            cells = tr.find_all("td", recursive=False)
            if len(cells) < 4:
                continue
            reg = _clean(cells[0].get_text(" ", strip=True))
            if not re.fullmatch(r"[3-5]\d{3}", reg):
                continue
            name = _compact_name(cells[1].get_text(" ", strip=True))
            comment = _clean(cells[3].get_text(" ", strip=True))
            if not name or len(comment) < 3 or comment in ("－", "—", "なし", "-"):
                continue
            record = (name, comment[:600])
            if reg in by_reg and by_reg[reg] != record:
                conflicts.add(reg)
            by_reg[reg] = record
    out = []
    for racer in racers or []:
        reg = str(racer.get("registration_no") or "").strip()
        if not reg or reg in conflicts or reg not in by_reg:
            continue
        official_name, comment = by_reg[reg]
        if _compact_name(racer.get("name")) != official_name:
            continue
        out.append({
            "lane": racer.get("lane"), "registration_no": reg,
            "name": racer.get("name"), "comment": comment,
            "source": "boatrace-ashiya.com",
            "source_kind": "ashiya_official_previous_day",
            "comment_scope": "series_day_racer",
            "comment_period": "previous_day",
        })
    return out


def fetch_ashiya_comments(date: str, rno: int, racers: list):
    url = ASHIYA_COMMENTS_URL
    today = datetime.now(ZoneInfo("Asia/Tokyo")).strftime("%Y%m%d")
    if str(date) != today:
        return {"ok": False, "comments": [], "source_url": url,
                "reason": "芦屋の公開一覧は現在開催分のため、指定日のコメントとは照合しません"}
    try:
        with _ASHIYA_LOCK:
            record = _ASHIYA_CACHE.get(date)
            if record and monotonic() - record[0] < 300:
                html = record[1]
            else:
                response = requests.get(url, timeout=(5, 15), headers={
                    "User-Agent": "Mozilla/5.0 (compatible; RACEPO/1.0)"})
                response.raise_for_status()
                response.encoding = response.apparent_encoding or response.encoding
                html = response.text
                _ASHIYA_CACHE[date] = (monotonic(), html)
        comments = parse_ashiya_comments(html, racers)
        return {"ok": bool(comments), "comments": comments, "source_url": url,
                "reason": None if comments else "芦屋公式コメント一覧から登録番号・選手名の一致を確認できませんでした"}
    except Exception as exc:
        return {"ok": False, "comments": [], "source_url": url,
                "reason": f"芦屋公式コメント取得失敗: {exc}"}


def fetch_venue_comments(date: str, jcd: str, rno: int, racers: list):
    """
    Venue adapter dispatcher.
    Start with Toda only.  Other venues can be added independently later.
    """
    jcd = str(jcd).zfill(2)

    if jcd == TODA_JCD:
        return fetch_toda_comments(date, rno, racers)
    if jcd == KARATSU_JCD:
        return fetch_karatsu_comments(date, rno, racers)
    if jcd == ASHIYA_JCD:
        return fetch_ashiya_comments(date, rno, racers)

    return {
        "ok": False,
        "comments": [],
        "source_url": None,
        "reason": "このレース場はコメント取得アダプター未対応です",
    }
