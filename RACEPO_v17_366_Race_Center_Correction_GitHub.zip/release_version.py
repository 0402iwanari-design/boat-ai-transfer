"""Read the version of the actual server release, not a UI design version."""
from pathlib import Path
import re

RELEASE_FILE = "RELEASE_VERSION"
_VERSION_RE = re.compile(r"^17\.\d+$")
_DEPLOY_RE = re.compile(r"RACEPO_v(17_\d+)(?:_|$)", re.IGNORECASE)

def deployed_version(project_directory=None):
    project = Path(project_directory) if project_directory is not None else Path(__file__).resolve().parent
    marker = project / RELEASE_FILE
    if marker.is_file():
        version = marker.read_text(encoding="utf-8").strip()
        if _VERSION_RE.fullmatch(version):
            return version
    # Backward compatibility with older releases that were named by the webhook.
    for parent in (project, *list(project.parents)[:2]):
        match = _DEPLOY_RE.search(parent.name)
        if match:
            return match.group(1).replace("_", ".")
    return "unknown"
