import unittest
from unittest.mock import patch
from boat_source import BoatRaceSource

class DummyDB:
    def __init__(self): self.snaps={}; self.comments=[]
    def get_snapshot(self,d,j,r,k):
        return {'data':self.snaps[(d,j,r,k)]} if (d,j,r,k) in self.snaps else None
    def save_snapshot(self,d,j,r,k,v): self.snaps[(d,j,r,k)]=v
    def save_comments(self,d,j,r,comments): self.comments.extend(comments)

class StatusTests(unittest.TestCase):
    def run_case(self,reason, comments, expected):
        obj=BoatRaceSource.__new__(BoatRaceSource); obj.db=DummyDB()
        obj.db.save_snapshot('20261109','21',2,'racelist',{'racers':[]})
        with patch('boat_source.fetch_venue_comments',return_value={'reason':reason,'comments':comments,'source_url':None}):
            obj.fetch_venue_comments_for_race('20261109','21',2)
        self.assertEqual(obj.db.get_snapshot('20261109','21',2,'comment_status')['data']['status'],expected)
        # Later refresh of beforeinfo must not erase independent status.
        obj.db.save_snapshot('20261109','21',2,'beforeinfo',{'weather':{'wind_speed':2}})
        self.assertEqual(obj.db.get_snapshot('20261109','21',2,'comment_status')['data']['status'],expected)
    def test_success(self): self.run_case(None,[{'lane':1,'comment':'伸びはいい'}],'available')
    def test_failure(self): self.run_case('取得失敗',[],'collection_error')
    def test_unmatched(self): self.run_case('照合できません',[],'collection_error')
    def test_unsupported(self): self.run_case('アダプター未対応',[],'unsupported')
    def test_markup(self):
        from pathlib import Path
        html=Path(__file__).parent.joinpath('static/index.html').read_text()
        for term in ('選手コメント：収集エラー','選手コメント：更新待ち','自動収集にまだ対応','status==="unpublished"','escapeHtml(reason'):
            self.assertIn(term,html)
if __name__=='__main__': unittest.main()
