import json
import sqlite3
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from daily_data_audit import audit_day
from statistical_ai import Store, import_local_db, feature_map, PATTERN_FIELDS

class DB:
    def __init__(self, path): self.path = path
    def connect(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

class NoTideTests(unittest.TestCase):
    def test_feature_map_never_tracks_tide(self):
        self.assertNotIn('tide_phase', PATTERN_FIELDS)
        self.assertNotIn('tide_phase', feature_map('2026-11-08', 5, tide_phase='満潮', wind_speed=2, wave=3))

    def test_no_tide_table_does_not_block_import_or_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'race.sqlite'
            r = Path(tmp) / 'research.sqlite'
            with sqlite3.connect(p) as c:
                c.executescript('''
                    CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,payload TEXT);
                    CREATE TABLE race_snapshots(date TEXT,jcd TEXT,rno INTEGER,kind TEXT,payload TEXT,captured_at TEXT);
                    CREATE TABLE race_schedule(date TEXT,jcd TEXT,rno INTEGER,deadline TEXT);
                    CREATE TABLE venue_event_meta(date TEXT,jcd TEXT,event_grade TEXT);
                ''')
                finish = json.dumps({'finishers':[{'lane':i,'finish':i} for i in range(1,7)]})
                c.execute('INSERT INTO race_results VALUES (?,?,?,?,?,?)',('20261108','12',5,'1-2-3',1200,finish))
                c.execute('INSERT INTO race_schedule VALUES (?,?,?,?)',('20261108','12',5,'17:30'))
                c.execute('INSERT INTO venue_event_meta VALUES (?,?,?)',('20261108','12','G1'))
                c.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',('20261108','12',5,'racelist',json.dumps({'racers':[{'lane':i,'class':'A1'} for i in range(1,7)]}),'2026-11-08T16:00:00+09:00'))
                c.execute('INSERT INTO race_snapshots VALUES (?,?,?,?,?,?)',('20261108','12',5,'beforeinfo',json.dumps({'weather':{'wind_direction':'向かい風','wind_speed_m':3,'wave_height_cm':2}}),'2026-11-08T17:00:00+09:00'))
            store = Store(r)
            out = import_local_db(store,p,only_day='20261108',only_venue='12')
            self.assertEqual(out['imported'],1)
            self.assertNotIn('tide_phase',store.read_venue('12')[0]['features'])
            audit = audit_day(DB(p),'20261108',now=datetime(2026,11,9,tzinfo=ZoneInfo('Asia/Tokyo')),research_path=r)
            self.assertNotIn('tide',audit['venues'][0]['fields'])
            self.assertNotIn('tide',audit['field_totals'])
            self.assertEqual(audit['venues'][0]['statistical']['complete_races'],1)

if __name__ == '__main__': unittest.main()
