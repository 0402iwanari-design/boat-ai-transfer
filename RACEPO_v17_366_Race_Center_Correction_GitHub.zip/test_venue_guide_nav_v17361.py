"""Regression checks for replacing the old venue-knowledge sidebar entry."""
import unittest
from pathlib import Path
from bs4 import BeautifulSoup
from fastapi.testclient import TestClient
from app import app

HTML = Path(__file__).parent.joinpath('static/index.html').read_text(encoding='utf-8')

class VenueGuideNavigationTests(unittest.TestCase):
    def test_sidebar_replaced_in_original_position(self):
        doc=BeautifulSoup(HTML,'html.parser')
        sidebar=doc.select_one('#leftSidebar')
        names=[node.get('id') for node in sidebar.find_all(recursive=False)]
        self.assertIn('sideVenueGuidesBtn',names)
        self.assertNotIn('sideKnowledgeBtn',names)
        self.assertEqual(names.index('sideVenueGuidesBtn'),names.index('sideTodayResultsBtn')+1)
        a=sidebar.select_one('#sideVenueGuidesBtn')
        self.assertEqual(a.name,'button')
        self.assertIsNone(a.get('href'))
        self.assertEqual(a.get_text(' ',strip=True).replace('📚','').strip(),'全国24場の特徴')

    def test_legacy_navigation_handler_removed_without_touching_data_engine(self):
        self.assertNotIn('sideKnowledge.onclick',HTML)
        self.assertIn('function openVenueKnowledge(code)',HTML)
        self.assertIn('id="knowledgeScreen"',HTML)

    def test_live_route_and_all_24_venues(self):
        with TestClient(app) as c:
            self.assertEqual(c.get('/venues').status_code,200)
            home=c.get('/')
            self.assertEqual(home.status_code,200)
            self.assertIn('id="venueGuidesScreen"',home.text)
            self.assertIn('全国24場の特徴',home.text)
            self.assertEqual(c.get('/api/health').json()['version'],'17.363')

if __name__=='__main__': unittest.main()
