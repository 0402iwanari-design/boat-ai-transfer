from __future__ import annotations
"""v17.208 validation build: 峰竜太(4320) nationwide + Kojima actual-entry history.

Collection method is intentionally the same validated flow used for nationwide:
1. Scan daily race index newest to oldest only as a candidate finder.
2. For nationwide, find racer 4320 across all venues.
3. For local history, inspect ONLY Kojima (jcd=16); do not collect other venues.
4. Open BOAT RACE official result page for each candidate race.
5. Determine actual entry course only from official スタート情報 lane order.
6. Preserve official ST and finish, then bucket by actual course 1..6.
7. Keep newest 10 per course.  For Kojima, continue back only as needed to 2023.
8. If fewer than 10 remain after checking through 2023, that count is normal completion.

欠場/non-start is ignored. Special results are retained when the racer actually started.
"""

import re
import threading
import time
import unicodedata
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
FLOOR_YEAR = 2023
FLOOR = "20230101"
VALIDATION_REG = "4320"
VALIDATION_NAME = "峰竜太"
VALIDATION_LOCAL_JCD = "16"  # 児島だけを当地履歴として収集

VENUES = [
    "桐生", "戸田", "江戸川", "平和島", "多摩川", "浜名湖", "蒲郡", "常滑", "津", "三国", "びわこ", "住之江",
    "尼崎", "鳴門", "丸亀", "児島", "宮島", "徳山", "下関", "若松", "芦屋", "福岡", "唐津", "大村",
]
VENUE_CODE = {n: f"{i:02d}" for i, n in enumerate(VENUES, 1)}


def _nfkc(s):
    return unicodedata.normalize("NFKC", str(s or ""))


def _norm(s):
    return re.sub(r"[\s\u3000]+", "", _nfkc(s))


def _venue_code(s):
    n = _norm(s)
    return next((code for name, code in VENUE_CODE.items() if _norm(name) == n), None)


def _date_token(s, year):
    text = _nfkc(s)
    # 8/30, 08/30, 2026/08/30, 2026-08-30
    m = re.search(r"(?<!\d)(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})(?!\d)", text)
    if not m:
        return None
    y = int(m.group(1) or year)
    return f"{y:04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def _race_token(s):
    m = re.fullmatch(r"\s*(\d{1,2})\s*R\s*", _nfkc(s), re.I)
    if not m:
        return None
    r = int(m.group(1))
    return r if 1 <= r <= 12 else None


def _st_token(s):
    """Official start text. Bare 1..6 is never ST."""
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return t
    if re.fullmatch(r"[FL]\.\d{1,2}", t):
        return t
    if t in {"F", "L"}:
        return t
    return None


def _st_value(s):
    """Signed value for ST ranking. F.01 -> -0.01. L without numeric is unranked."""
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return float("0" + t)
    m = re.fullmatch(r"F\.(\d{1,2})", t)
    if m:
        return -float("0." + m.group(1))
    m = re.fullmatch(r"L\.(\d{1,2})", t)
    if m:
        return float("0." + m.group(1))
    return None


def _finish_token(s):
    t = _norm(s).replace("着", "")
    # Numeric finishes + common BOAT RACE special result notation.
    return t if re.fullmatch(r"[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠", t) else None


def _expand_table(table):
    """Expand rowspan/colspan into a rectangular text grid."""
    grid = []
    spans = {}  # col -> [remaining rows, text]
    for tr in table.find_all("tr"):
        row, col = [], 0
        cells = tr.find_all(["th", "td"], recursive=False)
        ci = 0
        while ci < len(cells) or spans:
            while col in spans:
                rem, text = spans[col]
                while len(row) <= col:
                    row.append("")
                row[col] = text
                if rem <= 1:
                    del spans[col]
                else:
                    spans[col] = [rem - 1, text]
                col += 1
            if ci >= len(cells):
                if not spans:
                    break
                next_col = min(spans)
                while col < next_col:
                    row.append("")
                    col += 1
                continue
            cell = cells[ci]
            ci += 1
            text = " ".join(cell.stripped_strings)
            try:
                cs = max(1, int(cell.get("colspan", 1)))
            except (TypeError, ValueError):
                cs = 1
            try:
                rs = max(1, int(cell.get("rowspan", 1)))
            except (TypeError, ValueError):
                rs = 1
            for _ in range(cs):
                while col in spans:
                    rem, old = spans[col]
                    while len(row) <= col:
                        row.append("")
                    row[col] = old
                    if rem <= 1:
                        del spans[col]
                    else:
                        spans[col] = [rem - 1, old]
                    col += 1
                while len(row) <= col:
                    row.append("")
                row[col] = text
                if rs > 1:
                    spans[col] = [rs - 1, text]
                col += 1
        grid.append(row)
    width = max((len(r) for r in grid), default=0)
    return [r + [""] * (width - len(r)) for r in grid]


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = {
            "phase": "本日の出走表待ち",
            "validation_mode": "峰竜太（4320）全国＋児島・公式結果照合方式",
        }

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._scheduler, daemon=True, name="mine-course-history-national-kojima-official-verify"
        )
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            today = datetime.now(JST).strftime("%Y%m%d")
            try:
                self._run(today)
            except Exception as e:
                self.status = {
                    **self.db.get_course_history_target_status(today, VALIDATION_REG),
                    "phase": "収集処理エラー",
                    "scheduler_error": f"{type(e).__name__}: {e}",
                    "validation_mode": "峰竜太（4320）全国＋児島・公式結果照合方式",
                }
            self._stop.wait(10)

    def _reset_validation_racer(self, today):
        """v17.208 migration: preserve v17.204 nationwide rows and enable Kojima phase.

        Important: do NOT delete racer_course_runs here.  The user already verified
        nationwide collection, so v17.208 resumes the target in order to fill
        Kojima(16) local actual-course buckets.
        """
        key = "course_history_v17_208_mine4320_racer_exact_candidates"
        start = (datetime.now(JST).date() - timedelta(days=1)).strftime("%Y%m%d")
        with self.db.connect() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS app_migrations (
                    migration_key TEXT PRIMARY KEY, applied_at TEXT DEFAULT CURRENT_TIMESTAMP
                )"""
            )
            if con.execute("SELECT 1 FROM app_migrations WHERE migration_key=?", (key,)).fetchone():
                return False
            # Preserve all saved course-history rows. Reopen 峰4320/児島 target.
            # If v17.206 skipped a legacy day because its top-level JSON was a list,
            # rewind to that failed day so it is not permanently missed.
            # v17.208 changes the candidate-finder itself.  Re-scan local Kojima from
            # yesterday so no race that was missed/misidentified by v17.207 remains skipped.
            # Existing verified rows are preserved; UNIQUE(date,jcd,rno,registration_no)
            # makes this safe and idempotent.
            resume = start
            con.execute(
                """UPDATE course_history_target_state
                   SET status='pending',cursor_date=?,floor_date=?,target_date=?,retry_count=0,
                       failed_date=NULL,last_error=NULL,completed_at=NULL,updated_at=CURRENT_TIMESTAMP
                   WHERE registration_no=? AND jcd=?""",
                (resume, FLOOR, today, VALIDATION_REG, VALIDATION_LOCAL_JCD),
            )
            con.execute("INSERT INTO app_migrations(migration_key) VALUES(?)", (key,))
        return True

    def _ensure_validation_target(self, today):
        start = (datetime.now(JST).date() - timedelta(days=1)).strftime("%Y%m%d")
        with self.db.connect() as con:
            old = con.execute(
                "SELECT 1 FROM course_history_target_state WHERE registration_no=? AND jcd=?",
                (VALIDATION_REG, VALIDATION_LOCAL_JCD),
            ).fetchone()
            if old is None:
                con.execute(
                    """INSERT INTO course_history_target_state
                       (registration_no,jcd,name,status,cursor_date,floor_date,target_date)
                       VALUES(?,?,?,'pending',?,?,?)""",
                    (VALIDATION_REG, VALIDATION_LOCAL_JCD, VALIDATION_NAME, start, FLOOR, today),
                )
            else:
                con.execute(
                    """UPDATE course_history_target_state
                       SET name=?,status='pending',
                           cursor_date=COALESCE(cursor_date,?),floor_date=?,target_date=?,retry_count=0,
                           failed_date=NULL,last_error=NULL,updated_at=CURRENT_TIMESTAMP
                       WHERE registration_no=? AND jcd=?""",
                    (
                        VALIDATION_NAME,
                        start,
                        FLOOR,
                        today,
                        VALIDATION_REG,
                        VALIDATION_LOCAL_JCD,
                    ),
                )

    def _national_counts(self, reg):
        with self.db.connect() as con:
            rows = con.execute(
                """SELECT course,COUNT(*) n FROM racer_course_runs
                   WHERE registration_no=? AND date>=? GROUP BY course""",
                (reg, FLOOR),
            ).fetchall()
        return {int(x["course"]): min(10, int(x["n"])) for x in rows}

    @staticmethod
    def _national_done(nm):
        return all(nm.get(c, 0) >= 10 for c in range(1, 7))

    def _local_counts(self, reg, jcd=VALIDATION_LOCAL_JCD):
        with self.db.connect() as con:
            rows = con.execute(
                """SELECT course,COUNT(*) n FROM racer_course_runs
                   WHERE registration_no=? AND jcd=? AND date>=? GROUP BY course""",
                (reg, str(jcd).zfill(2), FLOOR),
            ).fetchall()
        return {int(x["course"]): min(10, int(x["n"])) for x in rows}

    @staticmethod
    def _local_done(lm):
        return all(lm.get(c, 0) >= 10 for c in range(1, 7))

    @staticmethod
    def _obj_jcd(obj):
        if not isinstance(obj, dict):
            return None
        raw = (obj.get("race_stadium_number") or obj.get("stadium_number") or
               obj.get("stadium_no") or obj.get("jcd"))
        try:
            return str(int(raw)).zfill(2)
        except Exception:
            t = str(raw or "").strip()
            return t.zfill(2) if t.isdigit() else None

    @staticmethod
    def _obj_rno(obj):
        if not isinstance(obj, dict):
            return None
        raw = obj.get("race_number") or obj.get("rno")
        try:
            n = int(raw)
            return n if 1 <= n <= 12 else None
        except Exception:
            return None

    @staticmethod
    def _contains_racer_exact(node, reg):
        """Exact registration-number match only; never infer from names/positions."""
        wanted = str(reg)
        if isinstance(node, list):
            return any(OfficialCourseHistoryCollector._contains_racer_exact(x, wanted) for x in node)
        if not isinstance(node, dict):
            return False
        for key in ("racer_number", "registration_number", "registration_no", "number", "toban"):
            if key in node and str(node.get(key) or "") == wanted:
                return True
        return any(OfficialCourseHistoryCollector._contains_racer_exact(v, wanted)
                   for k, v in node.items() if k not in {"name", "racer_name"})

    def _race_objects_strict(self, data):
        """Yield only objects that themselves own both venue and race number.

        v17.207 propagated a venue/race number down arbitrary nested dictionaries,
        which could associate racer 4320 with the wrong race.  This deliberately
        refuses inherited IDs: the same object must contain jcd + rno.
        """
        found = []
        def walk(node):
            if isinstance(node, list):
                for x in node:
                    walk(x)
                return
            if not isinstance(node, dict):
                return
            if self._obj_jcd(node) and self._obj_rno(node):
                found.append(node)
                return
            for v in node.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        walk(data)
        return found

    def _extract_exact_candidates(self, data, reg, ymd, only_jcd=None):
        """Extract candidate races only when the same race object contains racer 4320."""
        only = str(only_jcd).zfill(2) if only_jcd else None
        out = []
        for race in self._race_objects_strict(data):
            jcd = self._obj_jcd(race)
            rno = self._obj_rno(race)
            if not jcd or not rno or (only and jcd != only):
                continue
            # Look only inside this race object. No venue/race inheritance is allowed.
            if self._contains_racer_exact(race, reg):
                out.append({"date": str(ymd), "jcd": jcd, "rno": rno})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["jcd"], x["rno"]), reverse=True)

    def _official_racelist_has_racer(self, session, ymd, jcd, rno, reg):
        """Exact pre-check on BOAT RACE racelist; used only for 2023/01-04 fallback."""
        url = ("https://www.boatrace.jp/owpc/pc/race/racelist"
               f"?hd={ymd}&jcd={str(jcd).zfill(2)}&rno={int(rno)}")
        try:
            r = session.get(url, timeout=(5, 15))
            if r.status_code == 404:
                return False
            r.raise_for_status()
            text = _nfkc(BeautifulSoup(r.text, "html.parser").get_text(" "))
            return re.search(rf"(?<!\\d){re.escape(str(reg))}(?!\\d)", text) is not None
        except Exception:
            return False

    def _fetch_candidate_day(self, session, reg, ymd, only_jcd=None):
        """Racer-first exact candidate finder, then BOAT RACE official result verification.

        2025-05-01 onward: historical *results* API, exact racer-number match.
        2023-05-01..2025-04-30: programs v3, but only strict race-owned jcd/rno objects.
        2023-01-01..2023-04-30: Kojima-only BOAT RACE racelist exact registration check.

        Candidate sources are never trusted for course/ST/finish; those are still read
        only from the BOAT RACE official result page in _fetch_official_run().
        """
        ymd = str(ymd)
        year = ymd[:4]
        only = str(only_jcd).zfill(2) if only_jcd else None
        if only and only != VALIDATION_LOCAL_JCD:
            raise RuntimeError("v17.208 local validation is Kojima(16) only")

        # Before legacy API coverage: inspect only Kojima's 12 racelists, exact 4320 match.
        if ymd < "20230501":
            if only != VALIDATION_LOCAL_JCD:
                raise RuntimeError("2023/01-04 fallback is Kojima-only")
            rows = []
            for rno in range(1, 13):
                if self._official_racelist_has_racer(session, ymd, VALIDATION_LOCAL_JCD, rno, reg):
                    rows.append({"date": ymd, "jcd": VALIDATION_LOCAL_JCD, "rno": rno})
            self.status.update({
                "phase": "児島コース履歴・選手一致候補確認中",
                "crawl_stage": f"{ymd} 児島16の出走表で{reg}だけを照合",
                "scan_date": ymd,
                "last_fetch_state": "official racelist exact candidate check",
                "last_fetch_error": None,
                "candidate_races": len(rows),
                "direct_source": "BOAT RACE official racelist / Kojima16 only",
            })
            return rows, {"url": "BOAT RACE official racelist / Kojima16 only", "http": 200, "attempt": 1}

        if ymd >= "20250501":
            # Result history contains the racer registration number and therefore gives
            # an exact race candidate without guessing from table positions.
            url = f"https://boatraceopenapi.github.io/results/v2/{year}/{ymd}.json"
            source_label = "results-v2 exact racer history"
        else:
            url = f"https://boatraceopenapi.github.io/programs/v3/{year}/{ymd}.json"
            source_label = "programs-v3 strict race object"

        self.status.update({
            "phase": "児島コース履歴・選手一致候補確認中" if only else "全国コース履歴・選手一致候補確認中",
            "crawl_stage": f"{ymd} {VALIDATION_NAME}({reg})の出走だけ検索 → 児島16だけ残す ({source_label})",
            "scan_date": ymd,
            "last_fetch_state": "fetching racer exact candidate history",
            "last_fetch_error": None,
            "direct_source": url,
        })
        last = None
        for attempt in range(1, 4):
            try:
                r = session.get(url, timeout=(5, 20))
                if r.status_code == 404:
                    return [], {"url": url, "http": 404, "attempt": attempt}
                r.raise_for_status()
                data = r.json()
                rows = self._extract_exact_candidates(data, reg, ymd, only_jcd=only)
                self.status.update({
                    "last_fetch_state": "racer exact candidate history ok",
                    "last_fetch_error": None,
                    "candidate_races": len(rows),
                    "direct_source": r.url,
                })
                return rows, {"url": r.url, "http": r.status_code, "attempt": attempt}
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                self.status.update({
                    "last_fetch_error": last,
                    "last_fetch_state": f"racer candidate retry {attempt}/3",
                    "direct_source": url,
                })
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or f"{ymd} 選手一致候補取得失敗")

    def _official_result_url(self, x):
        return (
            "https://www.boatrace.jp/owpc/pc/race/raceresult"
            f"?hd={x['date']}&jcd={str(x['jcd']).zfill(2)}&rno={int(x['rno'])}"
        )

    def _parse_official_result(self, html, candidate, reg):
        """Parse one official result page and return this racer's actual-entry run.

        Actual course is determined ONLY from the lane order in スタート情報:
        first lane shown = 1C, second = 2C ... sixth = 6C.
        """
        soup = BeautifulSoup(html, "html.parser")

        # --- finish/lane from the result table ---
        lane = None
        finish = None
        for tr in soup.find_all("tr"):
            cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
            if not cells:
                continue
            joined = " ".join(cells)
            if not re.search(rf"(?<!\d){re.escape(str(reg))}(?!\d)", _nfkc(joined)):
                continue
            # Result rows are normally: 着 / 枠 / racer / time.
            finish_candidates = [_finish_token(c) for c in cells]
            finish_candidates = [x for x in finish_candidates if x is not None]
            if finish_candidates:
                finish = finish_candidates[0]
            # The lane is the first plain 1..6 cell after the finish cell.  Prefer cell 2.
            for idx, c in enumerate(cells):
                t = _norm(c)
                if re.fullmatch(r"[1-6]", t):
                    # If cell 0 is numeric it is usually finish, cell 1 is lane.
                    if idx == 0 and len(cells) > 1 and re.fullmatch(r"[1-6]", _norm(cells[1])):
                        continue
                    lane = int(t)
                    break
            if lane is not None:
                break

        # Racer not in finish table -> 欠場/non-start or page mismatch. Do not store.
        if lane is None or finish is None or finish == "欠":
            return None

        # --- official start order / ST ---
        lines = [x.strip() for x in soup.get_text("\n").splitlines() if x.strip()]
        try:
            start_i = next(i for i, x in enumerate(lines) if _norm(x) == "スタート情報")
        except StopIteration:
            return None

        end_i = len(lines)
        for i in range(start_i + 1, len(lines)):
            n = _norm(lines[i])
            if n in {"勝式", "払戻金", "水面気象情報", "返還", "決まり手"}:
                end_i = i
                break

        start_rows = []  # [(lane, st_raw)] in the exact displayed order
        seg = lines[start_i + 1 : end_i]
        i = 0
        while i < len(seg):
            t = _norm(seg[i])
            if re.fullmatch(r"[1-6]", t):
                slane = int(t)
                st = None
                # Images/決まり手 text can be between lane and ST; search only nearby.
                for j in range(i + 1, min(i + 6, len(seg))):
                    st = _st_token(seg[j])
                    if st is not None:
                        break
                    # Stop if another lane begins before ST was found.
                    if re.fullmatch(r"[1-6]", _norm(seg[j])):
                        break
                if st is not None and slane not in [z[0] for z in start_rows]:
                    start_rows.append((slane, st))
            i += 1

        # Some official pages render lane and ST in the same text fragment. Fallback regex.
        if len(start_rows) < 2:
            block = "\n".join(seg)
            for m in re.finditer(r"(?m)^\s*([1-6])\s*(?:\n|\s)+((?:F|L)?\.\d{1,2}|F|L)\s*$", block):
                pair = (int(m.group(1)), _norm(m.group(2)).upper())
                if pair[0] not in [z[0] for z in start_rows]:
                    start_rows.append(pair)

        if lane not in [z[0] for z in start_rows]:
            return None

        course_by_lane = {slane: pos for pos, (slane, _st) in enumerate(start_rows, 1)}
        st_by_lane = {slane: st for slane, st in start_rows}
        course = course_by_lane.get(lane)
        st_raw = st_by_lane.get(lane)
        if not course or not (1 <= course <= 6) or st_raw is None:
            return None

        # Competition rank: tied STs share rank and following rank is skipped.
        numeric = []
        for slane, st in start_rows:
            v = _st_value(st)
            if v is not None:
                numeric.append((slane, v))
        numeric.sort(key=lambda z: z[1])
        ranks, last, rank = {}, None, 0
        for pos, (slane, v) in enumerate(numeric, 1):
            if last is None or abs(v - last) > 1e-9:
                rank = pos
                last = v
            ranks[slane] = rank

        return {
            "date": str(candidate["date"]),
            "jcd": str(candidate["jcd"]).zfill(2),
            "rno": int(candidate["rno"]),
            "registration_no": str(reg),
            "lane": int(lane),
            "course": int(course),
            "finish": str(finish),
            "st_raw": str(st_raw),
            "st_rank": ranks.get(lane),
            "source": "boatrace-official-result:actual-entry-v17204",
        }

    def _fetch_official_run(self, session, candidate, reg):
        url = self._official_result_url(candidate)
        last = None
        for attempt in range(1, 4):
            try:
                r = session.get(url, timeout=(5, 20))
                r.raise_for_status()
                row = self._parse_official_result(r.text, candidate, reg)
                return row, {"url": r.url, "http": r.status_code, "attempt": attempt}
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or "公式レース結果取得失敗")

    def _collect_scope(self, session, reg, started, *, only_jcd=None, floor_date=None):
        """Collect one scope with resumable day cursor and non-fatal fetch failures.

        only_jcd=None => nationwide; '16' => Kojima only.
        Local/Kojima collection persists the next unscanned date after every day, so
        process restarts never jump back to the newest day. A failed candidate day or
        a failed official-result page is recorded but does not abort the whole crawl.
        """
        scope_name = "児島" if only_jcd else "全国"
        counts_fn = (lambda: self._local_counts(reg, only_jcd)) if only_jcd else (lambda: self._national_counts(reg))
        done_fn = self._local_done if only_jcd else self._national_done
        floor_day = floor_date or datetime(2026, 1, 1, tzinfo=JST).date()

        # Resume local history from the persisted cursor. Nationwide validation remains
        # unchanged because v17.204 already completed it for 峰4320.
        scan_day = datetime.now(JST).date() - timedelta(days=1)
        if only_jcd:
            with self.db.connect() as con:
                state = con.execute(
                    """SELECT cursor_date FROM course_history_target_state
                       WHERE registration_no=? AND jcd=?""",
                    (str(reg), str(only_jcd).zfill(2)),
                ).fetchone()
            cursor = str(state["cursor_date"] or "") if state else ""
            if re.fullmatch(r"\d{8}", cursor):
                try:
                    scan_day = datetime.strptime(cursor, "%Y%m%d").date()
                except ValueError:
                    pass

        checked_days = verified = candidate_total = saved = skipped = 0
        failed_days = failed_races = 0
        lastdiag = {}
        last_nonfatal_error = None
        seen_races = set()

        def persist_next_day(next_day, *, failed_date=None, error=None):
            if not only_jcd:
                return
            next_ymd = next_day.strftime("%Y%m%d")
            # Keep the target resumable/collecting. Store the latest non-fatal error for
            # diagnostics, but never turn one bad day/race into a terminal target error.
            with self.db.connect() as con:
                con.execute(
                    """UPDATE course_history_target_state
                       SET status='collecting',cursor_date=?,
                           failed_date=?,last_error=?,retry_count=?,
                           started_at=COALESCE(started_at,CURRENT_TIMESTAMP),
                           updated_at=CURRENT_TIMESTAMP
                       WHERE registration_no=? AND jcd=? AND status!='complete'""",
                    (
                        next_ymd,
                        str(failed_date) if failed_date else None,
                        str(error)[:500] if error else None,
                        1 if error else 0,
                        str(reg), str(only_jcd).zfill(2),
                    ),
                )

        while scan_day >= floor_day:
            cm = counts_fn()
            if done_fn(cm):
                break
            ymd = scan_day.strftime("%Y%m%d")
            day_error = None
            try:
                candidates, lastdiag = self._fetch_candidate_day(session, reg, ymd, only_jcd=only_jcd)
            except Exception as e:
                candidates = []
                failed_days += 1
                day_error = f"{type(e).__name__}: {e}"
                last_nonfatal_error = f"{ymd} candidate: {day_error}"
                self.status.update({
                    "phase": f"{scope_name}コース履歴・候補日取得失敗→次の日へ継続",
                    "crawl_stage": f"{ymd} {scope_name}候補日取得失敗。記録して次の日へ進みます",
                    "last_fetch_state": "candidate day failed; continue",
                    "last_fetch_error": day_error,
                    "scan_date": ymd,
                })

            # Hard safety: local phase must never process another venue.
            if only_jcd:
                candidates = [x for x in candidates if str(x.get("jcd")).zfill(2) == str(only_jcd).zfill(2)]
            checked_days += 1
            candidate_total += len(candidates)
            self.status.update({
                "checked_days": checked_days,
                "crawl_list_pages": checked_days,
                "crawl_elapsed_seconds": int(time.monotonic() - started),
                "national_counts": self._national_counts(reg),
                "local_counts": self._local_counts(reg, VALIDATION_LOCAL_JCD),
                "crawl_jcd": str(only_jcd).zfill(2) if only_jcd else None,
                "failed_days": failed_days,
                "failed_races": failed_races,
                "last_nonfatal_error": last_nonfatal_error,
            })

            for idx, cand in enumerate(candidates, 1):
                if only_jcd and str(cand.get("jcd")).zfill(2) != str(only_jcd).zfill(2):
                    continue
                key = (cand["date"], cand["jcd"], int(cand["rno"]))
                if key in seen_races:
                    continue
                seen_races.add(key)
                cm = counts_fn()
                if done_fn(cm):
                    break

                self.status.update({
                    "phase": f"BOAT RACE公式結果で{scope_name}実進入確認中",
                    "crawl_stage": f"{ymd} {scope_name}候補 {idx}/{len(candidates)} → 場{cand['jcd']} {cand['rno']}R",
                    "last_fetch_state": "verifying official result",
                    "direct_source": self._official_result_url(cand),
                    "crawl_detail_pages": verified,
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                    "last_parsed_rows": saved,
                    "last_matched_rows": verified,
                    "checked_days": checked_days,
                    "national_counts": self._national_counts(reg),
                    "local_counts": self._local_counts(reg, VALIDATION_LOCAL_JCD),
                    "crawl_jcd": str(only_jcd).zfill(2) if only_jcd else None,
                    "failed_days": failed_days,
                    "failed_races": failed_races,
                })
                try:
                    row, detaildiag = self._fetch_official_run(session, cand, reg)
                    verified += 1
                    lastdiag = detaildiag
                except Exception as e:
                    failed_races += 1
                    err = f"{type(e).__name__}: {e}"
                    last_nonfatal_error = f"{cand['date']} 場{cand['jcd']} {cand['rno']}R: {err}"
                    self.status.update({
                        "phase": f"{scope_name}公式結果1R取得失敗→次レースへ継続",
                        "crawl_stage": f"{cand['date']} 場{cand['jcd']} {cand['rno']}R 取得失敗。次レースへ進みます",
                        "last_fetch_state": "official result failed; continue",
                        "last_fetch_error": err,
                        "failed_races": failed_races,
                        "last_nonfatal_error": last_nonfatal_error,
                    })
                    continue

                if row is None:
                    skipped += 1
                    continue
                # Local phase safety check after official parse as well.
                if only_jcd and str(row.get("jcd")).zfill(2) != str(only_jcd).zfill(2):
                    skipped += 1
                    continue
                course = int(row["course"])
                cm = counts_fn()
                if cm.get(course, 0) >= 10:
                    continue
                row["source"] = "boatrace-official-result:actual-entry-v17208-kojima" if only_jcd else "boatrace-official-result:actual-entry-v17208-national"
                self.db.save_course_history_runs([row], keep_per_local_course=10)
                saved += 1
                self.status.update({
                    "last_fetch_state": "official result saved",
                    "last_fetch_error": None,
                    "last_parsed_rows": saved,
                    "last_matched_rows": verified,
                    "last_fetch_date": row["date"],
                    "national_counts": self._national_counts(reg),
                    "local_counts": self._local_counts(reg, VALIDATION_LOCAL_JCD),
                    "crawl_detail_pages": verified,
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                    "crawl_jcd": str(only_jcd).zfill(2) if only_jcd else None,
                    "last_verified_run": f"{row['date']} 場{row['jcd']} {row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "failed_days": failed_days,
                    "failed_races": failed_races,
                })

            # Persist progress only after all candidates for this date have been handled.
            # On restart the collector resumes from the following (older) date.
            next_day = scan_day - timedelta(days=1)
            persist_next_day(next_day, failed_date=ymd if day_error else None, error=day_error)
            scan_day = next_day

        return {
            "counts": counts_fn(), "done": done_fn(counts_fn()), "checked_days": checked_days,
            "verified": verified, "candidate_total": candidate_total, "saved": saved,
            "skipped": skipped, "failed_days": failed_days, "failed_races": failed_races,
            "last_nonfatal_error": last_nonfatal_error, "lastdiag": lastdiag,
        }

    def _run(self, today):
        migration_now = self._reset_validation_racer(today)
        self._ensure_validation_target(today)
        started = time.monotonic()
        self.status = {
            **self.db.get_course_history_target_status(today, VALIDATION_REG),
            "phase": "峰竜太（4320）全国確認→児島だけ当地履歴を取得開始",
            "validation_mode": "峰竜太（4320）全国＋児島16・選手一致候補→公式結果照合方式",
            "current_racer": VALIDATION_NAME,
            "current_registration_no": VALIDATION_REG,
            "clean_reset_applied": False,
            "local_phase_migration_applied": bool(migration_now),
            "crawl_stage": "全国の完成を確認 → 当地は児島16だけ候補抽出 → BOAT RACE公式結果で実進入確認",
            "note": "v17.208。当地点検は児島(jcd=16)だけ。他場は当地候補として解析・保存しない。日単位カーソル保存・1日/1R失敗継続に対応。全国v17.204の保存済みデータは保持。",
        }

        reg = VALIDATION_REG
        jcd = VALIDATION_LOCAL_JCD
        name = VALIDATION_NAME
        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
            "Accept-Language": "ja,en-US;q=0.8,en;q=0.6",
        })

        # Phase 1: nationwide should already be complete from v17.204. If not, finish it first.
        nm = self._national_counts(reg)
        national_result = None
        if not self._national_done(nm):
            national_result = self._collect_scope(
                session, reg, started, only_jcd=None,
                floor_date=datetime(2026, 1, 1, tzinfo=JST).date(),
            )
            nm = self._national_counts(reg)

        # Phase 2: ONLY Kojima. Existing Kojima rows saved during national scan count immediately.
        lm = self._local_counts(reg, jcd)
        local_result = None
        if not self._local_done(lm):
            local_result = self._collect_scope(
                session, reg, started, only_jcd=jcd,
                floor_date=datetime(2023, 1, 1, tzinfo=JST).date(),
            )
            lm = self._local_counts(reg, jcd)

        # Reaching 2023 with fewer than 10 is normal completion by specification.
        if self._national_done(nm) and (self._local_done(lm) or local_result is not None):
            self.db.complete_course_history_targets([(reg, jcd)])

        lr = local_result or {"checked_days": 0, "candidate_total": 0, "verified": 0, "saved": 0, "skipped": 0, "failed_days": 0, "failed_races": 0, "last_nonfatal_error": None, "lastdiag": {}}
        if self._local_done(lm):
            phase = f"{name} 全国＋児島1〜6C 履歴確認完了"
            fetch_state = "complete"
        else:
            phase = f"{name} 児島を2023年まで確認完了（10走未満のコースはその件数で正常完了）"
            fetch_state = "complete to 2023 floor"

        self.status = {
            **self.db.get_course_history_target_status(today, VALIDATION_REG),
            "phase": phase,
            "validation_mode": "峰竜太（4320）全国＋児島16・選手一致候補→公式結果照合方式",
            "current_racer": name,
            "current_registration_no": reg,
            "last_fetch_state": fetch_state,
            "last_parsed_rows": lr["saved"],
            "last_matched_rows": lr["verified"],
            "crawl_list_pages": lr["checked_days"],
            "crawl_detail_pages": lr["verified"],
            "crawl_elapsed_seconds": int(time.monotonic() - started),
            "crawl_stage": f"児島16だけ確認 {lr['checked_days']}日 → 候補 {lr['candidate_total']}走 → 公式結果 {lr['verified']}走 → 新規保存 {lr['saved']}走 / 除外 {lr['skipped']}走 / 日失敗 {lr['failed_days']} / R失敗 {lr['failed_races']}",
            "national_counts": nm,
            "local_counts": lm,
            "checked_days": lr["checked_days"],
            "crawl_jcd": jcd,
            "failed_days": lr["failed_days"],
            "failed_races": lr["failed_races"],
            "last_nonfatal_error": lr["last_nonfatal_error"],
            "direct_source": (lr.get("lastdiag") or {}).get("url"),
            "note": "v17.208。当地点検は児島(jcd=16)だけ。全国と同じ公式実進入判定を使い、各1〜6Cは直近10走まで。日単位カーソル保存・1日/1R失敗継続。不足時のみ2023年まで遡り、そこで足りなくても正常完了。",
        }

