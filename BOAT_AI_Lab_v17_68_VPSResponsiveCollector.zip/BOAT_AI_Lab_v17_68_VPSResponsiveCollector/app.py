from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from boat_source import BoatRaceSource
from collector import BackgroundCollector
from venue_knowledge import VenueKnowledgeCollector

app = FastAPI(title="BOAT AI Lab Backend", version="1.0.67")

class PredictionPayload(BaseModel):
    confidence: float | None = None
    judgement: str | None = None
    scenario: str | None = None
    main_picks: list = []
    value_picks: list = []
    leaks: list = []
    source_snapshot: dict = {}
    ai_comment: str | None = None

class CommentItem(BaseModel):
    lane: int
    comment: str
    source: str | None = None

class CommentsPayload(BaseModel):
    comments: list[CommentItem]

source = BoatRaceSource()
collector = BackgroundCollector(source)
knowledge_collector = VenueKnowledgeCollector(source.db)

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def index():
    return FileResponse(
        "static/index.html",
        headers={"Cache-Control":"no-store, no-cache, must-revalidate, max-age=0"}
    )

@app.on_event("startup")
async def start_background_collector():
    collector.start()
    knowledge_collector.start()

@app.get("/api/background/status")
def background_status():
    return collector.status

@app.get("/api/venues")
def venues():
    return {"venues": source.venues}

@app.get("/api/day/{yyyymmdd}")
def day(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_fast(yyyymmdd)

@app.get("/api/day-status/{yyyymmdd}")
def day_status(yyyymmdd: str):
    validate_date(yyyymmdd)
    cached = source.cache.get(f"day_v16_{yyyymmdd}", 3600)
    return {
        "official_cached": bool(cached),
        "last_day_scan": collector.status.get("last_day_scan"),
        "collector_message": collector.status.get("last_message"),
    }

@app.get("/api/schedule/{yyyymmdd}/{jcd}")
def race_schedule(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return {
        "date": yyyymmdd,
        "jcd": jcd.zfill(2),
        "races": source.db.get_race_schedule(yyyymmdd, jcd.zfill(2)),
    }

@app.get("/api/race/{yyyymmdd}/{jcd}/{rno}")
def race(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_race(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/before/{yyyymmdd}/{jcd}/{rno}")
def before(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_before_info(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/odds3t/{yyyymmdd}/{jcd}/{rno}")
def odds3t(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_odds3t(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/bundle/{yyyymmdd}/{jcd}/{rno}")
def bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/ui/{yyyymmdd}/{jcd}/{rno}")
def ui_bundle(yyyymmdd: str, jcd: str, rno: int):
    """
    フロント表示用。bundle をそのまま返す薄いエンドポイント。
    将来ここでAI予想・コメント等を統合する。
    """
    validate(yyyymmdd, rno)
    return source.get_bundle(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/cached/{yyyymmdd}/{jcd}/{rno}")
def cached_bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_cached_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/cached-day/{yyyymmdd}")
def cached_day_racelists(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_racelists(yyyymmdd)

@app.get("/api/results/{yyyymmdd}/{jcd}")
def results(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return source.get_results(yyyymmdd,jcd.zfill(2))

@app.get("/api/history/{jcd}")
def history(jcd: str, limit: int = 100):
    return {"rows": source.db.result_history(jcd.zfill(2), min(max(limit,1),1000))}



@app.get("/api/ai-preview/{yyyymmdd}/{jcd}/{rno}")
def ai_preview(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=False, preview=True,
    )

@app.post("/api/ai-generate/{yyyymmdd}/{jcd}/{rno}")
def ai_generate(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=True, preview=False,
    )


@app.post("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def save_prediction(yyyymmdd: str, jcd: str, rno: int, payload: PredictionPayload):
    validate(yyyymmdd,rno)
    return source.save_prediction(yyyymmdd,jcd.zfill(2),rno,payload.model_dump())

@app.get("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def get_prediction(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_prediction(yyyymmdd,jcd.zfill(2),rno)

@app.post("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def save_comments(yyyymmdd: str, jcd: str, rno: int, payload: CommentsPayload):
    validate(yyyymmdd,rno)
    return source.save_comments(
        yyyymmdd,jcd.zfill(2),rno,
        [x.model_dump() for x in payload.comments]
    )

@app.get("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def get_comments(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return {"comments": source.get_comments(yyyymmdd,jcd.zfill(2),rno)}

@app.get("/api/compare/{yyyymmdd}/{jcd}/{rno}")
def compare_prediction_result(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.compare(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/prediction-summary")
def prediction_summary(date: str | None = None):
    return source.prediction_summary(date)


@app.get("/api/diagnostic/ohmura")
def diagnostic_ohmura():
    return {
        "errors": collector.status.get("ohmura_errors", []),
        "current_state": collector.status.get("current_state"),
        "current_kind": collector.status.get("current_kind"),
        "current_venue": collector.status.get("current_venue"),
        "current_rno": collector.status.get("current_rno"),
    }


@app.get("/api/revision/{yyyymmdd}/{jcd}/{rno}")
def race_revision(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_race_revision(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/venue-knowledge/status")
def venue_knowledge_status():
    return {
        **knowledge_collector.status,
        "db_summary": source.db.venue_knowledge_summary(),
        "venues": source.db.venue_knowledge_monitor(),
    }

@app.get("/api/venue-profile/{jcd}")
def venue_profile(jcd: str):
    return source.get_current_venue_profile(str(jcd).zfill(2))


@app.get("/api/venue-knowledge/{jcd}")
def venue_knowledge(jcd: str, limit: int = 500):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "sources": source.db.get_venue_knowledge(code, limit),
    }

@app.get("/api/venue-knowledge-text/{jcd}")
def venue_knowledge_text(jcd: str, limit: int = 300):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "documents": source.db.get_venue_knowledge_text(code, limit),
    }


@app.get("/api/health")
def health():
    return {"ok": True, "version": "1.0.67", "background": collector.status["running"]}

def validate_date(yyyymmdd: str):
    if len(yyyymmdd) != 8 or not yyyymmdd.isdigit():
        raise HTTPException(400,"日付はYYYYMMDD形式")

def validate(yyyymmdd: str, rno: int):
    validate_date(yyyymmdd)
    if not 1 <= rno <= 12:
        raise HTTPException(400,"rnoは1〜12")


@app.get("/api/ai-results/{yyyymmdd}")
def ai_results(yyyymmdd: str):
    validate_date(yyyymmdd)
    from review_results import build_review
    return build_review(source.db, yyyymmdd, source.venues)

@app.get("/api/ai-statistics/{yyyymmdd}")
def ai_statistics(yyyymmdd: str):
    validate_date(yyyymmdd)
    from review_statistics import build_statistics
    return build_statistics(source.db, yyyymmdd, source.venues)

@app.get("/api/result-detail/{yyyymmdd}/{jcd}/{rno}")
def result_detail(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_saved_result_detail(yyyymmdd, jcd.zfill(2), rno)

@app.get("/api/completion/{yyyymmdd}")
def completion(yyyymmdd: str):
    validate_date(yyyymmdd)
    return {"date": yyyymmdd, "completed": [list(x) for x in sorted(source.db.get_confirmed_result_races(yyyymmdd))]}

@app.get("/api/local-frame-history/{yyyymmdd}/{jcd}/{rno}")
def local_frame_history(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_local_frame_history(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/official-coverage")
def official_coverage():
    return {"venues": knowledge_collector.coverage, "status": knowledge_collector.status}

@app.post("/api/official-rescan")
def official_rescan():
    return knowledge_collector.request_rescan()
