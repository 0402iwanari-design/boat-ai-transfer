from __future__ import annotations

import re
from bs4 import BeautifulSoup

def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()

PREFECTURES = [
    "北海道","青森","岩手","宮城","秋田","山形","福島","茨城","栃木","群馬",
    "埼玉","千葉","東京","神奈川","新潟","富山","石川","福井","山梨","長野",
    "岐阜","静岡","愛知","三重","滋賀","京都","大阪","兵庫","奈良","和歌山",
    "鳥取","島根","岡山","広島","山口","徳島","香川","愛媛","高知","福岡",
    "佐賀","長崎","熊本","大分","宮崎","鹿児島","沖縄"
]

def strip_prefecture_from_name(name: str | None, origin: str | None = None):
    if not name:
        return name
    n = re.sub(r"\s+", "", name)

    candidates = []
    if origin:
        o = origin.replace("都","").replace("府","").replace("県","")
        candidates.append(o)
    candidates.extend(PREFECTURES)

    for p in sorted(set(candidates), key=len, reverse=True):
        if p and n.endswith(p) and len(n) > len(p) + 1:
            n = n[:-len(p)]
            break
    return n

def num(text, default=None):
    if text is None:
        return default
    m = re.search(r"-?\d+(?:\.\d+)?", str(text).replace(",", ""))
    if not m:
        return default
    v = float(m.group())
    return int(v) if v.is_integer() else v


def parse_meeting_day(html: str, yyyymmdd: str):
    """
    Parse the current meeting day from BOAT RACE official racelist navigation.

    v17.42 bug:
      The regex used r"\\s*" inside a raw string, so it searched for the
      literal characters "\\s" instead of whitespace. That made meeting-day
      detection fail even when the official page showed the day.

    v17.43:
      - normalize full-width digits
      - accept spaces / weekday text between date and day label
      - inspect individual nav/link/option text as a second path
      - use the chronological position of the official date navigation only
        as a last fallback for 初日/最終日
    """
    if not html or len(yyyymmdd) != 8 or not yyyymmdd.isdigit():
        return None

    soup = BeautifulSoup(html, "html.parser")
    trans = str.maketrans("０１２３４５６７８９", "0123456789")

    month = int(yyyymmdd[4:6])
    day = int(yyyymmdd[6:8])

    def normalize(s):
        s = (s or "").translate(trans)
        s = s.replace("　", " ")
        return re.sub(r"\s+", " ", s).strip()

    def day_from_label(label, fallback_index=None):
        lab = normalize(label)
        if lab == "初日":
            return {
                "number": 1,
                "label": "1日目",
                "official_label": label,
            }
        if lab == "最終日":
            if fallback_index is None:
                return None
            return {
                "number": int(fallback_index),
                "label": f"最終日（{int(fallback_index)}日目）",
                "official_label": label,
            }
        m = re.search(r"([1-9]\d*)\s*日目", lab)
        if m:
            n = int(m.group(1))
            return {
                "number": n,
                "label": f"{n}日目",
                "official_label": label,
            }
        return None

    # Path 1: normalized whole-page text.
    # Accept e.g.
    #   9月15日 3日目
    #   9月15日（火）3日目
    #   9月15日 火 ３日目
    text = normalize(soup.get_text(" "))
    date_label_re = re.compile(
        r"(?<!\d)(\d{1,2})\s*月\s*(\d{1,2})\s*日"
        r"[^0-9月日]{0,24}?"
        r"(初日|[1-9]\d*\s*日目|最終日)"
    )

    rows = []
    seen = set()
    for m in date_label_re.finditer(text):
        mm = int(m.group(1))
        dd = int(m.group(2))
        lab = m.group(3).replace(" ", "")
        key = (mm, dd, lab)
        if key not in seen:
            seen.add(key)
            rows.append(key)

    for idx, (mm, dd, lab) in enumerate(rows, start=1):
        if mm == month and dd == day:
            result = day_from_label(lab, idx)
            if result:
                return result

    # Path 2: official nav items can split date and day label across nested tags.
    selectors = [
        "a", "li", "option", "button",
        ".is-date", ".is-current", ".is-active",
    ]
    nodes = []
    node_seen = set()
    for sel in selectors:
        for node in soup.select(sel):
            ident = id(node)
            if ident in node_seen:
                continue
            node_seen.add(ident)
            nodes.append(node)

    target_date_re = re.compile(
        rf"(?<!\d){month}\s*月\s*0?{day}\s*日"
    )
    generic_label_re = re.compile(r"(初日|[1-9]\d*\s*日目|最終日)")

    for node in nodes:
        t = normalize(node.get_text(" "))
        if not target_date_re.search(t):
            continue

        lm = generic_label_re.search(t)
        if lm:
            result = day_from_label(lm.group(1).replace(" ", ""))
            if result:
                return result

        # Sometimes the label is a sibling of the date span.
        parent = node.parent
        if parent is not None:
            pt = normalize(parent.get_text(" "))
            lm = generic_label_re.search(pt)
            if lm:
                result = day_from_label(lm.group(1).replace(" ", ""))
                if result:
                    return result

    # Path 3: collect visible official date-navigation items and infer final-day
    # ordinal from their sequence. This is used only when the page explicitly
    # ties our target date to "最終日".
    nav_rows = []
    for node in nodes:
        t = normalize(node.get_text(" "))
        dm = re.search(
            r"(?<!\d)(\d{1,2})\s*月\s*(\d{1,2})\s*日",
            t
        )
        lm = generic_label_re.search(t)
        if dm and lm:
            row = (
                int(dm.group(1)), int(dm.group(2)),
                lm.group(1).replace(" ", "")
            )
            if row not in nav_rows:
                nav_rows.append(row)

    for idx, (mm, dd, lab) in enumerate(nav_rows, start=1):
        if mm == month and dd == day:
            result = day_from_label(lab, idx)
            if result:
                return result

    return None


def parse_race_index(html: str):
    """
    BOAT RACE公式の実HTML構造に合わせた締切予定時刻パーサー。

    診断で確認した構造:
      <tr> ... 1R ... 2R ... 12R ... </tr>
      <tr>
        <td ...><span>締切予定時刻</span></td>
        <td ...>10:47</td>
        <td ...>11:16</td>
        ...
        <td ...>16:30</td>
      </tr>

    まず「締切予定時刻」を含む同一<tr>から時刻だけを読む。
    12件揃わなければページ全体の同ラベル直後をフォールバック。
    """
    soup = BeautifulSoup(html, "html.parser")

    # Exact structure first.
    label_node = soup.find(string=re.compile(r"締切予定時刻"))
    if label_node:
        tr = label_node.find_parent("tr")
        if tr:
            cells = tr.find_all(["th", "td"])
            times = []
            for cell in cells:
                txt = clean(cell.get_text(" "))
                m = re.fullmatch(r"(\d{1,2}:\d{2})", txt)
                if m:
                    times.append(m.group(1))

            if len(times) >= 12:
                return [
                    {"rno": i, "deadline": t}
                    for i, t in enumerate(times[:12], start=1)
                ]

            # Some cells may contain nested labels/text.
            row_text = clean(tr.get_text(" "))
            times = re.findall(r"(?<!\d)(\d{1,2}:\d{2})(?!\d)", row_text)
            if len(times) >= 12:
                return [
                    {"rno": i, "deadline": t}
                    for i, t in enumerate(times[:12], start=1)
                ]

    # Fallback: page text, only after "締切予定時刻".
    text = clean(soup.get_text(" "))
    pos = text.find("締切予定時刻")
    if pos >= 0:
        window = text[pos:pos + 700]
        times = re.findall(r"(?<!\d)(\d{1,2}:\d{2})(?!\d)", window)
        if len(times) >= 12:
            return [
                {"rno": i, "deadline": t}
                for i, t in enumerate(times[:12], start=1)
            ]

    return []


GRADE_TEXT_NORMALIZE = str.maketrans({
    "Ｓ": "S", "Ｇ": "G", "Ｐ": "P",
    "１": "1", "２": "2", "３": "3",
    # BOAT RACE公式では GⅠ / GⅡ / GⅢ のローマ数字表記も使われる。
    "Ⅰ": "1", "Ⅱ": "2", "Ⅲ": "3",
    "ⅰ": "1", "ⅱ": "2", "ⅲ": "3",
})


def _normalize_grade_text(value: str) -> str:
    return str(value or "").upper().translate(GRADE_TEXT_NORMALIZE)


def _grade_from_title_text(value: str) -> str | None:
    """Recognise official Japanese/roman grade spellings in a meeting title."""
    text = _normalize_grade_text(value)
    compact = re.sub(r"\s+", "", text)
    # 若松ヤングダービー等の「プレミアムGI」「PGI」はPG1。
    if re.search(r"プレミアムG(?:I|1)", compact) or re.search(r"(?<![A-Z0-9])PG(?:I|1)(?![A-Z0-9])", text):
        return "PG1"
    if re.search(r"(?<![A-Z0-9])SG(?![A-Z0-9])", text):
        return "SG"
    # Official titles also use GI/GII/GIII as well as G1/G2/G3.
    for pattern, grade in (
        (r"(?<![A-Z0-9])G(?:III|3)(?![A-Z0-9])", "G3"),
        (r"(?<![A-Z0-9])G(?:II|2)(?![A-Z0-9])", "G2"),
        (r"(?<![A-Z0-9])G(?:I|1)(?![A-Z0-9])", "G1"),
    ):
        if re.search(pattern, text):
            return grade
    return None


def _race_page_meta(soup: BeautifulSoup):
    event_title = None
    event_grade = None
    heading = soup.select_one(".heading2_title")
    grade_map = {
        "issg": "SG", "sg": "SG",
        "ispg1": "PG1", "pg1": "PG1",
        "isg1": "G1", "isgrade1": "G1", "gradeg1": "G1", "eventg1": "G1", "g1": "G1",
        "isg2": "G2", "isgrade2": "G2", "gradeg2": "G2", "eventg2": "G2", "g2": "G2",
        "isg3": "G3", "isgrade3": "G3", "gradeg3": "G3", "eventg3": "G3", "g3": "G3",
        "isippan": "一般戦", "ippan": "一般戦",
    }
    if heading:
        title_node = heading.select_one(".heading2_titleName")
        event_title = clean(title_node.get_text(" ")) if title_node else None
        # Official pages use slightly different class spellings by grade/page.
        # Normalize only the title area's own class names, never racer/profile text.
        classes = {
            re.sub(r"[^a-z0-9]", "", str(value).lower())
            for node in [heading, *heading.find_all(True)]
            for value in (node.get("class") or [])
        }
        event_grade = next((label for key, label in grade_map.items() if key in classes), None)
        if not event_grade:
            event_grade = _grade_from_title_text(clean(heading.get_text(" ")))
        if not event_grade and event_title:
            event_grade = _grade_from_title_text(event_title)

    # Depending on the official page/layout, the meeting name can be present
    # only in the document title or another title-labelled element.  Keep the
    # lookup limited to title-like areas so global SG/G1/G2/G3 navigation links
    # cannot leak into another venue.
    title_candidates = []
    if soup.title:
        title_candidates.append(clean(soup.title.get_text(" ")))
    for node in soup.select(
        ".heading2_titleName, .heading2_title, "
        "[class*='eventTitle'], [class*='event-title'], "
        "[class*='raceTitle'], [class*='race-title'], "
        "[id*='eventTitle'], [id*='raceTitle']"
    ):
        value = clean(node.get_text(" "))
        if value and value not in title_candidates:
            title_candidates.append(value)
    if not event_grade or event_grade == "一般戦":
        for value in title_candidates:
            found = _grade_from_title_text(value)
            if found:
                event_grade = found
                if not event_title:
                    event_title = value
                break

    # Grade icons can sit beside the title.  Search only the title's local
    # container, never the full document: global navigation also contains
    # SG/G1/G2/G3 links and could assign another meeting's grade by mistake.
    if not event_grade:
        regions = []
        if heading:
            regions.append(heading)
            if heading.parent:
                regions.append(heading.parent)
        for region in regions:
            nodes = [region, *region.find_all(True)]
            for node in nodes:
                values = list(node.get("class") or [])
                for attr in ("id", "alt", "title", "src", "data-grade", "data-race-grade"):
                    if node.get(attr):
                        values.append(str(node.get(attr)))
                normalized = {
                    re.sub(r"[^a-z0-9]", "", _normalize_grade_text(value).lower())
                    for value in values
                }
                found = next((label for key, label in grade_map.items() if key in normalized), None)
                if not found:
                    explicit = " ".join(_normalize_grade_text(value).lower() for value in values)
                    marker = re.search(r"(?:grade|icon|race)[_\-/]?(sg|pg1|g[123])(?:[^a-z0-9]|$)", explicit)
                    if marker:
                        found = marker.group(1).upper()
                if found:
                    event_grade = found
                    break
            if event_grade:
                break

    # An open official racelist with a real meeting title and no graded icon is
    # an ordinary meeting.  This makes 一般戦 explicit instead of leaving it blank.
    if not event_grade and event_title:
        event_grade = "一般戦"
    race_name = None
    detail = soup.select_one(".title16_titleDetail__add2020")
    if detail:
        value = clean(detail.get_text(" "))
        value = re.sub(r"\s*1800m.*$", "", value, flags=re.I).strip()
        race_name = value or None
    return {
        "event_grade": event_grade,
        "event_title": event_title,
        "race_name": race_name,
    }

def parse_venue_meta(html: str):
    """Event grade/title available on the same racelist HTML as meeting day."""
    return _race_page_meta(BeautifulSoup(html, "html.parser"))


def parse_day_venue_event_meta(html: str) -> dict:
    """Read graded meetings from the official all-venues daily index.

    Some racelist pages label their heading with the race name only (予選等),
    so the meeting grade is not present there.  The official daily index keeps
    the meeting title/grade beside a link containing that venue's jcd.  Return
    only explicit graded meetings; ordinary meetings continue to use the
    racelist fallback.
    """
    soup = BeautifulSoup(html, "html.parser")
    result = {}
    for code_number in range(1, 25):
        code = f"{code_number:02d}"
        anchors = [
            a for a in soup.find_all("a", href=True)
            if re.search(rf"(?:[?&]|&amp;)jcd=0?{code_number}(?:&|$)", str(a.get("href") or ""))
        ]
        best = None
        for anchor in anchors:
            node = anchor
            for depth in range(7):
                if node is None or getattr(node, "name", None) in {"body", "html"}:
                    break
                nodes = [node, *node.find_all(True)]
                values = [clean(node.get_text(" "))]
                for child in nodes:
                    values.extend(str(child.get(k) or "") for k in (
                        "class", "id", "alt", "title", "src", "data-grade", "data-race-grade"
                    ))
                evidence = " ".join(values)
                grade = _grade_from_title_text(evidence)
                if not grade:
                    normalized = _normalize_grade_text(evidence)
                    marker = re.search(
                        r"(?:GRADE|ICON|RACE|LABEL)[_\-/ ]*(PG1|SG|G[123])(?:[^A-Z0-9]|$)",
                        normalized,
                    )
                    grade = marker.group(1) if marker else None
                if grade:
                    text = clean(node.get_text(" "))
                    candidate = {
                        "event_grade": grade,
                        "event_title": text[:500] or None,
                        "source": "official-day-index",
                        "depth": depth,
                    }
                    # Prefer the smallest local card around this venue link.
                    if best is None or len(text) < len(best.get("event_title") or "" ):
                        best = candidate
                    break
                node = node.parent
        if best:
            best.pop("depth", None)
            result[code] = best
    return result

def grade_markup_diagnostic(html: str) -> dict:
    """Small, safe diagnostic of the official title markup when grade is unclear."""
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for node in soup.find_all(["div", "span", "h1", "h2", "img"]):
        classes = " ".join(str(x) for x in (node.get("class") or []))
        ident = str(node.get("id") or "")
        alt = str(node.get("alt") or "")
        text = clean(node.get_text(" "))
        haystack = _normalize_grade_text(" ".join([classes, ident, alt, text]))
        if re.search(r"(?:^|[^A-Z0-9])(SG|PG1|G[123])(?:$|[^A-Z0-9])", haystack):
            rows.append({
                "tag": node.name, "class": classes, "id": ident,
                "alt": alt, "text": text[:300],
                "data": {k: str(v) for k, v in node.attrs.items() if str(k).startswith("data-")},
            })
        if len(rows) >= 40:
            break
    heading = soup.select_one(".heading2_title")
    return {
        "title_area": {
            "class": " ".join(heading.get("class") or []) if heading else "",
            "text": clean(heading.get_text(" "))[:500] if heading else "",
        },
        "grade_like_nodes": rows,
    }


def _flatten_table_rows(soup: BeautifulSoup):
    out = []
    for tr in soup.find_all("tr"):
        cells = [clean(x.get_text(" ")) for x in tr.find_all(["th","td"])]
        if cells:
            out.append(cells)
    return out


def parse_race_deadline(html: str, rno: int | None = None):
    races = parse_race_index(html)
    if not races:
        return None

    if rno is None:
        return races[0].get("deadline")

    for race in races:
        if int(race.get("rno", 0)) == int(rno):
            return race.get("deadline")

    return None


def parse_deadline_from_saved_text(text: str, rno: int):
    """
    Backfill helper for old racelist snapshots.
    Older snapshots already stored the visible page text in raw_text.
    If that text contains the 12 scheduled times, recover the deadline
    without another network request.
    """
    if not text:
        return None

    clean_text = clean(text)
    pos = clean_text.find("締切予定時刻")
    if pos < 0:
        return None

    window = clean_text[pos:pos + 500]
    times = re.findall(r"(?<!\d)(\d{1,2}:\d{2})(?!\d)", window)
    if len(times) >= 12 and 1 <= int(rno) <= 12:
        return times[int(rno) - 1]

    return None



def _fw_to_ascii(value: str) -> str:
    return (value or "").translate(str.maketrans(
        "０１２３４５６７８９１２３４５６",
        "0123456789123456"
    ))


def _meeting_finish(value: str):
    s = clean(_fw_to_ascii(value))
    m = re.search(r"(?<!\d)([1-6]|F|L|転|落|沈|妨|失|欠|不|エ)(?:着)?(?!\d)", s)
    return m.group(1) if m else None


def _meeting_rno(value: str):
    s = clean(_fw_to_ascii(value))
    m = re.search(r"(?<!\d)(1[0-2]|[1-9])\s*R(?!\d)", s, re.I)
    if m:
        return int(m.group(1))
    # Official top row can contain just the race number in the current-series
    # block. Accept it only in the dedicated meeting-result parser.
    if re.fullmatch(r"(1[0-2]|[1-9])", s):
        return int(s)
    return None


def _meeting_course(value: str):
    s = clean(_fw_to_ascii(value))
    if re.fullmatch(r"[1-6]", s):
        return int(s)
    return None


def _meeting_st(value: str):
    s = clean(_fw_to_ascii(value)).upper().replace(" ", "")
    if re.fullmatch(r"\.\d{2}", s):
        return "0" + s
    if re.fullmatch(r"0\.\d{2}", s):
        return s
    if re.fullmatch(r"F\.?\d{2}", s):
        return s
    if re.fullmatch(r"L\.?\d{2}", s):
        return s
    return None


def _meeting_result_summary(entries, source):
    dedup = []
    seen = set()
    for x in entries:
        key = (
            x.get("rno"), x.get("course"),
            x.get("st"), x.get("finish")
        )
        if key in seen:
            continue
        seen.add(key)
        dedup.append(x)

    # Keep the official left-to-right chronological display order.
    # Sorting by race number destroys day grouping (e.g. 4R, 8R / 3R, 7R).
    numeric = [
        int(x["finish"]) for x in dedup
        if str(x.get("finish") or "").isdigit()
    ]
    st_values = []
    flying_starts = 0
    for x in dedup:
        raw = str(x.get("st") or "").strip().upper()
        if raw.startswith("F"):
            flying_starts += 1
            continue
        if re.fullmatch(r"0?\.\d{2}", raw):
            try:
                st_values.append(float(raw if raw.startswith("0") else "0" + raw))
            except ValueError:
                pass
    return {
        "entries": dedup,
        "race_count": len(dedup),
        "avg_rank": (
            round(sum(numeric)/len(numeric), 3)
            if numeric else None
        ),
        "top2_rate": (
            round(
                sum(1 for x in numeric if x <= 2)
                / len(numeric) * 100, 2
            ) if numeric else None
        ),
        "avg_st": round(sum(st_values) / len(st_values), 3) if st_values else None,
        "st_count": len(st_values),
        "flying_starts": flying_starts,
        "source": source,
    }


def _parse_result_layers(layer_rows):
    """
    Official racelist renders current-meeting records as four aligned rows:
      race no / course / ST / finish.
    Preserve empty cells because column position is the relationship.
    """
    if len(layer_rows) < 4:
        return []

    layers = []
    for tr in layer_rows[:4]:
        cells = tr.find_all(["td", "th"], recursive=False)
        layers.append([
            clean(_fw_to_ascii(c.get_text(" ")))
            for c in cells
        ])

    if len(layers) < 4:
        return []

    max_len = max(len(x) for x in layers)
    for x in layers:
        x.extend([""] * (max_len-len(x)))

    entries = []
    for idx in range(max_len):
        top, course_s, st_s, finish_s = (
            layers[0][idx], layers[1][idx],
            layers[2][idx], layers[3][idx]
        )
        rno = _meeting_rno(top)
        course = _meeting_course(course_s)
        st = _meeting_st(st_s)
        finish = _meeting_finish(finish_s)

        # Race-number row can contain bare 1..12 on the official page.
        # Require ST or finish as confirmation to avoid unrelated numbers.
        if rno is None:
            continue
        if st is None and finish is None:
            continue

        entries.append({
            "rno": int(rno),
            "course": course,
            "st": st,
            "finish": finish,
        })
    return entries



def _expanded_direct_cells(tr):
    """
    Return direct TD/TH text while expanding colspan.

    BOAT RACE's current-series block uses blank colspan cells. Keeping the
    visual column count is essential because race no / course / ST / finish
    are related by column position.
    """
    out = []
    for cell in tr.find_all(["td", "th"], recursive=False):
        text = clean(_fw_to_ascii(cell.get_text(" ")))
        try:
            colspan = max(1, int(cell.get("colspan", 1)))
        except Exception:
            colspan = 1
        out.extend([text] * colspan)
    return out


def _meeting_boat_lane_from_cell(cell):
    """
    Extract only *boat/frame specific* color information from the official
    race-number cell.

    v17.57 intentionally stopped accepting generic tokens such as "color-3"
    or "bg-4".  Those classes can belong to unrelated styling and were able
    to paint a past race with the wrong boat color.

    If the official cell does not expose a boat-specific token, return None
    rather than inventing a color.
    """
    if cell is None:
        return None

    nodes = [cell] + list(cell.find_all(True))

    for node in nodes:
        classes = " ".join(str(x) for x in (node.get("class") or []))
        ident = str(node.get("id") or "")
        attrs = f"{classes} {ident}"

        # Known/likely BOAT RACE-specific variants.
        for pat in (
            r"(?:^|[\s_-])is[-_]?boat[-_]?color[-_]?([1-6])(?:$|[\s_-])",
            r"(?:^|[\s_-])boat[-_]?color[-_]?([1-6])(?:$|[\s_-])",
            r"(?:^|[\s_-])boat[-_]?lane[-_]?([1-6])(?:$|[\s_-])",
            r"(?:^|[\s_-])boat[-_]?([1-6])(?:$|[\s_-])",
            r"(?:^|[\s_-])waku[-_]?([1-6])(?:$|[\s_-])",
            r"(?:^|[\s_-])frame[-_]?([1-6])(?:$|[\s_-])",
        ):
            m = re.search(pat, attrs, re.I)
            if m:
                return int(m.group(1))

        # Explicit data attributes are safe because they name the boat/frame.
        for key in ("data-boat", "data-waku", "data-frame", "data-lane"):
            val = str(node.get(key) or "").strip()
            if re.fullmatch(r"[1-6]", val):
                return int(val)

    return None


def _expanded_direct_cell_objects(tr):
    out = []
    for cell in tr.find_all(["td", "th"], recursive=False):
        try:
            colspan = max(1, int(cell.get("colspan", 1)))
        except Exception:
            colspan = 1
        for _ in range(colspan):
            out.append(cell)
    return out


def _parse_official_racer_row_block_with_slots(
    racer_row,
    meeting_day_no=None,
):
    """
    Parse the official 4-row current-meeting block while preserving blank
    visual slots.

    v17.57 realignment:
      * choose the race-number segment by "cleanliness", not only hit count
      * profile/stat cells are heavily penalized if they leak into the segment
      * data in a day later than the actual current meeting day is rejected
      * after selection, future-day slots are force-cleared

    The official layout has two visual race slots per day.
    """
    following = []
    node = racer_row.find_next_sibling("tr")
    while node is not None and len(following) < 8:
        text = clean(_fw_to_ascii(node.get_text(" ")))
        if re.search(r"\b\d{4}\s*/\s*[AB][12]\b", text):
            break
        following.append(node)
        node = node.find_next_sibling("tr")

    if len(following) < 3:
        return [], []

    expanded = [_expanded_direct_cells(x) for x in following]

    st_idx = None
    for idx, cells in enumerate(expanded):
        st_hits = sum(1 for x in cells if _meeting_st(x) is not None)
        if st_hits >= 1:
            st_idx = idx
            break

    if st_idx is None or st_idx < 1 or st_idx + 1 >= len(expanded):
        return [], []

    course_cells = expanded[st_idx - 1]
    st_cells = expanded[st_idx]
    finish_cells = expanded[st_idx + 1]
    width = max(len(course_cells), len(st_cells), len(finish_cells))
    if width <= 0:
        return [], []

    def pad_right(values):
        return list(values) + [""] * (width - len(values))

    course_cells = pad_right(course_cells)
    st_cells = pad_right(st_cells)
    finish_cells = pad_right(finish_cells)

    top_cells_obj = _expanded_direct_cell_objects(racer_row)
    top_all = [
        clean(_fw_to_ascii(cell.get_text(" ")))
        for cell in top_cells_obj
    ]
    if not top_all:
        return [], []

    # Remove the far-right "早見" cell before segment selection.
    if len(top_all) > width and re.fullmatch(
        r"(?:1[0-2]|[1-9])R", clean(_fw_to_ascii(top_all[-1])), re.I
    ):
        top_all = top_all[:-1]
        top_cells_obj = top_cells_obj[:-1]

    best_entries = []
    best_slots = []
    best_quality = None

    if len(top_all) >= width:
        starts = range(0, len(top_all) - width + 1)
    else:
        starts = [0]

    max_current_slot = None
    try:
        if meeting_day_no is not None:
            day_no = int(meeting_day_no)
            if day_no >= 1:
                max_current_slot = min(width, day_no * 2)
    except Exception:
        max_current_slot = None

    for start in starts:
        top = top_all[start:start + width]
        top_obj = top_cells_obj[start:start + width]
        if len(top) < width:
            pad = width - len(top)
            top = [""] * pad + top
            top_obj = [None] * pad + top_obj

        entries = []
        slots = []
        invalid_nonempty = 0
        future_hits = 0
        colored_hits = 0

        for idx in range(width):
            raw_top = clean(_fw_to_ascii(top[idx]))
            rno = _meeting_rno(raw_top)

            # A correct meeting-result segment consists only of blank cells or
            # valid race numbers. Profile/stat values must never be considered
            # part of this segment.
            if raw_top and rno is None:
                invalid_nonempty += 1

            course = _meeting_course(course_cells[idx])
            st = _meeting_st(st_cells[idx])
            finish = _meeting_finish(finish_cells[idx])
            boat_lane = (
                _meeting_boat_lane_from_cell(top_obj[idx])
                if top_obj[idx] is not None else None
            )
            if boat_lane is not None:
                colored_hits += 1

            slot = {
                "rno": int(rno) if rno is not None else None,
                "course": course,
                "st": st,
                "finish": finish,
                "boat_lane": boat_lane,
            }
            slots.append(slot)

            if rno is None:
                continue

            if max_current_slot is not None and idx >= max_current_slot:
                future_hits += 1

            if st is None and finish is None:
                continue
            entries.append(dict(slot))

        complete = sum(
            1 for x in entries
            if x.get("course") is not None
            and x.get("st") is not None
            and x.get("finish") is not None
        )

        # Priority:
        #  1. absolutely no data in a future meeting day
        #  2. absolutely no profile/stat leakage into result slots
        #  3. more complete official result records
        #  4. more records, then more verified boat-color tokens
        quality = (
            -future_hits,
            -invalid_nonempty,
            complete,
            len(entries),
            colored_hits,
            start,  # in a tie, prefer the later segment (after profile cells)
        )

        if best_quality is None or quality > best_quality:
            best_quality = quality
            best_entries = entries
            best_slots = slots

    # A meeting cannot contain records in a day later than "today's meeting
    # day". Force those slots blank even if malformed HTML/CSS fooled a parser.
    if max_current_slot is not None:
        for idx in range(max_current_slot, len(best_slots)):
            best_slots[idx] = {
                "rno": None,
                "course": None,
                "st": None,
                "finish": None,
                "boat_lane": None,
            }
        best_entries = [
            dict(x) for idx, x in enumerate(best_slots[:max_current_slot])
            if x.get("rno") is not None
            and (x.get("st") is not None or x.get("finish") is not None)
        ]

    # Preserve the official six-day/two-slot geometry when present.
    while (
        len(best_slots) > 12
        and len(best_slots) % 2 == 0
        and all(
            not any(v for k, v in slot.items() if k != "boat_lane")
            for slot in best_slots[-2:]
        )
    ):
        best_slots = best_slots[:-2]

    return best_entries, best_slots


def _parse_official_racer_row_block(racer_row):
    entries, _ = _parse_official_racer_row_block_with_slots(racer_row)
    return entries


def _parse_official_meeting_results(
    soup: BeautifulSoup,
    normalized_racers,
    meeting_day_no=None,
):
    """
    Parse BOAT RACE official current-meeting records.

    v17.47 primary path matches the actual official racelist layout:
      racer/profile + race-number row
      -> course row
      -> ST row
      -> finish row

    Older nested-table logic remains as fallback for alternate layouts.
    """
    racer_by_reg = {
        str(x.get("registration_no")): x
        for x in normalized_racers
        if x.get("registration_no")
    }
    if not racer_by_reg:
        return {}

    out = {}

    candidate_rows = []
    for tr in soup.find_all("tr"):
        txt = clean(_fw_to_ascii(tr.get_text(" ")))
        if re.search(r"\b\d{4}\s*/\s*[AB][12]\b", txt):
            candidate_rows.append(tr)

    used_regs = set()

    # PRIMARY: actual official four-row block where row 1 is also the racer row.
    for racer_row in candidate_rows:
        row_text = clean(_fw_to_ascii(racer_row.get_text(" ")))
        reg_m = re.search(r"\b(\d{4})\s*/\s*([AB][12])\b", row_text)
        if not reg_m:
            continue
        reg = reg_m.group(1)
        if reg not in racer_by_reg or reg in used_regs:
            continue

        entries, slots = _parse_official_racer_row_block_with_slots(
            racer_row,
            meeting_day_no=meeting_day_no,
        )
        if entries:
            lane = int(racer_by_reg[reg]["lane"])
            summary = _meeting_result_summary(
                entries,
                "official-racelist-four-row-block-v17.50"
            )
            summary["slots"] = slots

            # Official far-right "早見" value is on the racer row itself.
            direct_texts = [
                clean(_fw_to_ascii(c.get_text(" ")))
                for c in racer_row.find_all(["td", "th"], recursive=False)
            ]
            hayami = None
            for value in reversed(direct_texts):
                if re.fullmatch(r"(?:1[0-2]|[1-9])R", value, re.I):
                    hayami = value.upper()
                    break
            summary["hayami"] = hayami

            out[lane] = summary
            used_regs.add(reg)

    # FALLBACK 1: nested table versions.
    for racer_row in candidate_rows:
        row_text = clean(_fw_to_ascii(racer_row.get_text(" ")))
        reg_m = re.search(r"\b(\d{4})\s*/\s*([AB][12])\b", row_text)
        if not reg_m:
            continue
        reg = reg_m.group(1)
        if reg not in racer_by_reg or reg in used_regs:
            continue

        entries = []
        for nt in racer_row.find_all("table"):
            rows = nt.find_all("tr", recursive=False)
            if len(rows) < 4:
                tb = nt.find("tbody", recursive=False)
                if tb is not None:
                    rows = tb.find_all("tr", recursive=False)
            if len(rows) < 4:
                continue

            candidate = _parse_result_layers(rows)
            if candidate:
                entries = candidate
                break

        if entries:
            lane = int(racer_by_reg[reg]["lane"])
            out[lane] = _meeting_result_summary(
                entries,
                "official-racelist-nested-fallback"
            )
            used_regs.add(reg)

    # FALLBACK 2: registration node + descendant rows.
    for reg, racer in racer_by_reg.items():
        lane = int(racer["lane"])
        if lane in out:
            continue

        reg_node = soup.find(string=re.compile(rf"\b{re.escape(reg)}\b"))
        if reg_node is None:
            continue
        parent_tr = reg_node.find_parent("tr")
        if parent_tr is None:
            continue

        all_nested_rows = parent_tr.find_all("tr")
        for i in range(max(0, len(all_nested_rows) - 3)):
            candidate = _parse_result_layers(all_nested_rows[i:i + 4])
            if candidate:
                out[lane] = _meeting_result_summary(
                    candidate,
                    "official-racelist-descendant-fallback"
                )
                break

    return out


def parse_race_list(html: str, meeting_day_no=None):
    """
    BOAT RACE出走表を正規化。
    HTMLが多少変わっても raw_cells を保持してデバッグ可能にする。
    """
    soup = BeautifulSoup(html, "html.parser")
    rows = _flatten_table_rows(soup)
    racers = []

    # 公式のメイン出走表は「艇番」「選手セル」「F/L/ST」「全国」「当地」「モーター」「ボート」...
    for cells in rows:
        if not cells:
            continue

        lane = None
        first = cells[0].replace("１","1").replace("２","2").replace("３","3").replace("４","4").replace("５","5").replace("６","6")
        if re.fullmatch(r"[1-6]", first):
            lane = int(first)
        if lane is None or len(cells) < 6:
            continue

        joined = " | ".join(cells)

        # 登録番号 / 級別
        reg = None
        racer_class = None
        m = re.search(r"\b(\d{4})\s*/\s*([AB][12])\b", joined)
        if m:
            reg, racer_class = m.group(1), m.group(2)

        # 氏名候補: 登録番号/級別の直後にある日本語名
        name = None
        if m:
            after = joined[m.end():]
            nm = re.search(r"([一-龥々ぁ-んァ-ヶー　 ]{2,20})", after)
            if nm:
                name = clean(nm.group(1)).replace(" ", "")

        # 支部/出身、年齢/体重
        branch = origin = None
        age = weight = None
        bo = re.search(r"([一-龥]{2,4})/([一-龥]{2,4})", joined)
        if bo:
            branch, origin = bo.group(1), bo.group(2)

        # 公式セル内で氏名と都道府県名が連結して取れる場合があるので分離
        name = strip_prefecture_from_name(name, origin)

        aw = re.search(r"(\d{2})歳/(\d+(?:\.\d+)?)kg", joined)
        if aw:
            age, weight = int(aw.group(1)), float(aw.group(2))

        f = l = avg_st = None
        fm = re.search(r"\bF(\d+)\b", joined)
        lm = re.search(r"\bL(\d+)\b", joined)
        if fm: f = int(fm.group(1))
        if lm: l = int(lm.group(1))

        # F/L直後付近の0.xxを平均STとして採用
        stm = re.search(r"F\d+\s*\|?\s*L\d+\s*\|?\s*(0\.\d{2})", joined)
        if stm:
            avg_st = float(stm.group(1))

        # テーブルセル単位の数値を抽出。
        # cell 2以降に統計ブロックが並ぶ公式レイアウトを利用
        stats = []
        for c in cells[2:]:
            vals = re.findall(r"(?<!\d)(\d+(?:\.\d+)?)(?!\d)", c.replace(",", ""))
            stats.extend(float(v) for v in vals)

        # joinedからST以降の標準列順を直接取るフォールバック
        # avgST, 全国 勝率/2連/3連, 当地, motor No/2連/3連, boat...
        seq = []
        if stm:
            tail = joined[stm.end():]
            seq = [float(x) for x in re.findall(r"(?<!\d)(\d+(?:\.\d+)?)(?!\d)", tail)]

        def triplet(start):
            return {
                "win_rate": seq[start] if len(seq) > start else None,
                "quinella_rate": seq[start+1] if len(seq) > start+1 else None,
                "trio_rate": seq[start+2] if len(seq) > start+2 else None,
            }

        national = triplet(0)
        local = triplet(3)

        motor = {
            "no": int(seq[6]) if len(seq) > 6 else None,
            "quinella_rate": seq[7] if len(seq) > 7 else None,
            "trio_rate": seq[8] if len(seq) > 8 else None,
        }
        boat = {
            "no": int(seq[9]) if len(seq) > 9 else None,
            "quinella_rate": seq[10] if len(seq) > 10 else None,
            "trio_rate": seq[11] if len(seq) > 11 else None,
        }

        scratch_markers = [
            "欠場", "出走取消", "取消", "欠 場"
        ]
        scratched = any(
            marker in joined
            for marker in scratch_markers
        ) or any(clean(c) == "欠" for c in cells)

        racers.append({
            "lane": lane,
            "registration_no": reg,
            "class": racer_class,
            "name": name,
            "branch": branch,
            "origin": origin,
            "age": age,
            "weight_kg": weight,
            "f": f,
            "l": l,
            "avg_st": avg_st,
            "national": national,
            "local": local,
            "motor": motor,
            "boat": boat,
            "scratched": scratched,
            "status": "欠場" if scratched else "出走",
            "raw_cells": cells,
        })

    # 同じ艇番の今節成績サブ行を誤認した場合に先頭だけ残す
    unique = {}
    for r in racers:
        if r["registration_no"]:
            unique.setdefault(r["lane"], r)

    normalized_racers = [unique[k] for k in sorted(unique)]

    # 今節/節間成績
    # First use the official rowspan-aware parser. The older text fallback is
    # retained only for unusual layouts.
    meeting_by_lane = _parse_official_meeting_results(
        soup, normalized_racers, meeting_day_no=meeting_day_no
    )

    if not meeting_by_lane:
        for rr in normalized_racers:
            lane = int(rr["lane"])
            cells = rr.get("raw_cells") or []
            joined = " | ".join(str(x) for x in cells)
            entries = []
            for rm in re.finditer(
                r"(?<!\d)(\d{1,2})R\s*(?:着\s*)?"
                r"([1-6]|F|L|転|落|沈|妨|失|欠)(?!\d)",
                _fw_to_ascii(joined),
            ):
                race_no, finish = rm.groups()
                race_no = int(race_no)
                if 1 <= race_no <= 12:
                    entries.append({
                        "rno": race_no,
                        "course": None,
                        "st": None,
                        "finish": finish,
                    })
            if entries:
                numeric = [
                    int(x["finish"]) for x in entries
                    if str(x.get("finish") or "").isdigit()
                ]
                meeting_by_lane[lane] = {
                    "entries": entries,
                    "race_count": len(entries),
                    "avg_rank": (
                        round(sum(numeric)/len(numeric), 3)
                        if numeric else None
                    ),
                    "top2_rate": (
                        round(sum(1 for x in numeric if x <= 2)/len(numeric)*100, 2)
                        if numeric else None
                    ),
                    "source": "official-racelist-text-fallback",
                }

    for rr in normalized_racers:
        lane = int(rr["lane"])
        rr["meeting_results"] = meeting_by_lane.get(lane)

    scratch_lanes = [
        int(r["lane"])
        for r in normalized_racers
        if r.get("scratched")
    ]

    return {
        "racers": normalized_racers,
        "scratch_lanes": scratch_lanes,
        "has_scratch": bool(scratch_lanes),
        "raw_text": clean(soup.get_text(" "))[:30000],
        **_race_page_meta(soup),
    }

def parse_before_info(html: str):
    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" "))

    weather = {}
    patterns = {
        "temperature_c": r"気温\s*([-\d.]+)\s*℃",
        "water_temperature_c": r"水温\s*([-\d.]+)\s*℃",
        "wind_speed_m": r"風速\s*([-\d.]+)\s*m",
        "wave_height_cm": r"波高\s*([-\d.]+)\s*cm",
    }
    for key, pat in patterns.items():
        m = re.search(pat, text)
        weather[key] = float(m.group(1)) if m else None

    # 風向は画像表現の場合があるためテキストで取れた時だけ
    wm = re.search(r"風向\s*([^\s|]{1,8})", text)
    weather["wind_direction"] = wm.group(1) if wm else None

    # 天候（公式ページにテキストがある場合）
    condition = None
    cm = re.search(
        r"(?:天候|天気)\s*(晴れ|晴|くもり|曇り|曇|雨|小雨|大雨|雪|霧)",
        text
    )
    if cm:
        condition = cm.group(1)
    else:
        # アイコンのalt/titleに天候が入るケースにも対応
        for tag in soup.find_all(["img", "span", "div"]):
            blob = " ".join([
                str(tag.get("alt") or ""),
                str(tag.get("title") or ""),
                clean(tag.get_text(" ")),
            ])
            m = re.search(
                r"(晴れ|晴|くもり|曇り|曇|雨|小雨|大雨|雪|霧)",
                blob
            )
            if m and ("天" in blob or "weather" in blob.lower()):
                condition = m.group(1)
                break

    weather["condition"] = condition

    # 潮汐。BOAT RACE本体や各場ページから同文言が取り込まれた場合に保持。
    # 値がない場ではNoneのままにして、AI側で「×」表示する。
    tide_phase = None
    tm = re.search(
        r"(?:潮|潮汐|潮位|潮回り)\s*[：:]?\s*"
        r"(満潮|干潮|上げ潮|下げ潮|上げ|下げ|中潮|大潮|小潮|長潮|若潮)",
        text
    )
    if tm:
        tide_phase = tm.group(1)

    high_tide_time = None
    low_tide_time = None
    hm = re.search(r"満潮(?:時刻)?\s*[：:]?\s*(\d{1,2}:\d{2})", text)
    lm = re.search(r"干潮(?:時刻)?\s*[：:]?\s*(\d{1,2}:\d{2})", text)
    if hm:
        high_tide_time = hm.group(1)
    if lm:
        low_tide_time = lm.group(1)

    weather["tide_phase"] = tide_phase
    weather["high_tide_time"] = high_tide_time
    weather["low_tide_time"] = low_tide_time

    racers = []
    rows = _flatten_table_rows(soup)
    for cells in rows:
        joined = " | ".join(cells)
        lane_m = re.match(r"^\s*([1-6１-６])(?:\s|\|)", joined)
        if not lane_m:
            continue
        lane_char = lane_m.group(1)
        lane = "１２３４５６".find(lane_char)+1 if lane_char in "１２３４５６" else int(lane_char)

        exhibition = None
        tilt = None
        weight = None
        adjustment = None
        parts_exchange = None

        em = re.search(r"(\d\.\d{2})", joined)
        if em:
            exhibition = float(em.group(1))
        tm = re.search(r"チルト\s*([+\-]?\d+(?:\.\d+)?)", joined)
        if tm:
            tilt = float(tm.group(1))
        wtm = re.search(r"(\d+(?:\.\d+)?)\s*kg", joined)
        if wtm:
            weight = float(wtm.group(1))
        am = re.search(r"調整(?:重量)?\s*([+\-]?\d+(?:\.\d+)?)", joined)
        if am:
            adjustment = float(am.group(1))
        pm = re.search(r"部品交換\s*[：:]?\s*([^|]{1,80})", joined)
        if pm:
            parts_exchange = clean(pm.group(1)) or None

        if exhibition is not None or tilt is not None or weight is not None:
            racers.append({
                "lane": lane,
                "weight_kg": weight,
                "adjustment_kg": adjustment,
                "exhibition_time": exhibition,
                "tilt": tilt,
                "parts_exchange": parts_exchange,
                "raw_cells": cells,
            })

    # The official before-info table writes "チルト" in the column header,
    # while each racer row contains only the numeric value.  Reading the row
    # text alone therefore misses values such as 0.0 and -0.5.  Resolve the
    # value by its explicit header position and merge it into the lane row.
    column_rows = {}
    for table in soup.find_all("table"):
        header_row = next(
            (tr for tr in table.find_all("tr") if tr.find_all("th", recursive=False)),
            None,
        )
        if header_row is None:
            continue
        headers = [clean(x.get_text(" ")) for x in header_row.find_all("th", recursive=False)]
        tilt_index = next((i for i, value in enumerate(headers) if "チルト" in value), None)
        exhibition_index = next((i for i, value in enumerate(headers) if "展示" in value and "タイム" in value), None)
        weight_index = next((i for i, value in enumerate(headers) if value == "体重"), None)
        parts_index = next((i for i, value in enumerate(headers) if "部品交換" in value or value == "部品"), None)
        if tilt_index is None and exhibition_index is None and weight_index is None and parts_index is None:
            continue

        for tr in table.find_all("tr"):
            cells = [clean(x.get_text(" ")) for x in tr.find_all("td", recursive=False)]
            if not cells:
                continue
            lane_text = cells[0].translate(str.maketrans("１２３４５６", "123456"))
            if not re.fullmatch(r"[1-6]", lane_text):
                continue
            lane = int(lane_text)

            def column_number(index, unit=""):
                if index is None or index >= len(cells):
                    return None
                value = cells[index].replace(unit, "").strip()
                if not re.fullmatch(r"[+\-]?\d+(?:\.\d+)?", value):
                    return None
                return float(value)

            def column_text(index):
                if index is None or index >= len(cells):
                    return None
                value = clean(cells[index])
                return value if value and value not in ("-", "－", "—") else None

            column_rows[lane] = {
                "lane": lane,
                "weight_kg": column_number(weight_index, "kg"),
                "exhibition_time": column_number(exhibition_index),
                "tilt": column_number(tilt_index),
                "parts_exchange": column_text(parts_index),
                "tilt_source": "official-beforeinfo-column",
                "raw_cells": cells,
            }

    if column_rows:
        merged = {int(x["lane"]): x for x in racers}
        for lane, values in column_rows.items():
            row = merged.setdefault(lane, {"lane": lane})
            for key, value in values.items():
                if value is not None or key in ("tilt_source", "raw_cells"):
                    row[key] = value
        racers = [merged[lane] for lane in sorted(merged)]

    # ST表示はページ内の .xx を6つ拾うフォールバック
    # 出走表の平均ST等と混同しないよう「スタート展示」以降に限定
    start_display = []
    sd = re.search(r"スタート展示(.{0,2500})", text)
    if sd:
        block = sd.group(1)
        # まず「艇番 + ST」がテキストで取れる場合を優先
        pairs = re.findall(r"([1-6])\s*([FL]?\.\d{2})", block)
        if len(pairs) >= 6:
            for course, (lane, st_raw) in enumerate(pairs[:6], start=1):
                start_display.append({
                    "lane": int(lane),
                    "course": course,
                    "st_raw": st_raw
                })
        else:
            # 艇番が画像で取れない場合は枠なりとして保持
            values = re.findall(r"(?<!\d)([FL]?\.\d{2})(?!\d)", block)
            for idx, val in enumerate(values[:6], start=1):
                start_display.append({
                    "lane": idx,
                    "course": idx,
                    "st_raw": val,
                    "entry_inferred": True
                })

    # オリジナル展示
    # 各場で名称・項目が異なるため、固定の1項目に潰さず
    # 「艇番 + ラベル付き計測値 + raw_cells」の形で保存する。
    original_exhibition = []
    original_keywords = (
        "オリジナル展示", "一周タイム", "回り足", "直線タイム",
        "ターンタイム", "展示航走", "周回展示", "展示計測"
    )

    for table in soup.find_all("table"):
        table_text = clean(table.get_text(" "))
        if not any(k in table_text for k in original_keywords):
            continue

        # header labels are kept so venue-specific measurements remain usable.
        headers = [
            clean(x.get_text(" "))
            for x in table.find_all("th")
        ]

        for tr in table.find_all("tr"):
            cells = [
                clean(x.get_text(" "))
                for x in tr.find_all(["th", "td"])
            ]
            if not cells:
                continue

            joined = " | ".join(cells)
            lane_m = re.search(r"(?<!\d)([1-6１-６])(?!\d)", cells[0])
            if not lane_m:
                continue
            lane_char = lane_m.group(1)
            lane = (
                "１２３４５６".find(lane_char) + 1
                if lane_char in "１２３４５６"
                else int(lane_char)
            )

            metrics = {}
            numeric_values = []
            for idx, cell in enumerate(cells[1:], start=1):
                mm = re.fullmatch(r"([+\-]?\d+(?:\.\d+)?)", cell)
                if not mm:
                    continue
                val = float(mm.group(1))
                numeric_values.append(val)

                label = (
                    headers[idx] if idx < len(headers)
                    else f"計測{idx}"
                )
                if label:
                    metrics[label] = val

            # Label-oriented extraction also works when table headers flatten badly.
            known = {
                "一周タイム": r"一周(?:タイム)?\s*[：:]?\s*(\d+(?:\.\d+)?)",
                "回り足": r"回り足(?:タイム)?\s*[：:]?\s*(\d+(?:\.\d+)?)",
                "直線タイム": r"直線(?:タイム)?\s*[：:]?\s*(\d+(?:\.\d+)?)",
                "ターンタイム": r"ターン(?:タイム)?\s*[：:]?\s*(\d+(?:\.\d+)?)",
            }
            for label, pat in known.items():
                mm = re.search(pat, joined)
                if mm:
                    metrics[label] = float(mm.group(1))

            if metrics or numeric_values:
                original_exhibition.append({
                    "lane": lane,
                    "metrics": metrics,
                    "values": numeric_values,
                    "raw_cells": cells,
                })

    # Deduplicate one row per lane while retaining the richest row.
    if original_exhibition:
        best = {}
        for row in original_exhibition:
            lane = int(row["lane"])
            quality = len(row.get("metrics") or {}) + len(row.get("values") or [])
            old = best.get(lane)
            old_q = (
                len(old.get("metrics") or {}) + len(old.get("values") or [])
                if old else -1
            )
            if quality > old_q:
                best[lane] = row
        original_exhibition = [best[k] for k in sorted(best)]

    # 選手コメント。公式に掲載がある場合だけ保存。
    comments = []
    for row in rows:
        joined = " | ".join(row)
        if "コメント" not in joined:
            continue

        lane_m = re.search(r"(?<!\d)([1-6])(?!\d)", joined)
        lane = int(lane_m.group(1)) if lane_m else None

        # "コメント"以降を本文候補にする
        body = joined.split("コメント", 1)[-1]
        body = re.sub(r"^[：:\s|]+", "", body)
        body = clean(body)

        if body and len(body) >= 2:
            comments.append({
                "lane": lane,
                "comment": body[:500],
            })

    return {
        "weather": weather,
        "racers": racers,
        "start_display": start_display,
        "original_exhibition": original_exhibition,
        "comments": comments,
        "raw_text": text[:30000],
        **_race_page_meta(soup),
    }


def parse_heiwajima_original_exhibition(html: str):
    """Parse Heiwajima's venue-original '直前＆展示' table."""
    soup = BeautifulSoup(html, "html.parser")
    rows = []
    for table in soup.find_all("table"):
        table_text = clean(table.get_text(" "))
        if "オリジナルデータ" not in table_text or "まわり足" not in table_text:
            continue
        trs = table.find_all("tr")
        for index, tr in enumerate(trs):
            cells = [clean(x.get_text(" ")) for x in tr.find_all(["th", "td"])]
            if len(cells) < 8 or not re.fullmatch(r"[1-6]", cells[0]):
                continue
            lane = int(cells[0])
            # Main row: lane, racer, タイム, 一周, まわり足, 直線,
            # 展示タイム, 体重, 部品交換. The following row contains
            # speed values and tilt/adjustment; only tilt is merged here.
            values = []
            for value in cells[3:7]:
                try: values.append(float(value))
                except (TypeError, ValueError): values.append(None)
            next_cells = []
            if index + 1 < len(trs):
                next_cells = [clean(x.get_text(" ")) for x in trs[index+1].find_all(["th", "td"])]
            tilt = None
            if next_cells and next_cells[0] == "時速" and len(next_cells) >= 5:
                try: tilt = float(next_cells[4])
                except (TypeError, ValueError): pass
            if all(x is None for x in values[:3]):
                continue
            rows.append({
                "lane": lane,
                "metrics": {
                    "一周": values[0], "まわり足": values[1], "直線": values[2],
                    "展示タイム": values[3],
                },
                "tilt": tilt,
                "weight": cells[7] if len(cells) > 7 else None,
                "parts_replacement": cells[8] if len(cells) > 8 and cells[8] else None,
                "source": "heiwajima-original-exhibition",
            })
        break
    return rows

def parse_odds3t(html: str):
    """
    公式3連単表は、1着ごとに
    2着→3着→オッズ が20通りずつ、合計120通り。
    HTMLテーブル内の数値列を使い復元する。
    """
    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" "))
    update_time = None
    um = re.search(r"オッズ更新時間\s*(\d{1,2}:\d{2})", text)
    if um:
        update_time = um.group(1)

    # 各table rowのセルを活用して3要素パターンを抽出
    found = {}
    rows = _flatten_table_rows(soup)

    # 方法1: セル列の中から「first second third odds」のグループを再構成
    # firstは表の縦ブロックで省略されるため、120通り完全復元できない場合は方法2へ。
    for first in range(1,7):
        for second in range(1,7):
            if second == first:
                continue
            for third in range(1,7):
                if third in (first, second):
                    continue
                found.setdefault(f"{first}-{second}-{third}", None)

    # BeautifulSoupテーブルのDOMでは各1着列が独立セル群になっていることが多い。
    # テキストから既知の公式並び順(1着1..6、各2着4候補×3着4候補)を復元。
    # 数値オッズだけを「3連単オッズ」以降から抽出し120個ある場合に割り当てる。
    marker = text.find("3連単オッズ")
    odds_text = text[marker:] if marker >= 0 else text
    raw_numbers = re.findall(r"(?<![\d.])(\d+\.\d+|\d{1,4})(?![\d.])", odds_text)

    # 先頭には艇番・選手情報等もあるため、DOMから odds値候補をより厳しく収集
    odds_values = []
    for td in soup.find_all("td"):
        t = clean(td.get_text(" "))
        if re.fullmatch(r"\d+(?:\.\d+)?", t):
            v = float(t)
            # 艇番1〜6単独を除外し、オッズらしい値を集める
            if "." in t or v > 6:
                odds_values.append(v)

    # 公式表の順序:
    # first=1..6, second=1..6(ex first), third=1..6(ex first,second)
    combos = []
    for first in range(1,7):
        for second in range(1,7):
            if second == first:
                continue
            for third in range(1,7):
                if third in (first,second):
                    continue
                combos.append(f"{first}-{second}-{third}")

    # DOM差異で多めに拾う場合があるため、120個ちょうどの連続窓を優先
    if len(odds_values) >= 120:
        # 最後側は注記数字が少ないため先頭120を採用。
        # 実運用テスト時に公式ページごとに検証ログで調整可能。
        vals = odds_values[:120]
        for combo, value in zip(combos, vals):
            found[combo] = value

    rows_out = [
        {"combo": combo, "odds": value}
        for combo, value in found.items()
        if value is not None
    ]

    return {
        "update_time": update_time,
        "count": len(rows_out),
        "odds": rows_out,
        "raw_text": text[:30000],
    }


def _odds_combos_120():
    combos = []
    for first in range(1, 7):
        for second in range(1, 7):
            if second == first:
                continue
            for third in range(1, 7):
                if third in (first, second):
                    continue
                combos.append(f"{first}-{second}-{third}")
    return combos


def parse_odds3t_recovery(html: str):
    """
    Recovery parser for 3連単 odds.

    Strategy A:
      existing parse_odds3t()

    Strategy B:
      read leaf/table cells that look like odds, keeping '-' style placeholders.
      If exactly 120 table-ordered values can be reconstructed, assign them to
      the official 120-combination order.

    Strategy C:
      inspect each table independently and find the best 120-value candidate
      window. This avoids unrelated numeric cells before/after the odds board.

    Returns the best result plus parser_method / diagnostic counts.
    """
    primary = parse_odds3t(html)
    if len(primary.get("odds") or []) == 120:
        primary["parser_method"] = "primary"
        primary["recovery_diagnostics"] = {
            "primary_count": 120,
            "table_candidates": [],
        }
        return primary

    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" "))
    combos = _odds_combos_120()

    def parse_cell_value(raw):
        t = clean(raw)
        if not t:
            return None, False

        # Explicit no-odds/cancel placeholders. Keep the row so the 120
        # combinations remain aligned.
        if t in {"-", "—", "－", "欠", "欠場", "取消"}:
            return None, True

        # Odds are normally decimal, but occasionally integer-looking.
        if re.fullmatch(r"\d+(?:\.\d+)?", t):
            v = float(t)
            # Single boat numbers 1..6 are not odds unless decimal was shown.
            if "." in t or v > 6:
                return v, True

        return None, False

    candidates = []

    # Strategy B/C: table-by-table.  We intentionally don't merge unrelated
    # tables because that was the weakness of the old parser.
    for table_idx, table in enumerate(soup.find_all("table")):
        seq = []
        for cell in table.find_all(["td", "th"]):
            value, accepted = parse_cell_value(cell.get_text(" "))
            if accepted:
                seq.append(value)

        candidates.append((table_idx, seq))

    def candidate_score(seq):
        if len(seq) < 120:
            return -10**9, None

        best_score = -10**9
        best_window = None

        # Usually the correct table has exactly 120; if it has extra numeric
        # labels, scan limited windows and prefer odds-like density.
        max_start = min(max(0, len(seq) - 120), 240)
        for start in range(max_start + 1):
            w = seq[start:start + 120]
            numeric = [x for x in w if isinstance(x, (int, float))]
            placeholders = 120 - len(numeric)

            # A valid odds board may include a few '-' cells due to scratches.
            # Prefer many numeric odds and only a small placeholder count.
            score = len(numeric) * 10 - placeholders * 2

            # Typical odds are positive. Penalize impossible values.
            score -= sum(30 for x in numeric if x <= 0)

            if score > best_score:
                best_score = score
                best_window = w

        return best_score, best_window

    best = None
    best_score = -10**9
    best_table = None

    for table_idx, seq in candidates:
        score, window = candidate_score(seq)
        if window is not None and score > best_score:
            best = window
            best_score = score
            best_table = table_idx

    if best is not None and len(best) == 120:
        rows = [
            {
                "combo": combo,
                "odds": value,
            }
            for combo, value in zip(combos, best)
        ]

        um = re.search(r"オッズ更新時間\s*(\d{1,2}:\d{2})", text)

        return {
            "update_time": um.group(1) if um else None,
            "count": 120,
            "odds": rows,
            "raw_text": text[:30000],
            "parser_method": "table-window-recovery",
            "recovery_diagnostics": {
                "primary_count": len(primary.get("odds") or []),
                "best_table": best_table,
                "best_score": best_score,
                "table_candidates": [
                    {"table": idx, "accepted_cells": len(seq)}
                    for idx, seq in candidates
                ],
            },
        }

    primary["parser_method"] = "primary-incomplete"
    primary["recovery_diagnostics"] = {
        "primary_count": len(primary.get("odds") or []),
        "table_candidates": [
            {"table": idx, "accepted_cells": len(seq)}
            for idx, seq in candidates
        ],
    }
    return primary



def odds_combos_for_lanes(active_lanes):
    lanes = sorted(int(x) for x in active_lanes)
    combos = []
    for first in lanes:
        for second in lanes:
            if second == first:
                continue
            for third in lanes:
                if third in (first, second):
                    continue
                combos.append(f"{first}-{second}-{third}")
    return combos


def parse_odds3t_for_active_lanes(html: str, active_lanes):
    """
    Parse odds when one or more boats are scratched.

    6 active boats -> 120
    5 active boats -> 60
    4 active boats -> 24

    Official odds tables keep the same ordered-race concept, but scratched
    combinations disappear.  We therefore rebuild the expected combination
    order from the active lane set and find the best table-local numeric window.
    """
    active_lanes = sorted(int(x) for x in active_lanes)
    combos = odds_combos_for_lanes(active_lanes)
    expected = len(combos)

    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" "))

    def accepted_value(raw):
        t = clean(raw)
        if not t:
            return None, False

        if t in {"-", "—", "－"}:
            return None, True

        if re.fullmatch(r"\d+(?:\.\d+)?", t):
            v = float(t)
            if "." in t or v > 6:
                return v, True

        return None, False

    best = None
    best_score = -10**9
    best_table = None
    table_counts = []

    for table_idx, table in enumerate(soup.find_all("table")):
        seq = []
        for cell in table.find_all(["td", "th"]):
            value, accepted = accepted_value(cell.get_text(" "))
            if accepted:
                seq.append(value)

        table_counts.append({
            "table": table_idx,
            "accepted_cells": len(seq),
        })

        if len(seq) < expected:
            continue

        max_start = min(max(0, len(seq) - expected), 260)

        for start in range(max_start + 1):
            window = seq[start:start + expected]
            numeric = [
                x for x in window
                if isinstance(x, (int, float))
            ]
            placeholders = expected - len(numeric)
            score = len(numeric) * 10 - placeholders * 2

            if score > best_score:
                best_score = score
                best = window
                best_table = table_idx

    if best is None or len(best) != expected:
        return {
            "count": 0,
            "odds": [],
            "expected_count": expected,
            "active_lanes": active_lanes,
            "parser_method": "active-lanes-incomplete",
            "diagnostics": {
                "tables": table_counts,
            },
            "raw_text": text[:30000],
        }

    rows = [
        {"combo": combo, "odds": value}
        for combo, value in zip(combos, best)
    ]

    um = re.search(
        r"オッズ更新時間\s*(\d{1,2}:\d{2})",
        text
    )

    return {
        "update_time": um.group(1) if um else None,
        "count": expected,
        "odds": rows,
        "expected_count": expected,
        "active_lanes": active_lanes,
        "parser_method": "active-lanes-table-window",
        "diagnostics": {
            "best_table": best_table,
            "best_score": best_score,
            "tables": table_counts,
        },
        "raw_text": text[:30000],
    }



def _expand_html_table(table):
    grid=[]
    spans={}
    rows=table.find_all("tr")
    for r_idx,tr in enumerate(rows):
        row=[]
        c_idx=0
        def fill():
            nonlocal c_idx
            while (r_idx,c_idx) in spans:
                row.append(spans[(r_idx,c_idx)])
                c_idx+=1
        fill()
        for cell in tr.find_all(["th","td"]):
            fill()
            txt=clean(cell.get_text(" "))
            try: rs=max(1,int(cell.get("rowspan",1)))
            except Exception: rs=1
            try: cs=max(1,int(cell.get("colspan",1)))
            except Exception: cs=1
            for dc in range(cs):
                row.append(txt)
                for dr in range(1,rs):
                    spans[(r_idx+dr,c_idx+dc)]=txt
            c_idx+=cs
            fill()
        pending=[c for rr,c in spans if rr==r_idx and c>=c_idx]
        if pending:
            for c in range(c_idx,max(pending)+1):
                row.append(spans.get((r_idx,c),""))
        grid.append(row)
    w=max((len(r) for r in grid),default=0)
    return [r+[""]*(w-len(r)) for r in grid]


def parse_odds3t_matrix(html: str):
    soup=BeautifulSoup(html,"html.parser")
    text=clean(soup.get_text(" "))
    all_combos=[]
    for first in range(1,7):
        for second in range(1,7):
            if second==first: continue
            for third in range(1,7):
                if third in (first,second): continue
                all_combos.append(f"{first}-{second}-{third}")

    best=[]
    best_table=None
    diags=[]
    for ti,table in enumerate(soup.find_all("table")):
        records=[]
        for row in _expand_html_table(table):
            if len(row)<18: continue
            for g in range(6):
                base=g*3
                s=clean(row[base]); t=clean(row[base+1]); v=clean(row[base+2])
                if not re.fullmatch(r"[1-6]",s) or not re.fullmatch(r"[1-6]",t):
                    continue
                first=g+1; second=int(s); third=int(t)
                if second==first or third in (first,second): continue
                combo=f"{first}-{second}-{third}"
                if "欠場" in v:
                    status="scratch"; odds=None
                elif re.fullmatch(r"\d+(?:\.\d+)?",v):
                    status="numeric"; odds=float(v)
                else:
                    continue
                records.append({"combo":combo,"odds":odds,"status":status})
        dedup={}
        for rec in records:
            dedup.setdefault(rec["combo"],rec)
        records=list(dedup.values())
        diags.append({"table":ti,"records":len(records),
                      "numeric":sum(r["status"]=="numeric" for r in records),
                      "scratch":sum(r["status"]=="scratch" for r in records)})
        if len(records)>len(best):
            best=records; best_table=ti

    recmap={r["combo"]:r for r in best}
    numeric=[r for r in best if r["status"]=="numeric"]
    lanes=set()
    for r in numeric:
        lanes.update(int(x) for x in r["combo"].split("-"))

    scratch=[]
    if len(recmap)>=100 and "欠場" in text:
        scratch=[lane for lane in range(1,7) if lane not in lanes]
    active=[lane for lane in range(1,7) if lane not in scratch]
    n=len(active)
    expected=n*(n-1)*(n-2) if n>=3 else 0
    scratch_set=set(scratch)
    odds=[]
    for combo in all_combos:
        parts=[int(x) for x in combo.split("-")]
        if scratch_set.intersection(parts): continue
        rec=recmap.get(combo)
        if rec and rec["status"]=="numeric":
            odds.append({"combo":combo,"odds":rec["odds"]})

    um=re.search(r"オッズ更新時間\s*(\d{1,2}:\d{2})",text)
    return {
        "update_time":um.group(1) if um else None,
        "count":len(odds),
        "expected_count":expected or 120,
        "odds":odds,
        "scratch_lanes":scratch,
        "active_lanes":active,
        "matrix_records":len(recmap),
        "parser_method":"official-odds-matrix",
        "matrix_diagnostics":{"best_table":best_table,"tables":diags},
        "raw_text":text[:30000],
    }


def parse_result_list(html: str):
    soup = BeautifulSoup(html, "html.parser")
    text = clean(soup.get_text(" "))

    results = []
    for rno in range(1, 13):
        section_m = re.search(rf"(?:^|\s){rno}R\b(.{{0,1800}}?)(?=\s{rno+1}R\b|$)", text)
        section = section_m.group(1) if section_m else ""

        combo = None
        payout = None

        cm = re.search(r"([1-6])\s*-\s*([1-6])\s*-\s*([1-6])", section)
        if cm:
            combo = f"{cm.group(1)}-{cm.group(2)}-{cm.group(3)}"

        # 3連単付近の円金額
        pm = re.search(r"3連単.{0,100}?[¥￥]?\s*([\d,]+)\s*円?", section)
        if not pm:
            pm = re.search(r"[¥￥]\s*([\d,]+)", section)
        if pm:
            payout = int(pm.group(1).replace(",",""))

        kimarite = None
        # まくり差しを先に判定
        for word in ["まくり差し","逃げ","差し","まくり","抜き","恵まれ"]:
            if word in section:
                kimarite = word
                break

        if combo or payout or kimarite:
            results.append({
                "rno": rno,
                "trifecta": combo,
                "payout_yen": payout,
                "odds": round(payout / 100, 1) if payout else None,
                "kimarite": kimarite,
            })

    return results


def parse_result_detail(html: str, rno: int | None = None):
    """Parse official per-race result fields, including popularity rank."""
    soup = BeautifulSoup(html, "html.parser")
    result = {
        "rno": int(rno) if rno is not None else None,
        "trifecta": None,
        "payout_yen": None,
        "odds": None,
        "popularity": None,
        "kimarite": None,
        "finishers": [],
        "start_courses": [],
    }

    for table in soup.find_all("table"):
        headers = [clean(x.get_text(" ")) for x in table.find_all("th")]
        if not ({"勝式", "組番", "払戻金", "人気"} <= set(headers)):
            continue
        for tr in table.find_all("tr"):
            cells = tr.find_all("td", recursive=False)
            if not cells or clean(cells[0].get_text(" ")) != "3連単":
                continue
            nums = [clean(x.get_text(" ")) for x in tr.select(".numberSet1_number")]
            if len(nums) >= 3 and all(re.fullmatch(r"[1-6]", x) for x in nums[:3]):
                result["trifecta"] = "-".join(nums[:3])
            if len(cells) >= 3:
                payout_m = re.search(r"([\d,]+)", clean(cells[2].get_text(" ")))
                if payout_m:
                    result["payout_yen"] = int(payout_m.group(1).replace(",", ""))
            if len(cells) >= 4:
                popularity_m = re.search(r"\d+", clean(cells[3].get_text(" ")))
                if popularity_m:
                    result["popularity"] = int(popularity_m.group())
            break
        if result["trifecta"]:
            break

    if result["payout_yen"] is not None:
        result["odds"] = round(result["payout_yen"] / 100, 1)

    for table in soup.find_all("table"):
        header_text = " ".join(clean(x.get_text(" ")) for x in table.find_all("th"))
        if "決まり手" not in header_text:
            continue
        for td in table.find_all("td"):
            value = clean(td.get_text(" "))
            if value in ("まくり差し", "逃げ", "差し", "まくり", "抜き", "恵まれ"):
                result["kimarite"] = value
                break
        if result["kimarite"]:
            break

    # Full official finishing order: finish, boat/frame, registration and name.
    trans = str.maketrans("１２３４５６", "123456")
    for table in soup.find_all("table"):
        headers = [clean(x.get_text(" ")) for x in table.find_all("th")]
        if not ({"着", "枠", "ボートレーサー"} <= set(headers)):
            continue
        for tr in table.find_all("tr"):
            cells = tr.find_all("td", recursive=False)
            if len(cells) < 3:
                continue
            finish_text = clean(cells[0].get_text(" ")).translate(trans)
            lane_text = clean(cells[1].get_text(" ")).translate(trans)
            fm = re.search(r"[1-6]", finish_text)
            status_m = re.search(r"F|L|欠|失|妨|転|落|沈|エ", finish_text, re.I)
            lm = re.search(r"[1-6]", lane_text)
            if (not fm and not status_m) or not lm:
                continue
            racer_text = clean(cells[2].get_text(" "))
            reg = re.search(r"(?<!\d)(\d{4})(?!\d)", racer_text)
            name = re.sub(r"(?<!\d)\d{4}(?!\d)", "", racer_text).strip()
            result["finishers"].append({
                "finish": int(fm.group()) if fm else status_m.group().upper(),
                "status": None if fm else status_m.group().upper(),
                "lane": int(lm.group()),
                "registration_no": reg.group(1) if reg else None,
                "name": name or None,
            })
        break

    # The official start-information diagram is ordered by actual entry course.
    start_nodes = soup.select(".table1_boatImage1")
    seen_lanes = set()
    for course, node in enumerate(start_nodes, start=1):
        number = node.select_one(".table1_boatImage1Number")
        m = re.search(r"[1-6]", clean(number.get_text(" ")) if number else "")
        if not m:
            continue
        lane = int(m.group())
        if lane in seen_lanes:
            continue
        seen_lanes.add(lane)
        # Result pages show actual entry order and usually the actual ST in
        # the same boat node.  Keep it when available for racer history.
        node_text = clean(node.get_text(" "))
        st_match = re.search(r"(?:[FL]\s*)?(?:0)?\.\d{2}", _fw_to_ascii(node_text), re.I)
        result["start_courses"].append({
            "lane": lane,
            "course": len(seen_lanes),
            "st_raw": st_match.group(0).replace(" ", "") if st_match else None,
        })

    course_by_lane = {x["lane"]: x["course"] for x in result["start_courses"]}
    for row in result["finishers"]:
        row["course"] = course_by_lane.get(row["lane"])
        st_by_lane = {x["lane"]: x.get("st_raw") for x in result["start_courses"]}
        row["st_raw"] = st_by_lane.get(row["lane"])

    # A race can be final even when 3連単 is not established (multiple F/L,
    # etc.). Keep it as an official final result instead of "waiting".
    abnormal = [x for x in result["finishers"] if not isinstance(x.get("finish"), int)]
    if result["finishers"] and abnormal and not result.get("trifecta"):
        result["result_confirmed"] = True
        result["result_status"] = "3連単不成立"

    result.update({k: v for k, v in _race_page_meta(soup).items() if v})

    return result
