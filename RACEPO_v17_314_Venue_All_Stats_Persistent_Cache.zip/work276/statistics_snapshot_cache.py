"""Best-effort, atomic, disk-backed statistics response snapshots.

The DB/WAL fingerprint prevents serving snapshots after database writes.  This
is intentionally conservative: unrelated writes can cause recomputation, but
never justify serving an outdated statistics snapshot.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import time


def fingerprint(db_path):
    base = Path(db_path)
    signature = []
    for path in (base, Path(str(base) + '-wal')):
        try:
            stat = path.stat()
            signature.append([str(path), stat.st_size, stat.st_mtime_ns])
        except FileNotFoundError:
            signature.append([str(path), None, None])
    return signature


def cache_file(db_path, date):
    base = Path(db_path)
    identity = hashlib.sha256(str(base.resolve()).encode()).hexdigest()[:16]
    return base.parent / '.racepo_statistics_cache' / f'{identity}_{date}.json'


def read_snapshot(db_path, date, ttl_seconds):
    path = cache_file(db_path, date)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('version') != 1 or data.get('date') != date:
            return None
        if time.time() - float(data['saved_at']) >= ttl_seconds:
            return None
        if data['fingerprint'] != fingerprint(db_path):
            return None
        return data['payload']
    except (OSError, ValueError, KeyError, TypeError):
        return None


def save_snapshot(db_path, date, payload, before):
    if before != fingerprint(db_path):
        return False  # Data changed while calculating: never persist a stale result.
    path = cache_file(db_path, date)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp = tempfile.mkstemp(prefix='.pending_', suffix='.json', dir=path.parent)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as out:
                json.dump({'version': 1, 'date': date, 'saved_at': time.time(),
                           'fingerprint': before, 'payload': payload}, out,
                          ensure_ascii=False, separators=(',', ':'))
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
        return True
    except OSError:
        return False  # Read-only installation: calculations still work.
