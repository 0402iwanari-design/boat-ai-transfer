from __future__ import annotations
"""v17.212: ChatGPT-manual-flow validation for 峰竜太4320 / 児島 / 実進入1C-6C.

This build intentionally mirrors the successful manual collection order:
  1) Open the RACER'S OWN history page first (not a day/venue crawl).
  2) Take only races belonging to racer 4320.
  3) Keep only Kojima (jcd=16) candidates.
  4) Open the BOAT RACE official result page for each candidate.
  5) Determine actual entry course from official スタート情報 lane order.
  6) Save by actual-entry course 1C-6C, newest first, maximum 10 each.
  7) If recent racer history is insufficient, use the racer's yearly archive
     newest year -> ... -> 2020-01-01. Each course stops at 10; a course with fewer than 10 at the floor is normal completion.

Nationwide history is NEVER deleted or rewritten in this validation build.
Local history uses a separate physical table (racer_local_course_runs), so
local rebuilds cannot damage the already verified nationwide 60 runs.
"""

import re
import threading
import time
import unicodedata
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
FLOOR_YEAR = 2020
VALIDATION_REG = "4320"
VALIDATION_NAME = "峰竜太"
VALIDATION_LOCAL_JCD = "16"  # 児島だけ
VALIDATION_LOCAL_COURSES = (1, 2, 3, 4, 5, 6)

VENUES = [
    "桐生", "戸田", "江戸川", "平和島", "多摩川", "浜名湖", "蒲郡", "常滑", "津", "三国", "びわこ", "住之江",
    "尼崎", "鳴門", "丸亀", "児島", "宮島", "徳山", "下関", "若松", "芦屋", "福岡", "唐津", "大村",
]
VENUE_CODE = {n: f"{i:02d}" for i, n in enumerate(VENUES, 1)}


def _nfkc(s):
    return unicodedata.normalize("NFKC", str(s or ""))


def _norm(s):
    return re.sub(r"[\s\u3000]+", "", _nfkc(s))


def _venue_code(s):
    n = _norm(s)
    for name, code in VENUE_CODE.items():
        if _norm(name) == n:
            return code
    # Yearly pages sometimes contain decorations around the venue name.
    for name, code in VENUE_CODE.items():
        if _norm(name) in n and len(_norm(name)) >= 1:
            return code
    return None


def _date_token(s, year):
    text = _nfkc(s)
    m = re.search(r"(?<!\d)(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})(?!\d)", text)
    if not m:
        m = re.search(r"(?<!\d)(?:(\d{4})年)?\s*(\d{1,2})月\s*(\d{1,2})日", text)
    if not m:
        return None
    y = int(m.group(1) or year)
    return f"{y:04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def _race_token(s):
    m = re.fullmatch(r"\s*(\d{1,2})\s*R\s*", _nfkc(s), re.I)
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 12 else None


def _st_token(s):
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return t
    if re.fullmatch(r"[FL]\.\d{1,2}", t):
        return t
    if t in {"F", "L"}:
        return t
    return None


def _st_value(s):
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return float("0" + t)
    m = re.fullmatch(r"F\.(\d{1,2})", t)
    if m:
        return -float("0." + m.group(1))
    m = re.fullmatch(r"L\.(\d{1,2})", t)
    if m:
        return float("0." + m.group(1))
    return None


def _finish_token(s):
    t = _norm(s).replace("着", "")
    return t if re.fullmatch(r"[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠", t) else None


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = {
            "phase": "本日の出走表待ち",
            "validation_mode": "v17.212 峰4320 全国保持＋児島1C-6C / ChatGPT同手順",
        }

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._scheduler, daemon=True, name="mine-kojima-allcourses-chatgpt-flow")
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            today = datetime.now(JST).strftime("%Y%m%d")
            try:
                self._run(today)
            except Exception as e:
                self.status.update({
                    "phase": "収集処理エラー",
                    "scheduler_error": f"{type(e).__name__}: {e}",
                    "validation_mode": "v17.212 峰4320 全国保持＋児島1C-6C / ChatGPT同手順",
                })
            self._stop.wait(20)

    def _ensure_local_table(self):
        with self.db.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS racer_local_course_runs (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, lane INTEGER, course INTEGER NOT NULL,
                finish TEXT, st_raw TEXT, st_rank INTEGER, source TEXT,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_racer_local_course_runs_lookup
                           ON racer_local_course_runs(registration_no,jcd,course,date DESC)""")
            con.execute("""CREATE TABLE IF NOT EXISTS app_migrations (
                migration_key TEXT PRIMARY KEY, applied_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")

    def _reset_local_only_once(self, today):
        """Delete only local validation rows. Nationwide racer_course_runs is untouched."""
        self._ensure_local_table()
        key = "course_history_v17_212_mine4320_kojima_allcourses_20200101_chatgpt_exact_flow"
        with self.db.connect() as con:
            if con.execute("SELECT 1 FROM app_migrations WHERE migration_key=?", (key,)).fetchone():
                return False
            con.execute("DELETE FROM racer_local_course_runs WHERE registration_no=? AND jcd=?",
                        (VALIDATION_REG, VALIDATION_LOCAL_JCD))
            con.execute("DELETE FROM app_migrations WHERE migration_key=?",
                        (self._floor_complete_key(),))
            # Target state is diagnostic only; do not touch nationwide rows/state.
            old = con.execute("SELECT 1 FROM course_history_target_state WHERE registration_no=? AND jcd=?",
                              (VALIDATION_REG, VALIDATION_LOCAL_JCD)).fetchone()
            if old:
                con.execute("""UPDATE course_history_target_state SET status='pending',cursor_date=NULL,
                               floor_date='20200101',target_date=?,retry_count=0,failed_date=NULL,
                               last_error=NULL,completed_at=NULL,updated_at=CURRENT_TIMESTAMP
                               WHERE registration_no=? AND jcd=?""",
                            (today, VALIDATION_REG, VALIDATION_LOCAL_JCD))
            else:
                con.execute("""INSERT INTO course_history_target_state
                               (registration_no,jcd,name,status,cursor_date,floor_date,target_date)
                               VALUES(?,?,?,'pending',NULL,'20200101',?)""",
                            (VALIDATION_REG, VALIDATION_LOCAL_JCD, VALIDATION_NAME, today))
            con.execute("INSERT INTO app_migrations(migration_key) VALUES(?)", (key,))
        return True

    def _national_counts(self):
        with self.db.connect() as con:
            rows = con.execute("""SELECT course,COUNT(*) n FROM racer_course_runs
                                  WHERE registration_no=? GROUP BY course""",
                               (VALIDATION_REG,)).fetchall()
        return {int(x["course"]): min(10, int(x["n"])) for x in rows}

    def _local_counts(self):
        self._ensure_local_table()
        with self.db.connect() as con:
            rows = con.execute("""SELECT course,COUNT(*) n FROM racer_local_course_runs
                                  WHERE registration_no=? AND jcd=? AND date>='20200101' GROUP BY course""",
                               (VALIDATION_REG, VALIDATION_LOCAL_JCD)).fetchall()
        return {int(x["course"]): min(10, int(x["n"])) for x in rows}

    def _local_rows(self):
        with self.db.connect() as con:
            rows = con.execute("""SELECT date,jcd,rno,lane,course,finish,st_raw,st_rank,source
                                  FROM racer_local_course_runs
                                  WHERE registration_no=? AND jcd=?
                                  ORDER BY course ASC,date DESC,rno DESC""",
                               (VALIDATION_REG, VALIDATION_LOCAL_JCD)).fetchall()
        return [dict(x) for x in rows]

    @staticmethod
    def _done(local_counts):
        return all(local_counts.get(c, 0) >= 10 for c in VALIDATION_LOCAL_COURSES)

    def _floor_complete_key(self):
        return "course_history_v17_212_mine4320_kojima_allcourses_floor_complete"

    def _floor_complete(self):
        self._ensure_local_table()
        with self.db.connect() as con:
            return bool(con.execute("SELECT 1 FROM app_migrations WHERE migration_key=?",
                                    (self._floor_complete_key(),)).fetchone())

    def _mark_floor_complete(self):
        with self.db.connect() as con:
            con.execute("INSERT OR IGNORE INTO app_migrations(migration_key) VALUES(?)",
                        (self._floor_complete_key(),))

    def _session(self):
        s = requests.Session()
        s.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ja,en-US;q=0.8,en;q=0.6",
            "Cache-Control": "no-cache",
        })
        return s

    def _get_html(self, session, urls, label):
        last = None
        for url in urls:
            for attempt in range(1, 4):
                try:
                    self.status.update({"phase": label, "direct_source": url,
                                        "last_fetch_state": f"fetch {attempt}/3", "last_fetch_error": None})
                    r = session.get(url, timeout=(6, 25), allow_redirects=True)
                    if r.status_code == 404:
                        last = f"HTTP 404: {url}"
                        break
                    r.raise_for_status()
                    if len(r.text) < 500:
                        raise RuntimeError(f"HTML too short ({len(r.text)})")
                    return r.text, {"url": r.url, "http": r.status_code, "attempt": attempt}
                except Exception as e:
                    last = f"{type(e).__name__}: {e}"
                    self.status.update({"last_fetch_error": last})
                    if attempt < 3:
                        self._stop.wait(1)
        raise RuntimeError(last or f"{label} 取得失敗")

    def _parse_recent_racer_page(self, html, today_year):
        """Parse only the '近走成績' table from the racer's own page."""
        soup = BeautifulSoup(html, "html.parser")
        out = []
        for table in soup.find_all("table"):
            heads = [" ".join(x.stripped_strings) for x in table.find_all("th")]
            h = "|".join(_norm(x) for x in heads)
            if not ("日付" in h and "場" in h and "R" in h and ("進入" in h or "枠" in h)):
                continue
            for tr in table.find_all("tr"):
                cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
                if len(cells) < 3:
                    continue
                d = _date_token(cells[0], today_year)
                jcd = _venue_code(cells[1]) if len(cells) > 1 else None
                rno = _race_token(cells[2]) if len(cells) > 2 else None
                if d and jcd and rno:
                    out.append({"date": d, "jcd": jcd, "rno": rno, "candidate_source": "boatracedata-racer-recent"})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_recent_racer_candidates(self, session):
        url = f"https://boatracedata.com/racer/{VALIDATION_REG}"
        html, diag = self._get_html(session, [url], "峰4320本人の近走履歴を取得中")
        rows = self._parse_recent_racer_page(html, datetime.now(JST).year)
        # EXACTLY racer-first then venue-filter: other venues never become local candidates.
        rows = [x for x in rows if x["jcd"] == VALIDATION_LOCAL_JCD]
        self.status.update({
            "phase": "峰4320本人の近走履歴→児島16だけ抽出",
            "crawl_stage": f"BOATRACE DATA 峰4320近走 → 児島候補 {len(rows)}走",
            "last_fetch_state": "racer recent candidates ok",
            "candidate_races": len(rows),
            "direct_source": diag.get("url"),
        })
        return rows

    def _expand_table(self, table):
        """Expand rowspan/colspan so date/R columns stay aligned."""
        grid = []
        spans = {}
        trs = table.find_all("tr")
        for r, tr in enumerate(trs):
            row = []
            c = 0
            cells = tr.find_all(["th", "td"], recursive=False)
            i = 0
            while i < len(cells) or any(k[0] == r for k in spans):
                while (r, c) in spans:
                    val, remain = spans[(r, c)]
                    row.append(val)
                    del spans[(r, c)]
                    c += 1
                if i >= len(cells):
                    break
                cell = cells[i]; i += 1
                val = " ".join(cell.stripped_strings)
                rs = int(cell.get("rowspan", 1) or 1)
                cs = int(cell.get("colspan", 1) or 1)
                for dc in range(cs):
                    row.append(val)
                    if rs > 1:
                        for dr in range(1, rs):
                            spans[(r + dr, c + dc)] = (val, rs - dr)
                c += cs
            grid.append(row)
        width = max((len(x) for x in grid), default=0)
        return [x + [""] * (width - len(x)) for x in grid]

    def _nearest_table_venue(self, table):
        """Find the venue from the closest preceding section text, never from another race column."""
        node = table
        checked = 0
        while node is not None and checked < 60:
            node = node.find_previous()
            if node is None:
                break
            if getattr(node, "name", None) in {"table", "tr", "td", "th"}:
                continue
            txt = " ".join(node.stripped_strings) if hasattr(node, "stripped_strings") else ""
            if not txt or len(txt) > 240:
                continue
            checked += 1
            jcd = _venue_code(txt)
            if jcd:
                return jcd
        return None

    def _parse_year_archive_candidates(self, html, year):
        """Racer-first yearly archive parser.

        Source is the racer's own '全出走結果' page. We only extract
        date + venue + R candidates here; actual course/ST/finish are always
        re-checked on the BOAT RACE official result page.
        """
        soup = BeautifulSoup(html, "html.parser")
        out = []
        for table in soup.find_all("table"):
            jcd = self._nearest_table_venue(table)
            if jcd != VALIDATION_LOCAL_JCD:
                continue
            rows = self._expand_table(table)
            if not rows:
                continue
            dates = {}
            for row in rows:
                for i, c in enumerate(row):
                    d = _date_token(c, year)
                    if d and "20200101" <= d <= datetime.now(JST).strftime("%Y%m%d"):
                        dates[i] = d
            if not dates:
                continue
            for row in rows:
                for col, cell in enumerate(row):
                    rno = _race_token(cell)
                    if not rno:
                        continue
                    date = dates.get(col)
                    if date:
                        out.append({"date": date, "jcd": jcd, "rno": rno,
                                    "candidate_source": f"boatrace-db-racer-yall-{year}"})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_year_racer_candidates(self, session, year):
        urls = [f"https://boatrace-db.net/racer/yall/regno/{VALIDATION_REG}/year/{year}/"]
        html, diag = self._get_html(session, urls, f"峰4320本人の{year}年全出走履歴を取得中")
        rows = self._parse_year_archive_candidates(html, year)
        self.status.update({
            "phase": f"峰4320本人の{year}年履歴→児島16だけ抽出",
            "crawl_stage": f"峰4320 {year}年全出走 → 児島候補 {len(rows)}走",
            "last_fetch_state": f"racer year {year} candidates ok",
            "candidate_races": len(rows),
            "direct_source": diag.get("url"),
        })
        return rows

    def _official_result_url(self, x):
        return ("https://www.boatrace.jp/owpc/pc/race/raceresult"
                f"?hd={x['date']}&jcd={str(x['jcd']).zfill(2)}&rno={int(x['rno'])}")

    def _parse_official_result(self, html, candidate, reg):
        soup = BeautifulSoup(html, "html.parser")
        lane = None
        finish = None
        # Result row: find exact registration number 4320.
        for tr in soup.find_all("tr"):
            cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
            if not cells:
                continue
            joined = _nfkc(" ".join(cells))
            if not re.search(rf"(?<!\d){re.escape(str(reg))}(?!\d)", joined):
                continue
            fs = [_finish_token(c) for c in cells]
            fs = [x for x in fs if x is not None]
            if fs:
                finish = fs[0]
            for idx, c in enumerate(cells):
                t = _norm(c)
                if re.fullmatch(r"[1-6]", t):
                    if idx == 0 and len(cells) > 1 and re.fullmatch(r"[1-6]", _norm(cells[1])):
                        continue
                    lane = int(t)
                    break
            if lane:
                break
        if not lane or finish == "欠" or finish is None:
            return None

        # Find スタート情報 section and preserve its display order.
        start_rows = []
        start_header = None
        for tag in soup.find_all(["h2", "h3", "h4", "dt", "th", "div", "p"]):
            if "スタート情報" in _norm(tag.get_text(" ", strip=True)):
                start_header = tag
                break
        search_root = start_header.parent if start_header is not None else soup
        # Official markup varies; collect lane + ST pairs in DOM order near the section.
        for node in search_root.find_all(["tr", "li", "div"], recursive=True):
            text = _nfkc(" ".join(node.stripped_strings))
            # Avoid huge container nodes that duplicate descendants.
            if len(text) > 120:
                continue
            lane_m = re.search(r"(?<!\d)([1-6])(?!\d)", text)
            st_m = re.search(r"(?<![A-Z0-9])([FL]?\.\d{1,2}|F|L)(?!\d)", _norm(text).upper())
            if lane_m and st_m:
                pair = (int(lane_m.group(1)), st_m.group(1))
                if pair[0] not in [x[0] for x in start_rows]:
                    start_rows.append(pair)
            if len(start_rows) >= 6:
                break
        # Fallback: scan compact text nodes globally, still preserving DOM order.
        if lane not in [x[0] for x in start_rows]:
            start_rows = []
            for node in soup.find_all(["tr", "li", "div"]):
                text = _nfkc(" ".join(node.stripped_strings))
                if len(text) > 100:
                    continue
                lm = re.search(r"(?<!\d)([1-6])(?!\d)", text)
                sm = re.search(r"([FL]?\.\d{1,2}|F|L)", _norm(text).upper())
                if lm and sm:
                    pair = (int(lm.group(1)), sm.group(1))
                    if pair[0] not in [x[0] for x in start_rows]:
                        start_rows.append(pair)
                if len(start_rows) >= 6:
                    break
        if lane not in [x[0] for x in start_rows] or len(start_rows) < 2:
            return None

        course_by_lane = {slane: pos for pos, (slane, _st) in enumerate(start_rows, 1)}
        st_by_lane = {slane: st for slane, st in start_rows}
        course = course_by_lane.get(lane)
        st_raw = st_by_lane.get(lane)
        if not course or st_raw is None:
            return None

        numeric = []
        for slane, st in start_rows:
            v = _st_value(st)
            if v is not None:
                numeric.append((slane, v))
        numeric.sort(key=lambda z: z[1])
        ranks, last, rank = {}, None, 0
        for pos, (slane, v) in enumerate(numeric, 1):
            if last is None or abs(v-last) > 1e-9:
                rank = pos
                last = v
            ranks[slane] = rank

        return {
            "date": str(candidate["date"]), "jcd": str(candidate["jcd"]).zfill(2),
            "rno": int(candidate["rno"]), "registration_no": str(reg), "lane": lane,
            "course": int(course), "finish": str(finish), "st_raw": str(st_raw),
            "st_rank": ranks.get(lane), "source": "boatrace-official-result:local-chatgpt-flow-v17212",
        }

    def _fetch_official_run(self, session, candidate):
        url = self._official_result_url(candidate)
        last = None
        for attempt in range(1, 4):
            try:
                self.status.update({"phase": "BOAT RACE公式結果で実進入確認中",
                                    "direct_source": url, "last_fetch_state": f"official {attempt}/3"})
                r = session.get(url, timeout=(6, 25))
                r.raise_for_status()
                return self._parse_official_result(r.text, candidate, VALIDATION_REG), {
                    "url": r.url, "http": r.status_code, "attempt": attempt}
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                self.status.update({"last_fetch_error": last})
                if attempt < 3:
                    self._stop.wait(1)
        raise RuntimeError(last or "公式レース結果取得失敗")

    def _save_if_kojima_course(self, row):
        if not row:
            return False
        if row["jcd"] != VALIDATION_LOCAL_JCD or int(row["course"]) not in VALIDATION_LOCAL_COURSES:
            return False
        # If this course already has 10 newer runs, do not touch it.
        if self._local_counts().get(int(row["course"]), 0) >= 10:
            return False
        self.db.save_local_course_history_runs([row], keep_per_course=10)
        return True

    def _process_candidates(self, session, candidates, seen, started):
        verified = saved = 0
        for cand in candidates:
            if self._done(self._local_counts()):
                break
            key = (cand["date"], cand["jcd"], int(cand["rno"]))
            if key in seen:
                continue
            seen.add(key)
            # Hard guard: local validation is Kojima only.
            if cand["jcd"] != VALIDATION_LOCAL_JCD:
                continue
            try:
                row, diag = self._fetch_official_run(session, cand)
                verified += 1
            except Exception as e:
                self.status.update({"last_nonfatal_error": f"{key}: {type(e).__name__}: {e}"})
                continue
            if row:
                self.status.update({
                    "crawl_stage": f"{row['date']} 児島{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "last_verified_run": f"{row['date']} 児島{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "crawl_detail_pages": self.status.get("crawl_detail_pages", 0) + 1,
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                })
                if self._save_if_kojima_course(row):
                    saved += 1
                    self.status.update({
                        "last_fetch_state": f"児島実進入{row['course']}C saved",
                        "last_fetch_date": row["date"],
                        "local_counts": self._local_counts(),
                        "local_history": self._local_rows(),
                    })
        return verified, saved

    def _run(self, today):
        migration_now = self._reset_local_only_once(today)
        # On subsequent scheduler loops, if complete, only report; do not restart/rewrite.
        lm = self._local_counts()
        if self._done(lm) or self._floor_complete():
            self.status.update({
                "phase": "峰竜太 児島・実進入1C-6C 直近最大10走 完了",
                "validation_mode": "v17.212 峰4320 全国保持＋児島1C-6C / ChatGPT同手順",
                "national_counts": self._national_counts(), "local_counts": lm,
                "local_history": self._local_rows(), "last_fetch_state": "complete 10" if self._done(lm) else "complete to 2020-01-01 floor",
            })
            return

        started = time.monotonic()
        session = self._session()
        seen = set()
        total_candidates = total_verified = total_saved = 0
        archive_errors = []
        self.status = {
            "phase": "ChatGPTと同じ手順で峰4320本人の履歴を取得開始",
            "validation_mode": "v17.212 峰4320 全国保持＋児島1C-6C / ChatGPT同手順",
            "current_racer": VALIDATION_NAME, "current_registration_no": VALIDATION_REG,
            "clean_reset_applied": bool(migration_now),
            "crawl_stage": "選手4320本人の履歴 → 児島16だけ → BOAT RACE公式結果 → 実進入1C-6Cへ振り分け保存",
            "national_counts": self._national_counts(), "local_counts": lm,
            "local_history": self._local_rows(),
            "note": "日付/場の総当たりはしない。選手本人の履歴を先に取得する。全国テーブルは読み取りのみで削除・更新しない。",
        }

        # STEP 1: exactly like the manual check: recent racer history first.
        try:
            recent = self._fetch_recent_racer_candidates(session)
        except Exception as e:
            recent = []
            archive_errors.append(f"recent racer page: {type(e).__name__}: {e}")
        total_candidates += len(recent)
        v, s = self._process_candidates(session, recent, seen, started)
        total_verified += v; total_saved += s

        # STEP 2: if still short, open the racer's own yearly archive newest -> oldest.
        if not self._done(self._local_counts()):
            for year in range(min(datetime.now(JST).year - 1, 2025), FLOOR_YEAR-1, -1):
                if self._done(self._local_counts()):
                    break
                try:
                    rows = self._fetch_year_racer_candidates(session, year)
                except Exception as e:
                    archive_errors.append(f"{year}: {type(e).__name__}: {e}")
                    self.status.update({
                        "phase": f"峰4320 {year}年選手履歴の取得失敗",
                        "last_nonfatal_error": archive_errors[-1],
                    })
                    continue
                total_candidates += len(rows)
                v, s = self._process_candidates(session, rows, seen, started)
                total_verified += v; total_saved += s
                self.status.update({
                    "crawl_list_pages": 1 + (2025 - year + 1),
                    "candidate_races": total_candidates, "last_matched_rows": total_verified,
                    "last_parsed_rows": total_saved, "national_counts": self._national_counts(),
                    "local_counts": self._local_counts(), "local_history": self._local_rows(),
                    "crawl_elapsed_seconds": int(time.monotonic()-started),
                })

        lm = self._local_counts()
        if self._done(lm):
            phase = "峰竜太 児島・実進入1C-6C 直近10走ずつ完了"
            state = "complete 10"
            self._mark_floor_complete()
        elif not archive_errors:
            phase = f"峰竜太 児島1C-6Cを2020/01/01まで確認完了（合計{sum(lm.values())}走）"
            state = "complete to 2020-01-01 floor"
            self._mark_floor_complete()
        else:
            phase = f"峰竜太 児島1C-6C 収集中（取得元エラーあり / 合計{sum(lm.values())}走）"
            state = "incomplete: source errors"
        self.status.update({
            "phase": phase, "last_fetch_state": state,
            "candidate_races": total_candidates, "last_matched_rows": total_verified,
            "last_parsed_rows": total_saved, "national_counts": self._national_counts(),
            "local_counts": lm, "local_history": self._local_rows(),
            "crawl_elapsed_seconds": int(time.monotonic()-started),
            "crawl_stage": f"峰4320本人履歴の児島候補 {total_candidates}走 → 公式確認 {total_verified}走 → 当地保存合計 {sum(lm.values())}走 / 1C-6C {lm}",
            "last_nonfatal_error": " | ".join(archive_errors[-4:]) if archive_errors else None,
            "note": "v17.212。ChatGPT手順固定：選手本人履歴→児島だけ→公式結果→実進入1C-6Cへ振り分け。2020/01/01まで。全国データは別テーブルのまま一切変更しない。",
        })
