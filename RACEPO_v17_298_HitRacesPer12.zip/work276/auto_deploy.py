"""GitHub push webhook を受けて BOAT AI Lab を安全に更新する小さな実行器。"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT = Path(os.environ.get("BOAT_APP_ROOT", "/opt/boat-ai-lab"))
REPOSITORY = ROOT / "x"
RELEASES = ROOT / "releases"
SECRET_FILE = ROOT / ".boat_ai_github_webhook_secret"
LOCK_FILE = ROOT / ".boat_ai_deploy.lock"
STATUS_FILE = ROOT / "auto_deploy_status.json"
LOG_FILE = ROOT / "auto_deploy.log"


def configured() -> bool:
    return SECRET_FILE.is_file() and bool(SECRET_FILE.read_text(encoding="utf-8").strip())


def verify_signature(payload: bytes, signature: str | None) -> bool:
    if not configured() or not signature or not signature.startswith("sha256="):
        return False
    secret = SECRET_FILE.read_text(encoding="utf-8").strip().encode("utf-8")
    expected = "sha256=" + hmac.new(secret, payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def _write_status(state: str, message: str) -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    STATUS_FILE.write_text(json.dumps({"state": state, "message": message, "updated_at": int(time.time())}, ensure_ascii=False), encoding="utf-8")


def _run(command: list[str], *, cwd: Path | None = None) -> str:
    result = subprocess.run(command, cwd=cwd, check=True, text=True, capture_output=True)
    return (result.stdout or "") + (result.stderr or "")


def _safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for member in zf.infolist():
            target = (destination / member.filename).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError("ZIP内に不正なパスがあります")
        zf.extractall(destination)


def _project_directory(release: Path) -> Path:
    if (release / "requirements.txt").is_file() and (release / "app.py").is_file():
        return release
    candidates = [p for p in release.iterdir() if p.is_dir() and (p / "requirements.txt").is_file() and (p / "app.py").is_file()]
    if len(candidates) == 1:
        return candidates[0]
    raise RuntimeError("ZIP内にアプリ本体（requirements.txt / app.py）が見つかりません")


def queue_deploy() -> bool:
    """Run updater in its own systemd unit, outside the web service cgroup.

    Without this isolation, systemctl restart boat-ai-lab.service terminates
    the updater before it can report completion or roll back.
    """
    ROOT.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(LOCK_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        # Do not discard a possibly-live lock. A stale lock is a manual
        # recovery situation; never start two concurrent deployments.
        return False
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(str(os.getpid()))
    unit = f"racepo-deploy-{int(time.time())}-{os.getpid()}"
    try:
        subprocess.run(
            ["systemd-run", f"--unit={unit}", "--collect",
             sys.executable, str(Path(__file__).resolve()), "--deploy"],
            check=True, text=True, capture_output=True, timeout=15,
        )
    except Exception:
        LOCK_FILE.unlink(missing_ok=True)
        raise
    return True


def _switch_release(project: Path) -> None:
    """Atomically select new release; restart and health check; roll back on failure."""
    current = ROOT / "current"
    if not current.is_symlink():
        raise RuntimeError("current リンクが存在しません。先に起動設定を確認してください")
    previous = current.resolve(strict=True)
    service = "boat-ai-lab.service"
    # Refuse to switch if systemd is not configured to use current.
    configured = _run(["systemctl", "show", service, "-p", "ExecStart", "-p", "WorkingDirectory"])
    if str(current) not in configured:
        raise RuntimeError("systemd が /opt/boat-ai-lab/current を参照していません")
    temp_link = ROOT / f".current-deploy-{os.getpid()}"
    try:
        temp_link.symlink_to(project.resolve(strict=True), target_is_directory=True)
        temp_link.replace(current)
        try:
            _run(["systemctl", "restart", service])
            _wait_for_healthy_app()
        except Exception:
            rollback_link = ROOT / f".current-rollback-{os.getpid()}"
            rollback_link.symlink_to(previous, target_is_directory=True)
            rollback_link.replace(current)
            # Attempt to restore previously working version.
            try:
                _run(["systemctl", "restart", service])
            except Exception as rollback_error:
                raise RuntimeError(f"切替失敗、復旧起動も失敗: {rollback_error}")
            raise RuntimeError("新バージョンの起動確認に失敗。旧バージョンへ戻しました")
    finally:
        temp_link.unlink(missing_ok=True)


def _wait_for_healthy_app() -> None:
    import urllib.request
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen("http://127.0.0.1:8000/", timeout=3) as response:
                if response.status == 200:
                    return
        except Exception:
            pass
        time.sleep(2)
    raise RuntimeError("アプリのHTTP 200を45秒以内に確認できませんでした")

def deploy() -> None:
    try:
        _write_status("running", "GitHubから更新を取得中")
        time.sleep(2)  # webhookの応答を返してから、現在のアプリを停止する。
        if not REPOSITORY.is_dir():
            raise RuntimeError("GitHub連携フォルダ /opt/boat-ai-lab/x がありません")

        before = _run(["git", "-C", str(REPOSITORY), "rev-parse", "HEAD"]).strip()
        _run(["git", "-C", str(REPOSITORY), "pull", "--ff-only"])
        changed = _run(["git", "-C", str(REPOSITORY), "diff", "--name-only", before, "HEAD"]).splitlines()
        archives = [REPOSITORY / name for name in changed if name.lower().endswith(".zip")]
        archives = [path for path in archives if path.is_file()]
        if not archives:
            _write_status("skipped", "今回のGitHub更新にはZIPがありません")
            return

        archive = archives[-1]
        safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in archive.stem)[:80]
        release = RELEASES / f"{time.strftime('%Y%m%d-%H%M%S')}_{safe_name}"
        _safe_extract(archive, release)
        project = _project_directory(release)

        _write_status("running", "必要な部品を準備中")
        _run([sys.executable, "-m", "venv", ".venv"], cwd=project)
        python = project / ".venv" / "bin" / "python"
        _run([str(python), "-m", "pip", "install", "-r", "requirements.txt"], cwd=project)

        _write_status("running", "systemdで最新版に切り替え中")
        _switch_release(project)
        _write_status("success", f"更新完了：{archive.name}")
    except Exception as exc:
        _write_status("error", str(exc))
        with LOG_FILE.open("a", encoding="utf-8") as log:
            log.write(f"ERROR: {exc}\n")
    finally:
        LOCK_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    if "--deploy" in sys.argv:
        deploy()
