import sqlite3, json, contextlib
from review_results import build_review
class FakeDB:
    def __init__(self):
        self.con=sqlite3.connect(':memory:')
        self.con.row_factory=sqlite3.Row
        self.query_count=0
        self.con.executescript("""
        CREATE TABLE predictions(date TEXT,jcd TEXT,rno INTEGER,main_picks TEXT,value_picks TEXT,leaks TEXT,source_snapshot TEXT,created_at TEXT);
        CREATE TABLE race_results(date TEXT,jcd TEXT,rno INTEGER,trifecta TEXT,payout_yen INTEGER,odds REAL,kimarite TEXT,payload TEXT,updated_at TEXT);
        """)
        snap={"pre_prediction":{"strategies":{"base":{"picks":["1-2-3"]}}},"pre_saved_at":"2026-10-12T00:00:00+09:00","generated_at":"2026-10-12T00:00:00+09:00"}
        self.con.execute("INSERT INTO predictions VALUES(?,?,?,?,?,?,?,?)",("20261012","01",1,"[]","[]","[]",json.dumps(snap),"2026-10-12T00:00:00+09:00"))
        self.con.execute("INSERT INTO race_results VALUES(?,?,?,?,?,?,?,?,?)",("20261012","01",1,"1-2-3",1200,12.0,"逃げ",json.dumps({"finishers":[1,2,3],"result_confirmed":True}),"2026-10-12T12:00:00+09:00"))
    @contextlib.contextmanager
    def connect(self):
        outer=self
        class Conn:
            def __enter__(self): return self
            def __exit__(self,*a): pass
            def execute(self,*a): outer.query_count+=1; return outer.con.execute(*a)
        yield Conn()
    def get_day_schedule(self,date): return {"01":[{"rno":1,"deadline":"12:00"}]}
db=FakeDB()
out=build_review(db,"20261012",[{"code":"01","name":"Test Venue"}])
assert len(out["venues"])==1
r=out["venues"][0]["races"][0]
assert r["actual"]=="1-2-3" and r["payout_yen"]==1200 and r["result_confirmed"]
assert r["finishers"]==[1,2,3]
assert db.query_count==2, db.query_count
print("PASS AI results batch reads: predictions/results preserved; only 2 SQL queries")
