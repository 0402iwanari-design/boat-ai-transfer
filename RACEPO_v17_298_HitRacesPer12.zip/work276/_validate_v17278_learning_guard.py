from pathlib import Path
root=Path(__file__).parent
src=(root/'prediction_learning.py').read_text()
app=(root/'app.py').read_text()
html=(root/'static/index.html').read_text()
assert 'candidate_score_adjustments' in src
assert '"score_adjustments": {}' in src
assert '"coverage_bonus": 0' in src
assert 'learning_validation_required' in src
assert '時系列バックテストで回収率改善を確認するまで' in src
assert 'version="1.0.278"' in app
assert '"version": "1.0.278"' in app
assert 'v17.278 学習補正検証前停止版' in html
print('v17.278 learning guard PASS')
