
const fs=require('fs'), vm=require('vm');
const html=fs.readFileSync('static/index.html','utf8');
const start=html.indexOf('let raceOpenToken=0;\nasync function openRace(r){');
const end=html.indexOf('\nasync function refresh(){', start);
if(start<0||end<0) throw Error('openRace function not found');
const chunk=html.slice(start,end);
const pending={};
const calls={render:[],tabs:[],get:[],show:[],quick:0};
const els={sync:{textContent:''},detailTitle:{textContent:''},detailDeadline:{textContent:''}};
const ctx={
 S:{rno:null,date:'20261012',venue:{code:'01',name:'Test',races:[{rno:1,deadline:'12:00'},{rno:2,deadline:'12:30'}]},cache:new Map([['01-1',{race:{racers:[1,2,3,4,5,6]},before:null}] ]),activeTab:'racelist'},
 $:id=>els[id]||(els[id]={textContent:'',classList:{toggle(){}}}),
 show:x=>calls.show.push(x),renderRaceQuickNav:()=>calls.quick++,render:d=>calls.render.push(d),
 tab:x=>calls.tabs.push(x),get:u=>{calls.get.push(u);return new Promise(resolve=>pending[u]=resolve)},
 console,Date,Number,String,Promise
};
vm.createContext(ctx);
vm.runInContext(chunk+`\nthis.openRace=openRace;`,ctx);
(async()=>{
 const p1=ctx.openRace(1); await Promise.resolve();
 if(calls.render.length!==1||calls.tabs.length!==1||calls.get.length!==1) throw Error('cached render/tab/request did not happen immediately');
 const p2=ctx.openRace(2); await Promise.resolve();
 pending['/api/cached/20261012/01/1']({race:{marker:'stale'}});
 await p1;
 if(calls.render.some(x=>x?.race?.marker==='stale')) throw Error('stale response overwrote selected race');
 pending['/api/cached/20261012/01/2']({race:{marker:'current'}});
 await p2;
 if(!calls.render.some(x=>x?.race?.marker==='current')) throw Error('current response not rendered');
 console.log('PASS cached render and tab before fetch; stale race response ignored; current response rendered');
})().catch(e=>{console.error(e);process.exit(1)});
