from pathlib import Path
root=Path(__file__).parent
app=(root/'app.py').read_text(encoding='utf-8')
html=(root/'static/index.html').read_text(encoding='utf-8')
review=(root/'review_results.py').read_text(encoding='utf-8')
assert 'version="1.0.279"' in app and '"version": "1.0.279"' in app
assert 'v17.279 レース画面即時表示・安全なバックグラウンド更新版' in html
assert 'raceOpenToken' in html and '保存済みデータを表示中・最新情報を確認しています' in html
assert 'predictions = {}' in review and 'results = {}' in review
assert 'db.get_prediction(date,code,rno)' not in review
assert 'db.get_result_for_race_db(date,code,rno)' not in review
print('PASS v17.279 release guards')
