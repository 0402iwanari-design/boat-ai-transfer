"""One-time private admin setup, run in server console; never send passwords in chat."""
import getpass
import admin_auth


def main():
    print("レースポ 管理者ログイン設定（パスワードは画面に表示されません）")
    if admin_auth.config():
        response = input("設定済みの管理者ID・パスワードを変更しますか？ [yes/NO]: ")
        if response.strip().lower() != "yes":
            print("変更せず終了しました")
            return
    username = input("管理者ID（半角英数3文字以上）: ").strip()
    password = getpass.getpass("パスワード（12文字以上）: ")
    verify = getpass.getpass("パスワードをもう一度: ")
    if password != verify:
        print("パスワードが一致しません。何も変更していません")
        return
    admin_auth.write_config(username, password)
    print("管理者設定を保存しました。ブラウザの『管理者ログイン』から入れます")


if __name__ == "__main__":
    main()
