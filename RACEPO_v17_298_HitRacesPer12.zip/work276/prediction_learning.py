"""Result-based prediction review and bounded, leakage-safe feedback."""
from collections import Counter
from review_results import build_review


def _lane_rank(pred, actual):
    snap = (pred or {}).get("source_snapshot") or {}
    ranks = []
    for key, label in (("pre_prediction", "事前"), ("post_prediction", "直前")):
        stage = snap.get(key) or {}
        scores = stage.get("lane_scores") or {}
        ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
        rank = next((i + 1 for i, x in enumerate(ordered) if int(x.get("lane") or 0) == int(actual)), None)
        if rank:
            ranks.append({"stage": label, "rank": rank})
    return ranks


def analyze_race(db, date, code, venue, race):
    actual = race.get("actual")
    if not actual:
        return None
    pred = db.get_prediction(date, code, race["rno"]) or {}
    hits = race.get("ai_hits") or []
    first = int(actual.split("-")[0])
    ranks = _lane_rank(pred, first)
    best_rank = min((x["rank"] for x in ranks), default=None)
    evaluated = [x for x in race.get("stages", []) if x.get("evaluated")]
    all_picks = {p for x in evaluated for p in x.get("picks", [])}
    if hits:
        category = "的中"
        analysis = "確定出目を締切前の買い目に含められました。"
        improvement = "的中した評価経路を記録し、同じ条件で再現できるか継続確認します。"
    elif actual in all_picks:
        category = "買い目選択漏れ"
        analysis = "確定出目は候補内にありましたが、最終的な買い方から漏れました。"
        improvement = "候補確率が接近したレースでは合成オッズ条件を守りながら買い目範囲を広げます。"
    elif best_rank is not None and best_rank <= 2:
        category = "相手構成漏れ"
        analysis = "1着艇は上位評価できていましたが、2・3着の組み合わせを拾えませんでした。"
        improvement = "1着率が低く3連対率が高い選手を、2・3着付け候補として優先的に残します。"
    else:
        category = "1着評価不足"
        analysis = f"実際の1着・{first}号艇を十分高く評価できませんでした。"
        improvement = "実際の1着艇のコース1着率、ST、チルト、当日傾向と決まり手を再評価します。"
    kimarite = race.get("kimarite") or "不明"
    lesson = {
        "逃げ": "1コース本人実績と当日イン状況の重みを再確認",
        "差し": "2コース差しと内側のST差を再確認",
        "まくり": "外側のST・チルト・攻め実績を再確認",
        "まくり差し": "3〜6コースの攻め足と展開相手を再確認",
    }.get(kimarite, "着順別評価と組み合わせ範囲を再確認")
    return {
        "date": date, "jcd": code, "venue": venue, "rno": race["rno"],
        "actual": actual, "odds": race.get("result_odds"),
        "popularity": race.get("popularity"), "kimarite": kimarite,
        "hit": bool(hits), "hit_methods": hits, "category": category,
        "analysis": analysis, "reflection": analysis,
        "improvement": improvement, "lesson": lesson, "first_lane": first,
        "first_lane_ranks": ranks, "evaluated_methods": len(evaluated),
    }


def build_learning_report(db, date, venues):
    review = build_review(db, date, venues)
    rows = []
    for venue in review.get("venues", []):
        for race in venue.get("races", []):
            item = analyze_race(db, date, venue["code"], venue["name"], race)
            if item:
                rows.append(item)
    categories = Counter(x["category"] for x in rows)
    misses = [x for x in rows if not x["hit"]]
    today_reflections = [
        {"venue": x["venue"], "rno": x["rno"], "actual": x["actual"],
         "reflection": x["reflection"], "improvement": x["improvement"],
         "kimarite": x["kimarite"]}
        for x in misses
    ]
    return {
        "date": date, "summary": {"analyzed": len(rows), "hits": len(rows)-len(misses),
        "misses": len(misses), "categories": dict(categories)},
        "records": sorted(rows, key=lambda x: (x["jcd"], x["rno"])),
        "today_reflections": today_reflections,
        "policy": "予想時点より前に確定した結果だけを使い、十分な件数がある傾向のみ小幅補正します。",
    }


def feedback_before(db, date, jcd, rno):
    """Aggregate only earlier confirmed races. Never reads a future result."""
    with db.connect() as con:
        rows = con.execute("""
          SELECT rr.date,rr.jcd,rr.rno,rr.trifecta,rr.kimarite,p.source_snapshot,pr.review_json
          FROM race_results rr JOIN predictions p
            ON p.date=rr.date AND p.jcd=rr.jcd AND p.rno=rr.rno
          LEFT JOIN prediction_result_reviews pr
            ON pr.date=rr.date AND pr.jcd=rr.jcd AND pr.rno=rr.rno
          WHERE rr.trifecta IS NOT NULL AND
            (rr.date < ? OR (rr.date=? AND rr.jcd=? AND rr.rno < ?))
          ORDER BY rr.date DESC,rr.rno DESC LIMIT 120
        """, (date,date,str(jcd).zfill(2),int(rno))).fetchall()
    misses = Counter(); selection = 0; total = 0; miss_total = 0; source_dates = set()
    reviewed_count = 0; review_selection_gap = 0; review_categories = Counter()
    import json, re
    for row in rows:
        nums = re.findall(r"[1-6]", str(row["trifecta"] or ""))
        if len(nums) != 3: continue
        total += 1; first = int(nums[0]); source_dates.add(str(row["date"]))
        try: snap = json.loads(row["source_snapshot"] or "{}")
        except Exception: snap = {}
        try: review = json.loads(row["review_json"] or "{}") if row["review_json"] else {}
        except Exception: review = {}
        if review.get("status") == "complete":
            reviewed_count += 1
            cat = str(review.get("category") or "").strip()
            if cat:
                review_categories[cat] += 1
            if cat in {"買い目選択漏れ", "相手構成漏れ"}:
                review_selection_gap += 1
        stage = snap.get("post_prediction") or snap.get("pre_prediction") or {}
        picks = {str(x.get("combo") if isinstance(x,dict) else x) for x in stage.get("picks", [])}
        if "-".join(nums) not in picks:
            miss_total += 1
            scores = stage.get("lane_scores") or {}
            ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
            rank = next((i+1 for i,x in enumerate(ordered) if int(x.get("lane") or 0)==first), 9)
            if rank <= 2: selection += 1
            else: misses[first] += 1
    effective_selection_gap = max(selection, review_selection_gap)
    base = {
        "sample_size": total, "miss_count": miss_total,
        "selection_gap_count": effective_selection_gap,
        "reviewed_count": reviewed_count,
        "review_categories": dict(review_categories),
        "learning_sources": ["確定結果", "締切前予想スナップショット", "予想・結果詳細履歴"],
        "ranking_miss_by_lane": dict(misses),
        "source_date_from": min(source_dates) if source_dates else None,
        "source_date_to": max(source_dates) if source_dates else None,
    }
    if total < 8:
        return {**base, "score_adjustments": {}, "coverage_bonus": 0,
                "active": False, "inactive_reason": "確定済みの照合対象が8レース未満のため、過学習防止で補正を保留"}
    # v17.256: require repeated evidence before changing a lane score.
    # One upset must not permanently boost a lane. Shrink corrections strongly
    # until the sample grows, and keep coverage expansion bounded.
    shrink = min(1.0, max(0.35, total / 40.0))
    adjustments = {
        lane: round(min(0.8, count / total * 3.0 * shrink), 2)
        for lane,count in misses.items() if count >= 2
    }
    coverage_bonus = round(min(.07, effective_selection_gap / total * .10), 3)
    improvements = []
    for lane, value in sorted(adjustments.items()):
        improvements.append(f"{lane}号艇の1着評価を+{value:.2f}点補正")
    if coverage_bonus:
        improvements.append(f"相手・買い目の累積確率範囲を+{coverage_bonus*100:.1f}%拡張")
    # v17.278: outcome counts are diagnostic evidence, not proof that a
    # score change improves future ROI. Until a chronological out-of-sample
    # backtest compares the candidate against the unchanged model, do not let
    # these coarse, cross-venue miss counts alter live lane scores or coverage.
    # Keep candidate adjustments visible for audit, but disable their use.
    return {**base,
            "candidate_score_adjustments": adjustments,
            "candidate_coverage_bonus": coverage_bonus,
            "score_adjustments": {},
            "coverage_bonus": 0,
            "active": False,
            "applied_improvements": [],
            "inactive_reason": "候補傾向は検出しましたが、時系列バックテストで回収率改善を確認するまで予想点へ自動適用しません",
            "learning_validation_required": True}


def build_detailed_review(db, date, jcd, rno, venues):
    """Create and persist a result review. Never changes model weights here."""
    review = build_review(db, date, venues)
    venue = next((v for v in review.get("venues", []) if str(v.get("code")).zfill(2)==str(jcd).zfill(2)), None)
    race = next((r for r in (venue or {}).get("races", []) if int(r.get("rno") or 0)==int(rno)), None)
    if not venue or not race or not race.get("result_confirmed"):
        return {"status":"waiting", "message":"レース結果確定後に分析します。"}
    base = analyze_race(db, date, str(jcd).zfill(2), venue.get("name"), race) or {}
    pred = db.get_prediction(date, str(jcd).zfill(2), int(rno)) or {}
    snap = pred.get("source_snapshot") or {}
    stage = snap.get("post_prediction") or snap.get("pre_prediction") or {}
    actual = str(race.get("actual") or "")
    actual_first = int(actual.split("-")[0]) if actual and actual[0].isdigit() else None
    scores = stage.get("lane_scores") or {}
    ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
    predicted_first = int(ordered[0].get("lane")) if ordered else None
    strengths=[]; weaknesses=[]; candidates=[]
    if actual_first and predicted_first == actual_first:
        strengths.append(f"1着の{actual_first}号艇を最上位評価できていました。")
    elif actual_first:
        weaknesses.append(f"実際の1着{actual_first}号艇を1着最上位にできませんでした。")
        candidates.append(f"{venue.get('name')}で{actual_first}号艇を低く見積もった条件を場別に蓄積して再検証")
    all_picks=[]
    for st in race.get("stages",[]):
        if not st.get("evaluated"): continue
        all_picks += list(st.get("picks") or [])
    if actual in set(all_picks):
        strengths.append("確定出目そのものは締切前の候補に残せていました。")
        if not race.get("ai_hits"):
            weaknesses.append("候補にはあったものの、最終購入対象として残せませんでした。")
            candidates.append("期待値閾値・買い目削減処理で的中候補を落としたケースとして集計")
    elif actual:
        weaknesses.append("確定出目を締切前の買い目候補に含められませんでした。")
    kimarite=race.get("kimarite") or "不明"
    if kimarite != "不明": candidates.append(f"決まり手「{kimarite}」時の評価誤差を場別・風条件別に集計")
    if race.get("ai_hits"):
        strengths.append("購入判断は的中につながりました。")
    else:
        weaknesses.append("購入した予想は払戻につながりませんでした。" if all_picks else "このレースは購入対象外または予想未保存でした。")
    # A single race is evidence, not an automatic weight change.
    result={**base, "status":"complete", "good_points":strengths or ["今回の1レースだけでは明確な成功要因を断定しません。"],
            "bad_points":weaknesses or ["今回の1レースだけでは明確な失敗要因を断定しません。"],
            "bet_review": base.get("analysis") or "買い目と結果を照合しました。",
            "value_review":"予想時点の確率・オッズ・購入判断を保存データとして累積し、同条件の標本が増えてから期待値判断を検証します。",
            "learning_candidates":candidates or ["同条件のレースを追加蓄積してから学習候補を判定"],
            "learning_policy":"このレース単独では重みを変更しません。全場共通・場別・水面条件別に十分な件数を集め、バックテストで改善を確認した候補だけを学習対象にします。",
            "venue_learning_key":str(jcd).zfill(2)}
    db.save_prediction_result_review(date,jcd,rno,result)
    return result
