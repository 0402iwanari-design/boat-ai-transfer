"""Regression check for official no-sample course rows and bulk retries."""
import tempfile
from pathlib import Path
from db import BoatDB, _official_split_complete
from boat_source import BoatRaceSource

DATE = '20261014'

def payload(reg, missing_sample=False, missing_split=False):
    rows=[]
    for course in range(1,7):
        no_sample=missing_sample and course in (5,6)
        parts=(None,None,None) if no_sample or (missing_split and course == 2) else (20.0,20.0,20.0)
        rows.append({'course':course,'trio_rate':None if no_sample else 60.0,
                     'first_rate':parts[0],'second_rate':parts[1],'third_rate':parts[2], 'avg_st':None if no_sample else .15})
    return {'registration_no':reg,'name':reg,'course_stats_version':4,
            'course_breakdown_version':5,'course_breakdown_complete':not missing_split,
            'course_stats':rows,'profile':{'name':reg}}

with tempfile.TemporaryDirectory() as tmp:
    db=BoatDB(str(Path(tmp)/'racer.db'))
    racers=[{'registration_no':str(5000+i),'name':str(5000+i)} for i in range(3)]
    db.save_basic_race_atomic(DATE,'12',1,{'racers':racers},'12:00','test')
    db.save_official_racer_search_data(DATE,payload('5000',missing_sample=True))
    db.save_official_racer_search_data(DATE,payload('5001',missing_split=True))
    pending=db.official_racer_collection_pending(DATE)
    assert {r['registration_no'] for r in pending}=={'5001','5002'},pending
    assert _official_split_complete(payload('5000',missing_sample=True))
    assert not _official_split_complete(payload('5001',missing_split=True))
    assert db.get_racer_public_data('5000')['official_data']['data']['course_stats'][5]['first_rate'] is None
    db.mark_official_racer_collection(DATE,'5000',status='complete',verified=True)
    assert {r['registration_no'] for r in db.official_racer_collection_pending(DATE)} == {'5001','5002'}
    # A second polling pass must not turn a valid '-' course back into pending.
    assert not any(r['registration_no']=='5000' for r in db.official_racer_collection_pending(DATE))
    src=BoatRaceSource.__new__(BoatRaceSource)
    src.db=db
    src._racer_course_stats_cache={}
    fresh={'official_data':{'data':payload('5000',missing_sample=True)}}
    assert not src._course_breakdown_needs_repair(fresh), 'no-sample courses must not trigger background repair'
    broken={'official_data':{'data':payload('5001',missing_split=True)}}
    assert src._course_breakdown_needs_repair(broken), 'actual missing splits still trigger repair'
    assert not _official_split_complete({'course_stats':[]})
print('PASS: official no-sample courses are reused; truly missing splits are retried; no synthetic 0% values')
