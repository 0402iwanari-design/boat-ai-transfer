"""Read-only view of historically saved bet recommendations.

Metrics are supplied by review_statistics.build_statistics, so the UI does not
recalculate payouts, modify saved picks, or rewrite database records.
"""
from html import escape


def render_skip_analysis() -> str:
    return r'''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>レースポ 管理者｜購入見送り検証</title>
<style>
:root{color-scheme:dark}body{font-family:system-ui,sans-serif;background:#0e1727;color:#eef4ff;margin:0;padding:18px;line-height:1.6}
main{max-width:1050px;margin:auto}h1{font-size:1.35rem}h2{font-size:1.08rem;margin-top:2rem}
.note{color:#b8c6d9}.box{background:#17243a;padding:14px;border-radius:10px;margin:12px 0}
.tablewrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:780px}th,td{border-bottom:1px solid #42516a;padding:9px 8px;text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left}
.good{color:#7ce6b3}.bad{color:#ffa7a7}input,button{font-size:1rem;padding:8px;background:#243854;color:white;border:1px solid #8299b9;border-radius:7px}button{cursor:pointer}
</style><style>
/* v17.293 desktop comparison view */
@media(min-width:901px){
body{background:radial-gradient(ellipse at 90% 0%,#15417355,transparent 45%),#071322;color:#edf4ff;padding:30px 36px}
main{max-width:1330px}h1{font-size:26px;letter-spacing:.01em}h2{margin:0 0 15px;font-size:19px}
.note{color:#b8cee6}.box{background:linear-gradient(160deg,#142941,#0d2036);border:1px solid #355574;border-radius:16px;padding:22px 25px;margin:20px 0;box-shadow:0 10px 24px #0003}
.tablewrap{border:1px solid #335371;border-radius:12px;scrollbar-color:#537c9f #102035}
table{font-variant-numeric:tabular-nums}th{background:#1b3958;color:#c5ddf4}th,td{border-color:#314e69;padding:13px 12px}tbody tr:nth-child(even){background:#172f475d}tbody tr:hover{background:#22528158}
input,button{border-radius:10px;background:#112840;border-color:#456d95;padding:10px 13px}button{background:linear-gradient(120deg,#1c79cf,#14549a);border-color:#4da7eb;min-width:100px}button:hover{filter:brightness(1.15)}
.good{color:#52d9a9}.bad{color:#ff929c}button:focus-visible,input:focus-visible{outline:2px solid #e6c476;outline-offset:2px}
}
</style><style id="racepo-skip-type-v295">
@media(min-width:901px){
body{font-family:"Yu Gothic UI","Hiragino Kaku Gothic ProN",Meiryo,system-ui,sans-serif;color:#e8f2ff;letter-spacing:.018em}
h1,h2{font-family:"Yu Mincho","Hiragino Mincho ProN","Noto Serif JP",Georgia,serif;font-weight:700;letter-spacing:.075em;color:#f3e6ce}
h1{font-size:29px}h2{font-size:20px}
.note{color:#b7cce0;line-height:1.85}
label,#state{color:#c0d8ed}button{font-weight:750;letter-spacing:.05em}
th{color:#c8dff2;letter-spacing:.045em;font-weight:700}td{color:#e6f1fd;font-variant-numeric:tabular-nums}
.good{color:#83e5c7}.bad{color:#f5aab1}
}
</style><style id="racepo-skip-refined-v297">
@media (min-width:901px){
:root{--r-sans:"Yu Gothic UI","Hiragino Kaku Gothic ProN","Meiryo",system-ui,sans-serif;--r-serif:"Yu Mincho","Hiragino Mincho ProN","Noto Serif JP",serif}
body,table,th,td,button,input,label,.note,#state{font-family:var(--r-sans)!important;-webkit-font-smoothing:antialiased}
body{background:radial-gradient(ellipse at 83% -10%,#145d7b54,transparent 56%),linear-gradient(145deg,#051422,#0d293d 52%,#061526)!important;color:#dce9ee!important}
h1,h2{font-family:var(--r-serif)!important;color:#f3e7d2!important;letter-spacing:.07em!important}
h1{border-left:3px solid #d8b879;padding-left:17px}
.box{background:linear-gradient(135deg,#13364a,#0a2134 80%)!important;border-color:#4a7583!important;box-shadow:inset 0 1px #ffffff16,0 12px 30px #0005!important}
th{color:#e6c995!important;background:#193d52!important;font:750 12px/1.5 var(--r-sans)!important}
td{color:#e2eff2!important;font:650 13px/1.6 var(--r-sans)!important;font-variant-numeric:tabular-nums}
button{background:linear-gradient(115deg,#e8c989,#cda457)!important;border-color:#f5d99b!important;color:#091c30!important;font-size:13px!important;font-weight:800!important}
.note{color:#b9cfdb!important}
}
</style></head><body><main><h1>レースポ｜購入見送りの過去成績検証（管理者専用）</h1>
<p class="note">既存の保存済みAI予想を使い、同じ期間・同じ予想モードの「全レース購入」と「購入推奨だけ」を比較します。買い目・収支・AIロジックは変更しません。</p>
<div class="box"><label>集計終了日 <input id="day" type="date"></label> <button id="go">集計</button><span id="state" role="status"></span></div>
<div id="output"></div>
<p class="note">注意：推奨判定が当時の保存時点で確定していたかを完全には検証できません。これは過去の参考比較であり、将来の利益を保証しません。購入レースが少ない場合や、古い履歴の一部には記録条件による偏りがあります。</p>
</main><script>
const $=id=>document.getElementById(id);
const esc=s=>String(s??'—').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const yen=n=>n==null?'—':Math.round(n).toLocaleString('ja-JP')+'円';
const pct=n=>n==null?'—':Number(n).toFixed(1)+'%';
const modes=[['PRE_hit','事前・的中率重視'],['PRE_return','事前・回収率重視'],['POST_hit','直前・的中率重視'],['POST_return','直前・回収率重視']];
const periods=['today','1m','6m','1y'];
function table(period){const m=period.metrics||{};let html='<div class="box"><h2>'+esc(period.label)+'</h2><div class="tablewrap"><table><thead><tr><th>モード</th><th>区分</th><th>購入R</th><th>的中R</th><th>的中率</th><th>投資</th><th>払戻</th><th>収支</th><th>回収率</th></tr></thead><tbody>';
for(const [key,label] of modes){for(const [prefix,type] of [['','全レース'],['RECOMMENDED_','購入推奨のみ']]){
const a=m[prefix+key]||{};const profit=(a.return_yen??0)-(a.stake_yen??0);const cls=profit>=0?'good':'bad';
html+='<tr><td>'+esc(label)+'</td><td>'+esc(type)+'</td><td>'+(a.races??0)+'</td><td>'+(a.hits??0)+'</td><td>'+pct(a.hit_rate)+'</td><td>'+yen(a.stake_yen)+'</td><td>'+yen(a.return_yen)+'</td><td class="'+cls+'">'+yen(profit)+'</td><td>'+pct(a.return_rate)+'</td></tr>';
}}return html+'</tbody></table></div></div>';}
async function run(){const date=$('day').value.replaceAll('-','');if(!/^\d{8}$/.test(date)){ $('state').textContent='日付を確認してください';return;}
$('state').textContent=' 集計中…';$('output').textContent='';
try{const resp=await fetch('/api/ai-statistics/'+date,{credentials:'same-origin'});
if(resp.status===401||resp.status===403){$('state').textContent=' 管理者ログインが必要です';return;}
if(!resp.ok)throw Error('HTTP '+resp.status);const data=await resp.json();
$('output').innerHTML=(data.overall_periods||[]).filter(p=>periods.includes(p.key)).map(table).join('');$('state').textContent=' 集計完了';
}catch(e){$('state').textContent=' 取得失敗：'+String(e.message||e);}}
$('day').value=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
$('go').addEventListener('click',run);run();
</script></body></html>'''
