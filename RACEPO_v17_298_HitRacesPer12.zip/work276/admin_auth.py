"""Administrator session authentication, independent of race/collector data."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from pathlib import Path

from fastapi import HTTPException, Request

CONFIG = Path(os.environ.get("RACEPO_ADMIN_CONFIG", "/opt/boat-ai-lab/admin_auth.json"))
COOKIE = "racepo_admin_session"
SESSION_SECONDS = 60 * 60 * 24 * 7


def config():
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        if not all(data.get(k) for k in ("username", "salt", "hash", "secret")):
            return None
        return data
    except (OSError, ValueError, TypeError):
        return None


def hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 390000).hex()


def write_config(username: str, password: str):
    if len(username) < 3 or len(username) > 64 or not username.isascii() or not all(c.isalnum() or c in "_-" for c in username):
        raise ValueError("IDは半角英数・_・- の3～64文字で設定してください")
    if len(password) < 12 or len(password) > 256:
        raise ValueError("パスワードは12～256文字で設定してください")
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    salt = secrets.token_bytes(24)
    payload = {"username": username, "salt": salt.hex(), "hash": hash_password(password, salt), "secret": secrets.token_hex(32)}
    path = CONFIG.with_name(CONFIG.name + ".new")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f)
    except BaseException:
        try: path.unlink()
        except OSError: pass
        raise
    os.chmod(path, 0o600)
    os.replace(path, CONFIG)
    os.chmod(CONFIG, 0o600)


def authenticate(username: str, password: str) -> bool:
    data = config()
    if not data or not hmac.compare_digest(username, data["username"]):
        # Do not leak whether the ID or password was wrong.
        return False
    try:
        return hmac.compare_digest(hash_password(password, bytes.fromhex(data["salt"])), data["hash"])
    except (ValueError, TypeError):
        return False


def issue_session() -> str:
    data = config()
    if not data: raise RuntimeError("管理者の初期設定が必要です")
    expiry = int(time.time()) + SESSION_SECONDS
    msg = f"{data['username']}:{expiry}".encode("utf-8")
    signature = hmac.new(bytes.fromhex(data["secret"]), msg, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(msg + b"." + signature).decode("ascii")


def is_admin(request: Request) -> bool:
    data = config()
    token = request.cookies.get(COOKIE)
    if not data or not token: return False
    try:
        raw = base64.urlsafe_b64decode(token.encode("ascii"))
        msg, signature = raw.rsplit(b".", 1)
        expected = hmac.new(bytes.fromhex(data["secret"]), msg, hashlib.sha256).digest()
        if not hmac.compare_digest(signature, expected): return False
        username, expires = msg.decode("utf-8").rsplit(":", 1)
        return hmac.compare_digest(username, data["username"]) and int(expires) > time.time()
    except (ValueError, TypeError, UnicodeDecodeError):
        return False


def require_admin(request: Request):
    if not is_admin(request):
        raise HTTPException(status_code=401, detail="管理者ログインが必要です")
