BOAT AI Lab v17.257

## v17.257
- AI予想の各出目に、保存済みオッズが反映されたら「xx.x倍」を表示。
- 的中率重視/回収率重視の各カードに合成オッズを表示。
- 各出目に「払戻 = 出目オッズ × AI配分額」を表示。
- オッズ未取得時は従来どおり「オッズ反映待ち」。
- オッズ収集タイミングは既存仕様を維持：08:00以降、T-15〜T-5は60秒、T-5〜締切は30秒、締切1分後に最終取得。

BOAT AI Lab v17.256

主修正: 年別履歴遅延補完
- boatrace-db.net の一時通信障害を、当日出走選手の初回構築を止める致命エラーとして扱わない。
- 取得済み・公式確認済みの履歴はそのまま利用し、不足する年別履歴だけを「年別補完待ち」に分離。
- v17.251以前で34人のように止まっていた一時通信障害行は、起動時に自動で foreground 完了 + 補完待ちへ移行。
- 外部年別履歴が復旧したら1人ずつバックグラウンドで補完し、成功後に補完待ちを解除。
- 未取得データを推測・捏造して保存することはしない。

継承:
- 事前出目先行表示 / オッズ反映待ち
- 直前AI T-15
- 的中率重視 5000円配分、最低100円
- 出走表4段表示、ST数字のみ
- 欠場保持、オッズ小数1桁、詳細履歴学習


## v17.254
- 出走表の「年齢・体重・支部・出身」を1列3段表示に変更。
- 1段目: 年齢 + 体重、2段目: 支部、3段目: 出身。
- スマホでも6選手行の高さを維持し、横幅を抑えつつ文字を読みやすく表示。


## v17.255
- 回収率・収支集計を均等配分ではなく、AI予想に保存された各買い目の実際の stake で計算。
- 的中時払戻 = 的中買い目の保存 stake × 確定オッズ。
- 事前/直前 × 的中率重視/回収率重視の review_statistics を同一ルールに統一。
- 日次まとめも保存 stake を使用。現行 strategy key (hit/return) と旧互換 key の両方に対応。
- 古い履歴で stake が保存されていない場合のみ legacy_equal_split として従来互換の均等配分を使用。

## v17.256
AI prediction calibration/reweighting update.
- Prioritizes current-series form and current-series ST over motor/boat and duplicated historical signals.
- Calibrates trifecta probabilities to reduce overconfidence.
- Uses bounded market-implied probability shrinkage only when a sufficiently complete odds board is present (PRE 30%, POST 20%).
- Makes return-rate edge screening more conservative after calibration.
- Makes result-learning corrections slower and less reactive to one-off upsets.
- Keeps v17.255 exact saved-stake statistics and all v17.254 UI/history fixes.
