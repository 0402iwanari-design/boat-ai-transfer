from __future__ import annotations

import itertools
import math
import unicodedata
import re
from datetime import datetime, timezone, timedelta

JST = timezone(timedelta(hours=9), name="JST")

LANE_BASE = {1: 1.00, 2: 0.74, 3: 0.69, 4: 0.63, 5: 0.52, 6: 0.44}
CLASS_SCORE = {"A1": 1.00, "A2": 0.78, "B1": 0.54, "B2": 0.35}

# Conservative frame priors.  Racer-specific official course rates, current
# series form, equipment, exhibition and same-day venue results update these;
# they are never used as the prediction by themselves.
POSITION_PRIOR = {
    1: {1: .50, 2: .16, 3: .13, 4: .11, 5: .06, 6: .04},
    2: {1: .22, 2: .24, 3: .20, 4: .16, 5: .11, 6: .07},
    3: {1: .15, 2: .20, 3: .21, 4: .19, 5: .15, 6: .10},
}

MODEL_SOURCES = [
    {
        "label": "BOAT RACE公式・レーサー別コース成績",
        "url": "https://www.boatrace.jp/owpc/pc/data/racersearch/course",
        "used_for": "コース別1着率・2着率・3着率・平均ST",
    },
    {
        "label": "BOAT RACE公式・出走表",
        "url": "https://www.boatrace.jp/owpc/pc/race/racelist",
        "used_for": "全国・当地・モーター・ボート・節間成績",
    },
    {
        "label": "BOAT RACE GUIDE・スタート展示",
        "url": "https://www.boatrace.jp/owpc/pc/extra/enjoy/guide/level1/l1_01_03_02.html",
        "used_for": "直前の進入コース・スタート判断",
    },
    {
        "label": "BOAT RACE GUIDE・周回展示",
        "url": "https://www.boatrace.jp/owpc/pc/extra/enjoy/guide/level1/l1_01_03_03.html",
        "used_for": "旋回・直線の直前評価",
    },
]

COLLECTION_CATALOG = [
    ("meeting_results", "節間成績"),
    ("national_lane_results", "全国成績（当該枠/コースデータ優先）"),
    ("local_lane_results", "当地同枠成績（保存済み公式結果から集計）"),
    ("course_quinella_rate", "選手コース別2連対率（保存済み公式結果から集計）"),
    ("motor", "モーター成績"),
    ("boat", "ボート成績"),
    ("avg_st", "平均ST"),
    ("exhibition_time", "展示タイム"),
    ("tilt", "チルト"),
    ("start_exhibition_st", "スタート展示ST"),
    ("start_entry", "スタート展示進入/STタイミング"),
    ("original_exhibition", "オリジナル展示"),
    ("wind_speed", "風速"),
    ("wind_direction", "風向"),
    ("tide", "潮（満潮・干潮等）"),
    ("wave_height", "波高"),
    ("comments", "選手コメント"),
    ("venue_material", "場特性資料"),
    ("in_escape_rate", "イン逃げ率 / 1コース1着率"),
    ("winning_method", "決まり手傾向"),
    ("popular_combos", "出やすい出目"),
    ("same_day_venue_results", "当日の同場で確定済みの前レース結果"),
    ("odds", "3連単オッズ"),
]


def _num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r"-?\d+(?:\.\d+)?", str(v).replace(",", "").replace("%", ""))
    return float(m.group()) if m else None


def _first(d, *keys):
    if not isinstance(d, dict):
        return None
    for k in keys:
        if d.get(k) not in (None, ""):
            return d.get(k)
    return None


def _lane_map(rows):
    out = {}
    for x in rows or []:
        if not isinstance(x, dict):
            continue
        lane = _num(_first(x, "lane", "boat", "waku", "course"))
        if lane and 1 <= int(lane) <= 6:
            out[int(lane)] = x
    return out


def _stats_present(block):
    if not isinstance(block, dict):
        return False
    return any(_num(v) is not None for v in block.values())


def _parse_start(st_raw):
    if st_raw is None:
        return None
    s = str(st_raw).strip().upper()
    m = re.search(r"([FL]?)(?:0)?\.(\d{2})", s)
    if not m:
        return None
    val = int(m.group(2)) / 100.0
    if m.group(1) == "F":
        val = -val
    return val


def _extract_odds(odds):
    out = {}
    for row in (odds or {}).get("odds") or []:
        combo = str(_first(row, "combo", "combination", "trifecta") or "")
        nums = re.findall(r"[1-6]", combo)
        val = _num(_first(row, "odds", "value", "rate"))
        if len(nums) == 3 and len(set(nums)) == 3 and val is not None and math.isfinite(val) and val > 0:
            out["-".join(nums)] = val
    return out


def _extract_percentage(text, labels):
    for label in labels:
        # conservative: percentage must be near the label
        pat = rf"{label}.{{0,24}}?(\d{{1,3}}(?:\.\d+)?)\s*%"
        m = re.search(pat, text, re.I)
        if m:
            v = float(m.group(1))
            if 0 <= v <= 100:
                return v
    return None


def build_venue_profile(documents):
    """
    Build venue characteristics from saved materials.

    Important:
    - Do NOT display raw crawled sentences as-is.
    - First reject legal/event/racer/program text.
    - Then score only water/course/weather/race-development material.
    - Finally convert evidence into short, normalized venue-characteristic notes.
    """
    chunks = []
    source_kinds = set()
    for x in (documents or []):
        if not isinstance(x, dict):
            continue
        title = str(x.get("title") or "").strip()
        body = str(x.get("content_text") or "").strip()
        kind = str(x.get("source_kind") or "").strip()
        if kind:
            source_kinds.add(kind)
        if title or body:
            chunks.append((title + "\n" + body).strip())

    text = unicodedata.normalize("NFKC", "\n".join(chunks)[:1200000])

    in_escape = _extract_percentage(
        text,
        [r"イン逃げ率", r"1コース1着率", r"1号艇1着率", r"イン1着率"]
    )

    methods = {}
    method_labels = {
        "逃げ": [r"逃げ"],
        "差し": [r"差し"],
        "まくり": [r"(?<!差し)まくり(?!差し)"],
        "まくり差し": [r"まくり差し"],
        "抜き": [r"抜き"],
    }
    for name, labels in method_labels.items():
        val = _extract_percentage(text, labels)
        if val is not None:
            methods[name] = val

    combo_hits = {}
    for m in re.finditer(
        r"公式3連単出目統計\s+([1-6])-([1-6])-([1-6])\s+(\d{1,3}(?:\.\d+)?)%",
        text
    ):
        aa, bb, cc, pct = m.groups()
        if len({aa, bb, cc}) != 3:
            continue
        combo = f"{aa}-{bb}-{cc}"
        val = float(pct)
        if 0 <= val <= 100:
            combo_hits[combo] = max(combo_hits.get(combo, 0), val)

    popular = [
        {"combo": k, "rate": v}
        for k, v in sorted(
            combo_hits.items(), key=lambda kv: kv[1], reverse=True
        )[:8]
    ]

    # -----------------------------
    # Relevance filter
    # -----------------------------
    positive_groups = {
        "水面・コース": (
            "水面", "1マーク", "１マーク", "2マーク", "２マーク",
            "ターンマーク", "コース幅", "バック水面", "ホーム水面",
            "ピット", "進入", "広い", "狭い", "振って", "距離"
        ),
        "風": (
            "向かい風", "追い風", "横風", "風速", "風向", "海風", "季節風",
            "強風", "弱風"
        ),
        "潮・波": (
            "満潮", "干潮", "潮位", "潮", "うねり", "波高", "波",
            "海水", "淡水", "汽水", "流れ"
        ),
        "レース傾向": (
            "イン", "センター", "アウト", "逃げ", "差し", "まくり",
            "まくり差し", "抜き", "伸び", "出足", "回り足", "旋回",
            "ダッシュ", "スロー"
        ),
    }

    hard_reject = (
        "使用日時", "申請書", "使用許可", "秩序", "善良な風俗",
        "入場料", "参加費", "営利", "未成年", "利用規約", "プライバシー",
        "Copyright", "お問い合わせ", "サイトマップ", "ログイン", "投票",
        "開催期間中", "シリーズ注目", "イベント", "トークショー",
        "プレゼント", "キャンペーン", "選手名", "登録番号",
        "出場予定選手", "レースガイド", "ライブ&リプレイ",
    )

    racer_noise = (
        "級別", "支部", "年齢", "勝率", "2連率", "3連率", "平均ST",
        "モーター", "ボート", "登録", "選手", "当地3年", "全国"
    )

    def split_candidates(src):
        # First normal Japanese sentence boundaries.
        out = re.split(r"(?<=[。！？])\s*|\n+", src)
        # Legacy flattened pages: create windows around meaningful keywords.
        flat = re.sub(r"\s+", " ", src)
        all_terms = []
        for vals in positive_groups.values():
            all_terms.extend(vals)
        for kw in dict.fromkeys(all_terms):
            for mm in list(re.finditer(re.escape(kw), flat))[:10]:
                left = max(0, mm.start() - 80)
                right = min(len(flat), mm.end() + 120)
                win = flat[left:right]
                # Trim to punctuation if available.
                p0 = max(
                    win.rfind("。", 0, mm.start() - left),
                    win.rfind("！", 0, mm.start() - left),
                    win.rfind("？", 0, mm.start() - left),
                )
                if p0 >= 0:
                    win = win[p0+1:]
                ends = [x for x in (
                    win.find("。", 15), win.find("！", 15), win.find("？", 15)
                ) if x >= 0]
                if ends:
                    win = win[:min(ends)+1]
                out.append(win)
        return out

    def relevance(sentence):
        s = re.sub(r"\s+", " ", sentence or "").strip()
        if len(s) < 10:
            return -999, []
        if any(x in s for x in hard_reject):
            return -999, []
        # Racer/program rows are usually data dumps rather than venue traits.
        racer_hits = sum(1 for x in racer_noise if x in s)
        if racer_hits >= 3:
            return -999, []

        cats = []
        score = 0
        for cat, words in positive_groups.items():
            hits = sum(1 for w in words if w in s)
            if hits:
                cats.append(cat)
                score += min(hits, 4) * 2

        # Prefer explanatory language.
        for x in ("ため", "ので", "傾向", "多い", "少ない", "強い", "弱い",
                  "有利", "不利", "届く", "決まり", "影響", "特徴", "なりやすい",
                  "広く", "狭く", "遠い", "近い"):
            if x in s:
                score += 1

        # Penalize date/program-like blobs and huge numeric rows.
        if len(re.findall(r"\d", s)) >= 18:
            score -= 8
        if s.count("%") >= 4:
            score -= 5
        if len(s) > 220:
            score -= 2

        return score, cats

    evidences = []
    seen = set()
    for raw in split_candidates(text):
        s = re.sub(r"\s+", " ", raw or "").strip(" ・|\t\r\n")
        score, cats = relevance(s)
        if score < 4 or not cats:
            continue
        key = re.sub(r"[\s　。、・|]", "", s)
        if not key:
            continue
        if any(key in old or old in key for old in list(seen)[-50:]):
            continue
        seen.add(key)
        evidences.append({
            "text": s[:220],
            "score": score,
            "categories": cats,
        })

    evidences.sort(key=lambda x: x["score"], reverse=True)

    # -----------------------------
    # Normalize into concise notes.
    # We intentionally do not echo whole source sentences.
    # -----------------------------
    notes = []

    def add_note(label, body):
        body = re.sub(r"\s+", " ", body).strip(" 。")
        if body and not any(body in x or x in body for x in notes):
            notes.append(f"{label}：{body}")

    joined = " ".join(x["text"] for x in evidences[:60])

    # Water / geometry
    water_bits = []
    if re.search(r"1マーク.{0,20}(振|寄|位置)", joined):
        water_bits.append("1マークの配置に特徴あり")
    if re.search(r"(1マーク|１マーク).{0,35}(2マーク|２マーク).{0,20}(遠|距離)", joined) or \
       re.search(r"(2マーク|２マーク).{0,35}(1マーク|１マーク).{0,20}(遠|距離)", joined):
        water_bits.append("1・2マーク間の距離に特徴あり")
    if re.search(r"(水面|コース).{0,18}(広|ワイド)", joined):
        water_bits.append("水面・コースは比較的広め")
    if re.search(r"(水面|コース).{0,18}(狭|タイト)", joined):
        water_bits.append("水面・コースは比較的狭め")
    if "海水" in joined:
        water_bits.append("海水水面")
    elif "汽水" in joined:
        water_bits.append("汽水水面")
    elif "淡水" in joined:
        water_bits.append("淡水水面")
    if water_bits:
        add_note("水面・コース", " / ".join(dict.fromkeys(water_bits)))

    # Wind
    wind_bits = []
    if "向かい風" in joined:
        wind_bits.append("向かい風の影響を受ける場面あり")
    if "追い風" in joined:
        wind_bits.append("追い風の影響を受ける場面あり")
    if "横風" in joined:
        wind_bits.append("横風の影響を受ける場面あり")
    if re.search(r"(風|強風).{0,20}(強|影響|荒)", joined):
        wind_bits.append("風の強さがレース展開に影響しやすい")
    if wind_bits:
        add_note("風", " / ".join(dict.fromkeys(wind_bits)))

    # Tide / wave
    tide_bits = []
    if any(x in joined for x in ("満潮", "干潮", "潮位")):
        tide_bits.append("潮位変化を確認したい水面")
    if "うねり" in joined:
        tide_bits.append("うねりの影響が出る場合あり")
    if re.search(r"(波|波高).{0,20}(高|影響|荒)", joined):
        tide_bits.append("波の状態が走りに影響する場合あり")
    if tide_bits:
        add_note("潮・波", " / ".join(dict.fromkeys(tide_bits)))

    # Race development
    race_bits = []
    if re.search(r"イン.{0,18}(強|有利|逃げ)", joined):
        race_bits.append("イン優勢の記述あり")
    if re.search(r"イン.{0,18}(弱|不利|苦戦)", joined):
        race_bits.append("インが絶対ではない記述あり")
    if re.search(r"センター.{0,20}(まくり|攻め|強)", joined):
        race_bits.append("センター勢の攻めに注意")
    if re.search(r"ダッシュ.{0,20}(まくり|攻め|届)", joined):
        race_bits.append("ダッシュ勢の攻めが届く記述あり")
    if "まくり差し" in joined:
        race_bits.append("まくり差しの展開も要注意")
    if re.search(r"2マーク.{0,20}(抜き|逆転)", joined):
        race_bits.append("2マークでの逆転・抜きに注意")
    if race_bits:
        add_note("レース傾向", " / ".join(dict.fromkeys(race_bits)))

    # If evidence exists but rules could not confidently normalize it,
    # report "under analysis" instead of dumping unrelated source text.
    if notes:
        direction = "収集資料を関連性判定し、場特性として使える内容だけを反映"
        analysis_state = "reflected"
    elif evidences:
        direction = "場特性に関係する資料を確認中。内容を整理してから反映します"
        analysis_state = "analyzing"
    elif documents:
        direction = "資料は保存済みですが、場特性として使える文章をまだ確認できていません"
        analysis_state = "no_relevant_text"
    else:
        direction = "場特性資料をまだ取得できていません"
        analysis_state = "no_documents"

    return {
        "direction": direction,
        "characteristic_notes": notes[:8],
        "in_escape_rate": in_escape,
        "winning_methods": methods,
        "popular_combos": popular,
        "document_count": len(documents or []),
        "relevant_evidence_count": len(evidences),
        "analysis_state": analysis_state,
        "source_kinds": sorted(source_kinds),
    }


def _meeting_results(racer):
    for key in ("meeting_results", "series_results", "current_meeting", "session_results"):
        v = racer.get(key) if isinstance(racer, dict) else None
        if v:
            return v
    return None


def _lane_specific(racer, locality):
    # Future collector adapters may use any of these aliases.
    keys = (
        *(("local_frame_stats", "local_frame") if locality == "local" else ()),
        f"{locality}_lane", f"{locality}_course",
        f"{locality}_lane_results", f"{locality}_course_results",
        f"{locality}_waku"
    )
    for k in keys:
        v = racer.get(k) if isinstance(racer, dict) else None
        if isinstance(v, dict) and _stats_present(v):
            return v
        if v not in (None, "", [], {}):
            return v
    # The current official racelist exposes the racer's nationwide/local
    # aggregate block as ``national`` / ``local``.  Prefer a future true
    # course-specific block above, but do not throw away this useful fallback.
    v = racer.get(locality) if isinstance(racer, dict) else None
    if isinstance(v, dict) and _stats_present(v):
        return v
    return None


def _course_stats(racer, course):
    """Saved official-result performance for one actual entry course."""
    rows = racer.get("course_stats") if isinstance(racer, dict) else None
    if not isinstance(rows, dict):
        return None
    return rows.get(course) or rows.get(str(course))


def build_availability(race, before, odds, documents, venue_profile, day_venue_trend=None, water_condition=None):
    racers = (race or {}).get("racers") or []
    br = (before or {}).get("racers") or []
    starts = (before or {}).get("start_display") or []
    original = (before or {}).get("original_exhibition") or []
    weather = (before or {}).get("weather") or {}
    comments = (before or {}).get("comments") or []

    def any_racer(pred):
        return bool(racers) and any(pred(x) for x in racers if isinstance(x, dict))

    flags = {
        "meeting_results": any_racer(lambda x: bool(_meeting_results(x))),
        "national_lane_results": any_racer(lambda x: bool(_lane_specific(x, "national"))),
        "local_lane_results": any_racer(lambda x: bool(_lane_specific(x, "local"))),
        "course_quinella_rate": any_racer(lambda x: bool(_course_stats(x, int(x.get("lane") or 0)))),
        "motor": any_racer(lambda x: _stats_present(x.get("motor") or {})),
        "boat": any_racer(lambda x: _stats_present(x.get("boat") or {})),
        "avg_st": any_racer(lambda x: _num(x.get("avg_st")) is not None),
        "exhibition_time": any(_num(x.get("exhibition_time")) is not None for x in br),
        "tilt": any(_num(x.get("tilt")) is not None for x in br),
        "start_exhibition_st": any(_parse_start(x.get("st_raw")) is not None for x in starts),
        "start_entry": bool(starts) and any(x.get("course") is not None for x in starts),
        "original_exhibition": bool(original),
        "wind_speed": _num(weather.get("wind_speed_m")) is not None,
        "wind_direction": bool(weather.get("wind_direction")),
        "tide": any(weather.get(k) for k in ("tide_phase", "high_tide_time", "low_tide_time")) or bool((water_condition or {}).get("tide_phase")),
        "wave_height": _num(weather.get("wave_height_cm")) is not None,
        "comments": bool(comments),
        "venue_material": bool(documents),
        "in_escape_rate": venue_profile.get("in_escape_rate") is not None,
        "winning_method": bool(venue_profile.get("winning_methods")),
        "popular_combos": bool(venue_profile.get("popular_combos")),
        "same_day_venue_results": int((day_venue_trend or {}).get("completed_races") or 0) > 0,
        "odds": bool(_extract_odds(odds)),
    }

    return [
        {
            "key": key,
            "label": label,
            "available": bool(flags.get(key)),
        }
        for key, label in COLLECTION_CATALOG
    ]


def _venue_lane_adjustments(active, venue_profile):
    """Small, evidence-based venue/course correction; never overrides racers."""
    active = [int(x) for x in active]
    out = {lane: {"score": 0.0, "reasons": []} for lane in active}
    vp = venue_profile or {}
    escape = _num(vp.get("in_escape_rate"))
    if escape is not None and 1 in out:
        # Around 50% is neutral.  The bounded correction is intentionally much
        # smaller than current-series, racer, motor and exhibition factors.
        delta = max(-5.0, min(5.0, (escape - 50.0) * 0.18))
        out[1]["score"] += delta
        out[1]["reasons"].append(f"場のイン逃げ率{escape:g}%")
        outside = [x for x in active if x != 1]
        if outside:
            share = -delta / len(outside)
            for lane in outside:
                out[lane]["score"] += share

    methods = vp.get("winning_methods") or {}
    method_targets = {
        "差し": (2,),
        "まくり": (3, 4),
        "まくり差し": (3, 4, 5),
    }
    for method, targets in method_targets.items():
        rate = _num(methods.get(method))
        lanes = [x for x in targets if x in out]
        if rate is None or not lanes:
            continue
        # The percentages in venue material may use different denominators, so
        # this is a capped relative hint rather than a direct probability.
        add = min(2.5, max(0.0, rate) * 0.05) / len(lanes)
        for lane in lanes:
            out[lane]["score"] += add
            out[lane]["reasons"].append(f"場の{method}傾向")
    return out


def _pre_lane_score(lane, racer):
    """
    PRE-BEFORE model.
    User-specified basis only:
      meeting performance
      national result for this lane/course
      local result for this lane/course
      motor
      boat
    Missing items are not silently replaced with unrelated values.
    """
    # 枠だけで予想が決まらないよう基礎点を抑え、選手本人の当該コース
    # 成績・今節の走りを相対的に重くする。
    score = LANE_BASE.get(lane, 0.4) * 10
    reasons = [f"{lane}枠基礎"]

    meeting = _meeting_results(racer)
    if meeting:
        # Generic support for structured future collectors.
        vals = []
        if isinstance(meeting, dict):
            for k in ("score", "rate", "avg_rank", "points", "win_rate"):
                v = _num(meeting.get(k))
                if v is not None:
                    vals.append((k, v))
        if vals:
            k, v = vals[0]
            if "avg_rank" in k:
                # 1.0 is excellent, 6.0 is poor. Current-series form is a
                # meaningful PRE factor but must not dominate all other data.
                form = max(0.0, min((6.0 - v) / 5.0, 1.0))
                score += form * 28
                reasons.append(f"節間平均着 {v:.2f}")
            else:
                score += max(0, min(v / 8.0, 1.2)) * 28
                reasons.append("節間成績")

        else:
            entries = meeting.get("entries") if isinstance(meeting, dict) else None
            numeric = []
            for e in (entries or []):
                f = str((e or {}).get("finish") or "")
                if f.isdigit():
                    numeric.append(int(f))
            if numeric:
                av = sum(numeric) / len(numeric)
                form = max(0.0, min((6.0 - av) / 5.0, 1.0))
                score += form * 28
                reasons.append(f"節間平均着 {av:.2f}")
            else:
                score += 3
                reasons.append("節間成績")

        # 今節のSTはF持ちなどで普段より慎重なスタートになっている
        # 状態も表す。F/L表記は平均に混ぜず、正常値だけで評価する。
        entries = meeting.get("entries") if isinstance(meeting, dict) else []
        st_values = []
        for e in entries or []:
            raw = str((e or {}).get("st") or "").strip().upper()
            if re.fullmatch(r"0?\.\d{2}", raw):
                st_values.append(float(raw if raw.startswith("0") else "0" + raw))
        meeting_avg_st = _num(meeting.get("avg_st")) if isinstance(meeting, dict) else None
        if meeting_avg_st is None and st_values:
            meeting_avg_st = sum(st_values) / len(st_values)
        if meeting_avg_st is not None:
            st_adj = max(-10.0, min(10.0, (0.19 - meeting_avg_st) * 95.0))
            score += st_adj
            reasons.append(f"節間平均ST {meeting_avg_st:.2f}")
            f_count = int(_num(_first(racer, "f", "f_count", "flying")) or 0)
            if f_count and meeting_avg_st >= 0.18:
                score -= 2.5
                reasons.append(f"F{f_count}持ち・節間ST慎重")

    # Before the start exhibition is published, boat frame is the best known
    # entry-course estimate.  The POST stage can still change the final score
    # using the actual entry information, while this history is a transparent
    # supporting signal rather than a replacement for official racer data.
    course_block = _course_stats(racer, lane)
    if isinstance(course_block, dict):
        first_rate = _num(course_block.get("first_rate"))
        q = _num(course_block.get("quinella_rate"))
        trio = _num(course_block.get("trio_rate"))
        course_avg_st = _num(course_block.get("avg_st"))
        starts = int(_num(course_block.get("starts")) or 0)
        if q is None:
            second_rate = _num(course_block.get("second_rate"))
            if first_rate is not None and second_rate is not None:
                q = first_rate + second_rate
        if first_rate is not None:
            score += max(0, min(first_rate / 100.0, 1.0)) * 10
            reasons.append(f"公式 {lane}コース1着{first_rate:g}%")
        if q is not None and starts:
            reliability = min(1.0, max(0.2, starts / 20.0))
            score += max(0, min(q / 100.0, 1.1)) * 11 * reliability
            reasons.append(f"{lane}コース2連{q:g}%（{starts}走）")
        elif q is not None:
            score += max(0, min(q / 100.0, 1.1)) * 11
            reasons.append(f"公式 {lane}コース2連{q:g}%")
        elif trio is not None:
            # Official racer-search course page publishes course-specific
            # three-in-the-money performance even before our own history has
            # accumulated.  It is a supporting signal, not a substitute for
            # current race / motor / exhibition information.
            score += max(0, min(trio / 100.0, 1.1)) * 7
            reasons.append(f"公式 {lane}コース3連{trio:g}%")
        if course_avg_st is not None:
            score += max(-6.0, min(6.0, (0.19 - course_avg_st) * 60.0))
            reasons.append(f"公式 {lane}コース平均ST {course_avg_st:.2f}")

        # 「1枠だから逃げる」ではなく、その選手が実際に1コースで
        # 弱い場合はイン基礎点を打ち消す。2連対率を優先し、未取得時
        # は3連対率を補助判定に使う。
        if lane == 1:
            if q is not None and q < 55:
                penalty = min(12.0, (55.0 - q) * 0.35)
                score -= penalty
                reasons.append(f"1コース2連率低め -{penalty:.1f}")
            elif q is None and trio is not None and trio < 68:
                penalty = min(10.0, (68.0 - trio) * 0.25)
                score -= penalty
                reasons.append(f"1コース3連率低め -{penalty:.1f}")

    for locality, label, weight in (
        ("national", "全国成績（当該枠/コース優先）", 14),
        ("local", "当地同枠成績", 8),
    ):
        block = _lane_specific(racer, locality)
        if isinstance(block, dict):
            win = _num(_first(block, "win_rate", "first_rate", "1st_rate", "rate"))
            q = _num(_first(block, "quinella_rate", "2ren", "top2_rate"))
            sample = int(_num(_first(block, "starts", "sample_size", "races")) or 0)
            reliability = min(1.0, max(0.25, sample / 12.0)) if sample else 1.0
            if win is not None:
                score += max(0, min(win / (100 if win > 10 else 8), 1.2)) * weight * reliability
                reasons.append(
                    f"当地同枠実績 {sample}走" if locality == "local" and sample else label
                )
            elif q is not None:
                score += max(0, min(q / 100.0, 1.2)) * (weight * 0.7) * reliability
                reasons.append(
                    f"当地同枠実績 {sample}走" if locality == "local" and sample else label
                )
        elif block:
            score += weight * 0.25
            reasons.append(label)

    motor = racer.get("motor") or {}
    mr = _num(_first(motor, "quinella_rate", "2ren", "rate"))
    if mr is not None:
        score += max(0, min(mr / 50.0, 1.3)) * 11
        reasons.append(f"モーター2連{mr:g}%")

    boat = racer.get("boat") or {}
    br = _num(_first(boat, "quinella_rate", "2ren", "rate"))
    if br is not None:
        score += max(0, min(br / 50.0, 1.3)) * 5
        reasons.append(f"ボート2連{br:g}%")

    if racer.get("scratched") or str(racer.get("status") or "") == "欠場":
        return -9999, ["欠場"]

    return score, reasons


def _tilt_racer_skill(lane, racer, start_row):
    """Estimate whether the racer can turn an outside high tilt into an attack.

    The score is deliberately evidence-weighted: a 3-degree setting is not
    enough by itself.  Official course performance, class, national win rate,
    average/current ST and current-series finishes decide how much of the
    high-tilt attack signal is trusted.
    """
    parts = []

    grade = str((racer or {}).get("class") or "").upper()
    if grade in CLASS_SCORE:
        parts.append((CLASS_SCORE[grade], 0.20))

    national = (racer or {}).get("national") or {}
    win_rate = _num(_first(national, "win_rate", "rate"))
    if win_rate is not None:
        parts.append((max(0.0, min(1.0, (win_rate - 3.0) / 5.0)), 0.15))

    course = _course_stats(racer or {}, lane) or {}
    first_rate = _num(course.get("first_rate"))
    quinella_rate = _num(course.get("quinella_rate"))
    if first_rate is not None:
        parts.append((max(0.0, min(1.0, first_rate / 45.0)), 0.25))
    if quinella_rate is not None:
        parts.append((max(0.0, min(1.0, quinella_rate / 70.0)), 0.10))

    avg_st = _num((racer or {}).get("avg_st"))
    if avg_st is not None:
        parts.append((max(0.0, min(1.0, (0.24 - avg_st) / 0.15)), 0.12))

    display_st = _parse_start((start_row or {}).get("st_raw"))
    if display_st is not None:
        if display_st < 0:
            parts.append((0.0, 0.10))
        else:
            parts.append((max(0.0, min(1.0, (0.22 - display_st) / 0.17)), 0.10))

    meeting = _meeting_results(racer or {}) or {}
    finishes = []
    for entry in meeting.get("entries") or []:
        finish = _num((entry or {}).get("finish"))
        if finish is not None and 1 <= finish <= 6:
            finishes.append(finish)
    if finishes:
        avg_finish = sum(finishes) / len(finishes)
        parts.append((max(0.0, min(1.0, (6.0 - avg_finish) / 5.0)), 0.08))

    if not parts:
        return 0.25
    weight = sum(w for _, w in parts) or 1.0
    return max(0.0, min(1.0, sum(v * w for v, w in parts) / weight))


def _learned_tilt_adjustment(lane, tilt_performance):
    """Return a bounded adjustment learned from prior official outcomes."""
    stats = ((tilt_performance or {}).get("by_lane") or {}).get(lane) or {}
    high = stats.get("high") or {}
    other = stats.get("other") or {}
    n = int(high.get("starts") or 0)
    if n < int((tilt_performance or {}).get("sample_minimum") or 5):
        return 0.0, f"3度実績は蓄積中（{n}走）"

    high_win = _num(high.get("first_rate")) or 0.0
    high_top3 = _num(high.get("trio_rate")) or 0.0
    base_win = _num(other.get("first_rate"))
    base_top3 = _num(other.get("trio_rate"))
    # Compare against the same lane where possible.  With no baseline, use a
    # neutral prior and keep the correction small.  Shrink rare samples hard.
    win_delta = high_win - (base_win if base_win is not None else high_win)
    top3_delta = high_top3 - (base_top3 if base_top3 is not None else high_top3)
    reliability = min(0.75, n / 30.0)
    learned = reliability * max(-2.5, min(2.5, win_delta / 8.0 + top3_delta / 15.0))
    return learned, (
        f"保存済み3度実績{n}走・1着{high_win:g}%・3連対{high_top3:g}%"
    )


def _post_adjustment(lane, racer, before_row, start_row, original_row, weather, comments,
                     tilt_performance=None):
    """
    POST-BEFORE adjustment:
      PRE basis +
      start exhibition ST / entry timing
      original exhibition
      comments

    v17.169:
      Legacy direct wind/tide/wave scoring is intentionally disabled.
      Water conditions are collected and validated separately by Stage 3 and
      will only re-enter prediction through the unified Stage 4 interface.
    """
    adj = 0.0
    reasons = []
    position_boost = {1: 0.0, 2: 0.0, 3: 0.0}

    st = _parse_start((start_row or {}).get("st_raw"))
    if st is not None:
        # good start around 0.05-0.15. F-like starts receive caution.
        if st < 0:
            adj -= 3.0
            reasons.append(f"展示ST F{abs(st):.2f}")
        else:
            adj += max(-2.0, min((0.22 - st) / 0.17, 1.0) * 10)
            reasons.append(f"展示ST {st:.2f}")

    course = _num((start_row or {}).get("course"))
    entry_is_confirmed = not bool((start_row or {}).get("entry_inferred"))
    if course is not None:
        course = int(course)
        if course == lane:
            reasons.append(f"進入{course}コース")
        else:
            # moving inward is a small plus, outward a small minus
            adj += max(-4, min(4, (lane - course) * 1.5))
            reasons.append(f"進入変化 {lane}枠→{course}コース")

        # PREでは枠なりコースの公式平均STを使用している。ST展示で進入が
        # 確定してコースが変わった場合は、その選手の「実際の展示進入コース」
        # の平均STへ差し替える。艇番対応を推測した行(entry_inferred)では行わない。
        if entry_is_confirmed and course != lane:
            assumed = _course_stats(racer or {}, lane) or {}
            actual = _course_stats(racer or {}, course) or {}
            assumed_st = _num(assumed.get("avg_st"))
            actual_st = _num(actual.get("avg_st"))
            if actual_st is not None:
                actual_component = max(-5.0, min(5.0, (0.19 - actual_st) * 50.0))
                assumed_component = (max(-5.0, min(5.0, (0.19 - assumed_st) * 50.0))
                                     if assumed_st is not None else 0.0)
                adj += actual_component - assumed_component
                reasons.append(f"進入変更後 {course}コース平均ST {actual_st:.2f}")

    # Regular exhibition time is available as a secondary movement clue.
    ex = _num((before_row or {}).get("exhibition_time"))
    if ex is not None and 6.0 <= ex <= 8.0:
        adj += max(-2, min(5, (7.10 - ex) * 8))
        reasons.append(f"展示{ex:.2f}")

    tilt = _num((before_row or {}).get("tilt"))
    if tilt is not None:
        reasons.append(f"チルト{tilt:g}度")
        learned = 0.0
        learned_reason = None
        if tilt >= 2.5:
            learned, learned_reason = _learned_tilt_adjustment(lane, tilt_performance)
            reasons.append(learned_reason)
        if tilt >= 2.5 and lane in (5, 6):
            skill = _tilt_racer_skill(lane, racer, start_row)
            # High tilt on an outside course is an attacking signal.  Keep a
            # small base allowance, but let verified racer skill determine the
            # majority of the bonus so an inexperienced racer is not promoted
            # solely for selecting 3 degrees.
            adj += 2.0 + 6.0 * skill
            position_boost[1] = 0.18 + 0.66 * skill
            position_boost[2] = 0.08 + 0.18 * skill
            position_boost[3] = 0.03 + 0.10 * skill
            adj += learned
            # Actual saved outcomes tune the attack signal, but can never make
            # one rare 3-degree result dominate the other racer evidence.
            position_boost[1] += max(-0.12, min(0.12, learned / 12.0))
            position_boost[2] += max(-0.05, min(0.05, learned / 25.0))
            position_boost[3] += max(-0.03, min(0.03, learned / 35.0))
            if skill >= 0.67:
                reasons.append(f"外枠3度・攻撃力高（適性{skill*100:.0f}）")
            elif skill >= 0.45:
                reasons.append(f"外枠3度・まくり警戒（適性{skill*100:.0f}）")
            else:
                reasons.append(f"外枠3度だが実績加点限定（適性{skill*100:.0f}）")
        elif tilt >= 2.5 and lane in (3, 4):
            skill = _tilt_racer_skill(lane, racer, start_row)
            adj += 0.8 + 2.2 * skill + learned * 0.7
            position_boost[1] = 0.06 + 0.20 * skill + max(-0.08, min(0.08, learned / 16.0))
            reasons.append("センター高チルト攻め")
        elif tilt >= 2.5:
            skill = _tilt_racer_skill(lane, racer, start_row)
            adj += 0.4 + 1.0 * skill + learned * 0.4
            position_boost[1] = 0.02 + 0.08 * skill
            reasons.append("内寄り3度・伸び型を慎重評価")
        elif tilt >= 1.5:
            skill = _tilt_racer_skill(lane, racer, start_row)
            adj += 0.4 + 1.4 * skill
            position_boost[1] = 0.03 + 0.12 * skill
            position_boost[2] = 0.02 + 0.05 * skill
            reasons.append("高めチルト・伸び寄りを警戒")
        elif tilt >= 1.0:
            # User workflow: -0.5 / 0 / +0.5 are ordinary settings and must not
            # move the prediction.  Only a clearly raised setting is a small
            # supporting clue unless it reaches the high-tilt rules above.
            skill = _tilt_racer_skill(lane, racer, start_row)
            adj += 0.15 + 0.45 * skill
            position_boost[1] = 0.01 + 0.04 * skill
            reasons.append("チルト1度以上・補助評価")
        elif tilt <= -1.0 and lane in (1, 2, 3):
            adj += 0.20
            position_boost[2] = 0.01
            position_boost[3] = 0.01
            reasons.append("低チルト1度以下・補助評価")
        else:
            reasons.append("通常チルト・評価点なし")

    # Parts replacement is visible context only for now.  The user treats it
    # as a low-priority confirmation item, so it must not move the score by
    # itself without outcome evidence.
    parts_change = _first(before_row or {}, "parts_replacement", "parts_exchange", "parts")
    if not parts_change:
        parts_change = _first(racer or {}, "parts_replacement", "parts_exchange")
    if parts_change:
        reasons.append(f"部品交換:{str(parts_change)[:24]}（点数補正なし）")

    metrics = (original_row or {}).get("metrics") or {}
    vals = []
    for label, value in metrics.items():
        v = _num(value)
        if v is not None:
            vals.append((label, v))
    if vals:
        # Absolute scales vary by venue, therefore only a modest positive
        # availability adjustment here. Relative ranking is added later.
        reasons.append("オリジナル展示")

    # v17.169 integration guard:
    # Do not score raw wind/tide/wave here.  Stage 3 owns collection + combined
    # interpretation.  Stage 4 will provide one unified adjustment so legacy
    # weather logic cannot stack with the new water-condition correction.

    c = next(
        (x for x in comments or [] if _num(x.get("lane")) == lane),
        None
    )
    if c and c.get("comment"):
        text = str(c["comment"])
        positive = ("良い", "いい", "出足", "伸び", "上向", "納得", "足はいい")
        negative = ("悪い", "弱い", "合ってない", "重い", "足りない", "厳しい")
        if any(w in text for w in positive):
            adj += 2.5
        if any(w in text for w in negative):
            adj -= 2.5
        reasons.append("選手コメント")

    return adj, reasons, position_boost



def _stage4_water_adjustments(active, water_condition):
    """Return deliberately small, bounded Stage-4 lane corrections.

    Stage 3 remains the single interpreter of saved wind/tide/venue context.
    This function consumes only that saved interpretation.  It never reads raw
    tide/weather independently, which prevents the legacy/new double scoring
    that v17.169 removed.
    """
    out = {lane: {"score": 0.0, "reasons": []} for lane in active}
    w = water_condition or {}
    if not isinstance(w, dict) or w.get("water_condition_level") == "判定保留":
        return out, False
    speed = _num(w.get("wind_speed_m"))
    if speed is None:
        return out, False
    relation = str(w.get("wind_course_type") or "")
    tags = set(w.get("water_effect_tags") or [])
    band = str(w.get("wind_speed_band") or "")
    scale = 0.5 if band == "弱" else (1.25 if band == "強" else 1.0)

    def add(lane, value, reason):
        if lane in out:
            out[lane]["score"] += value * scale
            if reason not in out[lane]["reasons"]:
                out[lane]["reasons"].append(reason)

    # Very small generic wind prior. Venue-specific Stage-3 tags below are
    # stronger, but the whole correction remains capped so racer/exhibition
    # evidence stays dominant while real outcomes accumulate.
    if relation == "向かい風":
        add(1, -0.15, "水面補正:向かい風")
        add(3,  0.25, "水面補正:向かい風")
        add(4,  0.20, "水面補正:向かい風")
    elif relation == "追い風":
        add(1,  0.10, "水面補正:追い風")
        add(2,  0.25, "水面補正:追い風")
        add(3, -0.10, "水面補正:追い風")

    if "差し注意" in tags:
        add(1, -0.25, "場別水面:差し注意")
        add(2,  0.70, "場別水面:差し注意")
        add(3,  0.15, "場別水面:差し注意")
    if "まくり注意" in tags:
        add(1, -0.40, "場別水面:まくり注意")
        add(2, -0.20, "場別水面:まくり注意")
        add(3,  0.70, "場別水面:まくり注意")
        add(4,  0.55, "場別水面:まくり注意")
    if "イン不安定要素" in tags:
        add(1, -0.55, "場別水面:イン不安定")
        add(2,  0.20, "場別水面:イン不安定")
        add(3,  0.20, "場別水面:イン不安定")
    # うねり/ST難化 are preserved as evidence, but do not guess a winning lane.
    evidence_only = tags.intersection({"うねり注意", "ST難化注意", "潮流×風確認", "相対風向未確定"})
    if evidence_only:
        for lane in active:
            out[lane]["reasons"].append("水面注意:" + "・".join(sorted(evidence_only)))

    applied = any(abs(x["score"]) > 1e-9 for x in out.values())
    # Hard cap: Stage 4 starts weak.  We can learn stronger/venue-specific
    # weights later from saved outcomes rather than assuming them now.
    for lane in out:
        out[lane]["score"] = max(-1.5, min(1.5, out[lane]["score"]))
    return out, applied


def _original_relative_adjustments(original_rows):
    """Rank original-exhibition metrics within the six boats.

    Lower times are better.  Rank is the primary signal, while the actual gap
    controls how much confidence to put in that rank.  Strong original
    exhibition is deliberately more useful for 2nd/3rd-place candidacy than
    for forcing an outside boat into the win position.
    """
    rows = _lane_map(original_rows)
    score_adjustments = {i: 0.0 for i in range(1, 7)}
    position_boosts = {i: {1: 0.0, 2: 0.0, 3: 0.0} for i in range(1, 7)}
    diagnostics = {i: [] for i in range(1, 7)}
    labels = set()
    for row in rows.values():
        labels.update((row.get("metrics") or {}).keys())

    # Per-metric rank points.  These are intentionally modest because the
    # ordinary racer/course/ST evidence remains the model's foundation.
    rank_score = {1: 0.55, 2: 0.32, 3: 0.14, 4: 0.0, 5: -0.08, 6: -0.15}
    rank_pos = {
        1: {1: 0.04, 2: 0.13, 3: 0.16},
        2: {1: 0.02, 2: 0.09, 3: 0.12},
        3: {1: 0.00, 2: 0.04, 3: 0.06},
    }

    for label in sorted(labels):
        vals = []
        for lane, row in rows.items():
            v = _num((row.get("metrics") or {}).get(label))
            if v is not None:
                vals.append((lane, v))
        if len(vals) < 3:
            continue
        vals.sort(key=lambda x: x[1])
        metric_span = max(vals[-1][1] - vals[0][1], 1e-9)
        # If the whole field is nearly tied, ranking should barely matter.
        typical = max(abs(sum(v for _, v in vals) / len(vals)), 1e-6)
        relative_span = metric_span / typical
        gap_scale = max(0.20, min(1.0, relative_span / 0.035))
        for idx, (lane, value) in enumerate(vals, start=1):
            score_adjustments[lane] += rank_score.get(idx, 0.0) * gap_scale
            if idx in rank_pos:
                for place, boost in rank_pos[idx].items():
                    position_boosts[lane][place] += boost * gap_scale
            diagnostics[lane].append({
                "metric": str(label), "rank": idx, "value": value,
                "gap_scale": round(gap_scale, 3),
            })

    # Prevent four metrics from overwhelming racer ability.  The position cap
    # is intentionally larger for 2nd/3rd than for 1st.
    for lane in score_adjustments:
        score_adjustments[lane] = max(-0.60, min(1.65, score_adjustments[lane]))
        position_boosts[lane][1] = max(-0.05, min(0.16, position_boosts[lane][1]))
        position_boosts[lane][2] = max(0.0, min(0.42, position_boosts[lane][2]))
        position_boosts[lane][3] = max(0.0, min(0.52, position_boosts[lane][3]))
    return score_adjustments, position_boosts, diagnostics


def _meeting_snapshot(racer, current_course):
    """Compact current-series form used by the development engine."""
    meeting = _meeting_results(racer or {}) or {}
    entries = meeting.get("entries") if isinstance(meeting, dict) else []
    finishes, course_finishes, sts = [], [], []
    for e in entries or []:
        if not isinstance(e, dict):
            continue
        f = _num(e.get("finish"))
        if f is not None and 1 <= f <= 6:
            finishes.append(f)
            ec = _num(_first(e, "course", "entry_course", "lane"))
            if ec is not None and int(ec) == int(current_course):
                course_finishes.append(f)
        raw = str(e.get("st") or "").strip().upper()
        if re.fullmatch(r"0?\.\d{2}", raw):
            sts.append(float(raw if raw.startswith("0") else "0" + raw))
    avg_finish = (sum(finishes) / len(finishes)) if finishes else None
    course_avg_finish = (sum(course_finishes) / len(course_finishes)) if course_finishes else None
    avg_st = _num(meeting.get("avg_st")) if isinstance(meeting, dict) else None
    if avg_st is None and sts:
        avg_st = sum(sts) / len(sts)
    return {
        "avg_finish": avg_finish,
        "course_avg_finish": course_avg_finish,
        "course_runs": len(course_finishes),
        "avg_st": avg_st,
        "runs": len(finishes),
    }


def _regular_exhibition_ranks(active, before_map):
    vals = []
    for lane in active:
        v = _num((before_map.get(lane) or {}).get("exhibition_time"))
        if v is not None:
            vals.append((lane, v))
    vals.sort(key=lambda x: x[1])
    return {lane: {"rank": idx, "value": value, "field": len(vals)} for idx, (lane, value) in enumerate(vals, 1)}


def _current_form_development(active, race_map, before_map, start_map, original_rankings, venue_profile):
    """Build race development from *relationships* between the six racers.

    v17.174 changes the reasoning order: racer/course traits -> current-series
    form/ST -> first development hypothesis -> venue correction -> original
    exhibition confirmation -> weather/water later.  Most raw inputs already
    affect the ordinary score, so this function mainly adds interaction and
    position-specific effects rather than double-counting the same numbers.
    """
    ex_ranks = _regular_exhibition_ranks(active, before_map)
    form = {}
    position = {lane: {1: 0.0, 2: 0.0, 3: 0.0} for lane in active}
    score_adj = {lane: 0.0 for lane in active}
    events = []

    for lane in active:
        racer = race_map.get(lane) or {}
        start_row = start_map.get(lane) or {}
        raw_entry_course = _num(start_row.get("course"))
        entry_course = (int(raw_entry_course)
                        if raw_entry_course is not None and not start_row.get("entry_inferred")
                        else lane)
        course = _course_stats(racer, entry_course) or {}
        meeting = _meeting_snapshot(racer, entry_course)
        display_st = _parse_start(start_row.get("st_raw"))
        ex = ex_ranks.get(lane) or {}
        weakness, strength = 0.0, 0.0
        weak_reasons, strong_reasons, traits = [], [], []

        first_rate = _num(course.get("first_rate"))
        q_rate = _num(course.get("quinella_rate"))
        trio_rate = _num(course.get("trio_rate"))
        course_st = _num(course.get("avg_st"))
        if first_rate is not None:
            traits.append(f"{entry_course}コース1着{first_rate:g}%")
        if q_rate is not None:
            traits.append(f"{entry_course}コース2連{q_rate:g}%")
        if course_st is not None:
            traits.append(f"{entry_course}コースST{course_st:.2f}")
            # v17.178: official course-specific average ST is a core racer
            # characteristic, not display-only data.  Use the *actual start
            # exhibition entry course* when confirmed.  Missing course data is
            # neutral and is never converted to 0.00.
            if course_st >= 0.19:
                weakness += 0.24; weak_reasons.append(f"公式{entry_course}コース平均ST遅め{course_st:.2f}")
            elif course_st >= 0.17:
                weakness += 0.12; weak_reasons.append(f"公式{entry_course}コース平均STやや遅め{course_st:.2f}")
            elif course_st <= 0.12:
                strength += 0.22; strong_reasons.append(f"公式{entry_course}コース平均STかなり速い{course_st:.2f}")
            elif course_st <= 0.14:
                strength += 0.12; strong_reasons.append(f"公式{entry_course}コース平均ST良好{course_st:.2f}")

            # Relative ST matters for development: a dash/center racer whose
            # normal ST from this course is clearly faster than the boat just
            # inside has more chance to initiate the attack.
            inner = form.get(lane - 1) if lane > 1 else None
            inner_st = _num((inner or {}).get("course_avg_st"))
            if inner_st is not None:
                gap = inner_st - course_st
                if gap >= 0.04:
                    strength += 0.20; strong_reasons.append(f"内隣よりコース平均ST{gap:.2f}速い")
                elif gap >= 0.025:
                    strength += 0.12; strong_reasons.append(f"内隣よりコース平均ST優位")
                elif gap <= -0.04:
                    weakness += 0.16; weak_reasons.append(f"内隣よりコース平均ST{abs(gap):.2f}遅い")

        # v17.180: recent nationwide/local course history is intentionally
        # display/storage-only for now.  No score adjustment is made here.

        caf = meeting.get("course_avg_finish")
        cruns = int(meeting.get("course_runs") or 0)
        af = meeting.get("avg_finish")
        mst = meeting.get("avg_st")
        if cruns and caf is not None:
            if caf >= 4.0:
                weakness += 0.34; weak_reasons.append(f"今節{lane}コース平均着{caf:.1f}")
            elif caf >= 3.4:
                weakness += 0.20; weak_reasons.append(f"今節{lane}コースやや不調{caf:.1f}")
            elif caf <= 2.5:
                strength += 0.24; strong_reasons.append(f"今節{lane}コース好調{caf:.1f}")
        elif af is not None:
            if af >= 4.0:
                weakness += 0.22; weak_reasons.append(f"節間平均着{af:.1f}")
            elif af <= 2.5:
                strength += 0.20; strong_reasons.append(f"節間平均着{af:.1f}")

        if mst is not None:
            if mst >= 0.18:
                weakness += 0.38; weak_reasons.append(f"節間ST遅め{mst:.2f}")
            elif mst >= 0.16:
                weakness += 0.20; weak_reasons.append(f"節間STやや遅め{mst:.2f}")
            elif mst <= 0.13:
                strength += 0.28; strong_reasons.append(f"節間ST良好{mst:.2f}")

        if q_rate is not None:
            if lane == 1 and q_rate < 55:
                weakness += 0.28; weak_reasons.append("イン実績不安")
            elif lane != 1 and q_rate < 30:
                weakness += 0.28; weak_reasons.append(f"{lane}コース2連率低め")
            elif lane != 1 and q_rate < 40:
                weakness += 0.14; weak_reasons.append(f"{lane}コース実績やや弱い")
            elif q_rate >= 55:
                strength += 0.20; strong_reasons.append(f"{lane}コース実績良好")

        er = int(ex.get("rank") or 0)
        if er:
            if er >= 5:
                weakness += 0.28 if er == 5 else 0.36; weak_reasons.append(f"展示タイム{er}位")
            elif er <= 2:
                strength += 0.24 if er == 2 else 0.32; strong_reasons.append(f"展示タイム{er}位")

        if display_st is not None:
            if display_st < 0:
                # Exhibition F alone is not a hard negative.  It becomes a
                # meaningful uncertainty signal when the series ST is already slow.
                if mst is not None and mst >= 0.16:
                    weakness += 0.24; weak_reasons.append(f"展示F{abs(display_st):.2f}＋節間ST不安")
                else:
                    weakness += 0.06; weak_reasons.append(f"展示F{abs(display_st):.2f}（単独は軽視）")
            elif display_st >= 0.18:
                weakness += 0.22; weak_reasons.append(f"展示ST遅め{display_st:.2f}")
            elif display_st <= 0.10:
                strength += 0.18; strong_reasons.append(f"展示ST良好{display_st:.2f}")

        # Original exhibition is a later confirmation/revival step.  Multiple
        # top-two metrics can rescue 2nd/3rd candidacy without forcing 1st.
        ranks = original_rankings.get(lane) or []
        top2 = sum(1 for x in ranks if int(x.get("rank") or 99) <= 2)
        bottom2 = sum(1 for x in ranks if int(x.get("rank") or 0) >= 5)
        if top2 >= 3:
            strength += 0.34; strong_reasons.append(f"オリジナル展示上位{top2}項目")
        elif top2 >= 2:
            strength += 0.22; strong_reasons.append(f"オリジナル展示上位{top2}項目")
        if bottom2 >= 3:
            weakness += 0.16; weak_reasons.append(f"オリジナル展示下位{bottom2}項目")

        weakness = max(0.0, min(1.0, weakness))
        strength = max(0.0, min(1.0, strength))
        # Combined bad conditions suppress *specific finishing positions*, not
        # merely the overall score.  This is what can remove a weak 1-2/1-3 line.
        if weakness >= 0.85:
            position[lane][1] -= 0.50; position[lane][2] -= 0.55; position[lane][3] -= 0.35
            weak_reasons.append("悪材料重複・強い消し評価")
        elif weakness >= 0.68:
            position[lane][1] -= 0.38; position[lane][2] -= 0.38; position[lane][3] -= 0.12
            weak_reasons.append("1・2着評価を強く下げる")
        elif weakness >= 0.48:
            position[lane][1] -= 0.23; position[lane][2] -= 0.16; position[lane][3] -= 0.06
        elif weakness >= 0.32:
            position[lane][1] -= 0.10; position[lane][2] -= 0.07

        form[lane] = {
            "weakness": round(weakness, 3), "strength": round(strength, 3),
            "weak_reasons": weak_reasons, "strong_reasons": strong_reasons,
            "traits": traits, "meeting": meeting, "display_st": display_st,
            "entry_course": entry_course, "course_avg_st": course_st,
            "exhibition_rank": er or None, "exhibition_time": ex.get("value"),
            "original_top2_count": top2,
        }

    # Initial development is created from racers first.  Venue is only a
    # modifier after that, matching the user's actual prediction workflow.
    escape = _num((venue_profile or {}).get("in_escape_rate"))
    venue_attack_scale = 1.0
    if escape is not None:
        if escape >= 60: venue_attack_scale = 0.86
        elif escape <= 45: venue_attack_scale = 1.14

    attack_candidates = []
    for lane in active:
        if lane < 3:
            continue
        own = form.get(lane) or {}
        inner1 = form.get(lane - 1) or {}
        inner2 = form.get(lane - 2) or {}
        opening = float(inner1.get("weakness") or 0) * 0.72 + float(inner2.get("weakness") or 0) * 0.28
        own_weak = float(own.get("weakness") or 0)
        own_readiness = max(0.05, 0.64 + float(own.get("strength") or 0) * 0.55 - own_weak * 0.78)
        if own_weak >= 0.68:
            own_readiness *= 0.35
        elif own_weak >= 0.48:
            own_readiness *= 0.65
        attack = opening * own_readiness * venue_attack_scale
        # 4-course is the canonical dash attack point; 3/5 can still attack,
        # but require clearer evidence.
        if lane == 4: attack *= 1.10
        elif lane == 5: attack *= 0.92
        elif lane == 6: attack *= 0.72
        if attack < 0.25:
            continue
        attack_candidates.append((lane, attack))
        position[lane][1] += min(0.72, 0.18 + attack * 0.58)
        position[lane][2] += min(0.42, 0.10 + attack * 0.30)
        position[lane][3] += min(0.18, 0.04 + attack * 0.10)
        score_adj[lane] += min(2.4, attack * 2.0)
        reasons = []
        if float(inner1.get("weakness") or 0) >= .32:
            reasons.append(f"{lane-1}号艇の状態不安")
        if float(inner2.get("weakness") or 0) >= .32:
            reasons.append(f"{lane-2}号艇の状態不安")
        events.append({
            "type": "attack", "lane": lane, "strength": round(attack, 3),
            "label": f"{lane}号艇の攻め展開を上方修正",
            "reason": "＋".join(reasons) or "内側艇の状態差",
        })

        # When a center/dash boat attacks, following boats can gain 2nd/3rd
        # routes even if they are not head candidates themselves.
        if lane + 1 in position:
            position[lane + 1][2] += min(.18, attack * .14)
            position[lane + 1][3] += min(.30, attack * .24)
            events.append({"type":"follow", "lane":lane+1, "source_lane":lane,
                           "label":f"{lane+1}号艇は{lane}号艇の攻めに連動して2・3着評価UP"})
        if lane + 2 in position:
            position[lane + 2][3] += min(.18, attack * .14)

    # A credible center attack also lowers the unconditional escape assumption.
    if 1 in position and attack_candidates:
        strongest = max(x[1] for x in attack_candidates)
        if strongest >= .38:
            position[1][1] -= min(.28, strongest * .24)

    for lane in active:
        for place in (1, 2, 3):
            position[lane][place] = round(max(-0.65, min(0.85, position[lane][place])), 4)
        score_adj[lane] = round(max(-2.5, min(2.5, score_adj[lane])), 3)

    primary = max(attack_candidates, key=lambda x: x[1]) if attack_candidates else None
    if primary:
        summary = f"{primary[0]}号艇の攻めを中心に展開警戒"
    else:
        summary = "大きな内側崩れを検出せず、選手状態を優先して通常展開"
    return {
        "logic_version": "v17.178-racer-form-development-2",
        "reasoning_order": [
            "レーサー/コース特徴", "節間成績・節間平均ST", "初期展開予想",
            "場特性", "展示・オリジナル展示", "風・波・潮", "チルト/部品", "当地枠別成績で最終確認"
        ],
        "forms": {str(k): v for k, v in form.items()},
        "position_boosts": {str(k): v for k, v in position.items()},
        "score_adjustments": {str(k): v for k, v in score_adj.items()},
        "events": events,
        "summary": summary,
        "venue_in_escape_rate": escape,
        "venue_attack_scale": round(venue_attack_scale, 3),
    }


def _normalize(scores):
    vals = list(scores.values())
    mn, mx = min(vals), max(vals)
    if mx - mn < 1e-9:
        return {k: 0.5 for k in scores}
    return {k: (v - mn) / (mx - mn) for k, v in scores.items()}


def _softmax(values):
    if not values:
        return {}
    peak = max(values.values())
    exp = {key: math.exp(max(-20.0, min(20.0, value - peak))) for key, value in values.items()}
    total = sum(exp.values()) or 1.0
    return {key: value / total for key, value in exp.items()}


def _day_lane_block(day_venue_trend, lane):
    rows = (day_venue_trend or {}).get("lanes") or {}
    return rows.get(lane) or rows.get(str(lane)) or {}


def _combo_list(scores, active, odds_map=None, limit=None, venue_profile=None,
                race_map=None, day_venue_trend=None, position_boosts=None,
                market_blend=0.0, probability_power=0.86):
    """Build position-specific trifecta probabilities.

    The older model reused one overall boat ranking for 1st/2nd/3rd, which
    made combinations repetitive.  This model estimates each finishing
    position separately, so a lower overall-rated racer with a strong official
    second/third-place course record can still enter the ticket.
    """
    norm = _normalize(scores)
    race_map = race_map or {}
    venue_profile = venue_profile or {}
    position_boosts = position_boosts or {}
    completed = int((day_venue_trend or {}).get("completed_races") or 0)
    escape = _num(venue_profile.get("in_escape_rate"))
    utilities = {place: {} for place in (1, 2, 3)}
    score_weights = {1: 1.35, 2: 1.05, 3: 0.72}

    for lane in active:
        racer = race_map.get(lane) or race_map.get(str(lane)) or {}
        course = _course_stats(racer, lane) or {}
        rates = {
            1: _num(course.get("first_rate")),
            2: _num(course.get("second_rate")),
            3: _num(course.get("third_rate")),
        }
        trio_rate = _num(course.get("trio_rate"))
        day = _day_lane_block(day_venue_trend, lane)
        for place in (1, 2, 3):
            prior = max(0.01, POSITION_PRIOR[place].get(lane, 0.05))
            utility = score_weights[place] * norm[lane] + 0.28 * math.log(prior)
            if rates[place] is not None:
                utility += 1.45 * max(0.0, min(1.0, rates[place] / 100.0))
            # A racer with few wins but a high top-three rate is a natural
            # 2nd/3rd-place candidate. Conversely, a high win share relative
            # to the remaining top-three share is treated as a head candidate.
            if trio_rate is not None and rates[1] is not None:
                supporting_rate = max(0.0, trio_rate - rates[1])
                if place in (2, 3) and rates[1] < 25 and trio_rate >= 55:
                    utility += min(.42, supporting_rate / 100.0 * .65)
                if place == 1 and rates[1] >= 35 and supporting_rate < 25:
                    utility += min(.28, rates[1] / 100.0 * .45)
            utility += float(
                (position_boosts.get(lane) or position_boosts.get(str(lane)) or {}).get(place, 0.0)
                or 0.0
            )

            # Bayes-shrunk same-day evidence.  Four prior pseudo-races stop one
            # early upset from erasing the long-run venue/course information.
            if completed >= 3:
                if place == 1:
                    count = int(_num(day.get("first_count")) or 0)
                    baseline = (escape / 100.0) if lane == 1 and escape is not None else prior
                    baseline = max(.03, min(.90, baseline))
                    posterior = (baseline * 4.0 + count) / (4.0 + completed)
                    utility += max(-.60, min(.48, math.log(max(.01, posterior) / baseline)))
                else:
                    count = int(_num(day.get("top3_count")) or 0)
                    baseline_top3 = max(.12, min(.90, sum(POSITION_PRIOR[p][lane] for p in (1, 2, 3))))
                    posterior = (baseline_top3 * 4.0 + count) / (4.0 + completed)
                    utility += .28 * max(-.50, min(.40, math.log(max(.01, posterior) / baseline_top3)))

            # If the venue is normally strong for the inside but today's
            # confirmed results disagree, a weak B-class or weak-course racer
            # no longer receives an automatic escape assumption.
            if lane == 1 and place == 1 and completed >= 4:
                today_rate = (_num(day.get("first_rate")) or 0.0) / 100.0
                expected = (escape / 100.0) if escape is not None else POSITION_PRIOR[1][1]
                first_rate = rates[1]
                q_rate = _num(course.get("quinella_rate"))
                class_text = str(racer.get("class") or "").upper()
                weak_inside = class_text.startswith("B1") or class_text.startswith("B2")
                weak_inside = weak_inside or (first_rate is not None and first_rate < 45)
                weak_inside = weak_inside or (q_rate is not None and q_rate < 60)
                gap = expected - today_rate
                if weak_inside and gap >= .18:
                    utility -= min(.75, .20 + gap)
            utilities[place][lane] = utility

    probabilities = {place: _softmax(utilities[place]) for place in (1, 2, 3)}
    venue_rates = {
        str(x.get("combo")): _num(x.get("rate"))
        for x in venue_profile.get("popular_combos", [])
        if isinstance(x, dict) and x.get("combo")
    }
    rows = []
    for a, b, c in itertools.permutations(active, 3):
        # Condition each later position on the already used racers.
        p1 = probabilities[1][a]
        p2 = probabilities[2][b] / max(.05, 1.0 - probabilities[2][a])
        p3 = probabilities[3][c] / max(.05, 1.0 - probabilities[3][a] - probabilities[3][b])
        raw_probability = p1 * p2 * p3
        combo = f"{a}-{b}-{c}"
        venue_rate = venue_rates.get(combo)
        if venue_rate is not None:
            raw_probability *= 1.0 + min(.18, max(0.0, venue_rate) * .012)
        odd = (odds_map or {}).get(combo)
        rows.append({
            "combo": combo,
            "raw_probability": raw_probability,
            "odds": odd,
            "venue_rate": venue_rate,
        })
    # v17.256 probability calibration:
    # Hand-built score utilities tend to become over-confident after the
    # three finishing-position distributions are multiplied together. Flatten
    # them before any value calculation.  When a sufficiently complete odds
    # board exists, blend a bounded share of the normalized market-implied
    # distribution. This does not let odds choose the prediction by themselves;
    # it shrinks extreme AI probabilities toward a strong external baseline.
    raw_total = sum(row["raw_probability"] for row in rows) or 1.0
    power = max(0.72, min(1.0, float(probability_power or 0.86)))
    model_weights = []
    for row in rows:
        p = max(1e-12, row["raw_probability"] / raw_total)
        model_weights.append(p ** power)
    model_total = sum(model_weights) or 1.0
    model_probs = [w / model_total for w in model_weights]

    implied = []
    complete_market = sum(1 for row in rows if isinstance(row.get("odds"), (int, float)) and row.get("odds") > 0)
    if complete_market >= max(30, int(len(rows) * 0.65)):
        for row in rows:
            odd = row.get("odds")
            implied.append((1.0 / odd) if isinstance(odd, (int, float)) and odd > 0 else 0.0)
    implied_total = sum(implied)
    blend = max(0.0, min(0.40, float(market_blend or 0.0))) if implied_total > 0 else 0.0

    for idx, row in enumerate(rows):
        probability = model_probs[idx]
        if blend > 0:
            market_p = implied[idx] / implied_total
            probability = (1.0 - blend) * probability + blend * market_p
        row.pop("raw_probability", None)
        row["probability"] = round(probability, 6)
        row["score"] = round(probability, 6)
        odd = row.get("odds")
        row["value_score"] = round(probability * odd, 4) if odd is not None else None
        row["expected_return_index"] = row["value_score"]
        row["probability_calibration"] = {
            "power": power,
            "market_blend": round(blend, 3),
        }
    rows.sort(key=lambda x: x["probability"], reverse=True)
    selected = rows if limit is None else rows[:limit]
    return selected, rows


def _parse_user_insight(note, active):
    """Free text is a capped supporting opinion, never a replacement for data."""
    text = unicodedata.normalize("NFKC", str(note or "")).strip()
    out = {lane: 0.0 for lane in active}
    reasons = {lane: [] for lane in active}
    combos = []
    for m in re.finditer(r"([1-6])\s*[-=→>]\s*([1-6])\s*[-=→>]\s*([1-6])", text):
        nums = [int(m.group(i)) for i in (1, 2, 3)]
        combo = "-".join(map(str, nums))
        if len(set(nums)) == 3 and all(x in active for x in nums) and combo not in combos:
            combos.append(combo)
    positive = ("本命", "軸", "強い", "良い", "買い", "逃げ", "まくり", "差し", "残す", "期待")
    negative = ("弱い", "不安", "消し", "切り", "外す", "厳しい", "遅い", "評価下げ")
    clauses = [x for x in re.split(r"[。.!！?？、,\n]+", text) if x.strip()]
    for lane in active:
        # Sentiment needs an explicit unit. Bare digits inside a combination
        # such as 3-1-4 must never be mistaken for a lane opinion. Keep the
        # judgement inside the same punctuation-delimited clause.
        windows = [c for c in clauses if re.search(rf"(?<!\d){lane}(?:号艇|コース|枠)", c)]
        pos = sum(1 for w in windows if any(k in w for k in positive))
        neg = sum(1 for w in windows if any(k in w for k in negative))
        adj = max(-5.0, min(5.0, (pos-neg) * 2.5))
        if adj:
            out[lane] = adj
            reasons[lane].append(f"自分の見立て {'+' if adj > 0 else ''}{adj:.1f}")
    return {"text": text, "lane_adjustments": out, "reasons": reasons, "combos": combos[:6]}


def _apply_user_combos(rows, combos):
    wanted = set(combos or [])
    if not wanted:
        return rows
    for row in rows:
        if row.get("combo") in wanted:
            row["probability"] = float(row.get("probability") or 0) * 1.12
            row["user_input"] = True
    total = sum(float(row.get("probability") or 0) for row in rows) or 1.0
    for row in rows:
        probability = float(row.get("probability") or 0) / total
        row["probability"] = round(probability, 6)
        row["score"] = row["probability"]
        odd = row.get("odds")
        row["value_score"] = round(probability * odd, 4) if isinstance(odd, (int, float)) and odd > 0 else None
        row["expected_return_index"] = row["value_score"]
    rows.sort(key=lambda x: x["probability"], reverse=True)
    return rows


def _select_picks_with_user(rows, combos, limit=None, coverage_bonus=0.0):
    """Adaptive coverage set plus up to three explicit user combinations."""
    explicit = set((combos or [])[:3])
    selected = []
    cumulative = 0.0
    # Number of tickets changes with uncertainty instead of being fixed at six.
    for row in rows:
        if len(selected) >= 18:
            break
        selected.append(row)
        cumulative += float(row.get("probability") or 0)
        if len(selected) >= 4 and cumulative >= min(.78, .68 + float(coverage_bonus or 0)):
            break
    for combo in (combos or [])[:3]:
        row = next((x for x in rows if x.get("combo") == combo), None)
        if row and not any(x.get("combo") == combo for x in selected):
            selected.append(row)
    return sorted(selected, key=_combo_display_key)


def _combo_display_key(row):
    """艇番順（1着、2着、3着）に買い目を整列する表示用キー。"""
    try:
        values = tuple(int(x) for x in str(row.get("combo") or "").split("-"))
    except (TypeError, ValueError):
        return (99, 99, 99)
    return values if len(values) == 3 else (99, 99, 99)


def _allocate_5000(picks):
    """Allocate a fixed 5,000 yen race budget, preferring stronger positive edges."""
    if not picks:
        return []
    weights=[]
    for x in picks:
        p=float(x.get("probability") or 0); o=float(x.get("odds") or 0)
        edge=max(.02, p*o-1.0)
        weights.append(max(.01, p) * (1.0 + min(2.0, edge)))
    total=sum(weights) or 1.0
    stakes=[max(100, int(round((5000*w/total)/100.0))*100) for w in weights]
    # force exact 5,000 yen while preserving 100-yen units
    diff=5000-sum(stakes)
    order=sorted(range(len(picks)), key=lambda i: weights[i], reverse=(diff>0))
    while diff and order:
        changed=False
        for i in order:
            if diff>0:
                stakes[i]+=100; diff-=100; changed=True
            elif stakes[i]>100:
                stakes[i]-=100; diff+=100; changed=True
            if diff==0: break
        if not changed: break
    return stakes


def _allocate_5000_equal_payout(picks):
    """Dutch a fixed 5,000-yen hit-rate portfolio in 100-yen units.

    The common target gross payout is ``synthetic_odds * 5,000``.  Each ticket
    is first assigned the inverse-odds stake that would hit that target.  When
    the theoretical stake is below the BOAT RACE minimum, keep that combination
    at 100 yen instead of deleting it.  The remaining tickets are then adjusted
    in 100-yen units so the race budget is exactly 5,000 yen while staying as
    close as possible to the common target payout.
    """
    if not picks or len(picks) > 50:
        return []
    odds=[float(x.get("odds") or 0) for x in picks]
    if any((not math.isfinite(o)) or o <= 0 for o in odds):
        return []
    inv=[1.0/o for o in odds]
    invsum=sum(inv)
    if invsum <= 0:
        return []
    # synthetic_odds = 1 / invsum, therefore the ideal common gross payout is
    # synthetic_odds * 5,000 and raw[i] = target_payout / odds[i].
    target_payout=5000.0/invsum
    raw=[target_payout/o for o in odds]
    units_total=50
    raw_units=[x/100.0 for x in raw]
    units=[max(1,int(math.floor(x))) for x in raw_units]
    diff=units_total-sum(units)
    if diff>0:
        order=sorted(range(len(units)), key=lambda i:(raw_units[i]-math.floor(raw_units[i])), reverse=True)
        k=0
        while diff>0 and order:
            units[order[k % len(order)]] += 1
            diff -= 1; k += 1
    elif diff<0:
        # Remove units where rounding down hurts equal-payout least, never below 100 yen.
        while diff<0:
            candidates=[i for i,u in enumerate(units) if u>1]
            if not candidates:
                return []
            i=min(candidates, key=lambda j: abs(((units[j]-1)*100)*odds[j] - target_payout))
            units[i]-=1; diff+=1
    stakes=[u*100 for u in units]
    return stakes if sum(stakes)==5000 else []


def _portfolio_metrics(picks, allocation_mode="edge"):
    stakes=_allocate_5000_equal_payout(picks) if allocation_mode=="equal_payout" else _allocate_5000(picks)
    if not picks or not stakes:
        return {"investment":0,"expected_payout":0,"expected_profit":0,"expected_roi":None,
                "hit_probability":0,"ticket_count":0,"allocation":[]}
    expected=sum(st*float(x.get("probability") or 0)*float(x.get("odds") or 0)
                 for st,x in zip(stakes,picks))
    alloc=[]
    for st,x in zip(stakes,picks):
        y=dict(x); y["stake"]=st; y["expected_profit_contribution"]=round(st*((float(x.get("probability") or 0)*float(x.get("odds") or 0))-1),1)
        alloc.append(y)
    return {"investment":5000,"expected_payout":round(expected,1),"expected_profit":round(expected-5000,1),
            "expected_roi":round(expected/5000*100,1),"hit_probability":round(sum(float(x.get("probability") or 0) for x in picks)*100,2),
            "ticket_count":len(picks),"allocation":alloc}


def strategy_options(rows):
    """Build two different portfolios without collapsing either mode to 1-2 tickets.

    Hit-rate mode keeps the historical synthetic-odds floor (1.5x) but widens
    coverage.  Return-rate mode still prefers positive edge, while requiring a
    practical minimum spread when enough reasonable candidates exist.  The
    result is still capped at 13 tickets for return-rate mode.
    """
    valid=[dict(x) for x in rows if isinstance(x.get("odds"),(int,float)) and math.isfinite(x["odds"]) and x["odds"]>0]

    # 的中率重視:
    # Old logic often selected only a few high-probability combinations because
    # ticket-count penalties dominated.  Search 4..18 tickets, keep the agreed
    # synthetic-odds >= 1.5 condition, and prefer probability coverage around
    # 62-72% rather than simply minimizing ticket count.
    prob_order=sorted(valid,key=lambda x:x.get("probability") or 0,reverse=True)
    hit_best=None
    hit_candidates=[]
    max_hit_n=min(18,len(prob_order))
    min_hit_n=min(4,max_hit_n) if max_hit_n else 0
    for n in range(max(1,min_hit_n),max_hit_n+1):
        picks=prob_order[:n]; m=_portfolio_metrics(picks, allocation_mode="equal_payout")
        if not m.get("allocation"):
            continue
        inv=sum(1/x["odds"] for x in picks if x.get("odds"))
        synthetic=(1/inv) if inv else None
        if synthetic is not None and synthetic < 1.5:
            continue
        coverage=float(m.get("hit_probability") or 0)
        roi=float(m.get("expected_roi") or 0)
        # Coverage is primary.  Once near the desired band, avoid needless
        # expansion while still softly penalising extremely poor EV.
        target_bonus = 10.0 if 62.0 <= coverage <= 75.0 else 0.0
        score = coverage*1.35 + target_bonus - n*0.45 + max(-10.0,min(10.0,roi-100))*0.12
        hit_candidates.append((score,picks,m,synthetic))
        if hit_best is None or score>hit_best[0]: hit_best=(score,picks,m,synthetic)
    # If the 1.5x floor leaves no portfolio at all, preserve a usable fallback.
    if hit_best is None and prob_order:
        for n in range(1,min(10,len(prob_order))+1):
            picks=prob_order[:n]; m=_portfolio_metrics(picks, allocation_mode="equal_payout")
            if not m.get("allocation"):
                continue
            score=float(m.get("hit_probability") or 0)-n*.5
            if hit_best is None or score>hit_best[0]:
                inv=sum(1/x["odds"] for x in picks if x.get("odds"))
                hit_best=(score,picks,m,(1/inv if inv else None))

    # 回収率重視:
    # Keep the 13-ticket ceiling, but stop making one/two-ticket portfolios the
    # default.  Start with positive-edge candidates, then extend with the best
    # near-break-even candidates so 4+ tickets can be evaluated.  We only prefer
    # the wider portfolio when its expected ROI remains at least 100%.
    ranked_value=sorted(
        valid,
        key=lambda x:((x.get("expected_return_index") or 0)-1)*math.sqrt(max(.0001,x.get("probability") or 0)),
        reverse=True,
    )
    value_order=[x for x in ranked_value if (x.get("expected_return_index") or 0)>=1.06 and (x.get("probability") or 0)>=.0035]
    if len(value_order)<4:
        seen={x.get("combo") for x in value_order}
        for x in ranked_value:
            if x.get("combo") in seen:
                continue
            if (x.get("expected_return_index") or 0) < .98 or (x.get("probability") or 0) < .003:
                continue
            value_order.append(x); seen.add(x.get("combo"))
            if len(value_order)>=6:
                break
    ret_best=None
    ret_fallback=None
    for n in range(1,min(13,len(value_order))+1):
        picks=value_order[:n]; m=_portfolio_metrics(picks)
        score=(m["expected_profit"] or -9999)/100.0 + m["hit_probability"]*.16 - n*.65
        row=(score,picks,m,None)
        if ret_fallback is None or score>ret_fallback[0]: ret_fallback=row
        # Prefer at least four tickets when the wider set is not negative EV.
        if n>=4 and (m.get("expected_roi") or 0)>=102:
            if ret_best is None or score>ret_best[0]: ret_best=row
    if ret_best is None:
        ret_best=ret_fallback

    def pack(best,name):
        if not best:
            return {"label":name,"picks":[],"synthetic_odds":None,"status":"条件未達・見送り","allocation":"1レース5,000円"}
        _,picks,m,*rest=best
        inv=sum(1/x["odds"] for x in picks)
        status="候補あり"
        if name=="回収率重視" and ((m["expected_roi"] or 0)<108 or (m["expected_profit"] or 0)<400): status="期待利益不足・見送り"
        return {"label":name,"picks":sorted(m["allocation"],key=_combo_display_key),"synthetic_odds":1/inv if inv else None,
                "status":status,"allocation":"AI配分・合計5,000円（100円単位）",**{k:v for k,v in m.items() if k!="allocation"}}
    return {"hit":pack(hit_best,"的中率重視"),"return":pack(ret_best,"回収率重視"),
            "all_combinations":len(rows),"probability_total":round(sum(float(x.get("probability") or 0) for x in rows),6)}


def _bet_recommendation(stage, *, post_ready=False, stage_name="pre"):
    """Decide whether the race is suitable for an AI bet without result data.

    The decision intentionally uses only information available before closing:
    model confidence, missing inputs, probability concentration, ticket count,
    and synthetic odds.  It never reads the winning combination.
    """
    strategies = stage.get("strategies") or {}
    hit = strategies.get("hit") or {}
    picks = hit.get("picks") or []
    confidence = float(stage.get("confidence") or 0)
    missing = list(stage.get("missing") or [])
    cumulative = sum(float(x.get("probability") or 0) for x in picks if isinstance(x, dict))
    synthetic = _num(hit.get("synthetic_odds"))
    reasons = []
    required_confidence = 68.0 if stage_name == "post" else 74.0
    missing_limit = 4 if stage_name == "post" else 1
    recommended = True
    if stage_name == "post" and not post_ready:
        recommended = False
        reasons.append("直前のST・風・波が未完成")
    if confidence < required_confidence:
        recommended = False
        reasons.append(f"信頼度{confidence:.1f}%が基準{required_confidence:.0f}%未満")
    if len(missing) > missing_limit:
        recommended = False
        reasons.append(f"不足情報が{len(missing)}項目")
    if not picks:
        recommended = False
        reasons.append("締切前オッズで買い目を作れない")
    elif cumulative < .48:
        recommended = False
        reasons.append(f"買い目の予測確率合計が{cumulative*100:.1f}%")
    if synthetic is None or synthetic < 1.5:
        recommended = False
        reasons.append("合成オッズ1.5倍未満または未取得")
    if len(picks) > 12:
        recommended = False
        reasons.append(f"買い目が{len(picks)}点で広すぎる")
    if recommended:
        reasons = [
            f"信頼度{confidence:.1f}%",
            f"予測確率合計{cumulative*100:.1f}%",
            f"合成オッズ{synthetic:.2f}倍",
            f"不足情報{len(missing)}項目",
        ]
    return {
        "recommended": recommended,
        "label": "買うべき候補" if recommended else "見送り",
        "reasons": reasons,
        "confidence_threshold": required_confidence,
        "probability_coverage": round(cumulative, 4),
        "ticket_count": len(picks),
        "synthetic_odds": synthetic,
    }


def _scenario_candidates(rows, race_map, limit=3):
    """Show several plausible race developments instead of one fixed story."""
    leaders = []
    for row in sorted(rows or [], key=lambda x: float(x.get("probability") or 0), reverse=True):
        try:
            first = int(str(row.get("combo") or "").split("-")[0])
        except (ValueError, IndexError):
            continue
        if first in leaders:
            continue
        leaders.append(first)
        if len(leaders) >= limit:
            break
    output = []
    for lane in leaders:
        racer = race_map.get(lane) or {}
        name = racer.get("name") or f"{lane}号艇"
        development = "イン逃げ" if lane == 1 else "差し" if lane == 2 else "センター攻め" if lane in (3, 4) else "外枠攻め"
        output.append({"first_lane": lane, "label": f"{lane}号艇{name}の{development}"})
    return output


def _scenario(scores, race_map, weather=None, venue_profile=None):
    order = sorted(scores, key=lambda x: scores[x], reverse=True)
    a, b, c = order[:3]
    an = (race_map.get(a) or {}).get("name") or f"{a}号艇"
    bn = (race_map.get(b) or {}).get("name") or f"{b}号艇"

    if a == 1:
        text = f"1号艇{an}を中心にイン先マイ想定。相手筆頭は{b}号艇{bn}、次位は{c}号艇。"
    elif a in (3, 4):
        text = f"{a}号艇{an}のセンター攻めを軸に想定。{b}号艇{bn}を対抗、1号艇の残しも警戒。"
    else:
        text = f"{a}号艇{an}を総合首位評価。{b}号艇{bn}との主導権争いを想定。"

    # v17.169: raw weather is intentionally not folded into the AI scenario.
    # Stage 3 displays/saves it; Stage 4 will add the validated combined result.

    vp = venue_profile or {}
    if vp.get("direction"):
        text += " 場傾向：" + vp["direction"] + "。"

    return text


def predict(date, jcd, rno, race, before, odds, venue_documents, *,
            mode="balanced", preview=False, user_insight="",
            day_venue_trend=None, learning_feedback=None, tilt_performance=None,
            water_condition=None):
    race = race or {}
    before = before or {}
    race_map = _lane_map(race.get("racers") or [])
    before_map = _lane_map(before.get("racers") or [])
    start_map = _lane_map(before.get("start_display") or [])
    original_map = _lane_map(before.get("original_exhibition") or [])
    weather = before.get("weather") or {}
    comments = before.get("comments") or []
    odds_map = _extract_odds(odds)

    venue_profile = build_venue_profile(venue_documents)
    availability = build_availability(
        race, before, odds, venue_documents, venue_profile, day_venue_trend, water_condition
    )

    active = [
        lane for lane, r in race_map.items()
        if not r.get("scratched") and str(r.get("status") or "") != "欠場"
    ]
    insight = _parse_user_insight(user_insight, active)
    learning_feedback = learning_feedback or {}
    if len(active) < 3:
        empty_stage = {
            "confidence": 0,
            "scenario": "出走データ不足",
            "picks": [],
            "lane_scores": {},
            "missing": ["出走データ不足"],
        }
        return {
            "confidence": 0,
            "judgement": "見送り",
            "scenario": "出走データ不足",
            "main_picks": [],
            "value_picks": [],
            "leaks": ["出走データ不足"],
            "source_snapshot": {
                "engine": "AI Racer-Form Calibrated Model v5 / v17.257",
                "pre_prediction": empty_stage,
                "post_prediction": empty_stage,
                "availability": availability,
                "venue_profile": venue_profile,
                "post_ready": False,
            },
            "ai_comment": "AI Racer-Form Development Model v4",
        }

    # ---------- PRE-BEFORE ----------
    pre_scores = {}
    pre_details = {}
    for lane in active:
        score, reasons = _pre_lane_score(lane, race_map[lane])
        score += insight["lane_adjustments"].get(lane, 0.0)
        reasons += insight["reasons"].get(lane, [])
        pre_scores[lane] = score
        pre_details[lane] = {
            "lane": lane,
            "name": race_map[lane].get("name"),
            "score": round(score, 2),
            "reasons": reasons,
        }

    # Only bounded corrections learned from already-confirmed earlier races.
    for lane, adj in (learning_feedback.get("score_adjustments") or {}).items():
        # Historical rows can include a non-racing marker such as "欠場".
        # It is not a boat number and must never abort a prediction for the
        # other five boats.
        parsed_lane = _num(lane)
        if parsed_lane is None or not 1 <= int(parsed_lane) <= 6:
            continue
        lane = int(parsed_lane)
        if lane in pre_scores:
            pre_scores[lane] += float(adj)
            pre_details[lane]["score"] = round(pre_scores[lane], 2)
            pre_details[lane]["reasons"].append(f"結果振り返り補正 +{float(adj):.2f}")

    venue_adjustments = _venue_lane_adjustments(active, venue_profile)
    for lane in active:
        adj = venue_adjustments.get(lane) or {}
        pre_scores[lane] += float(adj.get("score") or 0)
        pre_details[lane]["score"] = round(pre_scores[lane], 2)
        pre_details[lane]["reasons"] = (
            pre_details[lane]["reasons"] + (adj.get("reasons") or [])
        )[:12]

    completed_today = int((day_venue_trend or {}).get("completed_races") or 0)
    if completed_today >= 3:
        for lane in active:
            day_lane = _day_lane_block(day_venue_trend, lane)
            if day_lane:
                pre_details[lane]["reasons"].append(
                    f"当日{completed_today}R時点 {lane}号艇1着{day_lane.get('first_count', 0)}回・3連対{day_lane.get('top3_count', 0)}回"
                )

    pre_picks, all_pre = _combo_list(
        pre_scores, active, odds_map=odds_map,
        venue_profile=venue_profile,
        race_map=race_map,
        day_venue_trend=day_venue_trend,
        market_blend=0.30, probability_power=0.86,
    )
    all_pre = _apply_user_combos(all_pre, insight["combos"])
    pre_picks = _select_picks_with_user(all_pre, insight["combos"], coverage_bonus=learning_feedback.get("coverage_bonus", 0))
    pre_missing_keys = {
        "meeting_results": "節間成績",
        "national_lane_results": "全国成績（当該枠/コースデータ優先）",
        "local_lane_results": "当地同枠成績（保存済み公式結果から集計）",
        "motor": "モーター成績",
        "boat": "ボート成績",
    }
    available_map = {x["key"]: x["available"] for x in availability}
    pre_missing = [
        label for key, label in pre_missing_keys.items()
        if not available_map.get(key)
    ]

    pre_order = sorted(pre_scores, key=lambda x: pre_scores[x], reverse=True)
    pre_margin = pre_scores[pre_order[0]] - pre_scores[pre_order[1]]
    pre_conf = max(30, min(88, 48 + pre_margin * 1.4))
    pre_conf *= 1 - min(0.10 * len(pre_missing), 0.45)
    pre_conf = round(pre_conf, 1)

    pre_stage = {
        "confidence": pre_conf,
        "scenario": _scenario(pre_scores, race_map, None, venue_profile),
        "picks": pre_picks,
        "strategies": strategy_options(all_pre),
        "lane_scores": pre_details,
        "missing": pre_missing,
        "basis": [
            "節間成績", "全国成績（当該枠/コース優先）",
            "当地同枠成績", "モーター", "ボート",
            "場別イン・決まり手・出目傾向",
            "当日の同場で確定済みの前レース結果",
            "1着・2着・3着を別々に推定する確率モデル",
            "自分の見立て（入力時のみ・補助点）",
        ],
    }
    pre_stage["scenarios"] = _scenario_candidates(all_pre, race_map)
    pre_stage["bet_decision"] = _bet_recommendation(
        pre_stage, post_ready=False, stage_name="pre"
    )

    # ---------- POST-BEFORE ----------
    post_scores = dict(pre_scores)
    post_details = {k: dict(v) for k, v in pre_details.items()}
    original_rel, original_position_boosts, original_rankings = _original_relative_adjustments(
        before.get("original_exhibition") or []
    )
    tilt_position_boosts = {}

    for lane in active:
        adj, rs, position_boost = _post_adjustment(
            lane, race_map[lane], before_map.get(lane, {}),
            start_map.get(lane, {}), original_map.get(lane, {}),
            weather, comments, tilt_performance
        )
        merged_position_boost = dict(position_boost or {})
        for place, boost in (original_position_boosts.get(lane) or {}).items():
            merged_position_boost[place] = float(merged_position_boost.get(place) or 0.0) + float(boost or 0.0)
        tilt_position_boosts[lane] = merged_position_boost
        adj += original_rel.get(lane, 0.0)
        ranks = original_rankings.get(lane) or []
        if ranks:
            top = [x for x in ranks if int(x.get("rank") or 99) <= 2]
            if top:
                rs.append("オリジナル展示上位:" + "・".join(f"{x['metric']}{x['rank']}位" for x in top[:4]))
        post_scores[lane] += adj
        post_details[lane]["score"] = round(post_scores[lane], 2)
        post_details[lane]["reasons"] = (
            post_details[lane].get("reasons", []) + rs
        )[:12]

    # v17.174: build the race development from racer traits/current form first.
    # This is an interaction layer: a weak inner boat can create an attacking
    # route for the dash boat outside it, and followers can gain 2nd/3rd routes.
    development = _current_form_development(
        active, race_map, before_map, start_map, original_rankings, venue_profile
    )
    for lane in active:
        dev_score = float((development.get("score_adjustments") or {}).get(str(lane), 0.0) or 0.0)
        post_scores[lane] += dev_score
        dev_pos = (development.get("position_boosts") or {}).get(str(lane)) or {}
        merged = tilt_position_boosts.setdefault(lane, {1: 0.0, 2: 0.0, 3: 0.0})
        for place in (1, 2, 3):
            merged[place] = float(merged.get(place) or 0.0) + float(dev_pos.get(place) or dev_pos.get(str(place)) or 0.0)
        form = (development.get("forms") or {}).get(str(lane)) or {}
        dev_reasons = []
        if float(form.get("weakness") or 0) >= .32:
            dev_reasons.append("現況不安:" + "・".join((form.get("weak_reasons") or [])[:3]))
        if float(form.get("strength") or 0) >= .32:
            dev_reasons.append("現況好材料:" + "・".join((form.get("strong_reasons") or [])[:3]))
        for event in development.get("events") or []:
            if int(_num(event.get("lane")) or 0) == lane:
                dev_reasons.append(str(event.get("label") or "展開連鎖"))
        post_details[lane]["score"] = round(post_scores[lane], 2)
        post_details[lane]["reasons"] = (post_details[lane].get("reasons", []) + dev_reasons)[:14]

    # Stage 4 water is deliberately later and weaker than racer/current-form
    # development. Missing/held water data applies no correction.
    water_adjustments, water_ai_applied = _stage4_water_adjustments(active, water_condition)
    for lane in active:
        wadj = water_adjustments.get(lane) or {}
        post_scores[lane] += float(wadj.get("score") or 0.0)
        post_details[lane]["score"] = round(post_scores[lane], 2)
        post_details[lane]["reasons"] = (
            post_details[lane].get("reasons", []) + (wadj.get("reasons") or [])
        )[:12]

    post_picks, all_post = _combo_list(
        post_scores, active, odds_map=odds_map,
        venue_profile=venue_profile,
        race_map=race_map,
        day_venue_trend=day_venue_trend,
        position_boosts=tilt_position_boosts,
        market_blend=0.20, probability_power=0.88,
    )
    all_post = _apply_user_combos(all_post, insight["combos"])
    post_picks = _select_picks_with_user(all_post, insight["combos"], coverage_bonus=learning_feedback.get("coverage_bonus", 0))
    post_strategies = strategy_options(all_post)
    value = post_strategies["return"]["picks"]

    post_required = {
        "tilt": "チルト",
        "start_exhibition_st": "スタート展示ST",
        "start_entry": "スタート展示進入/STタイミング",
        "original_exhibition": "オリジナル展示",
    }
    # Comments are currently an official-site pilot for Toda only.  Do not
    # penalize the other 23 venues for an adapter that does not exist yet.
    if str(jcd).zfill(2) == "02":
        post_required["comments"] = "選手コメント"
    post_missing = [
        label for key, label in post_required.items()
        if not available_map.get(key)
    ]

    post_order = sorted(post_scores, key=lambda x: post_scores[x], reverse=True)
    margin = post_scores[post_order[0]] - post_scores[post_order[1]]
    confidence = max(32, min(92, 54 + margin * 1.5))
    confidence *= 1 - min(0.055 * len(post_missing), 0.42)
    confidence = round(confidence, 1)

    # v17.169: Stage 3 water data must not gate AI readiness before Stage 4.
    post_ready = bool(available_map.get("start_exhibition_st"))

    post_stage = {
        "confidence": confidence,
        "scenario": (development.get("summary") or _scenario(post_scores, race_map, weather, venue_profile)),
        "picks": post_picks,
        "strategies": post_strategies,
        "lane_scores": post_details,
        "missing": post_missing,
        "basis": [
            "レーサー/コース特徴 → 節間成績・節間平均ST → 展開連鎖",
            "展示タイム・スタート展示ST/進入",
            "場特性は選手から作った展開を補正",
            "オリジナル展示は順位＋タイム差で2・3着候補も再評価",
            "チルト（-0.5/0/+0.5は評価点なし、高チルトのみ補助）",
            "選手コメント（現在は戸田公式パイロットのみ）",
            "潮×風×場特性の複合水面判定（第4段階・弱補正）",
            "場別イン・決まり手・出目傾向",
            "当日の同場で確定済みの前レース結果",
            "選手別コース1着・2着・3着率",
            "自分の見立て（入力時のみ・補助点）",
        ],
        "ready": post_ready,
    }
    post_stage["scenarios"] = _scenario_candidates(all_post, race_map)
    post_stage["bet_decision"] = _bet_recommendation(
        post_stage, post_ready=post_ready, stage_name="post"
    )

    judgement = post_stage["bet_decision"]["label"]

    leaks = [x["label"] for x in availability if not x["available"]]

    snapshot = {
        "engine": "AI Racer-Form Calibrated Model v5 / v17.257",
        "generated_at": datetime.now(JST).isoformat(),
        "preview": bool(preview),
        "mode": mode,
        "pre_prediction": pre_stage,
        "post_prediction": post_stage,
        "availability": availability,
        "venue_profile": venue_profile,
        "day_venue_trend": day_venue_trend or {},
        "learning_feedback": learning_feedback,
        "water_condition": {**(water_condition or {}), "ai_applied": bool(water_ai_applied)},
        "water_adjustments": {str(k): v for k, v in water_adjustments.items()},
        "original_exhibition_rankings": {str(k): v for k, v in original_rankings.items()},
        "original_exhibition_position_boosts": {str(k): v for k, v in original_position_boosts.items()},
        "race_development": development,
        "prediction_reasoning_order": development.get("reasoning_order") or [],
        "method_sources": MODEL_SOURCES,
        "post_ready": post_ready,
        "user_insight": insight,
    }

    return {
        "confidence": confidence,
        "judgement": judgement,
        "scenario": post_stage["scenario"],
        "main_picks": post_picks,
        "value_picks": value,
        "leaks": leaks,
        "source_snapshot": snapshot,
        "ai_comment": (
            "レーサー特徴と今節状態から展開を組み立て、展示・場・水面・当地実績で再調整。×の項目は予想根拠に使用していません。"
            "予想・利益を保証するものではありません。"
        ),
    }
