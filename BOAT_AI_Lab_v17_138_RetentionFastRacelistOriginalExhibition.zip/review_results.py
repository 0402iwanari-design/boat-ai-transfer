from datetime import datetime, timezone, timedelta
import re

JST = timezone(timedelta(hours=9))

def combo(value):
    nums = re.findall(r"[1-6]", str(value or ""))
    return "-".join(nums) if len(nums) == 3 and len(set(nums)) == 3 else None

def timely(raw, date, deadline, utc=False):
    if not raw or not deadline:
        return False
    try:
        dt = datetime.fromisoformat(raw)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc if utc else JST)
        end = datetime.strptime(date + " " + deadline, "%Y%m%d %H:%M").replace(tzinfo=JST)
        return dt < end
    except (ValueError, TypeError):
        return False

def build_review(db, date, venues):
    schedule = db.get_day_schedule(date)
    with db.connect() as con:
        keys = con.execute("SELECT jcd,rno FROM predictions WHERE date=? UNION SELECT jcd,rno FROM race_results WHERE date=?", (date,date)).fetchall()
    known = {(str(x["jcd"]).zfill(2), int(x["rno"])) for x in keys}
    for code, races in schedule.items():
        known.update((code, int(x["rno"])) for x in races)
    groups = []
    for venue in venues:
        code = str(venue["code"]).zfill(2)
        venue_known = any(x[0] == code for x in known)
        if not venue_known:
            continue
        rows = []
        deadlines = {int(x["rno"]):x.get("deadline") for x in schedule.get(code, [])}
        # A venue card always opens the familiar 1R through 12R grid, including
        # races whose prediction/result is still waiting or missing.
        for rno in range(1, 13):
            pred = db.get_prediction(date,code,rno) or {}
            snap = pred.get("source_snapshot") or {}
            result = db.get_result_for_race_db(date,code,rno) or {}
            actual = combo(result.get("trifecta"))
            confirmed = (
                actual is not None and result.get("payout_yen") is not None
            ) or bool(result.get("result_confirmed"))
            stages = []
            for key,label in (("pre_prediction","PRE"),("post_prediction","POST")):
                stage = snap.get(key) or {}
                stamp = (snap.get("pre_saved_at") if label == "PRE" else None) or snap.get("generated_at") or pred.get("created_at")
                valid = timely(stamp,date,deadlines.get(rno),utc=not snap.get("generated_at")) and timely(pred.get("created_at"),date,deadlines.get(rno),utc=True) and not snap.get("preview")
                if label == "POST" and not snap.get("post_ready"):
                    stage = {}
                options = stage.get("strategies") or {}
                for mode, option in options.items():
                    picks = [combo(x.get("combo") if isinstance(x,dict) else x) for x in option.get("picks",[])]
                    picks = list(dict.fromkeys(x for x in picks if x))
                    mode_stamp = stage.get("strategies_saved_at") or stamp
                    eligible = valid and (mode == "base" or timely(mode_stamp,date,deadlines.get(rno)))
                    status = (option.get("status") or "予想なし") if not picks else ("締切前保存を確認できず・集計対象外" if not eligible else ("3連単不成立・集計対象外" if confirmed and not actual else ("的中" if actual in picks else "不的中") if confirmed else "結果待ち"))
                    stages.append({"stage":label,"mode":mode,"label":option["label"],"picks":picks,"status":status,"saved_at":mode_stamp if mode != "base" else stamp,"synthetic_odds":option.get("synthetic_odds"),"evaluated":bool(picks and eligible and confirmed)})
            rows.append({
                "rno": rno,
                "deadline": deadlines.get(rno),
                "actual": actual,
                "payout_yen": result.get("payout_yen"),
                "result_odds": result.get("odds"),
                "popularity": result.get("popularity"),
                "kimarite": result.get("kimarite"),
                "result_confirmed": bool(result.get("result_confirmed")),
                "result_status": result.get("result_status"),
                "finishers": result.get("finishers") or [],
                "stages": stages,
                "ai_hits": [f"{'事前' if x['stage']=='PRE' else '直前'}・{x['label']}" for x in stages if x["status"] == "的中"],
            })
        groups.append({"code":code,"name":venue["name"],"races":rows})
    return {"date":date,"venues":groups}
