from __future__ import annotations

import json
import os
import time
from pathlib import Path

import hashlib

def _safe_name(key: str) -> str:
    """
    Convert arbitrary cache keys (including full URLs) to a Windows-safe filename.
    """
    raw = str(key).encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()

from typing import Any, Optional


class FileCache:
    def __init__(self, directory: str | None = None):
        if directory is None:
            local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
            self.dir = Path(local_app) / "BOAT_AI_Lab" / "cache"
        else:
            self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        safe = key.replace("/", "_").replace("?", "_").replace("&", "_").replace("=", "_")
        return self.dir / f"{safe}.json"

    def get(self, key: str, ttl_seconds: int) -> Optional[Any]:
        path = self._path(key)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if time.time() - payload["saved_at"] > ttl_seconds:
                return None
            return payload["data"]
        except Exception:
            return None

    def set(self, key: str, data: Any) -> None:
        path = self._path(key)
        tmp = path.with_suffix(".tmp")
        payload = {"saved_at": time.time(), "data": data}
        tmp.write_text(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )
        tmp.replace(path)

    def cleanup_expired(self, max_age_days: int = 7, temp_age_hours: int = 1) -> dict:
        """Delete stale display/HTTP caches; saved SQLite data is untouched."""
        now = time.time()
        normal_age = max(1, int(max_age_days)) * 24 * 60 * 60
        temp_age = max(1, int(temp_age_hours)) * 60 * 60
        deleted = 0
        failed = 0
        for path in self.dir.iterdir():
            if not path.is_file():
                continue
            limit = temp_age if path.suffix == ".tmp" else normal_age
            try:
                if now - path.stat().st_mtime > limit:
                    path.unlink()
                    deleted += 1
            except OSError:
                failed += 1
        return {"deleted": deleted, "failed": failed}
