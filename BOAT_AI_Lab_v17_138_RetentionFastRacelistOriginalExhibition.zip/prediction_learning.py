"""Result-based prediction review and bounded, leakage-safe feedback."""
from collections import Counter
from review_results import build_review


def _lane_rank(pred, actual):
    snap = (pred or {}).get("source_snapshot") or {}
    ranks = []
    for key, label in (("pre_prediction", "事前"), ("post_prediction", "直前")):
        stage = snap.get(key) or {}
        scores = stage.get("lane_scores") or {}
        ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
        rank = next((i + 1 for i, x in enumerate(ordered) if int(x.get("lane") or 0) == int(actual)), None)
        if rank:
            ranks.append({"stage": label, "rank": rank})
    return ranks


def analyze_race(db, date, code, venue, race):
    actual = race.get("actual")
    if not actual:
        return None
    pred = db.get_prediction(date, code, race["rno"]) or {}
    hits = race.get("ai_hits") or []
    first = int(actual.split("-")[0])
    ranks = _lane_rank(pred, first)
    best_rank = min((x["rank"] for x in ranks), default=None)
    evaluated = [x for x in race.get("stages", []) if x.get("evaluated")]
    all_picks = {p for x in evaluated for p in x.get("picks", [])}
    if hits:
        category = "的中"
        analysis = "確定出目を締切前の買い目に含められました。"
        improvement = "的中した評価経路を記録し、同じ条件で再現できるか継続確認します。"
    elif actual in all_picks:
        category = "買い目選択漏れ"
        analysis = "確定出目は候補内にありましたが、最終的な買い方から漏れました。"
        improvement = "候補確率が接近したレースでは合成オッズ条件を守りながら買い目範囲を広げます。"
    elif best_rank is not None and best_rank <= 2:
        category = "相手構成漏れ"
        analysis = "1着艇は上位評価できていましたが、2・3着の組み合わせを拾えませんでした。"
        improvement = "1着率が低く3連対率が高い選手を、2・3着付け候補として優先的に残します。"
    else:
        category = "1着評価不足"
        analysis = f"実際の1着・{first}号艇を十分高く評価できませんでした。"
        improvement = "実際の1着艇のコース1着率、ST、チルト、当日傾向と決まり手を再評価します。"
    kimarite = race.get("kimarite") or "不明"
    lesson = {
        "逃げ": "1コース本人実績と当日イン状況の重みを再確認",
        "差し": "2コース差しと内側のST差を再確認",
        "まくり": "外側のST・チルト・攻め実績を再確認",
        "まくり差し": "3〜6コースの攻め足と展開相手を再確認",
    }.get(kimarite, "着順別評価と組み合わせ範囲を再確認")
    return {
        "date": date, "jcd": code, "venue": venue, "rno": race["rno"],
        "actual": actual, "odds": race.get("result_odds"),
        "popularity": race.get("popularity"), "kimarite": kimarite,
        "hit": bool(hits), "hit_methods": hits, "category": category,
        "analysis": analysis, "reflection": analysis,
        "improvement": improvement, "lesson": lesson, "first_lane": first,
        "first_lane_ranks": ranks, "evaluated_methods": len(evaluated),
    }


def build_learning_report(db, date, venues):
    review = build_review(db, date, venues)
    rows = []
    for venue in review.get("venues", []):
        for race in venue.get("races", []):
            item = analyze_race(db, date, venue["code"], venue["name"], race)
            if item:
                rows.append(item)
    categories = Counter(x["category"] for x in rows)
    misses = [x for x in rows if not x["hit"]]
    today_reflections = [
        {"venue": x["venue"], "rno": x["rno"], "actual": x["actual"],
         "reflection": x["reflection"], "improvement": x["improvement"],
         "kimarite": x["kimarite"]}
        for x in misses
    ]
    return {
        "date": date, "summary": {"analyzed": len(rows), "hits": len(rows)-len(misses),
        "misses": len(misses), "categories": dict(categories)},
        "records": sorted(rows, key=lambda x: (x["jcd"], x["rno"])),
        "today_reflections": today_reflections,
        "policy": "予想時点より前に確定した結果だけを使い、十分な件数がある傾向のみ小幅補正します。",
    }


def feedback_before(db, date, jcd, rno):
    """Aggregate only earlier confirmed races. Never reads a future result."""
    with db.connect() as con:
        rows = con.execute("""
          SELECT rr.date,rr.jcd,rr.rno,rr.trifecta,rr.kimarite,p.source_snapshot
          FROM race_results rr JOIN predictions p
            ON p.date=rr.date AND p.jcd=rr.jcd AND p.rno=rr.rno
          WHERE rr.trifecta IS NOT NULL AND
            (rr.date < ? OR (rr.date=? AND rr.jcd=? AND rr.rno < ?))
          ORDER BY rr.date DESC,rr.rno DESC LIMIT 120
        """, (date,date,str(jcd).zfill(2),int(rno))).fetchall()
    misses = Counter(); selection = 0; total = 0; miss_total = 0; source_dates = set()
    import json, re
    for row in rows:
        nums = re.findall(r"[1-6]", str(row["trifecta"] or ""))
        if len(nums) != 3: continue
        total += 1; first = int(nums[0]); source_dates.add(str(row["date"]))
        try: snap = json.loads(row["source_snapshot"] or "{}")
        except Exception: snap = {}
        stage = snap.get("post_prediction") or snap.get("pre_prediction") or {}
        picks = {str(x.get("combo") if isinstance(x,dict) else x) for x in stage.get("picks", [])}
        if "-".join(nums) not in picks:
            miss_total += 1
            scores = stage.get("lane_scores") or {}
            ordered = sorted(scores.values(), key=lambda x: float(x.get("score") or 0), reverse=True)
            rank = next((i+1 for i,x in enumerate(ordered) if int(x.get("lane") or 0)==first), 9)
            if rank <= 2: selection += 1
            else: misses[first] += 1
    base = {
        "sample_size": total, "miss_count": miss_total,
        "selection_gap_count": selection,
        "ranking_miss_by_lane": dict(misses),
        "source_date_from": min(source_dates) if source_dates else None,
        "source_date_to": max(source_dates) if source_dates else None,
    }
    if total < 3:
        return {**base, "score_adjustments": {}, "coverage_bonus": 0,
                "active": False, "inactive_reason": "確定済みの照合対象が3レース未満のため、過学習防止で補正を保留"}
    adjustments = {
        lane: round(min(1.2, count / total * 4), 2)
        for lane,count in misses.items() if count >= 1
    }
    coverage_bonus = round(min(.08, selection / total * .12), 3)
    improvements = []
    for lane, value in sorted(adjustments.items()):
        improvements.append(f"{lane}号艇の1着評価を+{value:.2f}点補正")
    if coverage_bonus:
        improvements.append(f"相手・買い目の累積確率範囲を+{coverage_bonus*100:.1f}%拡張")
    active = bool(adjustments or coverage_bonus)
    return {**base, "score_adjustments": adjustments,
            "coverage_bonus": coverage_bonus, "active": active,
            "applied_improvements": improvements,
            "inactive_reason": None if active else "不的中原因に継続補正が必要な傾向はありません"}
