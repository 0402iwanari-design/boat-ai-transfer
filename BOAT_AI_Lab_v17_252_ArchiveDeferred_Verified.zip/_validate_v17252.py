from pathlib import Path
import tempfile
from db import BoatDB
from course_history import OfficialCourseHistoryCollector
from ai_predictor import _allocate_5000_equal_payout

root=Path(__file__).parent


# 0) Migration: v17.251-style transient archive errors become complete+deferred immediately.
dbfile0 = Path(tempfile.mkdtemp())/'migrate.db'
db0 = BoatDB(str(dbfile0))
# create schema first, then emulate an old pending row and rerun migration
c0 = OfficialCourseHistoryCollector(db0)
with db0.connect() as con:
    con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,retry_count,last_error,cursor_year,started_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                ('5396','近藤来希','pending',1,'2026年一時通信障害: ConnectTimeout: boatrace-db.net',2026))
c0._ensure_tables()
with db0.connect() as con:
    old=con.execute("SELECT status,last_error FROM course_history_initial_racers WHERE registration_no='5396'").fetchone()
    dq0=con.execute("SELECT failed_year,last_error FROM course_history_archive_deferred WHERE registration_no='5396'").fetchone()
assert old['status']=='complete' and old['last_error'] is None, dict(old)
assert dq0 and dq0['failed_year']==2026 and 'ConnectTimeout' in dq0['last_error'], dict(dq0)

dbfile = Path(tempfile.mkdtemp())/'t.db'
db = BoatDB(str(dbfile))
c = OfficialCourseHistoryCollector(db)

# 1) v17.252 deferred table exists and a source outage no longer leaves racer in error/pending.
with db.connect() as con:
    con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,retry_count,last_error,cursor_year,target_date,started_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)",
                ('5448','福田柊人','running',1,'2026年一時通信障害: ConnectTimeout',2026,'20261002'))
c._mark_archive_deferred_complete('5448', 2026, '2026年一時通信障害: ConnectTimeout')
with db.connect() as con:
    st=con.execute("SELECT status,retry_count,last_error,recent_done,cursor_year FROM course_history_initial_racers WHERE registration_no='5448'").fetchone()
    dq=con.execute("SELECT registration_no,failed_year,last_error FROM course_history_archive_deferred WHERE registration_no='5448'").fetchone()
assert st['status']=='complete', dict(st)
assert st['retry_count']==1, dict(st)  # no artificial increment
assert st['last_error'] is None, dict(st)
assert st['recent_done']==1, dict(st)
assert st['cursor_year']==2026, dict(st)  # exact failed year retained for resume
assert dq and dq['failed_year']==2026 and 'ConnectTimeout' in dq['last_error'], dict(dq)

# 2) Foreground overview counts it as complete, not error, while exposing enrichment backlog.
racers=[{'registration_no':'5448','name':'福田柊人'}]
ov=c._today_status_overview(racers)
assert ov['complete']==1 and ov['error']==0 and ov['archive_deferred']==1, ov
assert c._pending_today(racers)==[], c._pending_today(racers)

# 3) A normal final completion removes the deferred enrichment marker.
c._mark_complete('5448')
assert c._archive_deferred_rows(['5448'])==[]

# 4) Cooldown waits remain non-counting (v17.251 behavior preserved).
with db.connect() as con:
    con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,retry_count,last_error) VALUES(?,?,?,?,?)",
                ('5432','安藤瑠希','running',7,'2026年一時通信障害: ConnectTimeout'))
c._mark_archive_wait('5432','2026年一時通信障害: ConnectTimeout')
with db.connect() as con:
    row=con.execute("SELECT status,retry_count,last_error FROM course_history_initial_racers WHERE registration_no='5432'").fetchone()
assert row['status']=='pending' and row['retry_count']==7 and 'ConnectTimeout' in row['last_error'], dict(row)

# 5) Hit-rate bankroll rule remains unchanged.
picks=[
    {'combo':'1-2-3','odds':4.0,'probability':.25},
    {'combo':'1-3-2','odds':6.0,'probability':.20},
    {'combo':'2-1-3','odds':8.0,'probability':.15},
    {'combo':'6-5-4','odds':1000.0,'probability':.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000, stakes
assert all(x>=100 and x%100==0 for x in stakes), stakes
assert stakes[-1]==100, stakes

# 6) Version/UI/source guards.
src=(root/'course_history.py').read_text()
app=(root/'app.py').read_text()
html=(root/'static/index.html').read_text()
assert 'course_history_archive_deferred' in src
assert 'today_archive_deferred_count' in src
assert '年別補完待ち <strong>${archiveDeferred}人</strong>' in html
assert 'version="1.0.252"' in app and '"version": "1.0.252"' in app
assert 'v17.252 年別履歴遅延補完版' in html
print('PASS v17.252: archive outage no longer blocks foreground completion; deferred enrichment preserved and retried separately')
