import tempfile, time, threading
from pathlib import Path
import requests
from db import BoatDB
from course_history import OfficialCourseHistoryCollector, ARCHIVE_SOURCE_COOLDOWN_SECONDS

# Real sqlite schema/migration + candidate cache / failed-year resume state.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(str(Path(td)/'t.db'))
    c=OfficialCourseHistoryCollector(db)
    with db.connect() as con:
        con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,cursor_year,target_date) VALUES(?,?,?,?,?)",
                    ('5134','大原祥昌','pending',2026,'20261002'))
    rows=[{'date':'20260930','jcd':'18','rno':7,'course_hint':4,'st_hint':'.12','st_rank_hint':2,'finish_hint':'3','hint_confidence':'strict-matrix-v1','candidate_source':'test'}]
    c._cache_year_candidates('5134',2026,rows)
    c._advance_year('5134',2025)
    cached=c._cached_archive_candidates('5134')
    assert len(cached)==1 and cached[0]['date']=='20260930' and int(cached[0]['course_hint'])==4
    assert c._cursor_year('5134',2026)==2025

# Shared archive circuit breaker: 2 attempts on first transient failure, then fail-fast with zero extra calls.
class Resp:
    def __init__(self):
        self.status_code=502; self.text='x'*1000; self.url='https://boatrace-db.net/x'; self.content=self.text.encode()
    def raise_for_status(self):
        raise requests.HTTPError('502 Server Error: Bad Gateway for url: https://boatrace-db.net/x')
class BadSession:
    def __init__(self): self.calls=0
    def get(self,*a,**kw): self.calls+=1; return Resp()

c = object.__new__(OfficialCourseHistoryCollector)
c._stop=threading.Event(); c.status={}; c._archive_source_lock=threading.RLock(); c._archive_source_disabled_until=0.0; c._archive_source_last_error=None
s=BadSession()
try:
    c._fetch_year_racer_candidates(s,'5134','大原祥昌',2026)
    raise AssertionError('expected transient failure')
except Exception as e:
    assert c._is_transient_fetch_error(e)
assert s.calls==2, s.calls
assert c._archive_source_open()
calls=s.calls
try:
    c._fetch_year_racer_candidates(s,'5136','濱野斗馬',2026)
    raise AssertionError('expected open-circuit failure')
except Exception as e:
    assert 'クールダウン中' in str(e)
assert s.calls==calls, (s.calls,calls)
assert ARCHIVE_SOURCE_COOLDOWN_SECONDS==300

# PRE/POST timing behavior from v17.246 remains present.
root=Path(__file__).resolve().parent
collector=(root/'collector.py').read_text()
run=collector[collector.index('async def _run_current_day'):]
pos_basic=run.index('await self._basic_rebuild_phase()')
pos_pre=run.index('await self._pre_ai_prediction_phase()', pos_basic)
pos_deferred=run.index('async def deferred_startup_work()', pos_basic)
assert pos_basic < pos_pre < pos_deferred
assert '直前予想を生成・保存中…' in collector

html=(root/'static'/'index.html').read_text(); app=(root/'app.py').read_text()
assert 'v17.247 年別履歴タイムアウト復旧・再開版' in html
assert 'version="1.0.247"' in app and '"version": "1.0.247"' in app
print('PASS v17.247 archive circuit breaker + failed-year resume + v17.246 PRE/POST regression')
