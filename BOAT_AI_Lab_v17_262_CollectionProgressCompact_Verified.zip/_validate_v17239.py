from pathlib import Path

root = Path(__file__).resolve().parent
html = (root / 'static' / 'index.html').read_text(encoding='utf-8')
app = (root / 'app.py').read_text(encoding='utf-8')

checks = {
    'version 1.0.239': '1.0.239' in app,
    'visible initial load gauge': 'id="appLoadProgress"' in html and 'id="appLoadProgressBar"' in html and 'id="appLoadProgressText"' in html,
    'parallel initial health/day': 'await Promise.all([health(),loadDay()]);' in html,
    'removed unconditional 30s loadDay poll': 'setInterval(loadDay,30000)' not in html,
    'basic refresh signature ignores last_cycle churn': 'const sig=`${s.active_date}:${s.basic_complete||0}:${s.basic_total||0}`;' in html,
    'official day poll stops after cached': 'if(officialDaySeen) return;' in html,
    'venue knowledge only polls while visible': 'screen.classList.contains("hidden") || document.hidden' in html,
    'course-history poll stops after completion': 'courseHistoryCollectionComplete && !force' in html,
    'time UI full rerender minute guarded': 'minuteKey===lastTimeStyleMinute' in html,
    'live revision remains 2 seconds': 'setInterval(()=>{if(!document.hidden)watch();},2000)' in html,
    'background lifecycle remains 3 seconds': 'setInterval(()=>{if(!document.hidden)watchCollectorLifecycle();},3000)' in html,
    'completion remains 15 seconds': 'setInterval(()=>{if(!document.hidden)refreshCompletion();},15000)' in html,
    'resume refresh on visibility': 'document.addEventListener("visibilitychange"' in html,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit('FAIL: ' + ', '.join(failed))
print('PASS v17.239 lightweight polling + load gauge regression checks')
for k in checks:
    print('  OK', k)
