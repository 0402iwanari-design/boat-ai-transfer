from __future__ import annotations
import asyncio, time, inspect
from pathlib import Path
from ai_predictor import _allocate_5000_equal_payout
from collector import BackgroundCollector
import course_history

# 1) v17.249 bankroll rule stays intact: total 5,000 yen, minimum 100 yen,
# longshot is not removed merely because target/odds would be below 100 yen.
picks=[
    {"combo":"1-2-3","odds":4.0,"probability":.25},
    {"combo":"1-3-2","odds":6.0,"probability":.20},
    {"combo":"2-1-3","odds":8.0,"probability":.15},
    {"combo":"6-5-4","odds":1000.0,"probability":.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000, stakes
assert all(x>=100 and x%100==0 for x in stakes), stakes
assert stakes[-1]==100, stakes

# 2) Far-out PRE races must NOT fetch odds before T-15 anymore.
class FakeDB:
    def get_snapshot(self,*a,**k): return None
class FakeSource:
    def __init__(self):
        self.fetches=0; self.db=FakeDB()
    def fetch_odds_atomic(self,*a,**k):
        self.fetches += 1
        return {"ok":True,"saved":True,"verified":True,"count":120,"expected_count":120}

src=FakeSource()
c=BackgroundCollector(src)
c.running=True
c.today='20261002'
c.targets=[{"jcd":"01","rno":1,"venue":"桐生"}]
c.target_map={("01",1):c.targets[0]}
c.finished=set()
c._load_schedule_map=lambda:{("01",1):"10:00"}
c._odds_monitoring_started=lambda:True
c._minutes_to=lambda d:40.0
now=time.time(); c._deadline_ts=lambda d:now+2400
asyncio.run(c._dynamic_cycle())
assert src.fetches==0, src.fetches

# 3) UI must show provisional combinations with an odds-waiting message,
# and individual odds numbers must not be rendered in AI pick rows.
root=Path(__file__).parent
html=(root/'static/index.html').read_text()
assert 'オッズ反映待ち' in html
assert '出目予想を先に表示しています' in html
assert 'ai-provisional-picks' in html
ai_row=html[html.index('function aiComboRow'):html.index('// 予想の採用順')]
assert 'オッズ ${Number(x.odds)' not in ai_row
assert 'オッズ未取得' not in ai_row

# 4) Early-odds scheduler has been removed; ordinary T-15 gate remains.
collector=(root/'collector.py').read_text()
assert 'early_odds_key' not in collector
assert 'early_pre_odds' not in collector
assert 'if interval is not None:' in collector
assert 'if 0 <= mins <= 15:' in collector

# 5) Keep archive outage protection from v17.248/v17.247.
run_src=inspect.getsource(course_history.OfficialCourseHistoryCollector._run)
init_src=inspect.getsource(course_history.OfficialCourseHistoryCollector._initialize_racer)
assert '年別履歴ソース復旧待ち' in run_src
assert 'pending = pending[:1]' in run_src
assert 'archive_outage_partial_saved' in init_src

# 6) Version markers.
app=(root/'app.py').read_text()
assert 'v17.250 事前出目先行表示・オッズ非表示版' in html
assert 'version="1.0.250"' in app
assert '"version": "1.0.250"' in app
print('PASS v17.250: provisional PRE combos + no early odds + odds hidden in AI UI')
