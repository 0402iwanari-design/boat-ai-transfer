from pathlib import Path
import re
root=Path(__file__).resolve().parent
html=(root/'static'/'index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
checks={
    'backend version 1.0.241':'1.0.241' in app,
    'ui version v17.241':'v17.241 節間ST・着順表示修正版' in html,
    'four row order': html.find('row("rno"') < html.find('row("course"') < html.find('row("st"') < html.find('row("finish"'),
    'ST prefix':'ST${escapeHtml(shown)}' in html,
    'numeric finish adds suffix':'/^\\d+$/.test(raw)?`${raw}着`:raw' in html,
    'entry merge by race number':'const byRno=new Map();' in html and 'st:slot?.st??full?.st' in html and 'finish:slot?.finish??full?.finish' in html,
    'special finish safe':'title="本番着順"' in html,
    'meeting ST CSS':'.meeting-racer-grid .meeting-st{' in html,
}
for k,v in checks.items():
    assert v, k

# Behavioral mirror of the JS merge: partial official slot must inherit ST/finish
slots=[{'rno':2,'course':3,'boat_lane':3},{'rno':11,'course':5,'boat_lane':5}]
entries=[{'rno':2,'course':3,'st':'.08','finish':'5','boat_lane':3},{'rno':11,'course':5,'st':'.12','finish':'F','boat_lane':5}]
by={int(e['rno']):e for e in entries}
out=[]
for slot in slots:
    full=by.get(int(slot.get('rno') or 0))
    z=dict(full or {}); z.update(slot)
    for key in ('st','finish','course','boat_lane'):
        if slot.get(key) is None and full is not None:
            z[key]=full.get(key)
    out.append(z)
assert out[0]['st']=='.08' and out[0]['finish']=='5'
assert out[1]['st']=='.12' and out[1]['finish']=='F'
print('PASS v17.241 meeting ST/finish display + partial-slot merge checks')
