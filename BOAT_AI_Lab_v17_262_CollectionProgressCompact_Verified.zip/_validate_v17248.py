import inspect, math
import ai_predictor
import course_history

# 1) Hit-rate dutching: 5000 yen total, near-equal gross payout.
picks=[
    {"combo":"1-2-3","odds":4.0,"probability":.24},
    {"combo":"1-3-2","odds":6.0,"probability":.18},
    {"combo":"2-1-3","odds":8.0,"probability":.13},
    {"combo":"2-3-1","odds":8.0,"probability":.12},
]
st=ai_predictor._allocate_5000_equal_payout(picks)
assert sum(st)==5000, st
payouts=[a*b["odds"] for a,b in zip(st,picks)]
assert max(payouts)-min(payouts) <= 1000, (st,payouts)

# 2) A 1000x longshot that mathematically needs <100 yen must NOT be forced
#    to 100/300 yen in hit-rate mode.
longshot=picks[:3]+[{"combo":"6-5-4","odds":1000.0,"probability":.001}]
assert ai_predictor._allocate_5000_equal_payout(longshot)==[]

# 3) strategy hit allocation uses equal-payout mode and return mode remains edge-based.
src=inspect.getsource(ai_predictor.strategy_options)
assert 'allocation_mode="equal_payout"' in src
assert '回収率重視' in src

# 4) Archive outage protection: retry queue pauses during shared cooldown,
#    one-racer recovery probe, and useful candidates are saved before defer.
src2=inspect.getsource(course_history.OfficialCourseHistoryCollector._run)
assert '年別履歴ソース復旧待ち' in src2
assert 'pending = pending[:1]' in src2
src3=inspect.getsource(course_history.OfficialCourseHistoryCollector._initialize_racer)
assert 'archive_outage_partial_saved' in src3
assert 'candidate_count' in src3

print('PASS v17.248: archive cooldown/probe + hit-rate equal-payout allocation')
print('stakes=',st,'payouts=',payouts)
