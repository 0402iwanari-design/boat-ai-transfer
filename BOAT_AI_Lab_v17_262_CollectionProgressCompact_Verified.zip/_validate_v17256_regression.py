from pathlib import Path
from ai_predictor import _allocate_5000_equal_payout
root=Path(__file__).parent
html=(root/'static/index.html').read_text()
app=(root/'app.py').read_text()
collector=(root/'collector.py').read_text()
assert 'v17.256 AI予想確率校正・重み再調整版' in html
assert 'version="1.0.256"' in app
assert '"version": "1.0.256"' in app
# v17.254 racer bio stack preserved
assert '<col class="rl-bio"><col class="rl-tilt">' in html
assert '<th class="racelist-bio-head">年齢 / 体重<br>支部<br>出身</th>' in html
assert 'class="racelist-bio-cell"' in html
assert '${x.age??"—"}歳' in html
assert '${x.weight_kg??"—"}kg' in html
# v17.253 fixed 10 slots preserved
assert 'const labels=Array.from({length:10}' in html
assert 'Array(Math.max(0,10-history.length)).fill(null)' in html
# v17.250 PRE and odds-hidden preserved
assert 'オッズ反映待ち' in html
assert '出目予想を先に表示しています' in html
assert 'ai-provisional-picks' in html
ai_row=html[html.index('function aiComboRow'):html.index('// 予想の採用順')]
assert 'オッズ ${Number(x.odds)' not in ai_row
assert 'if 0 <= mins <= 15:' in collector
picks=[
 {"combo":"1-2-3","odds":4.0,"probability":.25},
 {"combo":"1-3-2","odds":6.0,"probability":.20},
 {"combo":"2-1-3","odds":8.0,"probability":.15},
 {"combo":"6-5-4","odds":1000.0,"probability":.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000 and stakes[-1]==100
print('v17.256 regression PASS')
