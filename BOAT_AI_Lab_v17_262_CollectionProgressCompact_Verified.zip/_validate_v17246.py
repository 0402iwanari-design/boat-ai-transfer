from pathlib import Path
root=Path(__file__).resolve().parent
collector=(root/'collector.py').read_text()
boat=(root/'boat_source.py').read_text()
html=(root/'static'/'index.html').read_text()
app=(root/'app.py').read_text()

# First PRE must be executed synchronously after basic rebuild and before deferred work.
run=collector[collector.index('async def _run_current_day'):]
pos_basic=run.index('await self._basic_rebuild_phase()')
pos_pre=run.index('await self._pre_ai_prediction_phase()', pos_basic)
pos_deferred=run.index('async def deferred_startup_work()', pos_basic)
assert pos_basic < pos_pre < pos_deferred, (pos_basic,pos_pre,pos_deferred)

# In deferred work, meeting repair / PRE refresh must precede heavy racer-history collection.
d=run[pos_deferred:]
pos_meeting=d.index('await self._meeting_results_status_phase()')
pos_refresh=d.index('await self._pre_ai_prediction_phase()', pos_meeting)
pos_collect=d.index('await collect_current_and_backlog()', pos_refresh)
assert pos_meeting < pos_refresh < pos_collect, (pos_meeting,pos_refresh,pos_collect)

# T-15 path is explicitly POST-oriented and preserves PRE in the source layer.
assert '直前予想を生成・保存中…' in collector
assert '事前予想＋直前予想を生成・保存中…' not in collector
assert 'preserve_pre = bool((old.get("pre_prediction") or {}).get("picks"))' in boat
assert 'snap["pre_prediction"] = pre' in boat

# UI copy and versions are synchronized.
assert '事前AI予想を生成中です。直前AI予想は締切15分前に更新します。' in html
assert 'v17.246 事前AI即時生成・直前15分分離版' in html
assert 'version="1.0.246"' in app
assert '"version": "1.0.246"' in app
print('PASS v17.246 PRE-after-basic / POST-at-T15 separation')
