from __future__ import annotations

import calendar
import json
from datetime import datetime

from review_results import combo, timely
from ai_predictor import _bet_recommendation


STAGES = (("pre_prediction", "PRE"), ("post_prediction", "POST"))
MODES = (("hit", "的中率重視"), ("return", "回収率重視"))
PERIODS = (
    ("today", 0, "本日"),
    ("1m", 1, "直近1か月"),
    ("6m", 6, "直近6か月"),
    ("1y", 12, "直近1年"),
)


def _month_start(end_date: str, months: int) -> str:
    end = datetime.strptime(end_date, "%Y%m%d").date()
    serial = end.year * 12 + end.month - 1 - months
    year, month0 = divmod(serial, 12)
    day = min(end.day, calendar.monthrange(year, month0 + 1)[1])
    shifted = end.replace(year=year, month=month0 + 1, day=day)
    # Inclusive SQL range: the day after the shifted boundary.
    return shifted.fromordinal(shifted.toordinal() + 1).strftime("%Y%m%d")


def _loads(raw):
    try:
        return json.loads(raw) if raw else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def _prediction_records(db, end_date: str):
    """Return deadline-valid strategy simulations up to the selected day."""
    with db.connect() as con:
        # Older test/portable databases may predate venue_event_meta. Keep
        # statistics backward-compatible and classify those rows as 不明.
        has_grade_table = bool(con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='venue_event_meta'"
        ).fetchone())
        grade_select = "vem.event_grade" if has_grade_table else "NULL AS event_grade"
        grade_join = (
            "LEFT JOIN venue_event_meta vem ON vem.date=p.date AND vem.jcd=p.jcd"
            if has_grade_table else ""
        )
        sql = f"""
            SELECT p.date,p.jcd,p.rno,p.created_at,p.source_snapshot,
                   rr.trifecta,rr.payout_yen,rr.odds,
                   rs.deadline,
                   {grade_select}
            FROM predictions p
            JOIN race_results rr
              ON rr.date=p.date AND rr.jcd=p.jcd AND rr.rno=p.rno
            LEFT JOIN race_schedule rs
              ON rs.date=p.date AND rs.jcd=p.jcd AND rs.rno=p.rno
            {grade_join}
            WHERE p.date<=?
              AND rr.trifecta IS NOT NULL
              AND rr.payout_yen IS NOT NULL
            ORDER BY p.date,p.jcd,p.rno
        """
        rows = con.execute(sql, (end_date,)).fetchall()

    records = []
    for row in rows:
        snap = _loads(row["source_snapshot"])
        if snap.get("preview"):
            continue
        actual = combo(row["trifecta"])
        if not actual:
            continue
        for stage_key, stage_label in STAGES:
            stage = snap.get(stage_key) or {}
            if stage_label == "POST" and not snap.get("post_ready"):
                continue
            stamp = (
                snap.get("pre_saved_at") if stage_label == "PRE" else None
            ) or snap.get("generated_at") or row["created_at"]
            # New records must be strictly proved as saved before the exact
            # closing time.  Older saved predictions may not have a preserved
            # deadline/snapshot after an app upgrade; do not make their
            # already-confirmed results disappear from the history screen.
            strict_valid = bool(row["deadline"]) and (
                timely(stamp, row["date"], row["deadline"], utc=not bool(snap.get("generated_at")))
                and timely(row["created_at"], row["date"], row["deadline"], utc=True)
            )
            legacy_history = row["date"] < end_date and bool(stage.get("picks") or stage.get("strategies"))
            valid = strict_valid or legacy_history
            if not valid:
                continue
            for mode, mode_label in MODES:
                option = (stage.get("strategies") or {}).get(mode) or {}
                mode_stamp = stage.get("strategies_saved_at") or stamp
                if not legacy_history and not timely(
                    mode_stamp, row["date"], row["deadline"],
                    utc=not bool(snap.get("generated_at")),
                ):
                    continue
                raw_picks = option.get("picks") or []
                entries = []
                seen = set()
                for raw_pick in raw_picks:
                    c = combo(raw_pick.get("combo") if isinstance(raw_pick, dict) else raw_pick)
                    if not c or c in seen:
                        continue
                    seen.add(c)
                    stake = None
                    if isinstance(raw_pick, dict):
                        raw_stake = raw_pick.get("stake_yen", raw_pick.get("stake"))
                        try:
                            stake = float(raw_stake) if raw_stake is not None else None
                        except (TypeError, ValueError):
                            stake = None
                        if stake is not None and stake <= 0:
                            stake = None
                    entries.append({"combo": c, "stake": stake})
                picks = [x["combo"] for x in entries]
                if not picks:
                    continue
                hit = actual in picks
                payout = int(row["payout_yen"] or 0)
                official_odds = row["odds"]
                if official_odds is None and payout:
                    official_odds = payout / 100.0

                # v17.255: statistics must use the exact stake saved by the AI
                # for each combination.  Older rows that predate saved per-pick
                # stakes keep a clearly identifiable equal-split fallback so
                # historical screens still work without inventing allocations.
                have_saved_stakes = bool(entries) and all(x["stake"] is not None for x in entries)
                if have_saved_stakes:
                    total_stake = round(sum(x["stake"] for x in entries), 2)
                    allocation_source = "saved_stakes"
                else:
                    total_stake = 5000.0
                    fallback = total_stake / len(entries)
                    for x in entries:
                        x["stake"] = fallback
                    allocation_source = "legacy_equal_split"
                winning_stake = next((x["stake"] for x in entries if x["combo"] == actual), 0.0) if hit else 0.0
                returned = round(float(winning_stake or 0) * float(official_odds or 0)) if hit else 0
                stake_per_pick = winning_stake if hit else (total_stake / len(entries) if entries else 0)
                decision = stage.get("bet_decision") or _bet_recommendation(
                    stage,
                    post_ready=bool(snap.get("post_ready")),
                    stage_name="post" if stage_label == "POST" else "pre",
                )
                raw_grade = (row["event_grade"] or "").strip()
                # PG1 is intentionally aggregated into G1 for statistics.
                grade = "G1" if raw_grade == "PG1" else (raw_grade or "不明")
                records.append({
                    "date": row["date"],
                    "jcd": str(row["jcd"]).zfill(2),
                    "grade": grade,
                    "rno": int(row["rno"]),
                    "stage": stage_label,
                    "mode": mode,
                    "mode_label": mode_label,
                    "actual": actual,
                    "picks": picks,
                    "hit": hit,
                    "stake_yen": total_stake,
                    "stake_per_pick_yen": round(stake_per_pick, 2),
                    "winning_stake_yen": round(float(winning_stake or 0), 2),
                    "allocation_source": allocation_source,
                    "return_yen": returned,
                    "payout_yen": payout,
                    "odds": official_odds,
                    "recommended": bool(decision.get("recommended")),
                    "bet_decision": decision,
                })
    return records


def _metric(rows, stage, mode, recommended_only=False):
    selected = [x for x in rows if x["stage"] == stage and x["mode"] == mode]
    if recommended_only:
        selected = [x for x in selected if x.get("recommended")]
    races = len(selected)
    hits = sum(1 for x in selected if x["hit"])
    stake = sum(x["stake_yen"] for x in selected)
    returned = sum(x["return_yen"] for x in selected)
    return {
        "races": races,
        "hits": hits,
        "hit_rate": round(hits / races * 100, 1) if races else None,
        "stake_yen": stake,
        "return_yen": returned,
        "return_rate": round(returned / stake * 100, 1) if stake else None,
    }


def _period_summary(rows, end_date):
    output = []
    for key, months, label in PERIODS:
        # 「本日」は表示中の日付だけを対象にする。過去日を表示している
        # 場合も、その選択日の1日分として正しく再現できる。
        start = end_date if key == "today" else _month_start(end_date, months)
        part = [x for x in rows if start <= x["date"] <= end_date]
        metrics = {}
        for _, stage in STAGES:
            for mode, _ in MODES:
                metrics[f"{stage}_{mode}"] = _metric(part, stage, mode)
                metrics[f"RECOMMENDED_{stage}_{mode}"] = _metric(
                    part, stage, mode, recommended_only=True
                )
        output.append({"key": key, "label": label, "start": start, "end": end_date, "metrics": metrics})
    return output


def _rankings(records, venue_names):
    # Rank a race only once even if PRE/POST or both strategies hit it.
    hits = {}
    for x in records:
        if not x["hit"]:
            continue
        key = (x["date"], x["jcd"], x["rno"])
        item = hits.setdefault(key, {
            "date": x["date"], "jcd": x["jcd"], "venue": venue_names.get(x["jcd"], x["jcd"]),
            "rno": x["rno"], "actual": x["actual"], "odds": x["odds"],
            "payout_yen": x["payout_yen"], "hits": [],
        })
        stage_name = "事前" if x["stage"] == "PRE" else "直前"
        label = f'{stage_name}・{x["mode_label"]}'
        if label not in item["hits"]:
            item["hits"].append(label)
    ranked = sorted(
        hits.values(),
        key=lambda x: (float(x["odds"] or 0), x["date"], x["rno"]),
        reverse=True,
    )
    return ranked[:10]


def _ai_return_rankings(records, venue_names, jcd=None):
    """Top 10 simulated AI returns from hit predictions.

    Uses the same saved per-pick stakes as the hit/return statistics.
    A race is shown once, using the largest actual simulated return among
    PRE/POST and modes.
    """
    best = {}
    for x in records:
        if not x.get("hit"):
            continue
        if jcd is not None and str(x.get("jcd")).zfill(2) != str(jcd).zfill(2):
            continue
        returned = int(x.get("return_yen") or 0)
        if returned <= 0:
            continue
        key = (x["date"], x["jcd"], x["rno"])
        prev = best.get(key)
        if prev is None or returned > prev["payout_yen"]:
            best[key] = {
                "date": x["date"],
                "jcd": x["jcd"],
                "venue": venue_names.get(x["jcd"], x["jcd"]),
                "rno": x["rno"],
                "actual": x["actual"],
                "payout_yen": returned,
                "official_payout_yen": int(x.get("payout_yen") or 0),
                "odds": float(x.get("odds") or 0) if x.get("odds") is not None else None,
                # 賭け金はレース総投資額ではなく、実際に的中した1買い目へ配分された金額。
                "bet_yen": round(float(x.get("winning_stake_yen") or x.get("stake_per_pick_yen") or 0)),
                "stake_yen": int(x.get("stake_yen") or 0),
                "stake_per_pick_yen": x.get("stake_per_pick_yen"),
                "stage": x.get("stage"),
                "mode": x.get("mode"),
            }
    return sorted(
        best.values(),
        key=lambda x: (x["payout_yen"], x["date"], x["rno"]),
        reverse=True,
    )[:10]


def _daily_series(records):
    """Daily hit/return history for the chart shown in AI予想と結果."""
    points = []
    for day in sorted({x["date"] for x in records}):
        rows = [x for x in records if x["date"] == day]
        metrics = {}
        for _, stage in STAGES:
            for mode, _ in MODES:
                metrics[f"{stage}_{mode}"] = _metric(rows, stage, mode)
                metrics[f"RECOMMENDED_{stage}_{mode}"] = _metric(
                    rows, stage, mode, recommended_only=True
                )
        points.append({"date": day, "metrics": metrics})
    return points


GRADE_ORDER = ("一般戦", "G3", "G2", "G1", "SG", "不明")


def build_statistics(db, end_date: str, venues):
    records = _prediction_records(db, end_date)
    names = {str(x["code"]).zfill(2): x["name"] for x in venues}
    venue_rows = []
    for code, name in names.items():
        part = [x for x in records if x["jcd"] == code]
        if not part:
            continue
        venue_rows.append({
            "code": code,
            "name": name,
            "periods": _period_summary(part, end_date),
            "top10": _rankings(part, names),
            "payout_top10": _ai_return_rankings(part, names, code),
            "daily_series": _daily_series(part),
        })

    # Grade statistics reuse the same in-memory prediction records, so this
    # adds no extra network access and no per-grade DB scan. PG1 is normalized
    # to G1 in _prediction_records as requested.
    grade_rows = []
    present = {x.get("grade") or "不明" for x in records}
    ordered_grades = [g for g in GRADE_ORDER if g in present]
    ordered_grades.extend(sorted(present - set(GRADE_ORDER)))
    for grade in ordered_grades:
        part = [x for x in records if (x.get("grade") or "不明") == grade]
        if not part:
            continue
        grade_rows.append({
            "grade": grade,
            "periods": _period_summary(part, end_date),
            "top10": _rankings(part, names),
            "payout_top10": _ai_return_rankings(part, names),
            "daily_series": _daily_series(part),
        })

    return {
        "end_date": end_date,
        "simulation": "1レース合計5,000円・AIが保存した実際の買い目別配分で集計",
        "overall_periods": _period_summary(records, end_date),
        "venues": venue_rows,
        "grades": grade_rows,
        "grade_rule": "PG1はG1に統合",
        "top10": _rankings(records, names),
        "payout_top10": _ai_return_rankings(records, names),
        "daily_series": _daily_series(records),
    }
