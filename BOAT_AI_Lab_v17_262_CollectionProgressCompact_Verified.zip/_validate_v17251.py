from pathlib import Path
import tempfile
from db import BoatDB
from course_history import OfficialCourseHistoryCollector
from ai_predictor import _allocate_5000_equal_payout

# 1) Synthetic archive cooldown must be distinguished from a real transport failure.
dbfile = Path(tempfile.mkdtemp())/'t.db'
db = BoatDB(str(dbfile))
c = OfficialCourseHistoryCollector(db)
assert c._is_archive_cooldown_wait(RuntimeError('boatrace-db.net 年別履歴は一時通信障害のためクールダウン中'))
assert not c._is_archive_cooldown_wait(TimeoutError('ConnectTimeout boatrace-db.net'))

# 2) Waiting does not increment retry_count and preserves the previous real error.
with db.connect() as con:
    con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,retry_count,last_error) VALUES(?,?,?,?,?)",
                ('5448','福田柊人','running',7,'2026年一時通信障害: ConnectTimeout'))
c._mark_archive_wait('5448','2026年一時通信障害: ConnectTimeout')
with db.connect() as con:
    row=con.execute("SELECT status,retry_count,last_error FROM course_history_initial_racers WHERE registration_no='5448'").fetchone()
assert row['status']=='pending', dict(row)
assert row['retry_count']==7, dict(row)
assert 'ConnectTimeout' in row['last_error'], dict(row)

# 3) Migration collapses only the old artificial cooldown-loop counter.
with db.connect() as con:
    con.execute("INSERT OR REPLACE INTO course_history_initial_racers(registration_no,name,status,retry_count,last_error) VALUES(?,?,?,?,?)",
                ('5432','安藤瑠希','pending',224,'2026年一時通信障害: RuntimeError: boatrace-db.net 年別履歴は一時通信障害のためクールダウン中'))
c._ensure_tables()
with db.connect() as con:
    row=con.execute("SELECT retry_count FROM course_history_initial_racers WHERE registration_no='5432'").fetchone()
assert row['retry_count']==1, dict(row)

# 4) v17.250 hit-rate bankroll rule remains: total 5000, min 100, longshot retained.
picks=[
    {'combo':'1-2-3','odds':4.0,'probability':.25},
    {'combo':'1-3-2','odds':6.0,'probability':.20},
    {'combo':'2-1-3','odds':8.0,'probability':.15},
    {'combo':'6-5-4','odds':1000.0,'probability':.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000, stakes
assert all(x>=100 and x%100==0 for x in stakes), stakes
assert stakes[-1]==100, stakes

# 5) Version + source guard.
root=Path(__file__).parent
src=(root/'course_history.py').read_text()
app=(root/'app.py').read_text()
html=(root/'static/index.html').read_text()
assert 'self._mark_archive_wait(reg, _pre_state.get("last_error"))' in src
assert 'retry_count=CASE WHEN retry_count>1 THEN 1 ELSE retry_count END' in src
assert 'version="1.0.251"' in app and '"version": "1.0.251"' in app
assert 'v17.251 年別クールダウン待機分離版' in html
print('PASS v17.251: cooldown wait separated from real failures; retry count stable; old artificial counts normalized')
