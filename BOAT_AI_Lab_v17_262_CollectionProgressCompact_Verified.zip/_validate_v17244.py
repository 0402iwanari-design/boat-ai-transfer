from pathlib import Path
root=Path(__file__).resolve().parent
html=(root/'static/index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
assert 'v17.244 出走表10%拡大・ST簡潔表示版' in html
assert 'version="1.0.244"' in app
assert '"version": "1.0.244"' in app
assert 'min-width:1650px!important' in html
assert 'height:97px!important' in html
assert 'font-size:10px!important' in html
assert 'title="本番ST">${escapeHtml(shown)}</span>' in html
assert 'title="本番ST">ST${escapeHtml(shown)}</span>' not in html
# Four meeting bands must remain.
assert '<tr>${row("course"' in html
assert '<tr>${row("st"' in html
assert '<tr>${row("finish"' in html
print('PASS v17.244 mobile race table +10% and numeric-only meeting ST')
