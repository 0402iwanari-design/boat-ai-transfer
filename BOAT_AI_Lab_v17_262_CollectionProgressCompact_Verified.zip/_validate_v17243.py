from pathlib import Path
root=Path(__file__).resolve().parent
html=(root/'static'/'index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
assert 'v17.243 節間成績4段表示サイズ調整版' in html
assert 'version="1.0.243"' in app
assert '"version": "1.0.243"' in app
assert 'height:88px!important' in html
assert 'height:22px!important' in html
assert 'row("rno",v=>`${v}R`,true)' in html
assert 'row("course",v=>`<span title="本番の実進入コース">進${v}</span>`)' in html
assert 'class="meeting-st" title="本番ST"' in html
assert 'class="meeting-finish" title="本番着順"' in html
# 6 racer rows x 88px + smartphone meeting header 68px = 596px, leaving room
# for the sticky navigation on a common ~844 CSS-pixel phone viewport.
assert 6*88+68 == 596
print('PASS v17.243 mobile meeting four-line sizing + version sync')
