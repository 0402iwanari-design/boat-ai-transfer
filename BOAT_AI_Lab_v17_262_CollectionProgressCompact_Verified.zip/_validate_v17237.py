import tempfile
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

RACELIST_DIV_HTML = '''
<html><body>
<div class="race-title">下関 3R</div>
<div class="entry-head">枠 ボートレーサー 全国 当地</div>
<div class="entry">1 3357 / B1 福島 陽子</div>
<div class="entry">2 3618 / A1 海野 ゆかり</div>
<div class="entry">3 5342 / B2 原村 百那</div>
<div class="entry">4 5416 / B1 龍田 真白</div>
<div class="entry">5 4556 / A1 竹井 奈美</div>
<div class="entry">6 3801 / B1 五反田 忍</div>
</body></html>
'''

class Resp:
    status_code=200
    url='https://www.boatrace.jp/owpc/pc/race/racelist?hd=20260719&jcd=19&rno=3'
    content=RACELIST_DIV_HTML.encode('utf-8')
    encoding='utf-8'
    apparent_encoding='utf-8'
    text=RACELIST_DIV_HTML
    def raise_for_status(self): pass

class Session:
    def __init__(self): self.calls=0
    def get(self,*a,**k): self.calls+=1; return Resp()

with tempfile.TemporaryDirectory() as td:
    c=OfficialCourseHistoryCollector(BoatDB(td+'/t.db'))
    regs=c._raw_official_racer_regs(RACELIST_DIV_HTML)
    assert regs == ['3357','3618','5342','5416','4556','3801'], regs
    cand={'date':'20260719','jcd':'19','rno':3}
    s=Session()
    # Production false-positive example: 4660 was not in this official 3R roster.
    assert c._candidate_racer_exists_on_official_race(s,cand,'4660',result_html='<html>結果</html>') is False
    assert s.calls == 1
    # Cache should answer a real racer without another fetch.
    assert c._candidate_racer_exists_on_official_race(s,cand,'3357',result_html='') is True
    assert s.calls == 1

print('PASS v17.237 roster text fallback + false-candidate membership validation')
