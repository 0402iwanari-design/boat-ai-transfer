from pathlib import Path

root = Path(__file__).resolve().parent
html = (root / 'static' / 'index.html').read_text(encoding='utf-8')
app = (root / 'app.py').read_text(encoding='utf-8')

assert 'v17.254 選手基本情報3段表示版' in html
assert 'version="1.0.254"' in app
assert '"version": "1.0.254"' in app

# Four profile facts are combined into one visual column.
assert '<col class="rl-bio"><col class="rl-tilt">' in html
assert '<th class="racelist-bio-head">年齢 / 体重<br>支部<br>出身</th>' in html
assert 'class="racelist-bio-cell"' in html
assert '${x.age??"—"}歳' in html
assert '${x.weight_kg??"—"}kg' in html
assert '${x.branch||"—"}</span><small>支部</small>' in html
assert '${x.origin||"—"}</span><small>出身</small>' in html

# Legacy independent columns must be gone from the race-list table CSS/markup.
assert 'col.rl-branch' not in html
assert 'col.rl-age' not in html
assert 'col.rl-weight' not in html
assert '<td>${x.age??"—"}</td>' not in html
assert '<td>${x.weight_kg??"—"}kg</td>' not in html

# Mobile layout keeps a single readable profile column rather than 3 narrow columns.
assert '.racelist-inline-meeting col.rl-bio{width:165px}' in html
assert '.racer-bio-line{min-height:25px;font-size:10px;gap:5px}' in html

# Prior v17.253 fixed-ten course history feature remains present.
assert 'const labels=Array.from({length:10}' in html
assert 'Array(Math.max(0,10-history.length)).fill(null)' in html

print('PASS v17.254: age/weight/branch/origin are rendered in one 3-line readable column; mobile sizing and v17.253 course history retained')
