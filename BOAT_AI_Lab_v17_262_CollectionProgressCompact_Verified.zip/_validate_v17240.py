from pathlib import Path
root=Path(__file__).parent
html=(root/'static'/'index.html').read_text()
app=(root/'app.py').read_text()
checks={
    'version 1.0.240':'1.0.240' in app,
    'ui v17.240':'v17.240 常時アクションロード版' in html,
    'global action click loader':'beginActionLoad(el)' in html and 'document.addEventListener("click",e=>' in html,
    'request-aware loader':'actionRequestStart()' in html and 'actionRequestEnd(tracked)' in html,
    'action loader progress':'setAppLoadProgress(8,actionLoadLabel(el))' in html,
    'finish after request':'setAppLoadProgress(92,"表示を更新中")' in html,
    'initial loader preserved':'setAppLoadProgress(12,"接続・開催情報を確認中")' in html,
    'lightweight polling preserved':'courseHistoryCollectionComplete && !force' in html,
}
for k,v in checks.items():
    print(('PASS' if v else 'FAIL'), k)
if not all(checks.values()): raise SystemExit(1)
print('PASS v17.240 always-on action load gauge regression checks')
