import os, tempfile
from pathlib import Path
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

root=Path(__file__).resolve().parent
src=(root/'course_history.py').read_text(encoding='utf-8')
assert "OR last_error='年別履歴ソース復旧待ち'" in src
assert '# v17.260: a shared archive cooldown is not a foreground racer error.' in src
assert 'self._mark_archive_deferred_complete(reg, year, _pre_state.get("last_error") or str(e))\n                    return True' in src

# Migration regression: exact wait-only marker must be removed from foreground error queue.
with tempfile.TemporaryDirectory() as td:
    db=BoatDB(os.path.join(td,'test.db'))
    c=OfficialCourseHistoryCollector(db)
    with db.connect() as con:
        con.execute("""INSERT OR REPLACE INTO course_history_initial_racers
            (registration_no,name,status,recent_done,cursor_year,retry_count,last_error,target_date,started_at)
            VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)""",
            ('5406','小畑楓夏','pending',0,2026,1,'年別履歴ソース復旧待ち','20261004'))
    # Re-run schema/migrations after seeding legacy state.
    c._ensure_tables()
    with db.connect() as con:
        row=con.execute("SELECT status,last_error FROM course_history_initial_racers WHERE registration_no='5406'").fetchone()
        d=con.execute("SELECT failed_year,last_error FROM course_history_archive_deferred WHERE registration_no='5406'").fetchone()
    assert row['status']=='complete', dict(row)
    assert row['last_error'] is None, dict(row)
    assert d is not None and int(d['failed_year'])==2026, dict(d) if d else None
    ov=c._today_status_overview([{'registration_no':'5406','name':'小畑楓夏'}])
    assert ov['complete']==1 and ov['error']==0 and ov['archive_deferred']==1, ov

html=(root/'static'/'index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
assert 'v17.260' in html and '1.0.260' in app
print('v17.260 archive wait migration validation PASS')
