from __future__ import annotations
import asyncio
import time
from ai_predictor import _allocate_5000_equal_payout
from collector import BackgroundCollector

# 1) Hit-rate allocation: common target = synthetic odds * 5000.
picks=[
    {"combo":"1-2-3","odds":4.0,"probability":.25},
    {"combo":"1-3-2","odds":6.0,"probability":.20},
    {"combo":"2-1-3","odds":8.0,"probability":.15},
    {"combo":"6-5-4","odds":1000.0,"probability":.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000, stakes
assert all(x>=100 and x%100==0 for x in stakes), stakes
assert stakes[-1]==100, stakes
syn=1/sum(1/float(x["odds"]) for x in picks)
target=syn*5000
# Ordinary-priced selections should remain close to target payout; the 1000x
# selection is intentionally allowed to overshoot because its minimum is 100 yen.
for st,row in zip(stakes[:-1],picks[:-1]):
    assert abs(st*row["odds"]-target)<=500, (stakes,target)

# 2) v17.249 early PRE-odds path: a 40-minute-away race gets one odds snapshot,
# immediately rebuilds PRE strategies, then is not fetched again before T-15.
class FakeSource:
    def __init__(self):
        self.fetches=0; self.builds=0
    def fetch_odds_atomic(self, date, jcd, rno, recovery):
        self.fetches += 1
        return {"ok":True,"saved":True,"verified":True,"count":120,"expected_count":120}
    def build_ai_prediction(self, date, jcd, rno, mode, save, preview):
        self.builds += 1
        return {"source_snapshot":{"pre_prediction":{"strategies":{"hit":{"picks":[{"combo":"1-2-3","odds":4.0}]}}}}}

src=FakeSource()
c=BackgroundCollector(src)
c.running=True
c.today='20261002'
c.targets=[{"jcd":"01","rno":1,"venue":"桐生"}]
c.target_map={("01",1):c.targets[0]}
c.finished=set()
c._load_schedule_map=lambda:{("01",1):"10:00"}
c._odds_monitoring_started=lambda:True
c._minutes_to=lambda d:40.0
now=time.time()
c._deadline_ts=lambda d:now+2400
asyncio.run(c._dynamic_cycle())
assert src.fetches==1, src.fetches
assert src.builds==1, src.builds
assert ("01",1) in c.pre_odds_done
# Same race must not repeat the far-out first-odds request.
asyncio.run(c._dynamic_cycle())
assert src.fetches==1, src.fetches
assert src.builds==1, src.builds

# 3) The ordinary 1.5x example still targets about 7,500 yen per hit.
base=[
    {"combo":"1-2-3","odds":4.0,"probability":.24},
    {"combo":"1-3-2","odds":6.0,"probability":.18},
    {"combo":"2-1-3","odds":8.0,"probability":.13},
    {"combo":"2-3-1","odds":8.0,"probability":.12},
]
base_stakes=_allocate_5000_equal_payout(base)
assert sum(base_stakes)==5000
base_syn=1/sum(1/x["odds"] for x in base)
assert abs(base_syn-1.5)<1e-9
base_payouts=[st*x["odds"] for st,x in zip(base_stakes,base)]
assert max(abs(x-7500) for x in base_payouts)<=300, (base_stakes,base_payouts)

# 4) Keep the v17.248 archive-outage protection while changing only allocation behavior.
import inspect, course_history
run_src=inspect.getsource(course_history.OfficialCourseHistoryCollector._run)
init_src=inspect.getsource(course_history.OfficialCourseHistoryCollector._initialize_racer)
assert '年別履歴ソース復旧待ち' in run_src
assert 'pending = pending[:1]' in run_src
assert 'archive_outage_partial_saved' in init_src
assert 'candidate_count' in init_src

# 5) Version markers.
from pathlib import Path
root=Path(__file__).parent
html=(root/'static/index.html').read_text()
app=(root/'app.py').read_text()
assert 'v17.249 事前オッズ早期取得・的中率最低100円版' in html
assert 'version="1.0.249"' in app
assert '"version": "1.0.249"' in app
print('PASS v17.249: early PRE odds + 5000-yen target payout with 100-yen floor')
