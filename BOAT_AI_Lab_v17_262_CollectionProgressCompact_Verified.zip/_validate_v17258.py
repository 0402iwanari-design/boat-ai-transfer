from pathlib import Path
import json, sqlite3, tempfile
from review_statistics import build_statistics, _prediction_records

root=Path(__file__).resolve().parent
html=(root/'static/index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
rs=(root/'review_statistics.py').read_text(encoding='utf-8')
assert 'v17.258 場別・グレード別AI成績版' in html
assert '1.0.258' in app
assert 'PG1はG1として集計します' in html
assert '🏟️ 場別の的中率・回収率' in html
assert '🏁 グレード別の的中率・回収率' in html
assert 'grade = "G1" if raw_grade == "PG1"' in rs
assert '"grades": grade_rows' in rs
assert 'AIが保存した実際の買い目別配分' in rs

class DB:
    def __init__(self,path): self.path=path
    def connect(self):
        con=sqlite3.connect(self.path); con.row_factory=sqlite3.Row; return con

with tempfile.TemporaryDirectory() as td:
    path=str(Path(td)/'grade.db')
    con=sqlite3.connect(path)
    con.executescript('''
    create table predictions(date text,jcd text,rno integer,created_at text,source_snapshot text);
    create table race_results(date text,jcd text,rno integer,trifecta text,payout_yen integer,odds real);
    create table race_schedule(date text,jcd text,rno integer,deadline text);
    create table venue_event_meta(date text,jcd text,event_grade text,event_title text,source text,updated_at text);
    ''')
    snap={"generated_at":"2026-10-03T01:00:00+09:00","pre_saved_at":"2026-10-03T01:00:00+09:00","pre_prediction":{"strategies_saved_at":"2026-10-03T01:00:00+09:00","strategies":{"hit":{"picks":[{"combo":"1-2-3","stake":5000}]},"return":{"picks":[{"combo":"1-2-3","stake":5000}]}}}}
    for jcd,grade,rno in [('01','PG1',1),('02','G1',2),('03','G3',3)]:
        con.execute('insert into predictions values(?,?,?,?,?)',('20261003',jcd,rno,'2026-10-02T16:00:00+00:00',json.dumps(snap)))
        con.execute('insert into race_results values(?,?,?,?,?,?)',('20261003',jcd,rno,'1-2-3',200,2.0))
        con.execute('insert into race_schedule values(?,?,?,?)',('20261003',jcd,rno,'12:00'))
        con.execute('insert into venue_event_meta values(?,?,?,?,?,?)',('20261003',jcd,grade,'x','test','now'))
    con.commit(); con.close()
    stats=build_statistics(DB(path),'20261003',[{'code':'01','name':'A'},{'code':'02','name':'B'},{'code':'03','name':'C'}])
    grades={x['grade']:x for x in stats['grades']}
    assert set(grades) == {'G1','G3'}, grades.keys()
    g1_today=grades['G1']['periods'][0]['metrics']['PRE_hit']
    assert g1_today['races']==2, g1_today
    assert stats['grade_rule']=='PG1はG1に統合'
    assert len(stats['venues'])==3
print('v17.258 validation PASS')
