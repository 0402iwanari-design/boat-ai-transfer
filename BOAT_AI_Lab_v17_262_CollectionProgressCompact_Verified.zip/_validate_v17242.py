
from pathlib import Path
import tempfile, json, asyncio

root=Path(__file__).parent
app=(root/'app.py').read_text()
bs=(root/'boat_source.py').read_text()
html=(root/'static/index.html').read_text()
col=(root/'collector.py').read_text()
ai=(root/'ai_predictor.py').read_text()
learn=(root/'prediction_learning.py').read_text()

assert 'version="1.0.242"' in app
assert '"version": "1.0.242"' in app
# Scratch must be monotonic once confirmed.
assert 'old_scratched or fresh_scratched' in bs
assert 'never clear it merely because a later official racelist' in bs
# Main odds/result displays always show one decimal.
assert 'Number(x.odds).toFixed(1)' in html
assert 'Number(r.odds).toFixed(1)+"倍"' in html
# Course-history finish colors.
for token in ['.finish-chip.finish-1','.finish-chip.finish-2','.finish-chip.finish-3','finishClass(h.finish)']:
    assert token in html, token
# Result review must be collector-generated rather than requiring the screen to be opened.
assert '_ensure_prediction_result_review' in col
assert 'build_detailed_review' in col
assert 'await asyncio.to_thread(\n                            self._ensure_prediction_result_review' in col
# Strategy safeguards.
assert 'synthetic is not None and synthetic < 1.5' in ai
assert 'n>=4 and (m.get("expected_roi") or 0)>=100' in ai
assert 'min(13,len(value_order))' in ai
assert 'LEFT JOIN prediction_result_reviews pr' in learn
assert '予想・結果詳細履歴' in learn

# Functional strategy test with a broad plausible distribution.
import sys
sys.path.insert(0,str(root))
from ai_predictor import strategy_options
rows=[]
probs=[.16,.13,.105,.085,.07,.06,.05,.045,.04,.035,.03,.028,.026,.024,.022,.02,.018,.016,.014,.012]
for i,pv in enumerate(probs):
    a=(i%6)+1; b=((i+1)%6)+1; c=((i+2)%6)+1
    if len({a,b,c})<3: c=((i+3)%6)+1
    odds=max(2.0,1.10/pv)
    rows.append({'combo':f'{a}-{b}-{c}','probability':pv,'odds':odds,'expected_return_index':pv*odds})
# unique combos only
uniq=[]; seen=set()
for r in rows:
    if r['combo'] not in seen:
        seen.add(r['combo']); uniq.append(r)
out=strategy_options(uniq)
assert len(out['return']['picks']) <= 13
assert len(out['return']['picks']) >= min(4,len(uniq))
assert len(out['hit']['picks']) >= min(4,len(uniq))
if out['hit']['synthetic_odds'] is not None and len(out['hit']['picks'])>=4:
    assert out['hit']['synthetic_odds'] >= 1.5 - 1e-9
print('PASS v17.242 scratch persistence + odds formatting + finish colors + auto review + strategy coverage')
