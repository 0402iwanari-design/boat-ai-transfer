from course_history import OfficialCourseHistoryCollector

UDAGAWA_RESULT_HTML = '''
<html><body><table>
<tr><th>着</th><th>枠</th><th>ボートレーサー</th><th>レースタイム</th></tr>
<tr><td>1</td><td>1</td><td>3357 福島陽子</td><td>1:52</td></tr>
<tr><td>2</td><td>6</td><td>3801 五反田忍</td><td>1:53</td></tr>
<tr><td>3</td><td>2</td><td>3618 海野ゆかり</td><td>1:54</td></tr>
<tr><td>4</td><td>5</td><td>4556 竹井奈美</td><td>1:55</td></tr>
<tr><td>5</td><td>4</td><td>5416 龍田真白</td><td></td></tr>
<tr><td>6</td><td>3</td><td>5342 原村百那</td><td></td></tr>
</table><div>スタート情報</div></body></html>
'''

class Resp:
    status_code = 200
    content = UDAGAWA_RESULT_HTML.encode('utf-8')
    encoding='utf-8'
    apparent_encoding='utf-8'
    def raise_for_status(self): pass

class Session:
    def __init__(self): self.calls=0
    def get(self,*a,**k): self.calls += 1; return Resp()

class Dummy(OfficialCourseHistoryCollector):
    def __init__(self):
        import threading
        self.status={}
        self._official_race_racer_cache={}
        self._official_race_racer_lock=threading.RLock()
        self._official_day_race_cache={}
        self._official_day_lock=threading.RLock()
        self._race_lock_guard=threading.Lock()
        self._race_fetch_locks={}
        self._stop=threading.Event()
    def _existing_saved_run(self,*a): return None
    def _cached_official_run(self,*a): return None
    def _race_page_cache_state(self,*a): return None
    def _cache_official_page_runs(self,*a): return 0
    def _parse_official_result(self,*a): return None
    def _candidate_exists_on_official_day(self,*a): return True

c={'date':'20260719','jcd':'19','rno':3}
d=Dummy()
regs=d._raw_official_racer_regs(UDAGAWA_RESULT_HTML)
assert set(regs)=={'3357','3801','3618','4556','5416','5342'}, regs
assert d._candidate_racer_exists_on_official_race(Session(),c,'4660',UDAGAWA_RESULT_HTML) is False
assert d._candidate_racer_exists_on_official_race(Session(),c,'3357',UDAGAWA_RESULT_HTML) is True

# Critical regression: real race exists, detailed parser returns zero, but target racer is absent.
# This must be dropped as a false archive candidate instead of entering retry forever.
s=Session(); d=Dummy()
row=d._fetch_official_run(s,c,'4660')
assert row is None
assert s.calls == 1, s.calls
assert d.status.get('invalid_archive_racer_candidates_dropped') == 1
assert 'does not contain racer 4660' in d.status.get('last_invalid_archive_candidate','')

# If the target racer is genuinely in the official roster, zero-detail parsing remains an error.
# We must not silently discard a real race just to reduce the retry queue.
html_present=UDAGAWA_RESULT_HTML.replace('3357 福島陽子','4660 宇田川信一')
class RespPresent(Resp): content=html_present.encode('utf-8')
class SessionPresent(Session):
    def get(self,*a,**k): self.calls += 1; return RespPresent()
d=Dummy(); s=SessionPresent()
try:
    d._fetch_official_run(s,c,'4660')
except RuntimeError as e:
    assert 'racercheck=present' in str(e), str(e)
else:
    raise AssertionError('present racer + parser zero must stay as an error')
assert s.calls == 3, s.calls

# Stronger link-based extraction also works.
link_html='<a href="/owpc/pc/data/racersearch/profile?toban=4660">宇田川信一</a>'
assert d._raw_official_racer_regs(link_html)==['4660']

print('PASS v17.236: false candidate racer membership is dropped; real-racer parser failures remain visible')
