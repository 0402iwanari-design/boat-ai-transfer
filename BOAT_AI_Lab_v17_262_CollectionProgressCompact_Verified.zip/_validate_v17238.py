import sqlite3
import tempfile
from db import BoatDB
from course_history import OfficialCourseHistoryCollector

STRUCT_ERR = (
    "RuntimeError: 公式結果ページ解析0件 "
    "[enc=UTF-8 bytes=13995 start=0 racer=1 reg=2 st=0 daycheck=exists racercheck=unknown]"
)

class DummySession:
    pass

with tempfile.TemporaryDirectory() as td:
    dbpath = td + '/t.db'

    # Simulate a v17.237 DB: failed queue exists, but has no archive-hint columns.
    con = sqlite3.connect(dbpath)
    con.execute('''CREATE TABLE course_history_failed_candidates (
        date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
        registration_no TEXT NOT NULL, error TEXT,
        retry_count INTEGER NOT NULL DEFAULT 0,
        last_try_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(date,jcd,rno,registration_no)
    )''')
    con.commit(); con.close()

    c = OfficialCourseHistoryCollector(BoatDB(dbpath))

    # 1) Migration adds all v17.238 fields and the quarantine table.
    with c.db.connect() as con:
        cols = {r['name'] for r in con.execute('PRAGMA table_info(course_history_failed_candidates)').fetchall()}
        for col in ('course_hint','st_hint','st_rank_hint','finish_hint','hint_confidence','candidate_source'):
            assert col in cols, (col, cols)
        q = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='course_history_unavailable_candidates'").fetchone()
        assert q is not None

    # 2) Failure queue preserves strict archive data instead of discarding it.
    cand = {
        'date':'20200910','jcd':'13','rno':4,
        'course_hint':5,'st_hint':'.14','st_rank_hint':3,'finish_hint':'6',
        'hint_confidence':'strict-matrix-v1','candidate_source':'year-archive-test',
    }
    c._record_failed_candidate(cand, '3319', STRUCT_ERR)
    pending = c._failed_candidates('3319')
    assert len(pending) == 1
    x = pending[0]
    assert x['course_hint'] == 5
    assert x['st_hint'] == '.14'
    assert x['st_rank_hint'] == 3
    assert x['finish_hint'] == '6'
    assert x['hint_confidence'] == 'strict-matrix-v1'
    assert x['candidate_source'] == 'year-archive-test'
    assert x['retry_count'] == 1

    # 3) A second structural-zero failure is quarantined, not requeued forever.
    seen = {}
    def structural_fail(session, candidate, reg):
        seen.update(candidate)
        raise RuntimeError(STRUCT_ERR.replace('RuntimeError: ', '', 1))
    c._fetch_official_run = structural_fail
    rv, rs, rf = c._retry_failed_candidates(DummySession(), '3319', '山崎義明', 0, ['13'])
    assert (rv, rs, rf) == (0, 0, 0), (rv, rs, rf)
    assert c._failed_candidates('3319') == []
    assert seen['course_hint'] == 5 and seen['st_hint'] == '.14' and seen['finish_hint'] == '6'
    with c.db.connect() as con:
        row = con.execute('''SELECT * FROM course_history_unavailable_candidates
                             WHERE registration_no='3319' AND date='20200910' AND jcd='13' AND rno=4''').fetchone()
        assert row is not None
        assert row['course_hint'] == 5 and row['st_hint'] == '.14' and row['finish_hint'] == '6'
        assert row['retry_count'] == 2

    # 4) Non-structural failures still stay in the retry queue and increment normally.
    cand2 = {'date':'20210101','jcd':'01','rno':1,'candidate_source':'test'}
    c._record_failed_candidate(cand2, '9999', 'RuntimeError: HTTP 500')
    def network_fail(session, candidate, reg):
        raise RuntimeError('HTTP 500')
    c._fetch_official_run = network_fail
    rv, rs, rf = c._retry_failed_candidates(DummySession(), '9999', 'test', 0, ['01'])
    assert (rv, rs, rf) == (0, 0, 1)
    p2 = c._failed_candidates('9999')
    assert len(p2) == 1 and p2[0]['retry_count'] == 2

print('PASS v17.238 preserve failed-candidate hints + stop repeated structural official-page retry loop')
