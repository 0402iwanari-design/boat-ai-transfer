from bs4 import BeautifulSoup
from course_history import _venue_code, _venue_code_from_context, OfficialCourseHistoryCollector

# Regression: event title containing 時津 must never become 津(09).
assert _venue_code('BTS長崎時津開設記念') is None
assert _venue_code_from_context('BTS長崎時津開設記念') is None
assert _venue_code('津') == '09'
assert _venue_code('24# 大村') == '24'
assert _venue_code_from_context('24# 大村') == '24'
assert _venue_code_from_context('24# 大村 一般戦') == '24'
assert _venue_code_from_context('津 一般') == '09'
assert _venue_code('大村') == '24'
assert _venue_code('BOATRACE大村') == '24'

obj=OfficialCourseHistoryCollector.__new__(OfficialCourseHistoryCollector)
# Nearest-table scan must skip the misleading event title and pick the explicit venue heading.
soup=BeautifulSoup('''<h2>24# 大村</h2><div>BTS長崎時津開設記念</div><table><tr><td>x</td></tr></table>''','html.parser')
assert obj._nearest_table_venue(soup.find('table')) == '24'

# If there is only the event title, no venue may be fabricated.
soup2=BeautifulSoup('''<div>BTS長崎時津開設記念</div><table><tr><td>x</td></tr></table>''','html.parser')
assert obj._nearest_table_venue(soup2.find('table')) is None

# Exact race link remains authoritative even if a surrounding heading is wrong.
html='''<html><body><h3>津 一般</h3><table>
<tr><th>選手</th><th>7月14日</th></tr>
<tr><td>4411</td><td><a href="https://www.boatrace.jp/owpc/pc/race/raceresult?hd=20230714&jcd=24&rno=8">8R</a></td></tr>
<tr><td></td><td>2</td></tr><tr><td></td><td>.12</td></tr><tr><td></td><td>(3)</td></tr><tr><td></td><td>1</td></tr>
</table></body></html>'''
rows=obj._parse_year_archive_candidates(html,2023)
assert rows and any(x['jcd']=='24' and x['date']=='20230714' and x['rno']==8 for x in rows), rows
print('PASS v17.235 strict venue resolver: 時津 title no longer maps to 津; explicit 大村/link maps to 24')
