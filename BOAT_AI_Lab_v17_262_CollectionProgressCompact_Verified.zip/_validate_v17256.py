import math
import ai_predictor as ai

# 1) Current-series form must have more leverage than equipment alone.
base_course={"first_rate":20,"quinella_rate":45,"trio_rate":65,"avg_st":.16,"starts":20}
def racer(avg_finish, avg_st, motor_rate, boat_rate=35):
    return {
        "meeting_results":{"avg_rank":avg_finish,"avg_st":avg_st,"entries":[{"finish":str(round(avg_finish)),"st":f"{avg_st:.2f}"}]},
        "course_stats":{"1":base_course},
        "national_lane_results":{"win_rate":30,"starts":10},
        "local_lane_results":{"win_rate":25,"starts":6},
        "motor":{"quinella_rate":motor_rate},
        "boat":{"quinella_rate":boat_rate},
    }
strong_form_weak_motor,_=ai._pre_lane_score(1,racer(1.8,.11,28))
weak_form_strong_motor,_=ai._pre_lane_score(1,racer(4.8,.21,55))
assert strong_form_weak_motor > weak_form_strong_motor, (strong_form_weak_motor,weak_form_strong_motor)

# 2) Probability calibration must flatten extreme model confidence.
scores={1:100,2:50,3:40,4:30,5:20,6:10}
_, rawish=ai._combo_list(scores,list(scores),probability_power=1.0,market_blend=0.0)
_, calibrated=ai._combo_list(scores,list(scores),probability_power=.86,market_blend=0.0)
assert calibrated[0]["probability"] < rawish[0]["probability"], (calibrated[0],rawish[0])
assert abs(sum(x['probability'] for x in calibrated)-1.0) < .001

# 3) With a near-complete odds board, market shrinkage must be active and EV less extreme.
combos=[]
for i,row in enumerate(calibrated):
    x=dict(row); x['odds']=5.0 + (i%40)*1.7
    combos.append(x)
# Re-run through combo builder using an odds map built for all 120 combos.
odds={x['combo']:x['odds'] for x in combos}
_, market=ai._combo_list(scores,list(scores),odds_map=odds,probability_power=.86,market_blend=.30)
assert market[0]['probability_calibration']['market_blend'] == .30
assert abs(sum(x['probability'] for x in market)-1.0) < .001

# 4) Hit allocation remains exact 5,000 yen and minimum 100 yen.
picks=[{"combo":"1-2-3","probability":.20,"odds":4.0},{"combo":"1-3-2","probability":.12,"odds":8.0},{"combo":"2-1-3","probability":.03,"odds":1000.0}]
stakes=ai._allocate_5000_equal_payout(picks)
assert sum(stakes)==5000 and min(stakes)>=100 and stakes[-1]==100, stakes

# 5) Return-rate mode remains capped at 13 and does not collapse to 1-2 tickets when viable candidates exist.
rows=[]
for i in range(12):
    rows.append({"combo":f"{1+(i%6)}-{1+((i+1)%6)}-{1+((i+2)%6)}","probability":.03-i*.0005,"odds":40+i,"expected_return_index":1.20-i*.005,"value_score":1.20-i*.005})
# eliminate invalid repeated combos just in case and call strategy.
for x in rows:
    nums=x['combo'].split('-')
    if len(set(nums))<3: x['combo']='1-2-3'
ret=ai.strategy_options(rows)['return']
assert len(ret['picks']) <= 13

print('v17.256 validation PASS')
