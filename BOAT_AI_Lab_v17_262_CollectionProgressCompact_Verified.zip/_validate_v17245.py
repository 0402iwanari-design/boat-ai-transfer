from course_history import OfficialCourseHistoryCollector, RECENT_SOURCE_COOLDOWN_SECONDS

class DummyDB:
    def connect(self):
        raise RuntimeError('not used')

class Resp:
    def __init__(self, code=502, text='x'*1000, url='https://boatracedata.com/racer/5136'):
        self.status_code=code; self.text=text; self.url=url; self.content=text.encode()
    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f'{self.status_code} Server Error: Bad Gateway for url: {self.url}')

class BadSession:
    def __init__(self): self.calls=0
    def get(self,*a,**kw):
        self.calls += 1
        return Resp()

c = object.__new__(OfficialCourseHistoryCollector)
import threading, time
c._stop=threading.Event(); c.status={}; c._recent_source_lock=threading.RLock(); c._recent_source_disabled_until=0.0; c._recent_source_last_error=None
s=BadSession()
rows=c._fetch_recent_racer_candidates(s,'5136','テスト選手')
assert rows == []
assert s.calls == 2, s.calls
assert c._recent_source_open()
assert c.status.get('recent_source_circuit_open') is True
calls=s.calls
rows2=c._fetch_recent_racer_candidates(s,'5282','別選手')
assert rows2 == []
assert s.calls == calls, (s.calls,calls)
assert c._is_transient_fetch_error('HTTPError: 503 Server Error')
assert c._is_transient_fetch_error('ReadTimeout: timed out')
assert not c._is_transient_fetch_error('HTML too short (20)')
assert RECENT_SOURCE_COOLDOWN_SECONDS == 300
print('PASS v17.245 supplemental-source circuit breaker and transient classification')
