from ai_predictor import build_venue_profile, _venue_lane_adjustments, VENUE_OFFICIAL_BASELINES

assert len(VENUE_OFFICIAL_BASELINES) == 24

# Regression: bare method words next to an unrelated 94.7% must never become
# fake winning-method percentages.
noise = [{
    'title': '場資料',
    'source_kind': 'test',
    'content_text': '逃げ：94.7% 差し：94.7% まくり：94.7% まくり差し：94.7% 抜き：94.7% 水面は広い。'
}]
p = build_venue_profile(noise, '07')
assert p['winning_methods'] == {}, p['winning_methods']
assert '逃げ' in p['winning_method_tendencies']
assert p['wind_guide']['general'] and p['wind_guide']['venue']
assert any('公式・水面' in x for x in p['characteristic_notes'])

# Explicitly labelled rate remains supported.
explicit = [{'title':'統計','source_kind':'test','content_text':'逃げ率 52.3% 差し占有率 18.4% 水面特性 インが強い。'}]
p2 = build_venue_profile(explicit, '07')
assert abs(p2['winning_methods']['逃げ'] - 52.3) < 1e-9
assert abs(p2['winning_methods']['差し'] - 18.4) < 1e-9

# Venue baselines are stable even with no scraped documents.
for jcd in VENUE_OFFICIAL_BASELINES:
    q = build_venue_profile([], jcd)
    assert q['official_baseline'] is True
    assert q['characteristic_notes']
    assert q['winning_method_tendencies']
    assert len(q['wind_guide']['general']) == 3

# Trusted qualitative tendencies have only small bounded AI effects.
adj = _venue_lane_adjustments([1,2,3,4,5,6], build_venue_profile([], '02'))
assert adj[1]['score'] < 0
assert adj[4]['score'] > 0
assert max(abs(v['score']) for v in adj.values()) < 2.0

print('v17.259 venue profile validation PASS')
