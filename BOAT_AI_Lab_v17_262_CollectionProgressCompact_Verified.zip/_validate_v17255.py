import json, sqlite3, tempfile
from pathlib import Path

from review_statistics import _prediction_records

class DB:
    def __init__(self,path): self.path=path
    def connect(self):
        con=sqlite3.connect(self.path); con.row_factory=sqlite3.Row; return con

def setup(path, saved=True):
    con=sqlite3.connect(path)
    con.executescript('''
    create table predictions(date text,jcd text,rno integer,created_at text,source_snapshot text);
    create table race_results(date text,jcd text,rno integer,trifecta text,payout_yen integer,odds real);
    create table race_schedule(date text,jcd text,rno integer,deadline text);
    ''')
    picks=[{"combo":"1-2-3","stake":3000,"odds":3.0},{"combo":"1-3-2","stake":1500,"odds":6.0},{"combo":"2-1-3","stake":500,"odds":20.0}] if saved else ["1-2-3","1-3-2","2-1-3"]
    snap={"generated_at":"2026-10-03T01:00:00+09:00","pre_saved_at":"2026-10-03T01:00:00+09:00","pre_prediction":{"strategies_saved_at":"2026-10-03T01:00:00+09:00","strategies":{"hit":{"picks":picks},"return":{"picks":picks}}}}
    con.execute('insert into predictions values(?,?,?,?,?)',('20261003','01',1,'2026-10-02T16:00:00+00:00',json.dumps(snap)))
    con.execute('insert into race_results values(?,?,?,?,?,?)',('20261003','01',1,'1-3-2',600,6.0))
    con.execute('insert into race_schedule values(?,?,?,?)',('20261003','01',1,'12:00'))
    con.commit(); con.close()

def main():
    with tempfile.TemporaryDirectory() as td:
        p=str(Path(td)/'a.db'); setup(p,True)
        rows=_prediction_records(DB(p),'20261003')
        hit=[x for x in rows if x['stage']=='PRE' and x['mode']=='hit'][0]
        assert hit['stake_yen']==5000, hit
        assert hit['winning_stake_yen']==1500, hit
        assert hit['return_yen']==9000, hit
        assert hit['allocation_source']=='saved_stakes', hit
        p2=str(Path(td)/'b.db'); setup(p2,False)
        rows2=_prediction_records(DB(p2),'20261003')
        h2=[x for x in rows2 if x['stage']=='PRE' and x['mode']=='hit'][0]
        assert round(h2['winning_stake_yen'],2)==round(5000/3,2), h2
        assert h2['allocation_source']=='legacy_equal_split', h2
    print('v17.255 validation PASS')
if __name__=='__main__': main()
