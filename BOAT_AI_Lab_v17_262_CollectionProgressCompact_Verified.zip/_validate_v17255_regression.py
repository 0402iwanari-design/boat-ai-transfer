from pathlib import Path
from ai_predictor import _allocate_5000_equal_payout

root=Path(__file__).parent
html=(root/'static/index.html').read_text()
app=(root/'app.py').read_text()
collector=(root/'collector.py').read_text()

# Current version markers
assert 'v17.255 実配分回収率集計修正版' in html
assert 'version="1.0.255"' in app
assert '"version": "1.0.255"' in app

# v17.254 racer bio stack preserved
assert '<col class="rl-bio"><col class="rl-tilt">' in html
assert '<th class="racelist-bio-head">年齢 / 体重<br>支部<br>出身</th>' in html
assert 'class="racelist-bio-cell"' in html
assert '${x.age??"—"}歳' in html
assert '${x.weight_kg??"—"}kg' in html
assert '${x.branch||"—"}</span><small>支部</small>' in html
assert '${x.origin||"—"}</span><small>出身</small>' in html
assert '.racelist-inline-meeting col.rl-bio{width:165px}' in html

# v17.253 fixed 10 slots preserved
assert 'const labels=Array.from({length:10}' in html
assert 'Array(Math.max(0,10-history.length)).fill(null)' in html

# v17.250 provisional PRE / hidden odds preserved
assert 'オッズ反映待ち' in html
assert '出目予想を先に表示しています' in html
assert 'ai-provisional-picks' in html
ai_row=html[html.index('function aiComboRow'):html.index('// 予想の採用順')]
assert 'オッズ ${Number(x.odds)' not in ai_row
assert 'if 0 <= mins <= 15:' in collector

# Hit allocation rule preserved
picks=[
 {"combo":"1-2-3","odds":4.0,"probability":.25},
 {"combo":"1-3-2","odds":6.0,"probability":.20},
 {"combo":"2-1-3","odds":8.0,"probability":.15},
 {"combo":"6-5-4","odds":1000.0,"probability":.001},
]
stakes=_allocate_5000_equal_payout(picks)
assert sum(stakes)==5000
assert stakes[-1]==100
print('v17.255 regression PASS')
