from boat_source import BoatRaceSource
from db import _official_course_payload

rows=lambda vals: ''.join(f'<tr><th>{i}コース</th><td>{v}</td></tr>' for i,v in enumerate(vals,1))
trio=[94.1,33.3,58.3,73.3,50.0,15.8]
# Fixture mirrors the official nested progress structure and deliberately uses
# alternate hyphenated class spellings for 2nd/3rd to exercise the robust parser.
parts=[(70.0,15.0,9.1),(20.0,8.0,5.3),(25.0,20.0,13.3),(30.0,25.0,18.3),(18.0,17.0,15.0),(0.0,5.0,10.8)]
barrows=[]
for i,(a,b,c) in enumerate(parts,1):
    spans=[]
    for n,v,cl in [(1,a,'is-progress1'),(2,b,'is-progress-2'),(3,c,'progress_3')]:
        if v: spans.append(f'<span class="is-progress" style="width:{v}%"><span class="{cl}" style="width:100%"></span></span>')
    barrows.append(f'<tr><th>{i}コース</th><td>{trio[i-1]}%</td><td>{"".join(spans)}</td></tr>')
html='<html><body><h2>テスト太郎</h2><table>'+rows([10,20,20,20,15,15])+'</table><table><caption>コース別3連対率</caption>'+''.join(barrows)+'</table><table>'+rows([.12,.13,.14,.15,.16,.17])+'</table><table>'+rows([2.1,2.2,2.3,2.4,2.5,2.6])+'</table></body></html>'
obj=BoatRaceSource.__new__(BoatRaceSource)
obj._get=lambda *a,**k: html
out=obj.fetch_official_racer_course_data('9999','テスト太郎')
assert out['course_stats_version']==4
for row, exp, total in zip(out['course_stats'],parts,trio):
    got=(row['first_rate'],row['second_rate'],row['third_rate'])
    assert got==exp,(got,exp)
    assert abs(sum(got)-total)<0.01,(got,total)
assert _official_course_payload(out) is not None
bad={**out,'course_stats':[dict(x) for x in out['course_stats']]}
bad['course_stats'][0]['second_rate']=0
assert _official_course_payload(bad) is None
print('PASS: 1st/2nd/3rd nested bars parsed separately; totals validated; partial snapshots rejected')
