from pathlib import Path
root=Path(__file__).resolve().parent
html=(root/'static/index.html').read_text(encoding='utf-8')
app=(root/'app.py').read_text(encoding='utf-8')
collector=(root/'collector.py').read_text(encoding='utf-8')
assert 'v17.257 AIオッズ・合成オッズ・払戻表示版' in html
assert '1.0.257' in app
assert 'ai-odds' in html and 'ai-payout' in html
assert '払戻 ${(odd*st).toLocaleString' in html
assert '合成オッズ ${o.synthetic_odds==null?' in html
assert 'オッズ反映待ち' in html
assert 'live_interval = 30 if 0 <= mins <= 5 else (60 if 0 <= mins <= 15 else None)' in collector
assert 'deadline_ts + 60' in collector
print('v17.257 validation PASS')
