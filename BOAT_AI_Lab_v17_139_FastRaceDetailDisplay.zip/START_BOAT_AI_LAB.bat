@echo off
setlocal
cd /d "%~dp0"
title BOAT AI Lab v17.139 Fast Race Detail

echo ==========================================
echo BOAT AI Lab v17.139 Fast Race Detail
echo ==========================================
echo.

set "PY="
where py >nul 2>&1
if not errorlevel 1 set "PY=py -3"

if not defined PY (
    where python >nul 2>&1
    if not errorlevel 1 set "PY=python"
)

if not defined PY (
    echo [ERROR] Python was not found.
    pause
    exit /b 1
)

echo [1/4] Python:
%PY% --version

echo.
echo [2/4] pip:
%PY% -m pip --version
if errorlevel 1 (
    echo [ERROR] pip is not available.
    pause
    exit /b 1
)

echo.
echo [3/4] Packages:
%PY% -c "import fastapi,uvicorn,requests,bs4,pypdf" >nul 2>&1
if errorlevel 1 (
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] Package installation failed.
        pause
        exit /b 1
    )
)

echo.
echo [4/4] Starting server + background collector...
echo.
echo IMPORTANT:
echo Close old BOAT AI Lab black windows before running this version.
echo Keep this window open while using the site.
echo URL: http://127.0.0.1:8000
echo.

start "" cmd /c "timeout /t 3 /nobreak >nul & start "" http://127.0.0.1:8000"
%PY% -m uvicorn app:app --host 127.0.0.1 --port 8000

echo.
echo Server stopped.
pause
