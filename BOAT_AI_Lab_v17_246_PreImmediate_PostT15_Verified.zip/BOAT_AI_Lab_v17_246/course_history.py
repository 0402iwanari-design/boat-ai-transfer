from __future__ import annotations
"""v17.230: need-only national/local collection + today-venue local filtering + live result maintenance.

UI progress enhancement: expose the current racer's local-course counts for today's venue(s) alongside nationwide counts.

Fixed collection flow (same racer-first flow validated with 峰竜太4320):
  1) Target ONLY racers appearing in today's saved official racelists.
  2) For a racer not initialized before, open that RACER'S OWN history first.
  3) For each candidate race, open the BOAT RACE official result page.
  4) Determine actual entry course from official スタート情報 order.
  5) Save the same confirmed run into:
       - nationwide history (racer_course_runs)
       - that venue's local history (racer_local_course_runs)
     Each venue/course keeps at most newest 10 rows; nationwide display reconstructs
     the newest 10 across all venues.
  6) Continue newest -> oldest through 2020-01-01 so every venue/course can be
     initialized as far as the agreed floor allows.
  7) Mark the racer initialized. That racer is NEVER historically crawled again.
  8) After initialization, newly confirmed official race results maintain both
     nationwide + local histories incrementally; DB trimming removes the oldest row.

One failed race does not abort the whole racer scan. A source/year fetch failure leaves
that racer unfinished so the scheduler can retry later. No all-racer/all-venue reset is done.
"""

import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import unicodedata
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

from parser import parse_result_detail

JST = ZoneInfo("Asia/Tokyo")
FLOOR_DATE = "20200101"
FLOOR_YEAR = 2020
MAX_PARALLEL_RACERS = 3
PREFILTER_RESERVE_PER_BUCKET = 3
TRANSIENT_HTTP_CODES = (429, 502, 503, 504)
RECENT_SOURCE_COOLDOWN_SECONDS = 300
VENUES = [
    "桐生", "戸田", "江戸川", "平和島", "多摩川", "浜名湖", "蒲郡", "常滑", "津", "三国", "びわこ", "住之江",
    "尼崎", "鳴門", "丸亀", "児島", "宮島", "徳山", "下関", "若松", "芦屋", "福岡", "唐津", "大村",
]
VENUE_CODE = {n: f"{i:02d}" for i, n in enumerate(VENUES, 1)}


def _nfkc(s):
    return unicodedata.normalize("NFKC", str(s or ""))


def _norm(s):
    return re.sub(r"[\s\u3000]+", "", _nfkc(s))


def _venue_code(s):
    """Parse a venue only from a venue-like token, never from arbitrary title text.

    The old implementation used substring matching (e.g. ``津`` inside
    ``BTS長崎時津開設記念``) and could manufacture the wrong venue code.
    This parser accepts exact venue cells plus explicit code/name labels only.
    """
    raw = _nfkc(s)
    n = _norm(raw)
    if not n:
        return None

    # Exact venue cell is always safe.
    for name, code in VENUE_CODE.items():
        if _norm(name) == n:
            return code

    # Explicit numeric venue code + venue name, e.g. ``24# 大村`` / ``24 大村``.
    m = re.search(r'(?<!\d)(2[0-4]|1\d|0?[1-9])\s*#?\s*([^\s#]+)', raw)
    if m:
        code = f"{int(m.group(1)):02d}"
        tail = _norm(m.group(2))
        expected = VENUES[int(code) - 1]
        if _norm(expected) in tail or tail in {_norm(expected), _norm(expected + '競艇場')} :
            return code

    # A compact venue label may carry only a standard suffix/prefix.  Do not
    # allow free-form substring matches inside event titles.
    for name, code in VENUE_CODE.items():
        nn = _norm(name)
        safe = {
            nn + '競艇場', nn + 'ボートレース', nn + 'BOATRACE',
            'ボートレース' + nn, 'BOATRACE' + nn,
        }
        if n in safe:
            return code
    return None


def _venue_code_from_context(s):
    """Strict venue extraction for headings surrounding an archive table.

    Context nodes often contain event titles.  Only explicit venue labels are
    accepted here so names such as ``時津`` cannot be mistaken for 津.
    """
    raw = _nfkc(s)
    n = _norm(raw)
    direct = _venue_code(raw)
    if direct:
        return direct

    # Common archive heading forms: ``24# 大村`` / ``24#大村 ...``.
    for idx, name in enumerate(VENUES, 1):
        if re.search(rf'(?<!\d)0?{idx}\s*#\s*{re.escape(name)}(?:$|[\s　:/／|｜（(])', raw):
            return f"{idx:02d}"

    # Venue-first compact headings such as ``津 一般`` or ``大村 G1`` are safe
    # enough because the venue name is the heading prefix, not a substring inside
    # an event title.  Restrict the tail to known race-grade/heading vocabulary.
    grade_tail = r'(?:一般(?:戦)?|SG|G1|G2|G3|ヴィーナス|ルーキー|マスターズ|タイトル戦)?'
    for idx, name in enumerate(VENUES, 1):
        if re.fullmatch(rf'\s*{re.escape(name)}(?:競艇場|ボートレース)?(?:[\s　:/／|｜-]+{grade_tail})?\s*', raw, re.I):
            return f"{idx:02d}"
    return None


def _date_token(s, year):
    text = _nfkc(s)
    m = re.search(r"(?<!\d)(?:(\d{4})[/-])?(\d{1,2})[/-](\d{1,2})(?!\d)", text)
    if not m:
        m = re.search(r"(?<!\d)(?:(\d{4})年)?\s*(\d{1,2})月\s*(\d{1,2})日", text)
    if not m:
        return None
    y = int(m.group(1) or year)
    return f"{y:04d}{int(m.group(2)):02d}{int(m.group(3)):02d}"


def _race_token(s):
    m = re.fullmatch(r"\s*(\d{1,2})\s*R\s*", _nfkc(s), re.I)
    if not m:
        return None
    n = int(m.group(1))
    return n if 1 <= n <= 12 else None


def _course_token(s):
    """Strictly parse an actual-entry course token from the archive matrix.

    We intentionally accept only a bare 1..6 cell.  Anything ambiguous falls back
    to official-result verification and is NEVER used to skip a page.
    """
    t = _norm(s)
    return int(t) if re.fullmatch(r"[1-6]", t) else None


def _st_token(s):
    t = _norm(s).upper()
    return t if re.fullmatch(r"(?:[FL]?\.\d{1,2}|[FL])", t) else None


def _st_rank_token(s):
    m = re.fullmatch(r"\(([1-6])\)", _norm(s))
    return int(m.group(1)) if m else None


def _archive_finish_token(s):
    t = _norm(s).upper()
    if re.fullmatch(r"[1-6]", t):
        return t
    if t in {"F", "L", "S0", "S1", "S2", "K0", "K1", "転", "落", "沈", "エ", "妨", "失", "不完"}:
        return t
    return None


def _st_value(s):
    t = _norm(s).upper()
    if re.fullmatch(r"\.\d{1,2}", t):
        return float("0" + t)
    m = re.fullmatch(r"F\.(\d{1,2})", t)
    if m:
        return -float("0." + m.group(1))
    m = re.fullmatch(r"L\.(\d{1,2})", t)
    if m:
        return float("0." + m.group(1))
    return None


def _finish_token(s):
    t = _norm(s).replace("着", "")
    return t if re.fullmatch(r"[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠", t) else None


class OfficialCourseHistoryCollector:
    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        # Three racers may fetch/parse concurrently. SQLite mutations remain serialized.
        self._db_write_lock = threading.RLock()
        self._status_lock = threading.RLock()
        self._race_lock_guard = threading.Lock()
        self._race_fetch_locks = {}
        self._worker_progress = {}
        self._prefilter_hint_mismatch_regs = set()
        # boatracedata.com is only a freshness supplement. If it starts returning
        # gateway/rate-limit errors, temporarily bypass it so all three worker slots
        # can continue with the authoritative year archive + BOAT RACE official data.
        self._recent_source_lock = threading.RLock()
        self._recent_source_disabled_until = 0.0
        self._recent_source_last_error = None
        # One result-list fetch validates all 12 races for a date/venue.  This is
        # used only when a per-race result page parses as zero rows, so malformed
        # archive candidates are dropped instead of being retried forever.
        self._official_day_race_cache = {}
        self._official_day_lock = threading.RLock()
        # Candidate racer membership cache.  Archive matrices can occasionally
        # manufacture a real date+venue+race key that belongs to somebody else.
        # Cache the official six-racer membership so those false positives are
        # discarded instead of retried forever.
        self._official_race_racer_cache = {}
        self._official_race_racer_lock = threading.RLock()
        self.status = {
            "phase": "本日の出走選手待ち",
            "validation_mode": "v17.246 事前AI即時生成・直前15分分離版",
        }
        self._ensure_tables()
        self._recover_stale_running_states()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._scheduler, daemon=True, name="course-history-today-racers-once")
        self._thread.start()

    def _ensure_tables(self):
        with self.db.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS racer_local_course_runs (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, lane INTEGER, course INTEGER NOT NULL,
                finish TEXT, st_raw TEXT, st_rank INTEGER, source TEXT,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_racer_local_course_runs_lookup
                           ON racer_local_course_runs(registration_no,jcd,course,date DESC)""")
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_initial_racers (
                registration_no TEXT PRIMARY KEY,
                name TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                recent_done INTEGER NOT NULL DEFAULT 0,
                initial_pass_done INTEGER NOT NULL DEFAULT 0,
                cursor_year INTEGER,
                floor_date TEXT NOT NULL DEFAULT '20200101',
                target_date TEXT,
                candidate_count INTEGER NOT NULL DEFAULT 0,
                verified_count INTEGER NOT NULL DEFAULT 0,
                saved_count INTEGER NOT NULL DEFAULT 0,
                retry_count INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                started_at TEXT,
                completed_at TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_course_history_initial_status
                           ON course_history_initial_racers(status,registration_no)""")
            # v17.233 migration: remember that the expensive archive scan has reached
            # the deferred individual-race retry stage. Older DBs do not have this flag.
            cols = {str(r["name"]) for r in con.execute("PRAGMA table_info(course_history_initial_racers)").fetchall()}
            if "initial_pass_done" not in cols:
                con.execute("ALTER TABLE course_history_initial_racers ADD COLUMN initial_pass_done INTEGER NOT NULL DEFAULT 0")
            # Backfill only states that explicitly reached the old terminal retry stage.
            con.execute("""UPDATE course_history_initial_racers
                           SET initial_pass_done=1
                           WHERE initial_pass_done=0
                             AND last_error LIKE '個別レース再試行待ち %'""")
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_official_run_cache (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, lane INTEGER, course INTEGER NOT NULL,
                finish TEXT, st_raw TEXT, st_rank INTEGER, source TEXT,
                cached_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_course_history_official_run_cache_lookup
                           ON course_history_official_run_cache(date,jcd,rno,registration_no)""")
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_official_race_cache (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                parsed_rows INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'parsed',
                fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno)
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_failed_candidates (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, error TEXT,
                course_hint INTEGER, st_hint TEXT, st_rank_hint INTEGER, finish_hint TEXT,
                hint_confidence TEXT, candidate_source TEXT,
                retry_count INTEGER NOT NULL DEFAULT 0,
                last_try_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")
            # v17.238 migration: older DBs kept only the race key/error. Preserve the
            # strict archive fields as well, so a deferred retry never throws away the
            # already parsed actual course/ST/ST-rank/finish information.
            fcols = {str(r["name"]) for r in con.execute("PRAGMA table_info(course_history_failed_candidates)").fetchall()}
            for col, decl in (
                ("course_hint", "INTEGER"), ("st_hint", "TEXT"),
                ("st_rank_hint", "INTEGER"), ("finish_hint", "TEXT"),
                ("hint_confidence", "TEXT"), ("candidate_source", "TEXT"),
            ):
                if col not in fcols:
                    con.execute(f"ALTER TABLE course_history_failed_candidates ADD COLUMN {col} {decl}")
            con.execute("""CREATE INDEX IF NOT EXISTS idx_course_history_failed_reg
                           ON course_history_failed_candidates(registration_no,date DESC)""")
            # Permanently remember official result pages that were repeatedly reachable
            # but structurally lacked start/ST data. These rows are NOT saved as course
            # history; they are quarantined only to prevent an endless retry loop.
            con.execute("""CREATE TABLE IF NOT EXISTS course_history_unavailable_candidates (
                date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
                registration_no TEXT NOT NULL, reason TEXT,
                course_hint INTEGER, st_hint TEXT, st_rank_hint INTEGER, finish_hint TEXT,
                hint_confidence TEXT, candidate_source TEXT,
                retry_count INTEGER NOT NULL DEFAULT 0,
                marked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno,registration_no)
            )""")

    def _recover_stale_running_states(self):
        """A process restart means no old worker thread can still be alive.

        Rows left as status=running by the previous process are therefore stale.
        Return them to pending without counting them as an error.
        """
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers
                               SET status='pending',updated_at=CURRENT_TIMESTAMP
                               WHERE status='running'""")

    def _scheduler(self):
        while not self._stop.is_set():
            today = datetime.now(JST).strftime("%Y%m%d")
            try:
                self._run(today)
            except Exception as e:
                self.status.update({
                    "phase": "コース履歴初期構築エラー",
                    "scheduler_error": f"{type(e).__name__}: {e}",
                })
            self._stop.wait(20)

    def _today_racers(self, today):
        """Read only today's already-saved official racelists; no web access here."""
        racers = {}
        with self.db.connect() as con:
            rows = con.execute(
                "SELECT jcd,payload FROM race_snapshots WHERE date=? AND kind='racelist'",
                (str(today),),
            ).fetchall()
        for row in rows:
            jcd = str(row["jcd"] or "").zfill(2)
            try:
                payload = json.loads(row["payload"] or "{}")
            except Exception:
                continue
            for x in payload.get("racers") or []:
                reg = str(x.get("registration_no") or "").strip()
                name = str(x.get("name") or "").strip()
                if not reg:
                    continue
                item = racers.setdefault(reg, {"registration_no": reg, "name": name, "today_venues": set()})
                if name:
                    item["name"] = name
                if jcd:
                    item["today_venues"].add(jcd)
        out = []
        for x in racers.values():
            x["today_venues"] = sorted(x["today_venues"])
            out.append(x)
        return sorted(out, key=lambda z: z["registration_no"])

    def _register_today_targets(self, today, racers):
        current_year = datetime.now(JST).year
        with self.db.connect() as con:
            for x in racers:
                con.execute("""
                    INSERT INTO course_history_initial_racers
                    (registration_no,name,status,recent_done,cursor_year,floor_date,target_date)
                    VALUES(?,?,'pending',0,?,?,?)
                    ON CONFLICT(registration_no) DO UPDATE SET
                      name=CASE WHEN excluded.name!='' THEN excluded.name ELSE course_history_initial_racers.name END,
                      target_date=excluded.target_date,
                      updated_at=CURRENT_TIMESTAMP
                """, (x["registration_no"], x.get("name") or "", current_year, FLOOR_DATE, str(today)))

    def _state(self, reg):
        with self.db.connect() as con:
            row = con.execute("SELECT * FROM course_history_initial_racers WHERE registration_no=?", (str(reg),)).fetchone()
        return dict(row) if row else None

    def _pending_today(self, racers):
        out = []
        for x in racers:
            s = self._state(x["registration_no"])
            if not s or s.get("status") != "complete":
                out.append(x)
        return out



    def _priority_pending_today(self, racers):
        """Return today's work queue in a strict priority order.

        1) Never-started racers first.
        2) Started but clean/pending racers next.
        3) Racers with retry/error state last.

        This keeps repeated failures from consuming worker slots while hundreds of
        racers have not yet had their first build attempt.
        """
        unstarted, clean_pending, retry_pending = [], [], []
        for x in racers:
            reg = str(x.get("registration_no") or "")
            st = self._state(reg) or {}
            if st.get("status") == "complete":
                continue
            if not st.get("started_at"):
                unstarted.append(x)
            elif st.get("last_error") or int(st.get("retry_count") or 0) > 0:
                retry_pending.append(x)
            else:
                clean_pending.append(x)
        if unstarted:
            return unstarted, "未着手優先"
        if clean_pending:
            return clean_pending, "通常未完了優先"
        return retry_pending, "エラー再試行フェーズ"

    def _today_status_overview(self, racers):
        regs = [str(x.get("registration_no") or "").strip() for x in (racers or []) if str(x.get("registration_no") or "").strip()]
        if not regs:
            return {"complete": 0, "running": 0, "error": 0, "unstarted": 0, "queued": 0, "errors": []}
        placeholders = ",".join("?" for _ in regs)
        with self.db.connect() as con:
            rows = con.execute(f"""SELECT registration_no,name,status,retry_count,last_error,started_at,completed_at
                                  FROM course_history_initial_racers
                                  WHERE registration_no IN ({placeholders})""", regs).fetchall()
        by = {str(r["registration_no"]): dict(r) for r in rows}
        complete = running = error = unstarted = queued = 0
        errors = []
        for x in racers:
            reg = str(x.get("registration_no") or "")
            r = by.get(reg)
            if not r or not r.get("started_at"):
                unstarted += 1
                continue
            if r.get("status") == "complete":
                complete += 1
            elif r.get("status") == "running":
                running += 1
            elif r.get("last_error") or int(r.get("retry_count") or 0) > 0:
                error += 1
                failed_details = self._failed_candidates(reg)[:5]
                errors.append({"registration_no": reg, "name": r.get("name") or x.get("name") or reg,
                               "error": str(r.get("last_error") or "再試行待ち")[:160],
                               "retry_count": int(r.get("retry_count") or 0),
                               "failed_races": [{
                                   "date": str(y.get("date") or ""),
                                   "jcd": str(y.get("jcd") or "").zfill(2),
                                   "rno": int(y.get("rno") or 0),
                                   "error": str(y.get("error") or "")[:220],
                                   "retry_count": int(y.get("retry_count") or 0),
                               } for y in failed_details]})
            else:
                queued += 1
        return {"complete": complete, "running": running, "error": error, "unstarted": unstarted,
                "queued": queued, "errors": errors[-8:]}

    def _mark_started(self, reg, name, today):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers
                           SET name=?,status='running',target_date=?,started_at=COALESCE(started_at,CURRENT_TIMESTAMP),
                               last_error=NULL,updated_at=CURRENT_TIMESTAMP
                           WHERE registration_no=?""", (name or "", str(today), str(reg)))

    def _mark_recent_done(self, reg):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("UPDATE course_history_initial_racers SET recent_done=1,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?", (str(reg),))

    def _mark_initial_pass_done(self, reg):
        """Persist that archive/history crawling is finished for this racer.

        From this point onward, any remaining work is only the small deferred
        individual-race retry queue. This survives restarts and unrelated errors.
        """
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("UPDATE course_history_initial_racers SET initial_pass_done=1,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?", (str(reg),))

    def _advance_year(self, reg, next_year, add_candidates=0, add_verified=0, add_saved=0):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers SET cursor_year=?,
                           candidate_count=candidate_count+?,verified_count=verified_count+?,saved_count=saved_count+?,
                           last_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (int(next_year), int(add_candidates), int(add_verified), int(add_saved), str(reg)))

    def _add_progress(self, reg, cand=0, verified=0, saved=0):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers SET
                           candidate_count=candidate_count+?,verified_count=verified_count+?,saved_count=saved_count+?,
                           updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (int(cand), int(verified), int(saved), str(reg)))

    def _mark_error(self, reg, err):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers SET status='pending',retry_count=retry_count+1,
                           last_error=?,updated_at=CURRENT_TIMESTAMP WHERE registration_no=?""",
                        (str(err)[:1200], str(reg)))

    def _mark_complete(self, reg):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""UPDATE course_history_initial_racers SET status='complete',cursor_year=?,
                           completed_at=CURRENT_TIMESTAMP,last_error=NULL,updated_at=CURRENT_TIMESTAMP
                           WHERE registration_no=?""", (FLOOR_YEAR-1, str(reg)))

    def _summary_counts(self, reg):
        with self.db.connect() as con:
            nrows = con.execute("""SELECT course,COUNT(*) n FROM racer_course_runs
                                   WHERE registration_no=? GROUP BY course""", (str(reg),)).fetchall()
            lrows = con.execute("""SELECT jcd,course,COUNT(*) n FROM racer_local_course_runs
                                   WHERE registration_no=? AND date>=? GROUP BY jcd,course""",
                                (str(reg), FLOOR_DATE)).fetchall()
        national = {int(x["course"]): min(10, int(x["n"])) for x in nrows}
        local_buckets = {(str(x["jcd"]).zfill(2), int(x["course"])): min(10, int(x["n"])) for x in lrows}
        return national, local_buckets

    def _today_local_progress(self, local_buckets, venue_codes):
        """JSON-safe local 1C-6C counts for the current racer's venue(s) today."""
        out = []
        for code in [str(x).zfill(2) for x in (venue_codes or [])]:
            venue = VENUES[int(code)-1] if code.isdigit() and 1 <= int(code) <= len(VENUES) else code
            counts = {c: int(local_buckets.get((code, c), 0)) for c in range(1, 7)}
            out.append({"jcd": code, "venue": venue, "counts": counts,
                        "total": sum(counts.values()),
                        "full_courses": sum(1 for v in counts.values() if v >= 10)})
        return out

    def _session(self):
        s = requests.Session()
        s.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "ja,en-US;q=0.8,en;q=0.6",
            "Cache-Control": "no-cache",
        })
        return s

    def _decode_official_response(self, response):
        """Decode BOAT RACE HTML using the encoding that preserves result-page semantics.

        requests may expose a legacy Japanese page as ISO-8859-1 when the HTTP
        header omits/gets the charset wrong.  In that case ``response.text`` becomes
        mojibake and every Japanese-header based parser returns zero rows even though
        the HTTP request succeeded.  Score several plausible decodings and choose the
        one containing the stable result-page labels.
        """
        raw = bytes(getattr(response, "content", b"") or b"")
        candidates = []
        seen = set()
        encs = [
            getattr(response, "encoding", None),
            getattr(response, "apparent_encoding", None),
            "utf-8", "cp932", "shift_jis", "euc_jp",
        ]
        for enc in encs:
            if not enc:
                continue
            key = str(enc).lower()
            if key in seen:
                continue
            seen.add(key)
            try:
                text = raw.decode(enc, errors="replace") if raw else str(getattr(response, "text", "") or "")
            except Exception:
                continue
            score = 0
            for token, weight in [
                ("スタート情報", 50), ("ボートレーサー", 40), ("払戻金", 25),
                ("決まり手", 20), ("水面気象情報", 15), ("着", 8), ("枠", 8),
            ]:
                if token in text:
                    score += weight
            # A real result page normally contains multiple registration numbers and ST tokens.
            score += min(len(re.findall(r"(?<!\d)\d{4}(?!\d)", text)), 6) * 3
            score += min(len(re.findall(r"(?<!\d)(?:[FL]\s*)?(?:0)?\.\d{2}(?!\d)", text, re.I)), 6) * 2
            candidates.append((score, str(enc), text))
        if not candidates:
            return str(getattr(response, "text", "") or ""), "unknown", 0
        candidates.sort(key=lambda x: x[0], reverse=True)
        score, enc, text = candidates[0]
        return text, enc, score

    def _official_html_diagnostic(self, html, encoding="unknown", byte_count=0):
        text = _nfkc(html or "")
        return {
            "encoding": str(encoding or "unknown"),
            "bytes": int(byte_count or 0),
            "has_start": "スタート情報" in text,
            "has_racer": "ボートレーサー" in text,
            "has_payout": "払戻金" in text,
            "reg_tokens": len(re.findall(r"(?<!\d)\d{4}(?!\d)", text)),
            "st_tokens": len(re.findall(r"(?<!\d)(?:[FL]\s*)?(?:0)?\.\d{2}(?!\d)", text, re.I)),
        }

    def _existing_saved_run(self, candidate, reg):
        """Reuse an already-confirmed saved run instead of reopening the official result page."""
        params = (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg))
        with self.db.connect() as con:
            row = con.execute("""SELECT date,jcd,rno,registration_no,lane,course,finish,st_raw,st_rank,source
                                 FROM racer_course_runs
                                 WHERE date=? AND jcd=? AND rno=? AND registration_no=?""", params).fetchone()
            if row is None:
                row = con.execute("""SELECT date,jcd,rno,registration_no,lane,course,finish,st_raw,st_rank,source
                                     FROM racer_local_course_runs
                                     WHERE date=? AND jcd=? AND rno=? AND registration_no=?""", params).fetchone()
        if row is None:
            return None
        out = dict(row); out["_reuse"] = "saved"
        return out

    def _cached_official_run(self, candidate, reg):
        params = (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg))
        with self.db.connect() as con:
            row = con.execute("""SELECT date,jcd,rno,registration_no,lane,course,finish,st_raw,st_rank,source
                                 FROM course_history_official_run_cache
                                 WHERE date=? AND jcd=? AND rno=? AND registration_no=?""", params).fetchone()
        if row is None:
            return None
        out = dict(row); out["_reuse"] = "cache"
        return out

    def _race_page_cache_state(self, candidate):
        params = (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]))
        with self.db.connect() as con:
            row = con.execute("""SELECT parsed_rows,status FROM course_history_official_race_cache
                                 WHERE date=? AND jcd=? AND rno=?""", params).fetchone()
        return dict(row) if row else None

    def _mark_race_page_parsed(self, candidate, parsed_rows):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""INSERT INTO course_history_official_race_cache
                    (date,jcd,rno,parsed_rows,status) VALUES(?,?,?,?, 'parsed')
                    ON CONFLICT(date,jcd,rno) DO UPDATE SET
                      parsed_rows=excluded.parsed_rows,status='parsed',fetched_at=CURRENT_TIMESTAMP""",
                    (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), int(parsed_rows)))

    def _record_failed_candidate(self, candidate, reg, err):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""INSERT INTO course_history_failed_candidates
                    (date,jcd,rno,registration_no,error,course_hint,st_hint,st_rank_hint,finish_hint,
                     hint_confidence,candidate_source,retry_count,last_try_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,1,CURRENT_TIMESTAMP)
                    ON CONFLICT(date,jcd,rno,registration_no) DO UPDATE SET
                      error=excluded.error,
                      course_hint=COALESCE(excluded.course_hint,course_history_failed_candidates.course_hint),
                      st_hint=COALESCE(excluded.st_hint,course_history_failed_candidates.st_hint),
                      st_rank_hint=COALESCE(excluded.st_rank_hint,course_history_failed_candidates.st_rank_hint),
                      finish_hint=COALESCE(excluded.finish_hint,course_history_failed_candidates.finish_hint),
                      hint_confidence=COALESCE(excluded.hint_confidence,course_history_failed_candidates.hint_confidence),
                      candidate_source=COALESCE(excluded.candidate_source,course_history_failed_candidates.candidate_source),
                      retry_count=course_history_failed_candidates.retry_count+1,
                      last_try_at=CURRENT_TIMESTAMP""",
                    (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg), str(err)[:1000],
                     candidate.get("course_hint"), candidate.get("st_hint"), candidate.get("st_rank_hint"),
                     candidate.get("finish_hint"), candidate.get("hint_confidence"), candidate.get("candidate_source")))

    @staticmethod
    def _is_structural_official_zero_error(err):
        text = str(err or "")
        # A normal parser failure may become parseable after a code update.  Quarantine
        # only the narrow case observed in production: the official URL repeatedly
        # returns an HTML document but the document itself has no start section and no
        # ST tokens. This is not a network timeout/HTTP failure.
        return ("公式結果ページ解析0件" in text and "start=0" in text and "st=0" in text)

    def _mark_unavailable_candidate(self, candidate, reg, reason, retry_count=0):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""INSERT INTO course_history_unavailable_candidates
                    (date,jcd,rno,registration_no,reason,course_hint,st_hint,st_rank_hint,finish_hint,
                     hint_confidence,candidate_source,retry_count,marked_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(date,jcd,rno,registration_no) DO UPDATE SET
                      reason=excluded.reason,
                      course_hint=COALESCE(excluded.course_hint,course_history_unavailable_candidates.course_hint),
                      st_hint=COALESCE(excluded.st_hint,course_history_unavailable_candidates.st_hint),
                      st_rank_hint=COALESCE(excluded.st_rank_hint,course_history_unavailable_candidates.st_rank_hint),
                      finish_hint=COALESCE(excluded.finish_hint,course_history_unavailable_candidates.finish_hint),
                      hint_confidence=COALESCE(excluded.hint_confidence,course_history_unavailable_candidates.hint_confidence),
                      candidate_source=COALESCE(excluded.candidate_source,course_history_unavailable_candidates.candidate_source),
                      retry_count=MAX(course_history_unavailable_candidates.retry_count,excluded.retry_count),
                      marked_at=CURRENT_TIMESTAMP""",
                    (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg), str(reason)[:1000],
                     candidate.get("course_hint"), candidate.get("st_hint"), candidate.get("st_rank_hint"),
                     candidate.get("finish_hint"), candidate.get("hint_confidence"), candidate.get("candidate_source"),
                     int(retry_count or 0)))
                con.execute("""DELETE FROM course_history_failed_candidates
                               WHERE date=? AND jcd=? AND rno=? AND registration_no=?""",
                            (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg)))

    def _clear_failed_candidate(self, candidate, reg):
        with self._db_write_lock:
            with self.db.connect() as con:
                con.execute("""DELETE FROM course_history_failed_candidates
                               WHERE date=? AND jcd=? AND rno=? AND registration_no=?""",
                            (str(candidate["date"]), str(candidate["jcd"]).zfill(2), int(candidate["rno"]), str(reg)))

    def _failed_candidates(self, reg):
        with self.db.connect() as con:
            rows = con.execute("""SELECT date,jcd,rno,error,retry_count,course_hint,st_hint,st_rank_hint,finish_hint,
                                         hint_confidence,candidate_source
                                  FROM course_history_failed_candidates
                                  WHERE registration_no=? ORDER BY date DESC,rno DESC""", (str(reg),)).fetchall()
        return [dict(x) for x in rows]

    def _parsed_official_detail(self, html, candidate):
        """Parse one BOAT RACE result page with the app's proven shared parser.

        v17.224 had a second, hand-written DOM parser in this module.  It could
        return zero rows even though the main BOAT AI Lab result parser could
        read the same page.  v17.230 deliberately has ONE parser path here:
        parser.parse_result_detail(), the same parser already used by the live
        official-result collector.
        """
        detail = parse_result_detail(html, int(candidate.get("rno") or 0)) or {}
        finishers = list(detail.get("finishers") or [])
        starts = list(detail.get("start_courses") or [])

        # Compatibility fallback for official pages whose CSS wrappers differ by era.
        # The visible result table has the stable semantic columns
        #   着 / 枠 / ボートレーサー
        # and the visible start section is ordered by actual entry course.
        soup = BeautifulSoup(html, "html.parser")
        if not finishers:
            trans = str.maketrans("１２３４５６", "123456")
            for table in soup.find_all("table"):
                htxt = " ".join(_nfkc(x.get_text(" ", strip=True)) for x in table.find_all("th"))
                if not all(k in htxt for k in ("着", "枠", "ボートレーサー")):
                    continue
                for tr in table.find_all("tr"):
                    cells = tr.find_all("td", recursive=False)
                    if len(cells) < 3:
                        continue
                    ft = _nfkc(cells[0].get_text(" ", strip=True)).translate(trans)
                    lt = _nfkc(cells[1].get_text(" ", strip=True)).translate(trans)
                    fm = re.search(r"[1-6]", ft)
                    sm = re.search(r"不完|不成立|エ|転|沈|落|妨|失|欠|F|L", ft, re.I)
                    lm = re.search(r"[1-6]", lt)
                    if (not fm and not sm) or not lm:
                        continue
                    racer_text = _nfkc(cells[2].get_text(" ", strip=True))
                    rm = re.search(r"(?<!\d)(\d{4})(?!\d)", racer_text)
                    if not rm:
                        continue
                    finishers.append({
                        "finish": fm.group() if fm else sm.group().upper(),
                        "lane": int(lm.group()),
                        "registration_no": rm.group(1),
                    })
                if finishers:
                    break

        if len(starts) < 2:
            text = _nfkc(soup.get_text(" ", strip=True))
            norm_text = re.sub(r"\s+", " ", text)
            pos = norm_text.find("スタート情報")
            if pos >= 0:
                section = norm_text[pos + len("スタート情報"):]
                # Stop before payout/weather sections so unrelated 1..6/.xx tokens
                # cannot be mistaken for start order.
                stops = [section.find(k) for k in ("勝式", "払戻金", "水面気象情報", "返還", "決まり手") if section.find(k) >= 0]
                if stops:
                    section = section[:min(stops)]
                pairs = []
                pat = re.compile(r"(?<!\d)([1-6])(?!\d)\s*(?:[^0-9FL]{0,40})?((?:[FL]\s*)?(?:0)?\.\d{1,2}|[FL])(?!\w)", re.I)
                for m in pat.finditer(section):
                    lane = int(m.group(1))
                    raw = re.sub(r"\s+", "", m.group(2)).upper()
                    if lane not in [x[0] for x in pairs]:
                        pairs.append((lane, raw))
                    if len(pairs) >= 6:
                        break
                if len(pairs) >= 2:
                    starts = [{"lane": lane, "course": i, "st_raw": raw} for i, (lane, raw) in enumerate(pairs, 1)]

        start_by_lane = {int(x.get("lane") or 0): x for x in starts if str(x.get("lane") or "").isdigit()}

        # Need actual-entry order to make a course-history row authoritative.
        if not finishers or len(starts) < 2:
            return []

        # Rank numeric STs with competition ranking (ties share rank). F/L are
        # kept as raw values but do not receive a numeric ST rank here.
        numeric = []
        for x in starts:
            lane = int(x.get("lane") or 0)
            raw = x.get("st_raw")
            val = _st_value(raw)
            if lane and val is not None:
                numeric.append((lane, val))
        numeric.sort(key=lambda z: z[1])
        ranks, last, rank = {}, None, 0
        for pos, (lane, val) in enumerate(numeric, 1):
            if last is None or abs(val - last) > 1e-9:
                rank = pos
                last = val
            ranks[lane] = rank

        rows = []
        for fin in finishers:
            reg = str(fin.get("registration_no") or "").strip()
            lane = int(fin.get("lane") or 0)
            if not reg or lane not in range(1, 7):
                continue
            finish = fin.get("finish")
            # 欠場 = did not run, so never enter course history.
            if str(finish or "").upper() in {"欠", "欠場"}:
                continue
            st = start_by_lane.get(lane) or {}
            course = fin.get("course") or st.get("course")
            raw = fin.get("st_raw") or st.get("st_raw")
            try:
                course = int(course)
            except Exception:
                continue
            if course not in range(1, 7) or raw is None:
                continue
            rows.append({
                "date": str(candidate["date"]),
                "jcd": str(candidate["jcd"]).zfill(2),
                "rno": int(candidate["rno"]),
                "registration_no": reg,
                "lane": lane,
                "course": course,
                "finish": str(finish),
                "st_raw": str(raw),
                "st_rank": ranks.get(lane),
                "source": "boatrace-official-result:shared-parser-v17225",
            })
        return rows

    def _official_page_racer_regs(self, html, candidate=None):
        # Compatibility helper used by validation/debug code.
        if candidate is not None:
            return [x["registration_no"] for x in self._parsed_official_detail(html, candidate)]
        # Without race metadata, use the finisher table portion of the shared parser.
        detail = parse_result_detail(html, None) or {}
        return [str(x.get("registration_no")) for x in detail.get("finishers") or [] if x.get("registration_no")]

    def _cache_official_page_runs(self, html, candidate):
        rows = self._parsed_official_detail(html, candidate)
        if not rows:
            return 0
        with self._db_write_lock:
            with self.db.connect() as con:
                for row in rows:
                    con.execute("""INSERT INTO course_history_official_run_cache
                    (date,jcd,rno,registration_no,lane,course,finish,st_raw,st_rank,source)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(date,jcd,rno,registration_no) DO UPDATE SET
                      lane=excluded.lane,course=excluded.course,finish=excluded.finish,
                      st_raw=excluded.st_raw,st_rank=excluded.st_rank,source=excluded.source,
                      cached_at=CURRENT_TIMESTAMP""",
                    (row["date"], row["jcd"], row["rno"], row["registration_no"], row.get("lane"),
                     row["course"], row.get("finish"), row.get("st_raw"), row.get("st_rank"),
                     row.get("source")))
        self._mark_race_page_parsed(candidate, len(rows))
        return len(rows)

    def _race_fetch_lock(self, candidate):
        key = (str(candidate.get("date") or ""), str(candidate.get("jcd") or "").zfill(2), int(candidate.get("rno") or 0))
        with self._race_lock_guard:
            lock = self._race_fetch_locks.get(key)
            if lock is None:
                lock = threading.Lock()
                self._race_fetch_locks[key] = lock
            return lock

    def _set_worker_progress(self, reg, **updates):
        with self._status_lock:
            cur = dict(self._worker_progress.get(str(reg)) or {})
            cur.update(updates)
            cur["registration_no"] = str(reg)
            self._worker_progress[str(reg)] = cur
            self.status["active_workers"] = list(self._worker_progress.values())[:MAX_PARALLEL_RACERS]

    def _clear_worker_progress(self, reg):
        with self._status_lock:
            self._worker_progress.pop(str(reg), None)
            self.status["active_workers"] = list(self._worker_progress.values())[:MAX_PARALLEL_RACERS]

    def _is_transient_fetch_error(self, err):
        text = str(err or "").lower()
        if any(f" {code} " in f" {text} " or f"{code} server error" in text or f"http {code}" in text
               for code in TRANSIENT_HTTP_CODES):
            return True
        return any(k in text for k in (
            "timeout", "timed out", "connectionerror", "connection reset",
            "temporarily unavailable", "remote disconnected", "name resolution",
            "max retries exceeded", "bad gateway", "gateway timeout", "service unavailable",
        ))

    def _get_html(self, session, urls, label, allow_404=False, attempts=3):
        last = None
        attempts = max(1, int(attempts or 1))
        for url in urls:
            for attempt in range(1, attempts + 1):
                try:
                    self.status.update({"phase": label, "direct_source": url,
                                        "last_fetch_state": f"fetch {attempt}/{attempts}", "last_fetch_error": None})
                    r = session.get(url, timeout=(6, 25), allow_redirects=True)
                    if r.status_code == 404:
                        if allow_404:
                            self.status.update({"last_fetch_state": "HTTP 404 = no data", "last_fetch_error": None})
                            return None, {"url": r.url, "http": 404, "attempt": attempt, "not_found": True}
                        last = f"HTTP 404: {url}"
                        break
                    r.raise_for_status()
                    if len(r.text) < 500:
                        raise RuntimeError(f"HTML too short ({len(r.text)})")
                    return r.text, {"url": r.url, "http": r.status_code, "attempt": attempt}
                except Exception as e:
                    last = f"{type(e).__name__}: {e}"
                    self.status.update({"last_fetch_error": last})
                    if attempt < attempts:
                        # Transient upstream failures get a modest backoff; parser/data
                        # errors remain fast. stop.wait keeps shutdown responsive.
                        delay = min(6, 1 + attempt) if self._is_transient_fetch_error(last) else 1
                        self._stop.wait(delay)
        raise RuntimeError(last or f"{label} 取得失敗")

    def _recent_source_open(self):
        with self._recent_source_lock:
            return time.monotonic() < float(self._recent_source_disabled_until or 0.0)

    def _disable_recent_source_temporarily(self, err):
        with self._recent_source_lock:
            self._recent_source_disabled_until = max(
                float(self._recent_source_disabled_until or 0.0),
                time.monotonic() + RECENT_SOURCE_COOLDOWN_SECONDS,
            )
            self._recent_source_last_error = str(err)[:500]
        self.status.update({
            "recent_source_circuit_open": True,
            "recent_source_cooldown_seconds": RECENT_SOURCE_COOLDOWN_SECONDS,
            "recent_source_last_error": str(err)[:500],
            "last_nonfatal_error": f"近走補助サイトを一時停止: {err}",
        })

    def _parse_recent_racer_page(self, html, today_year):
        soup = BeautifulSoup(html, "html.parser")
        out = []
        for table in soup.find_all("table"):
            heads = [" ".join(x.stripped_strings) for x in table.find_all("th")]
            h = "|".join(_norm(x) for x in heads)
            if not ("日付" in h and "場" in h and "R" in h and ("進入" in h or "枠" in h)):
                continue
            for tr in table.find_all("tr"):
                cells = [" ".join(x.stripped_strings) for x in tr.find_all(["th", "td"], recursive=False)]
                if len(cells) < 3:
                    continue
                d = _date_token(cells[0], today_year)
                jcd = _venue_code(cells[1]) if len(cells) > 1 else None
                rno = _race_token(cells[2]) if len(cells) > 2 else None
                if d and jcd and rno and d >= FLOOR_DATE:
                    out.append({"date": d, "jcd": jcd, "rno": rno, "candidate_source": "boatracedata-racer-recent"})
        uniq = {(x["date"], x["jcd"], x["rno"]): x for x in out}
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_recent_racer_candidates(self, session, reg, name):
        url = f"https://boatracedata.com/racer/{reg}"
        if self._recent_source_open():
            self.status.update({
                "phase": f"{name or reg} 近走補助サイト一時停止中→年別履歴へ",
                "crawl_stage": f"選手{reg}: 近走補助を省略し年別履歴を使用",
                "recent_source_circuit_open": True,
            })
            return []
        try:
            # This source is supplemental, so do not spend three worker slots repeatedly
            # hammering it during an upstream outage. Two tries are enough before opening
            # the shared circuit breaker for five minutes.
            html, diag = self._get_html(session, [url], f"{name or reg} 本人の近走履歴を取得中", attempts=2)
        except Exception as e:
            if self._is_transient_fetch_error(e):
                self._disable_recent_source_temporarily(e)
                return []
            raise
        rows = self._parse_recent_racer_page(html, datetime.now(JST).year)
        self.status.update({"phase": f"{name or reg} 本人の近走履歴を取得",
                            "crawl_stage": f"選手{reg}本人の近走 → 候補 {len(rows)}走",
                            "candidate_races": len(rows), "direct_source": diag.get("url"),
                            "recent_source_circuit_open": False})
        return rows

    def _expand_table(self, table):
        grid, spans = [], {}
        for r, tr in enumerate(table.find_all("tr")):
            row, c = [], 0
            cells = tr.find_all(["th", "td"], recursive=False)
            i = 0
            while i < len(cells) or any(k[0] == r for k in spans):
                while (r, c) in spans:
                    val = spans.pop((r, c))
                    row.append(val); c += 1
                if i >= len(cells):
                    break
                cell = cells[i]; i += 1
                val = " ".join(cell.stripped_strings)
                rs, cs = int(cell.get("rowspan", 1) or 1), int(cell.get("colspan", 1) or 1)
                for dc in range(cs):
                    row.append(val)
                    if rs > 1:
                        for dr in range(1, rs):
                            spans[(r + dr, c + dc)] = val
                c += cs
            grid.append(row)
        width = max((len(x) for x in grid), default=0)
        return [x + [""] * (width - len(x)) for x in grid]

    def _nearest_table_venue(self, table):
        node, checked = table, 0
        while node is not None and checked < 60:
            node = node.find_previous()
            if node is None:
                break
            if getattr(node, "name", None) in {"table", "tr", "td", "th"}:
                continue
            txt = " ".join(node.stripped_strings) if hasattr(node, "stripped_strings") else ""
            if not txt or len(txt) > 240:
                continue
            checked += 1
            jcd = _venue_code_from_context(txt)
            if jcd:
                return jcd
        return None

    def _parse_year_archive_candidates(self, html, year):
        """Parse racer-year archive candidates and attach a *strict* course hint.

        The archive matrix exposes, per race column: race number -> actual-entry
        course -> ST -> (ST rank) -> result.  We only attach ``course_hint`` when
        that exact five-row signature is present.  A missing/ambiguous hint never
        causes a skip; it simply falls back to the official result page.
        """
        soup = BeautifulSoup(html, "html.parser")
        out = []
        today = datetime.now(JST).strftime("%Y%m%d")
        for table in soup.find_all("table"):
            jcd = self._nearest_table_venue(table)
            if not jcd:
                continue
            rows = self._expand_table(table)
            if not rows:
                continue
            # Expanded colspan/rowspan means a date heading is repeated into every
            # race column it covers. Build a date-by-column map first.
            dates = {}
            for row in rows:
                for i, c in enumerate(row):
                    d = _date_token(c, year)
                    if d and FLOOR_DATE <= d <= today:
                        dates[i] = d
            if not dates:
                continue
            for ridx, row in enumerate(rows):
                for col, cell in enumerate(row):
                    rno = _race_token(cell)
                    d = dates.get(col)
                    if not (rno and d):
                        continue
                    cand = {"date": d, "jcd": jcd, "rno": rno,
                            "candidate_source": f"boatrace-db-racer-yall-{year}"}
                    # Prefer an exact race link when the archive provides one.  This
                    # prevents matrix date/venue misalignment from manufacturing a
                    # date+venue combination on which no race was actually held.
                    try:
                        cell_node = table.find_all("tr")[ridx].find_all(["th", "td"], recursive=False)
                        # Expanded columns can outnumber physical cells, so inspect the
                        # whole source row and accept only a link whose displayed race no.
                        # matches this matrix token.
                        for src_cell in cell_node:
                            if _race_token(" ".join(src_cell.stripped_strings)) != rno:
                                continue
                            for a in src_cell.find_all("a", href=True):
                                exact = self._race_key_from_href(a.get("href"))
                                if exact and exact[2] == rno:
                                    cand.update({"date": exact[0], "jcd": exact[1], "rno": exact[2],
                                                 "candidate_source": f"boatrace-db-racer-yall-link-{year}"})
                                    raise StopIteration
                    except StopIteration:
                        pass
                    except Exception:
                        pass
                    # Strict five-row signature.  This is only a prefilter hint;
                    # official BOAT RACE remains authoritative for saved values.
                    if ridx + 4 < len(rows):
                        c = _course_token(rows[ridx + 1][col])
                        st = _st_token(rows[ridx + 2][col])
                        sr = _st_rank_token(rows[ridx + 3][col])
                        fn = _archive_finish_token(rows[ridx + 4][col])
                        if c and st is not None and sr is not None and fn is not None:
                            cand.update({"course_hint": c, "st_hint": st,
                                         "st_rank_hint": sr, "finish_hint": fn,
                                         "hint_confidence": "strict-matrix-v1"})
                    out.append(cand)
        # Prefer a copy that carries a strict hint if duplicate race keys occur.
        uniq = {}
        for x in out:
            key = (x["date"], x["jcd"], x["rno"])
            old = uniq.get(key)
            if old is None or (x.get("course_hint") and not old.get("course_hint")):
                uniq[key] = x
        return sorted(uniq.values(), key=lambda x: (x["date"], x["rno"]), reverse=True)

    def _fetch_year_racer_candidates(self, session, reg, name, year):
        url = f"https://boatrace-db.net/racer/yall/regno/{reg}/year/{year}/"
        html, diag = self._get_html(session, [url], f"{name or reg} 本人の{year}年全出走履歴を取得中", allow_404=True, attempts=4)
        if html is None and diag.get("not_found"):
            rows = []
            self.status.update({"phase": f"{name or reg} {year}年本人履歴なし（404正常）",
                                "crawl_stage": f"選手{reg} {year}年全出走 → 0走（404正常）",
                                "candidate_races": 0, "direct_source": diag.get("url")})
            return rows
        rows = self._parse_year_archive_candidates(html, year)
        self.status.update({"phase": f"{name or reg} {year}年本人履歴を取得",
                            "crawl_stage": f"選手{reg} {year}年全出走 → 候補 {len(rows)}走",
                            "candidate_races": len(rows), "direct_source": diag.get("url")})
        return rows

    def _race_key_from_href(self, href):
        """Extract an authoritative (date,jcd,rno) key from a race/result link.

        Year-archive tables sometimes have complex rowspan/colspan layouts.  If a
        race cell carries a link with hd/jcd/rno, that link is safer than inferring
        the venue/date from surrounding matrix text.
        """
        if not href:
            return None
        try:
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(str(href)).query)
            d = (q.get("hd") or [None])[0]
            j = (q.get("jcd") or [None])[0]
            r = (q.get("rno") or [None])[0]
            if d and re.fullmatch(r"20\d{6}", str(d)) and j and r:
                ji = int(str(j)); ri = int(str(r))
                if 1 <= ji <= 24 and 1 <= ri <= 12:
                    return str(d), f"{ji:02d}", ri
        except Exception:
            return None
        return None

    def _official_resultlist_url(self, candidate):
        return ("https://www.boatrace.jp/owpc/pc/race/resultlist"
                f"?hd={candidate['date']}&jcd={str(candidate['jcd']).zfill(2)}")

    def _resultlist_races(self, html):
        """Return race numbers confidently present on an official daily result list.

        Empty set means the page was understood but contains no race rows; None means
        the HTML could not be identified confidently and must not be used to discard a
        candidate.
        """
        soup = BeautifulSoup(html or "", "html.parser")
        text = _nfkc(soup.get_text(" ", strip=True))
        # A genuine result-list page has at least one of these stable labels.
        if not any(k in text for k in ("結果一覧", "勝式・払戻金・結果", "着順 結果")):
            return None
        found = set()
        for a in soup.find_all("a", href=True):
            href = a.get("href") or ""
            key = self._race_key_from_href(href)
            if key:
                found.add(int(key[2]))
                continue
            m = re.fullmatch(r"\s*(1[0-2]|[1-9])R\s*", _nfkc(a.get_text(" ", strip=True)))
            if m:
                found.add(int(m.group(1)))
        # Fallback for rendered tables where links are stripped by upstream HTML.
        if not found:
            for table in soup.find_all("table"):
                t = _nfkc(table.get_text(" ", strip=True))
                if "レース" not in t:
                    continue
                found.update(int(x) for x in re.findall(r"(?<!\d)(1[0-2]|[1-9])R(?!\d)", t))
        return found

    def _candidate_exists_on_official_day(self, session, candidate):
        """Validate a suspicious archive candidate against the official daily list.

        Returns True/False when the daily page is understood, otherwise None.  Results
        are cached by date+venue, so many failed races from the same day cost one HTTP
        request total.
        """
        key = (str(candidate.get("date") or ""), str(candidate.get("jcd") or "").zfill(2))
        with self._official_day_lock:
            if key in self._official_day_race_cache:
                races = self._official_day_race_cache[key]
                return None if races is None else int(candidate.get("rno") or 0) in races
        url = self._official_resultlist_url(candidate)
        races = None
        try:
            r = session.get(url, timeout=(6, 25), allow_redirects=True)
            if r.status_code == 404:
                races = set()
            else:
                r.raise_for_status()
                html, _, _ = self._decode_official_response(r)
                races = self._resultlist_races(html)
        except Exception as e:
            self.status["official_day_validation_error"] = f"{type(e).__name__}: {e}"
            races = None
        with self._official_day_lock:
            self._official_day_race_cache[key] = races
        if races is None:
            return None
        return int(candidate.get("rno") or 0) in races

    def _official_racelist_url(self, candidate):
        return ("https://www.boatrace.jp/owpc/pc/race/racelist"
                f"?hd={candidate['date']}&jcd={str(candidate['jcd']).zfill(2)}&rno={int(candidate['rno'])}")

    def _raw_official_racer_regs(self, html):
        """Extract racer registration numbers without relying on the result parser.

        This intentionally uses only high-confidence official-page structures:
        racer profile links (``toban=NNNN``) and rows in a table whose heading
        contains ``ボートレーサー``.  It is used only to answer the binary question
        "was this racer actually entered in this race?" when detailed result
        parsing returned zero rows.
        """
        soup = BeautifulSoup(html or "", "html.parser")
        regs = []
        # Official racer profile links are the strongest signal.
        for a in soup.find_all("a", href=True):
            href = _nfkc(a.get("href") or "")
            m = re.search(r"(?:[?&]|/)toban(?:=|/)(\d{4})(?:\D|$)", href, re.I)
            if not m:
                m = re.search(r"[?&]toban=(\d{4})(?:&|$)", href, re.I)
            if m:
                regs.append(m.group(1))
        # Strong text fallback for current/legacy racelist HTML.  The official
        # entry table prints registration numbers as ``NNNN / A1`` etc.  Some
        # page generations wrap rows in divs rather than a normal <table>, so
        # limiting fallback extraction to table descendants can incorrectly
        # return an unknown roster.  Matching the class suffix keeps this
        # sufficiently strict while working across those wrappers.
        if len(set(regs)) < 4:
            page_text = _nfkc(soup.get_text(" ", strip=True))
            for m in re.finditer(r"(?<!\d)(\d{4})\s*/\s*(?:A1|A2|B1|B2)(?![A-Z0-9])", page_text, re.I):
                regs.append(m.group(1))

        # Secondary fallback: official-looking racer tables.  Keep this after
        # the class-pattern scan for older pages that omit the ``/ A1`` text.
        if len(set(regs)) < 4:
            for table in soup.find_all("table"):
                txt = _nfkc(table.get_text(" ", strip=True))
                if "ボートレーサー" not in txt:
                    continue
                for tr in table.find_all("tr"):
                    rowtxt = _nfkc(" ".join(tr.stripped_strings))
                    for m in re.finditer(r"(?<!\d)(\d{4})(?!\d)", rowtxt):
                        regs.append(m.group(1))
        out=[]
        seen=set()
        for reg in regs:
            if reg not in seen:
                seen.add(reg); out.append(reg)
        return out

    def _candidate_racer_exists_on_official_race(self, session, candidate, reg, result_html=None):
        """Return True/False when official six-racer membership is known, else None.

        First inspect the already-fetched result HTML.  If that does not expose a
        confident roster, fetch the official racelist for the exact same key.  We
        require at least four distinct registration numbers before treating absence
        as proof; otherwise we fail safe and return None.
        """
        key = (str(candidate.get("date") or ""), str(candidate.get("jcd") or "").zfill(2),
               int(candidate.get("rno") or 0))
        reg = str(reg)
        with self._official_race_racer_lock:
            cached = self._official_race_racer_cache.get(key)
        if cached is not None:
            return reg in cached if len(cached) >= 4 else None

        regs = self._raw_official_racer_regs(result_html or "")
        if len(regs) >= 4:
            with self._official_race_racer_lock:
                self._official_race_racer_cache[key] = set(regs)
            return reg in set(regs)

        url = self._official_racelist_url(candidate)
        try:
            rr = session.get(url, timeout=(6, 25), allow_redirects=True)
            if rr.status_code == 404:
                return None
            rr.raise_for_status()
            html2, _, _ = self._decode_official_response(rr)
            regs2 = self._raw_official_racer_regs(html2)
            if len(regs2) >= 4:
                with self._official_race_racer_lock:
                    self._official_race_racer_cache[key] = set(regs2)
                return reg in set(regs2)
        except Exception as e:
            self.status["official_racer_membership_error"] = f"{type(e).__name__}: {e}"
        return None

    def _official_result_url(self, x):
        return ("https://www.boatrace.jp/owpc/pc/race/raceresult"
                f"?hd={x['date']}&jcd={str(x['jcd']).zfill(2)}&rno={int(x['rno'])}")

    def _parse_official_result(self, html, candidate, reg):
        reg = str(reg)
        for row in self._parsed_official_detail(html, candidate):
            if str(row.get("registration_no")) == reg:
                return row
        return None

    def _fetch_official_run(self, session, candidate, reg):
        # 1) A row already saved for this racer/race is authoritative enough to reuse.
        old = self._existing_saved_run(candidate, reg)
        if old:
            self.status["official_saved_reuse_hits"] = int(self.status.get("official_saved_reuse_hits") or 0) + 1
            return old
        # 2) A result page fetched earlier for another racer can be reused from the shared parsed cache.
        cached = self._cached_official_run(candidate, reg)
        if cached:
            self.status["official_cache_hits"] = int(self.status.get("official_cache_hits") or 0) + 1
            return cached
        # A successfully parsed race page is a persistent negative cache too.  If this
        # racer has no cached row, the candidate was a false positive or a non-run/欠場;
        # reopening the exact same official page cannot add information.
        page_state = self._race_page_cache_state(candidate)
        if page_state and page_state.get("status") == "parsed" and int(page_state.get("parsed_rows") or 0) > 0:
            self.status["official_negative_cache_hits"] = int(self.status.get("official_negative_cache_hits") or 0) + 1
            return None

        url = self._official_result_url(candidate)
        last = None
        # Three racer workers can run together, but the same race page is fetched only once.
        race_lock = self._race_fetch_lock(candidate)
        with race_lock:
            cached = self._cached_official_run(candidate, reg)
            if cached:
                self.status["official_cache_hits"] = int(self.status.get("official_cache_hits") or 0) + 1
                return cached
            page_state = self._race_page_cache_state(candidate)
            if page_state and page_state.get("status") == "parsed" and int(page_state.get("parsed_rows") or 0) > 0:
                self.status["official_negative_cache_hits"] = int(self.status.get("official_negative_cache_hits") or 0) + 1
                return None
            for attempt in range(1, 4):
                try:
                    self.status.update({"phase": "BOAT RACE公式結果で実進入確認中",
                                        "direct_source": url, "last_fetch_state": f"official {attempt}/3"})
                    r = session.get(url, timeout=(6, 25))
                    r.raise_for_status()
                    self.status["official_web_fetches"] = int(self.status.get("official_web_fetches") or 0) + 1
                    html, selected_encoding, decode_score = self._decode_official_response(r)
                    diag = self._official_html_diagnostic(html, selected_encoding, len(getattr(r, "content", b"") or b""))
                    diag["score"] = decode_score
                    self.status["official_last_decode"] = diag
                    # Cache all racers parsed from this page so another worker can reuse it.
                    parsed_rows = self._cache_official_page_runs(html, candidate)
                    cached = self._cached_official_run(candidate, reg)
                    if cached:
                        return cached
                    if parsed_rows > 0:
                        # Page itself parsed successfully, but this candidate racer was not a
                        # completed starter (false-positive candidate / 欠場 etc.).
                        return None
                    # Zero parsed rows can mean either a parser problem OR a bad
                    # archive key.  Validate the date+venue against the official daily
                    # result list before putting it into the retry queue.  Example found
                    # in production: 2023-07-14 / 津 / 8R, even though 津 had no racing
                    # on that date. Such a candidate can never succeed on retry.
                    row = self._parse_official_result(html, candidate, reg)
                    if row:
                        return row
                    exists = self._candidate_exists_on_official_day(session, candidate)
                    if exists is False:
                        self.status["invalid_archive_candidates_dropped"] = int(
                            self.status.get("invalid_archive_candidates_dropped") or 0) + 1
                        self.status["last_invalid_archive_candidate"] = (
                            f"{candidate.get('date')} {str(candidate.get('jcd')).zfill(2)} "
                            f"{candidate.get('rno')}R: official daily list has no such race"
                        )
                        return None
                    # The race may be real but belong to somebody else.  This happens
                    # when an archive matrix column drifts and combines a real
                    # date+venue+R with the wrong racer.  Confirm the official roster
                    # before treating zero parsed rows as a parser failure.
                    racer_exists = self._candidate_racer_exists_on_official_race(
                        session, candidate, reg, result_html=html)
                    if racer_exists is False:
                        self.status["invalid_archive_racer_candidates_dropped"] = int(
                            self.status.get("invalid_archive_racer_candidates_dropped") or 0) + 1
                        self.status["last_invalid_archive_candidate"] = (
                            f"{candidate.get('date')} {str(candidate.get('jcd')).zfill(2)} "
                            f"{candidate.get('rno')}R: official roster does not contain racer {reg}"
                        )
                        return None
                    raise RuntimeError(
                        "公式結果ページ解析0件"
                        f" [enc={diag['encoding']} bytes={diag['bytes']} "
                        f"start={int(diag['has_start'])} racer={int(diag['has_racer'])} "
                        f"reg={diag['reg_tokens']} st={diag['st_tokens']} "
                        f"daycheck={'unknown' if exists is None else 'exists'} "
                        f"racercheck={'unknown' if racer_exists is None else 'present'}]"
                    )
                except Exception as e:
                    last = f"{type(e).__name__}: {e}"
                    self.status.update({"last_fetch_error": last})
                    if attempt < 3:
                        self._stop.wait(1)
        raise RuntimeError(last or "公式レース結果取得失敗")

    def _save_confirmed(self, row, local_target_venues=None):
        """Save nationwide always; save local only for the requested venue scope.

        During initial construction, ``local_target_venues`` is today's venue(s) for
        that racer. This prevents needless 24-venue local initialization. Live result
        maintenance may pass ``None`` to keep the race venue incrementally updated.
        """
        if not row:
            return 0
        jcd = str(row.get("jcd") or "").zfill(2)
        save_local = local_target_venues is None or jcd in {str(x).zfill(2) for x in (local_target_venues or [])}
        # Keep SQLite writes short and serialized; web fetch/HTML parsing still run in parallel.
        with self._db_write_lock:
            a = self.db.save_course_history_runs([row], keep_per_local_course=10)
            b = self.db.save_local_course_history_runs([row], keep_per_course=10) if save_local else 0
        return 1 if (a or b) else 0

    def _archive_row_from_candidate(self, cand, reg):
        """Build a complete historical run from a strict archive matrix row.

        Lane/frame is not present in the yearly matrix, so it is intentionally left
        NULL.  The fields used by course-history logic (venue, actual entry course,
        ST, ST-rank, result) are present and have already passed strict parsing.
        """
        if cand.get("hint_confidence") != "strict-matrix-v1":
            return None
        try:
            c = int(cand.get("course_hint"))
            if c not in range(1, 7):
                return None
            st = _st_token(cand.get("st_hint"))
            sr = int(cand.get("st_rank_hint"))
            fn = _archive_finish_token(cand.get("finish_hint"))
            if st is None or sr not in range(1, 7) or fn is None:
                return None
            return {
                "date": str(cand["date"]), "jcd": str(cand["jcd"]).zfill(2),
                "rno": int(cand["rno"]), "registration_no": str(reg),
                "lane": None, "course": c, "finish": str(fn),
                "st_raw": str(st), "st_rank": sr,
                "source": "boatrace-db-strict-archive:audited-v17223",
            }
        except Exception:
            return None

    def _strict_archive_plan(self, reg, candidates, local_target_venues=None):
        """Return exact strict rows needed for retained top10 plus ambiguous rows.

        Unlike the old prefilter, this does not add reserve rows to the expensive
        official queue.  Strict matrix rows are complete enough to be saved locally
        after a bounded audit succeeds.  Ambiguous rows always remain official-only.
        """
        uniq = {}
        for x in sorted(candidates, key=lambda z: (str(z.get("date") or ""), int(z.get("rno") or 0)), reverse=True):
            try:
                key = (str(x["date"]), str(x["jcd"]).zfill(2), int(x["rno"]))
            except Exception:
                continue
            old = uniq.get(key)
            if old is None or (x.get("hint_confidence") == "strict-matrix-v1" and old.get("hint_confidence") != "strict-matrix-v1"):
                uniq[key] = dict(x)
        ordered = sorted(uniq.values(), key=lambda z: (str(z.get("date") or ""), int(z.get("rno") or 0)), reverse=True)

        existing_nat = {c: 0 for c in range(1, 7)}
        existing_loc = {}
        existing_keys = set()
        try:
            with self.db.connect() as con:
                for r in con.execute("""SELECT date,jcd,rno,course FROM racer_course_runs
                                      WHERE registration_no=? ORDER BY date DESC,rno DESC""", (str(reg),)).fetchall():
                    key=(str(r["date"]),str(r["jcd"]).zfill(2),int(r["rno"]))
                    existing_keys.add(key)
                    c=int(r["course"])
                    existing_nat[c]=min(10,existing_nat.get(c,0)+1)
                for r in con.execute("""SELECT date,jcd,rno,course FROM racer_local_course_runs
                                      WHERE registration_no=? AND date>=? ORDER BY date DESC,rno DESC""", (str(reg),FLOOR_DATE)).fetchall():
                    key=(str(r["date"]),str(r["jcd"]).zfill(2),int(r["rno"]))
                    existing_keys.add(key)
                    pk=(str(r["jcd"]).zfill(2),int(r["course"]))
                    existing_loc[pk]=min(10,existing_loc.get(pk,0)+1)
        except Exception:
            existing_nat = {c: 0 for c in range(1,7)}
            existing_loc = {}
            existing_keys = set()

        strict, ambiguous, skipped = [], [], []
        target_venues = ({str(x).zfill(2) for x in local_target_venues} if local_target_venues is not None else set(VENUE_CODE.values()))
        nat = dict(existing_nat); loc = dict(existing_loc)
        for x in ordered:
            key=(str(x["date"]),str(x["jcd"]).zfill(2),int(x["rno"]))
            # Do not skip merely because the race exists in one history table.
            # A legacy/partial state may have nationwide saved but local missing (or vice versa);
            # the per-bucket counts below decide whether this row is still needed.
            if x.get("hint_confidence") != "strict-matrix-v1" or not x.get("course_hint"):
                # Unknown course can still affect any not-full bucket at this venue or nationwide.
                j=str(x.get("jcd") or "").zfill(2)
                national_incomplete = any(int(nat.get(c,0)) < 10 for c in range(1,7))
                local_incomplete = j in target_venues and any(int(loc.get((j,c),0)) < 10 for c in range(1,7))
                if national_incomplete or local_incomplete:
                    ambiguous.append(x)
                else:
                    skipped.append(x)
                continue
            c=int(x["course_hint"]); j=str(x["jcd"]).zfill(2); pk=(j,c)
            need_n=int(nat.get(c,0)) < 10
            need_l=(j in target_venues) and int(loc.get(pk,0)) < 10
            if need_n or need_l:
                strict.append(x)
                if need_n: nat[c]=int(nat.get(c,0))+1
                if need_l: loc[pk]=int(loc.get(pk,0))+1
            else:
                skipped.append(x)
        return strict, ambiguous, skipped

    def _choose_archive_audit(self, strict_rows):
        """Bounded representative audit: newest row per venue and per course.

        This catches venue-association mistakes and actual-course parser drift while
        keeping official requests bounded (<=30 unique rows in ordinary 24-venue data).
        Special-result rows are also sampled (up to 3) because they are easy to parse
        incorrectly and important to preserve verbatim.
        """
        ordered=sorted(strict_rows,key=lambda z:(str(z.get("date") or ""),int(z.get("rno") or 0)),reverse=True)
        picked={}
        seen_v=set(); seen_c=set()
        for x in ordered:
            key=(str(x.get("date")),str(x.get("jcd")).zfill(2),int(x.get("rno") or 0))
            j=str(x.get("jcd") or "").zfill(2); c=int(x.get("course_hint") or 0)
            if j not in seen_v:
                picked[key]=x; seen_v.add(j)
            if c and c not in seen_c:
                picked[key]=x; seen_c.add(c)
        specials=0
        for x in ordered:
            if specials >= 3: break
            if str(x.get("finish_hint") or "") not in {"1","2","3","4","5","6"}:
                key=(str(x.get("date")),str(x.get("jcd")).zfill(2),int(x.get("rno") or 0))
                if key not in picked:
                    picked[key]=x; specials += 1
        return list(picked.values())

    def _archive_matches_official(self, cand, row):
        if not row:
            return False
        try:
            return (
                int(cand.get("course_hint")) == int(row.get("course")) and
                str(_st_token(cand.get("st_hint"))) == str(_st_token(row.get("st_raw"))) and
                int(cand.get("st_rank_hint")) == int(row.get("st_rank")) and
                str(_archive_finish_token(cand.get("finish_hint"))) == str(_archive_finish_token(row.get("finish")))
            )
        except Exception:
            return False

    def _audit_strict_archive(self, session, reg, name, strict_rows, started):
        audit=self._choose_archive_audit(strict_rows)
        official_by_key={}
        checked=0
        for cand in audit:
            if self._stop.is_set():
                return False, official_by_key, checked
            try:
                row=self._fetch_official_run(session,cand,reg)
                checked += 1
            except Exception as e:
                self.status["archive_audit_error"] = f"{type(e).__name__}: {e}"
                return False, official_by_key, checked
            key=(str(cand["date"]),str(cand["jcd"]).zfill(2),int(cand["rno"]))
            if not self._archive_matches_official(cand,row):
                self.status["archive_audit_mismatch"] = (
                    f"{name or reg} {cand.get('date')} {str(cand.get('jcd')).zfill(2)} {cand.get('rno')}R"
                )
                return False, official_by_key, checked
            official_by_key[key]=row
        return True, official_by_key, checked

    def _save_audited_archive_rows(self, reg, strict_rows, official_by_key, local_target_venues=None):
        saved=0
        for cand in strict_rows:
            key=(str(cand["date"]),str(cand["jcd"]).zfill(2),int(cand["rno"]))
            row=official_by_key.get(key) or self._archive_row_from_candidate(cand,reg)
            if row:
                saved += self._save_confirmed(dict(row), local_target_venues=local_target_venues)
        return saved

    def _prefilter_needed_candidates(self, reg, candidates, local_target_venues=None):
        """Return (primary, reserve, skipped) before official-page verification.

        Strict archive rows are ranked newest-first inside both destinations they can affect:
        national course and venue/course.  The newest ten are primary.  The next few rows are
        reserve candidates and are touched only when a primary row turns out to be unusable
        (scratch/parse failure/etc.).  Ambiguous archive rows are always primary because they
        cannot be safely assigned without the BOAT RACE official result.
        """
        uniq = {}
        for x in sorted(candidates, key=lambda z: (str(z.get("date") or ""), int(z.get("rno") or 0)), reverse=True):
            try:
                key = (str(x["date"]), str(x["jcd"]).zfill(2), int(x["rno"]))
            except Exception:
                continue
            old = uniq.get(key)
            if old is None or (x.get("hint_confidence") == "strict-matrix-v1" and old.get("hint_confidence") != "strict-matrix-v1"):
                uniq[key] = dict(x)
        ordered = sorted(uniq.values(), key=lambda z: (str(z.get("date") or ""), int(z.get("rno") or 0)), reverse=True)

        existing_nat = {c: [] for c in range(1, 7)}
        existing_loc = {}
        existing_keys = set()
        try:
            with self.db.connect() as con:
                for r in con.execute("""SELECT date,jcd,rno,course FROM racer_course_runs
                                      WHERE registration_no=? ORDER BY date DESC,rno DESC""", (str(reg),)).fetchall():
                    key=(str(r["date"]),str(r["jcd"]).zfill(2),int(r["rno"]))
                    existing_keys.add(key)
                    existing_nat.setdefault(int(r["course"]),[]).append(key)
                for r in con.execute("""SELECT date,jcd,rno,course FROM racer_local_course_runs
                                      WHERE registration_no=? AND date>=? ORDER BY date DESC,rno DESC""", (str(reg),FLOOR_DATE)).fetchall():
                    key=(str(r["date"]),str(r["jcd"]).zfill(2),int(r["rno"]))
                    existing_keys.add(key)
                    existing_loc.setdefault((str(r["jcd"]).zfill(2),int(r["course"])),[]).append(key)
        except Exception:
            existing_nat = {c: [] for c in range(1,7)}
            existing_loc = {}
            existing_keys = set()

        target_venues = ({str(x).zfill(2) for x in local_target_venues} if local_target_venues is not None else set(VENUE_CODE.values()))
        nat_primary = {c: len(v[:10]) for c,v in existing_nat.items()}
        loc_primary = {k: len(v[:10]) for k,v in existing_loc.items()}
        nat_reserve = {c: 0 for c in range(1,7)}
        loc_reserve = {}
        primary, reserve, skipped = [], [], []

        for x in ordered:
            key=(str(x["date"]),str(x["jcd"]).zfill(2),int(x["rno"]))
            # Keep partially-saved races eligible so missing nationwide/local destinations
            # can be healed by _save_confirmed; bucket counts prevent unnecessary work.
            strict = x.get("hint_confidence") == "strict-matrix-v1"
            hint = x.get("course_hint") if strict else None
            if not hint:
                primary.append(x)
                continue
            c=int(hint); j=str(x["jcd"]).zfill(2)
            pk=(j,c)
            need_n = nat_primary.get(c,0) < 10
            need_l = (j in target_venues) and loc_primary.get(pk,0) < 10
            if need_n or need_l:
                primary.append(x)
                if need_n: nat_primary[c] = nat_primary.get(c,0) + 1
                if need_l: loc_primary[pk] = loc_primary.get(pk,0) + 1
                continue
            # Keep a tiny reserve per bucket, but do not fetch it unless a primary fails.
            need_rn = nat_reserve.get(c,0) < PREFILTER_RESERVE_PER_BUCKET
            need_rl = (j in target_venues) and loc_reserve.get(pk,0) < PREFILTER_RESERVE_PER_BUCKET
            if need_rn or need_rl:
                reserve.append(x)
                if need_rn: nat_reserve[c] = nat_reserve.get(c,0) + 1
                if need_rl: loc_reserve[pk] = loc_reserve.get(pk,0) + 1
            else:
                skipped.append(x)

        self.status.update({
            "prefilter_total_candidates": len(ordered),
            "prefilter_selected_candidates": len(primary),
            "prefilter_reserve_candidates": len(reserve),
            "prefilter_skipped_candidates": len(skipped),
            "prefilter_ambiguous_selected": sum(1 for x in primary if x.get("hint_confidence") != "strict-matrix-v1"),
        })
        return primary, reserve, skipped

    def _process_candidates(self, session, reg, name, candidates, seen, started, local_target_venues=None):
        verified = saved = failed = skipped_full = 0
        venue_name_by_code = {v: k for k, v in VENUE_CODE.items()}
        national, local = self._summary_counts(reg)
        target_venues = ({str(x).zfill(2) for x in local_target_venues} if local_target_venues is not None else set(VENUE_CODE.values()))
        for cand in candidates:
            if self._stop.is_set():
                break
            key = (cand["date"], cand["jcd"], int(cand["rno"]))
            if key in seen:
                continue
            seen.add(key)
            jcd = str(cand["jcd"]).zfill(2)
            # Candidates are newest -> oldest. If the archive gives a STRICT actual-course
            # hint and BOTH destinations that this run could affect are already full, an
            # older race cannot enter either retained top-10 list. Skip the official page.
            # Ambiguous/no-hint candidates are always verified, preserving correctness.
            hint = cand.get("course_hint") if cand.get("hint_confidence") == "strict-matrix-v1" else None
            if hint:
                c_hint = int(hint)
                need_n = int(national.get(c_hint, 0)) < 10
                need_l = (jcd in target_venues) and int(local.get((jcd, c_hint), 0)) < 10
                # Latest -> oldest: once a course is full, older races of that course
                # cannot change the retained top-10 for that destination.
                if not need_n and not need_l:
                    skipped_full += 1
                    self.status["official_course_hint_skips"] = int(self.status.get("official_course_hint_skips") or 0) + 1
                    continue
            national_done = all(int(national.get(c, 0)) >= 10 for c in range(1, 7))
            local_done = all(
                all(int(local.get((j, c), 0)) >= 10 for c in range(1, 7))
                for j in target_venues
            ) if target_venues else True
            if national_done and local_done:
                skipped_full += 1
                continue
            try:
                row = self._fetch_official_run(session, cand, reg)
                verified += 1
                self._clear_failed_candidate(cand, reg)
            except Exception as e:
                failed += 1
                self._record_failed_candidate(cand, reg, f"{type(e).__name__}: {e}")
                self.status.update({"last_nonfatal_error": f"{key}: {type(e).__name__}: {e}"})
                # IMPORTANT: one bad historical race must not rewind or abort the entire racer.
                # It is retried later from the tiny failed-candidate queue only.
                continue
            if row:
                strict_hint = cand.get("course_hint") if cand.get("hint_confidence") == "strict-matrix-v1" else None
                if strict_hint and int(strict_hint) != int(row.get("course") or 0):
                    self._prefilter_hint_mismatch_regs.add(str(reg))
                    self.status["prefilter_hint_mismatches"] = int(self.status.get("prefilter_hint_mismatches") or 0) + 1
                    self.status["last_hint_mismatch"] = (
                        f"{reg} {cand.get('date')} {str(cand.get('jcd')).zfill(2)} {cand.get('rno')}R "
                        f"archive={strict_hint}C official={row.get('course')}C"
                    )
                was_reused = bool(row.pop("_reuse", None))
                added = self._save_confirmed(row, local_target_venues=target_venues)
                saved += added
                c = int(row["course"]); rj = str(row["jcd"]).zfill(2)
                # Re-read real DB counts after an upsert. A race may already exist in
                # nationwide history while only its local copy is newly inserted (or vice versa);
                # incrementing both counters from one boolean can falsely mark a course full.
                national, local = self._summary_counts(reg)
                vname = venue_name_by_code.get(rj, rj)
                self.status.update({
                    "crawl_stage": f"{name or reg} / {row['date']} {vname}{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "last_verified_run": f"{row['date']} {vname}{row['rno']}R / {row['lane']}号艇→実進入{row['course']}C / ST {row['st_raw']} / {row['finish']}",
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                    "official_full_bucket_skips": int(self.status.get("official_full_bucket_skips") or 0) + skipped_full,
                })
                skipped_full = 0
                # No artificial delay is needed when the result came from DB/cache.
                if not was_reused:
                    self._stop.wait(0.01)
        if skipped_full:
            self.status["official_full_bucket_skips"] = int(self.status.get("official_full_bucket_skips") or 0) + skipped_full
        return verified, saved, failed

    def _retry_failed_candidates(self, session, reg, name, started, local_target_venues=None):
        pending = self._failed_candidates(reg)
        if not pending:
            return 0, 0, 0
        self._set_worker_progress(reg, phase=f"失敗レース再試行 {len(pending)}件", year=None)
        verified = saved = failed = 0
        for x in pending:
            if self._stop.is_set():
                break
            # v17.238: preserve all archive hints across deferred retries. Older DB rows
            # naturally have these fields as NULL; they still benefit from the bounded
            # structural-unavailable quarantine below.
            cand = {
                "date": x["date"], "jcd": x["jcd"], "rno": int(x["rno"]),
                "course_hint": x.get("course_hint"), "st_hint": x.get("st_hint"),
                "st_rank_hint": x.get("st_rank_hint"), "finish_hint": x.get("finish_hint"),
                "hint_confidence": x.get("hint_confidence"),
                "candidate_source": x.get("candidate_source") or "deferred-retry",
            }
            try:
                row = self._fetch_official_run(session, cand, reg)
                verified += 1
                self._clear_failed_candidate(cand, reg)
                if row:
                    saved += self._save_confirmed(row, local_target_venues=local_target_venues)
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
                prior_retries = int(x.get("retry_count") or 0)
                # Each _fetch_official_run already tried the same official page up to
                # three times. If a deferred retry again receives an HTML document with
                # no start section/ST data, repeating forever cannot improve the result.
                # Quarantine it without fabricating/saving a course-history row.
                if prior_retries >= 1 and self._is_structural_official_zero_error(err):
                    self._mark_unavailable_candidate(cand, reg, err, retry_count=prior_retries + 1)
                    self.status["official_structural_unavailable_skips"] = int(
                        self.status.get("official_structural_unavailable_skips") or 0) + 1
                    self.status["last_structural_unavailable"] = (
                        f"{reg} {cand['date']} {str(cand['jcd']).zfill(2)} {cand['rno']}R "
                        f"/ retry={prior_retries + 1} / official start/ST absent"
                    )
                    continue
                failed += 1
                self._record_failed_candidate(cand, reg, err)
        self.status["deferred_failed_candidates"] = len(self._failed_candidates(reg))
        return verified, saved, failed

    def _initialize_racer(self, racer, today):
        reg, name = racer["registration_no"], racer.get("name") or racer["registration_no"]
        # Capture the pre-start state before _mark_started clears last_error.  Retry-only
        # is safe only when the previous full initial pass explicitly reached the
        # "individual race retry pending" terminal state.  A process crash midway
        # through a normal build must still resume the full build instead.
        _pre_state = self._state(reg) or {}
        self._mark_started(reg, name, today)
        self._set_worker_progress(reg, name=name, phase="候補履歴を先読み", year=None,
                                  index=int(racer.get("_today_index") or 0),
                                  today_venues=racer.get("today_venues") or [])
        session, seen, started = self._session(), set(), time.monotonic()
        all_candidates = []

        _n0, _l0 = self._summary_counts(reg)
        _venues0 = [str(x).zfill(2) for x in (racer.get("today_venues") or [])]

        # v17.233: retry-only fast path with persistent initial-pass marker.
        # If the previous initial build completed except for a handful of failed
        # official result pages, do NOT fetch recent/year archive pages again.
        # Revisit only the rows recorded in course_history_failed_candidates.
        retry_only = self._failed_candidates(reg)
        retry_only_ready = bool(retry_only) and (
            int(_pre_state.get("initial_pass_done") or 0) == 1
            or str(_pre_state.get("last_error") or "").startswith("個別レース再試行待ち")
        )
        # Do not use queue membership alone as proof that the full archive pass finished.
        # A generic DB/worker error must resume the normal build; only a persisted
        # initial_pass_done marker (or legacy terminal retry message) may bypass it.
        if retry_only_ready:
            self.status.update({
                "phase": f"{name} 失敗レースだけ再試行中",
                "current_racer": name,
                "current_registration_no": reg,
                "current_today_venues": _venues0,
                "national_counts": _n0,
                "current_local_counts": self._today_local_progress(_l0, _venues0),
                "retry_only_mode": True,
                "retry_only_candidate_count": len(retry_only),
                "flow": "エラー再試行時は年別履歴を再取得せず、失敗した個別レースだけ再確認",
                "crawl_stage": f"{name}: 個別失敗{len(retry_only)}走だけ再試行（全履歴の再走査なし）",
            })
            self._set_worker_progress(reg, phase=f"失敗レースのみ再試行 {len(retry_only)}件", year=None)
            rv, rs, rf = self._retry_failed_candidates(session, reg, name, started, _venues0)
            self._add_progress(reg, 0, rv, rs)
            remaining_failed = self._failed_candidates(reg)
            if remaining_failed:
                self._mark_error(reg, f"個別レース再試行待ち {len(remaining_failed)}件（年別履歴の再取得なし）")
                self.status.update({
                    "deferred_failed_candidates": len(remaining_failed),
                    "crawl_elapsed_seconds": int(time.monotonic() - started),
                    "last_fetch_state": "retry-only pending; archive history was not fetched",
                })
                return False

            # All deferred failures are resolved. The expensive initial build had
            # already been completed before this retry phase, so mark the racer done.
            self._mark_recent_done(reg)
            self._mark_complete(reg)
            self._set_worker_progress(reg, phase="再試行完了", year=None)
            national, local = self._summary_counts(reg)
            self.status.update({
                "phase": f"{name} 個別失敗レース再試行完了",
                "national_counts": national,
                "current_local_counts": self._today_local_progress(local, _venues0),
                "local_bucket_count": len(local),
                "full_local_bucket_count": sum(1 for x in local.values() if x >= 10),
                "last_matched_rows": rv,
                "last_parsed_rows": rs,
                "crawl_elapsed_seconds": int(time.monotonic() - started),
                "last_fetch_state": "retry-only complete; archive history was not fetched",
            })
            return True
        self.status.update({
            "phase": f"{name} 必要レース候補を先に抽出中",
            "current_racer": name, "current_registration_no": reg,
            "current_today_venues": _venues0,
            "national_counts": _n0,
            "current_local_counts": self._today_local_progress(_l0, _venues0),
            "flow": "最新→過去で選手本人履歴を先読み→未完成Cだけ確認→全国＋本日当地だけ保存",
        })

        # 1) Fetch cheap racer-history INDEX pages first.  Do not open any official result page yet.
        #    v17.230: parse complete archive rows first; audit a bounded cross-section against official
        #    we know which historical rows can survive the final top-10 retention.
        try:
            self._set_worker_progress(reg, phase="近走候補先読み", year=datetime.now(JST).year)
            recent = self._fetch_recent_racer_candidates(session, reg, name)
            all_candidates.extend(recent)
        except Exception as e:
            # Recent page is only a freshness supplement. Year pages still cover history, so record
            # this diagnostically but continue instead of aborting the whole racer.
            self.status["last_nonfatal_error"] = f"{reg} 近走候補取得: {type(e).__name__}: {e}"

        current_year = datetime.now(JST).year
        for year in range(current_year, FLOOR_YEAR - 1, -1):
            if self._stop.is_set():
                return False
            try:
                self._set_worker_progress(reg, phase="年別候補先読み", year=year)
                rows = self._fetch_year_racer_candidates(session, reg, name, year)
                all_candidates.extend(rows)
            except Exception as e:
                kind = "一時通信障害" if self._is_transient_fetch_error(e) else "履歴取得異常"
                self.status["last_archive_error"] = f"{reg} {year}年 {kind}: {type(e).__name__}: {e}"
                # Year pages are core history data, unlike boatracedata.com. Never invent
                # or silently skip an entire year: keep this racer pending for a later retry.
                self._mark_error(reg, f"{year}年{kind}: {type(e).__name__}: {e}")
                return False

        # 2) Build the exact retained top-10 plan from strict archive rows first.
        #    Most historical rows already contain actual course/ST/ST-rank/result.  We do
        #    NOT blindly trust them: a bounded official audit (latest per venue + per course)
        #    must pass before strict rows are written without per-race web fetches.
        strict_rows, ambiguous_rows, skipped_rows = self._strict_archive_plan(reg, all_candidates, _venues0)
        self.status.update({
            "phase": f"{name} 履歴厳格データを監査中",
            "candidate_races": len(all_candidates),
            "archive_strict_candidates": len(strict_rows),
            "archive_ambiguous_candidates": len(ambiguous_rows),
            "archive_skipped_candidates": len(skipped_rows),
            "crawl_stage": f"{name}: 候補{len(all_candidates)}走 → 厳格{len(strict_rows)}走 / 曖昧{len(ambiguous_rows)}走 / 不要{len(skipped_rows)}走",
        })
        self._set_worker_progress(reg, phase=f"履歴監査 最大30走程度", year=None)

        v = saved = failed = 0
        audit_ok, audit_rows, audit_checked = self._audit_strict_archive(session, reg, name, strict_rows, started)
        self.status.update({
            "archive_audit_checked": audit_checked,
            "archive_audit_ok": bool(audit_ok),
        })

        if audit_ok:
            # Fast path: use the already-parsed strict matrix for the retained historical rows.
            # Only audit rows + genuinely ambiguous rows need BOAT RACE detail-page access.
            saved += self._save_audited_archive_rows(reg, strict_rows, audit_rows, _venues0)
            v += audit_checked
            self.status.update({
                "phase": f"{name} 厳格履歴採用・曖昧分だけ公式確認",
                "archive_direct_saved": saved,
                "official_avoided_by_archive": max(0, len(strict_rows) - audit_checked),
                "crawl_stage": f"{name}: 厳格{len(strict_rows)}走のうち監査{audit_checked}走 / 公式省略{max(0,len(strict_rows)-audit_checked)}走 / 曖昧{len(ambiguous_rows)}走",
            })
            self._set_worker_progress(reg, phase=f"曖昧だけ公式確認 {len(ambiguous_rows)}走", year=None)
            av, a_saved, af = self._process_candidates(session, reg, name, ambiguous_rows, seen, started, _venues0)
            v += av; saved += a_saved; failed += af
        else:
            # Safety path: any audit mismatch/fetch failure disables archive-direct saving for
            # this racer. Fall back to the v17.222 fully-official verification logic.
            self.status.update({
                "phase": f"{name} 履歴監査不一致→公式確認へフォールバック",
                "archive_fast_path_disabled": True,
            })
            selected, reserve, skipped = self._prefilter_needed_candidates(reg, all_candidates, _venues0)
            self._set_worker_progress(reg, phase=f"安全フォールバック公式確認 {len(selected)}走", year=None)
            self._prefilter_hint_mismatch_regs.discard(str(reg))
            v, saved, failed = self._process_candidates(session, reg, name, selected, seen, started, _venues0)
            if reserve:
                rv0, rs0, rf0 = self._process_candidates(session, reg, name, reserve, seen, started, _venues0)
                v += rv0; saved += rs0; failed += rf0
            # Do NOT fall back to every historical race.  If a strict archive hint
            # disagrees with official data, only re-check races that can still fill
            # an unfinished nationwide course or today's local venue/course.
            if skipped:
                nat_now, loc_now = self._summary_counts(reg)
                need_only = []
                for x in skipped:
                    strict = x.get("hint_confidence") == "strict-matrix-v1" and x.get("course_hint")
                    if not strict:
                        # Ambiguous rows matter only while some target bucket is unfinished.
                        national_incomplete = any(int(nat_now.get(c,0)) < 10 for c in range(1,7))
                        local_incomplete = any(
                            int(loc_now.get((j,c),0)) < 10 for j in _venues0 for c in range(1,7)
                        )
                        if national_incomplete or local_incomplete:
                            need_only.append(x)
                        continue
                    c=int(x["course_hint"]); j=str(x["jcd"]).zfill(2)
                    need_n = int(nat_now.get(c,0)) < 10
                    need_l = (j in _venues0) and int(loc_now.get((j,c),0)) < 10
                    if need_n or need_l:
                        need_only.append(x)
                if need_only:
                    self.status["need_only_fallback_candidates"] = len(need_only)
                    fv, fs, ff = self._process_candidates(session, reg, name, need_only, seen, started, _venues0)
                    v += fv; saved += fs; failed += ff
        self._add_progress(reg, len(all_candidates), v, saved)
        # The expensive archive scan is now complete. Persist this *before* touching
        # deferred failures so a restart/DB hiccup can never force the archive scan again.
        self._mark_initial_pass_done(reg)

        rv, rs, rf = self._retry_failed_candidates(session, reg, name, started, _venues0)
        v += rv; saved += rs; failed += rf
        remaining_failed = self._failed_candidates(reg)
        if remaining_failed:
            self._mark_error(reg, f"個別レース再試行待ち {len(remaining_failed)}件（全履歴の再走査はしません）")
            self.status["deferred_failed_candidates"] = len(remaining_failed)
            return False

        self._mark_recent_done(reg)
        self._mark_complete(reg)
        self._set_worker_progress(reg, phase="完了", year=FLOOR_YEAR)
        national, local = self._summary_counts(reg)
        self.status.update({
            "phase": f"{name} 初回履歴構築完了",
            "national_counts": national,
            "current_local_counts": self._today_local_progress(local, racer.get("today_venues") or []),
            "local_bucket_count": len(local),
            "full_local_bucket_count": sum(1 for x in local.values() if x >= 10),
            "last_matched_rows": v,
            "last_parsed_rows": saved,
            "crawl_elapsed_seconds": int(time.monotonic() - started),
            "last_fetch_state": "initial complete; future updates are result-only",
        })
        return True

    def _initialize_racer_worker(self, racer, today):
        reg = str(racer.get("registration_no") or "")
        try:
            return self._initialize_racer(racer, today)
        except Exception as e:
            try:
                self._mark_error(reg, f"並行処理例外: {type(e).__name__}: {e}")
            except Exception:
                pass
            return False
        finally:
            self._clear_worker_progress(reg)

    def _run(self, today):
        racers = self._today_racers(today)
        if not racers:
            self.status.update({
                "phase": "本日の出走選手待ち",
                "today": today,
                "today_target_count": 0,
                "message": "本日の公式出走表がDBへ保存された後に、当日出走選手だけを対象にします。",
            })
            return
        self._register_today_targets(today, racers)
        all_pending = self._pending_today(racers)
        pending, queue_mode = self._priority_pending_today(racers)
        complete = len(racers) - len(all_pending)
        overview = self._today_status_overview(racers)
        self.status.update({
            "today": today,
            "today_target_count": len(racers),
            "today_complete_count": complete,
            "today_pending_count": len(all_pending),
            "today_queue_mode": queue_mode,
            "today_work_queue_count": len(pending),
            "today_running_count": overview["running"],
            "today_error_count": overview["error"],
            "today_unstarted_count": overview["unstarted"],
            "today_queued_count": overview["queued"],
            "today_recent_errors": overview["errors"],
            "phase": ("未着手選手を優先処理中" if queue_mode == "未着手優先" else ("エラー選手を最後に再試行中" if queue_mode == "エラー再試行フェーズ" else "未完了選手を処理中")) if all_pending else "本日出走選手は全員初回構築済み",
            "validation_mode": "v17.246 事前AI即時生成・直前15分分離版",
            "message": "初回完了済み選手は歴史ページへ再アクセスしません。以後は確定レース結果だけで全国＋その場を更新します。",
        })
        if not all_pending:
            return
        order_map = {str(x.get("registration_no")): idx for idx, x in enumerate(racers, 1)}
        self.status.update({
            "parallel_racer_workers": MAX_PARALLEL_RACERS,
            "active_workers": [],
            "message": ("未着手選手を先に最大3人同時で処理します。未着手が0人になってから再試行待ち選手へ移ります。" if queue_mode == "未着手優先" else "最大3人同時。未完了の通常処理を先に行い、エラー再試行は最後のフェーズで行います。" if queue_mode != "エラー再試行フェーズ" else "未着手選手が0人になったため、失敗した個別レースだけを再試行しています。"),
        })
        # Fetch/parse up to three racers concurrently. SQLite mutations are serialized
        # inside the collector, so this reduces waiting without introducing concurrent writes.
        with ThreadPoolExecutor(max_workers=MAX_PARALLEL_RACERS, thread_name_prefix="course-racer") as pool:
            futures = {}
            for racer in pending:
                if self._stop.is_set():
                    break
                reg = str(racer.get("registration_no") or "")
                worker_racer = dict(racer)
                worker_racer["_today_index"] = order_map.get(reg, 0)
                worker_racer["_queue_mode"] = queue_mode
                futures[pool.submit(self._initialize_racer_worker, worker_racer, today)] = worker_racer

            for future in as_completed(futures):
                racer = futures[future]
                try:
                    future.result()
                except Exception as e:
                    reg = str(racer.get("registration_no") or "")
                    self._mark_error(reg, f"worker失敗: {type(e).__name__}: {e}")
                ov2 = self._today_status_overview(racers)
                self.status.update({
                    "today_complete_count": ov2["complete"],
                    "today_running_count": ov2["running"],
                    "today_error_count": ov2["error"],
                    "today_unstarted_count": ov2["unstarted"],
                    "today_queued_count": ov2["queued"],
                    "today_recent_errors": ov2["errors"],
                    "today_pending_count": len(self._pending_today(racers)),
                })
                if self._stop.is_set():
                    break
        pending2 = self._pending_today(racers)
        next_queue, next_mode = self._priority_pending_today(racers)
        ov3 = self._today_status_overview(racers)
        self.status.update({
            "today_complete_count": ov3["complete"],
            "today_pending_count": len(pending2),
            "today_queue_mode": next_mode,
            "today_work_queue_count": len(next_queue),
            "today_running_count": ov3["running"],
            "today_error_count": ov3["error"],
            "today_unstarted_count": ov3["unstarted"],
            "today_queued_count": ov3["queued"],
            "today_recent_errors": ov3["errors"],
            "phase": "本日出走選手は全員初回構築済み" if not pending2 else ("未着手選手を優先処理中" if next_mode == "未着手優先" else ("エラー選手を最後に再試行中" if next_mode == "エラー再試行フェーズ" else "未完了選手を次回再開")),
        })
