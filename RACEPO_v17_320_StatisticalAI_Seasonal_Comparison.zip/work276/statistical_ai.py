"""RACEPO experimental venue-by-venue evidence engine (opt-in, separate DB).

No network access, app DB mutation, prediction change or background task occurs
on module import. Invoke the CLI explicitly to collect/import/analyse.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
import csv
from datetime import date as Date, datetime, timedelta, timezone
from itertools import combinations
import io
import json
import math
import os
from pathlib import Path
import re
import sqlite3
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

SOURCE_BASE = "https://boatracecsv.github.io/data"
STREAMS = ("results/realtime", "results/payouts", "programs/race_cards", "programs/title",
           "previews/sui", "previews/tkz", "previews/stt")
REQUIRED = STREAMS[:3]
DEFAULT_MIN_TRAIN, DEFAULT_MIN_TEST = 120, 60
PATTERN_FIELDS = ("month", "season", "season_window", "race_band", "race_no", "hour_band", "grade",
                  "weather", "wind_dir", "wind_speed", "wave", "tide_phase",
                  "lane1_class", "lane2_class", "lane3_class", "lane4_class",
                  "lane1_st", "lane2_st", "lane4_st", "fastest_exhibit")
PAIR_FIELDS = ("season", "season_window", "race_band", "grade", "wind_dir", "wind_speed", "wave",
               "lane1_class", "lane2_class", "lane4_class", "lane1_st", "fastest_exhibit")
TRIPLES = (("season", "race_band", "wind_speed"),
           ("season", "race_band", "lane1_class"),
           ("race_band", "lane1_class", "lane2_class"),
           ("grade", "wind_speed", "lane1_class"))
VENUES = {f"{i:02d}" for i in range(1, 25)}
COMBO_RE = re.compile(r"^[1-6]-[1-6]-[1-6]$")
SEASON_NAMES = {"spring": "春（3〜5月）", "summer": "夏（6〜8月）",
                "autumn": "秋（9〜11月）", "winter": "冬（12〜2月）"}
SEASON_BY_MONTH = {month: name for name, months in (
    ("spring", (3,4,5)), ("summer", (6,7,8)),
    ("autumn", (9,10,11)), ("winter", (12,1,2))) for month in months}



def default_store():
    return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "BOAT_AI_Lab" / "statistical_ai.db"


def parse_combo(value):
    txt = str(value or "").strip().translate(str.maketrans("１２３４５６－", "123456-"))
    if not COMBO_RE.fullmatch(txt) or len(set(txt.split("-"))) != 3:
        return None
    return txt


def positive_yen(value):
    txt = str(value or "").strip().replace(",", "").replace("円", "")
    if not re.fullmatch(r"[0-9]+", txt):
        return None
    n = int(txt)
    return n if 100 <= n <= 20000000 else None


def float_or_none(v):
    try:
        x = float(str(v).strip().replace(",", ""))
        return x if math.isfinite(x) else None
    except (ValueError, TypeError):
        return None


def range_label(v, bounds, labels):
    n = float_or_none(v)
    if n is None or n < 0:
        return None
    for cutoff, label in zip(bounds, labels):
        if n < cutoff:
            return label
    return labels[-1]


def code_key(row):
    key = str(row.get("レースコード") or "").strip()
    if not re.fullmatch(r"20\d{10}", key) or key[8:10] not in VENUES:
        return None
    try:
        Date.fromisoformat(f"{key[:4]}-{key[4:6]}-{key[6:8]}")
        rno = int(key[10:])
    except ValueError:
        return None
    return key if 1 <= rno <= 12 else None


def valid_clock(v):
    m = re.search(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)", str(v or ""))
    return f"{int(m.group(1)):02d}:{m.group(2)}" if m else None


def feature_map(day, rno, clock=None, grade=None, weather=None, wind_dir=None,
                wind_speed=None, wave=None, tide_phase=None, racers=None,
                exhibit_times=None):
    month = int(day[5:7])
    features = {"month": f"{month:02d}",
                "season": SEASON_BY_MONTH[month],
                "season_window": "11-03" if month in (11, 12, 1, 2, 3) else "04-10",
                "race_no": str(rno),
                "race_band": "9-12" if rno >= 9 else "5-8" if rno >= 5 else "1-4"}
    if clock:
        hour = int(clock[:2]); features["hour_band"] = "night" if hour >= 17 else "day" if hour >= 12 else "morning"
    if grade:
        g = str(grade).upper().strip()
        features["grade"] = "G1" if g == "PG1" else "一般" if g in ("IP", "一般戦") else g
    if weather not in (None, ""):
        features["weather"] = str(weather)
    if wind_dir not in (None, ""):
        features["wind_dir"] = str(wind_dir)
    for k, value, bounds, labels in (
        ("wind_speed", wind_speed, [2, 4, 6], ["0-1", "2-3", "4-5", "6+"]),
        ("wave", wave, [3, 6, 11], ["0-2", "3-5", "6-10", "11+"]),
    ):
        label = range_label(value, bounds, labels)
        if label: features[k] = label
    if tide_phase not in (None, "", "unknown"):
        features["tide_phase"] = str(tide_phase)
    if racers:
        for lane in range(1, 7):
            r = racers.get(lane) or {}
            cl = str(r.get("class") or "").upper().strip()
            if cl in ("A1", "A2", "B1", "B2"):
                features[f"lane{lane}_class"] = cl
            st = float_or_none(r.get("avg_st"))
            if st is not None and 0 <= st < 1:
                features[f"lane{lane}_st"] = "fast" if st < .13 else "mid" if st < .18 else "slow"
    if exhibit_times:
        valid = {lane: float_or_none(t) for lane, t in exhibit_times.items()}
        valid = {lane: t for lane, t in valid.items() if t is not None and t > 0}
        # Don't invent a fastest lane from a partially captured exhibition.
        if len(valid) == 6:
            fastest = min(valid, key=lambda n: (valid[n], n))
            features["fastest_exhibit"] = str(fastest)
    return features


def _entries(rows):
    return {key: row for row in rows if (key := code_key(row))}


def csv_from_bytes(data):
    try:
        decoded = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV encoding must be UTF-8") from exc
    return list(csv.DictReader(io.StringIO(decoded)))


def _race_card_features(row):
    racers = {}
    for i in range(1, 7):
        racers[i] = {"class": row.get(f"艇{i}_級別"), "avg_st": row.get(f"艇{i}_全国平均ST")}
    return racers


def _exhibit(row):
    if not row:
        return None
    return {n: row.get(f"艇{n}_展示タイム") for n in range(1, 7)}


def _optional_pre_race(row, deadline):
    """Prevent post-close snapshots being used to explain earlier choices."""
    if not row:
        return None
    captured = str(row.get("取得日時") or "").strip()
    if captured:
        try:
            capture_time = datetime.fromisoformat(captured)
            if capture_time.tzinfo is None:
                return None  # Ambiguous timezone: refuse.
            dt = datetime.fromisoformat(f"{row['レース日']}T{deadline}:00+09:00")
            if capture_time > dt:
                return None
        except (KeyError, ValueError):
            return None
    return row


class Store:
    def __init__(self, path=None):
        self.path = Path(path or default_store())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS pattern_races (
                    key TEXT PRIMARY KEY, day TEXT NOT NULL, venue TEXT NOT NULL,
                    rno INTEGER NOT NULL, combo TEXT NOT NULL, payout_yen INTEGER NOT NULL,
                    features TEXT NOT NULL, source TEXT NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                );
                CREATE INDEX IF NOT EXISTS idx_pattern_venue_day ON pattern_races(venue,day);
                CREATE TABLE IF NOT EXISTS pattern_reports (
                    venue TEXT PRIMARY KEY, payload TEXT NOT NULL,
                    generated_at TEXT NOT NULL
                );
            """)

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            with con:
                yield con
        finally:
            con.close()

    def upsert(self, data):
        with self.connect() as con:
            con.executemany("""
                INSERT INTO pattern_races(key,day,venue,rno,combo,payout_yen,features,source)
                VALUES (:key,:day,:venue,:rno,:combo,:payout_yen,:features,:source)
                ON CONFLICT(key) DO UPDATE SET
                  combo=excluded.combo,payout_yen=excluded.payout_yen,
                  features=CASE
                    WHEN pattern_races.source LIKE 'BoatraceCSV%' AND excluded.source LIKE 'RACEPO%'
                    THEN pattern_races.features ELSE excluded.features END,
                  source=CASE
                    WHEN pattern_races.source LIKE 'BoatraceCSV%' AND excluded.source LIKE 'RACEPO%'
                    THEN pattern_races.source ELSE excluded.source END,
                  updated_at=CURRENT_TIMESTAMP
            """, data)
        return len(data)

    def read_venue(self, venue):
        with self.connect() as con:
            rows = con.execute("SELECT key,day,venue,rno,combo,payout_yen,features FROM pattern_races WHERE venue=? ORDER BY day,key", (venue,)).fetchall()
        result = []
        for row in rows:
            features = json.loads(row["features"])
            # Existing research DBs used a two-season grouping. Normalize on read
            # so previously imported races immediately support the four seasons.
            month = int(row["day"][5:7])
            features["season"] = SEASON_BY_MONTH[month]
            features["season_window"] = "11-03" if month in (11,12,1,2,3) else "04-10"
            result.append(dict(row) | {"features": features})
        return result

    def save_report(self, venue, result):
        with self.connect() as con:
            con.execute("""INSERT INTO pattern_reports(venue,payload,generated_at) VALUES(?,?,?)
                        ON CONFLICT(venue) DO UPDATE SET payload=excluded.payload,generated_at=excluded.generated_at""",
                        (venue, json.dumps(result, ensure_ascii=False), datetime.now().isoformat(timespec="seconds")))

    def report(self, venue):
        with self.connect() as con:
            row = con.execute("SELECT payload FROM pattern_reports WHERE venue=?", (venue,)).fetchone()
        return json.loads(row["payload"]) if row else None


def import_csv_day(store, day, rows_by_stream):
    """Join official-like pre-race CSV with confirmed result+3T payout, skipping incomplete races.

    CSV rows are one race per 12-digit key. Exact source day and venue from key,
    pre-race temporal checks, full six-finisher requirement, no refunded/cancelled racing.
    """
    result = _entries(rows_by_stream.get("results/realtime") or [])
    payout = _entries(rows_by_stream.get("results/payouts") or [])
    cards = _entries(rows_by_stream.get("programs/race_cards") or [])
    titles = _entries(rows_by_stream.get("programs/title") or [])
    sui = _entries(rows_by_stream.get("previews/sui") or [])
    tkz = _entries(rows_by_stream.get("previews/tkz") or [])
    result_rows, skipped = [], Counter()
    for key, rr in result.items():
        if key[:8] != day.replace("-", ""):
            skipped["date_mismatch"] += 1; continue
        pay = payout.get(key); card = cards.get(key)
        if not pay or not card:
            skipped["missing_payout_or_card"] += 1; continue
        first3 = [str(rr.get(f"{i}着_艇番") or "").strip() for i in range(1, 4)]
        combo = parse_combo("-".join(first3))
        payout_combo = parse_combo(pay.get("3連単_組番"))
        amount = positive_yen(pay.get("3連単_払戻金"))
        if not combo or not payout_combo or combo != payout_combo or amount is None:
            skipped["invalid_result_payout"] += 1; continue
        # Exclude five-boat races and irregular races from 6-boat fixed-price simulations.
        finishers = [str(rr.get(f"{i}着_艇番") or "").strip() for i in range(1, 7)]
        if set(finishers) != set("123456"):
            skipped["incomplete_six_boats"] += 1; continue
        clock = valid_clock(rr.get("締切時刻") or card.get("締切時刻"))
        title = titles.get(key) or {}
        if str(title.get("中止状態") or "").strip():
            skipped["cancelled"] += 1; continue
        safe_sui = _optional_pre_race(sui.get(key), clock) if clock else None
        safe_tkz = _optional_pre_race(tkz.get(key), clock) if clock else None
        features = feature_map(day, int(key[-2:]), clock, title.get("グレード"),
                               (safe_sui or {}).get("天候"), (safe_sui or {}).get("風向"),
                               (safe_sui or {}).get("風速(m)"), (safe_sui or {}).get("波の高さ(cm)"),
                               racers=_race_card_features(card), exhibit_times=_exhibit(safe_tkz))
        result_rows.append({"key": key, "day": day, "venue": key[8:10],
                            "rno": int(key[10:]), "combo": combo, "payout_yen": amount,
                            "features": json.dumps(features, ensure_ascii=False, sort_keys=True),
                            "source": "BoatraceCSV(pre-race/result/payout)"})
    return {"day": day, "imported": store.upsert(result_rows), "skipped": dict(skipped)}


def fetch_day(day, local_root=None):
    rows, errors = {}, {}
    yyyy, mm, dd = day.split("-")
    for stream in STREAMS:
        if local_root:
            path = Path(local_root) / stream / yyyy / mm / f"{dd}.csv"
            if not path.is_file():
                errors[stream] = "not found"; continue
            data = path.read_bytes()
        else:
            url = f"{SOURCE_BASE}/{stream}/{yyyy}/{mm}/{dd}.csv"
            req = Request(url, headers={"User-Agent": "RACEPO-Statistical-Research/0.1"})
            try:
                with urlopen(req, timeout=12) as response:
                    data = response.read(25_000_001)
            except (HTTPError, URLError, TimeoutError, OSError) as exc:
                errors[stream] = type(exc).__name__; continue
        if len(data) > 25_000_000:
            errors[stream] = "file too large"; continue
        try:
            rows[stream] = csv_from_bytes(data)
        except ValueError:
            errors[stream] = "unsupported encoding"
    return rows, errors


def sync_days(store, start, end, local_root=None, max_days=31):
    first, last = Date.fromisoformat(start), Date.fromisoformat(end)
    if last < first or (last - first).days >= max_days:
        raise ValueError(f"1回の同期は最大{max_days}日。日付範囲を確認してください")
    out = []
    d = first
    while d <= last:
        rows, errors = fetch_day(d.isoformat(), local_root)
        if not all(rows.get(k) for k in REQUIRED):
            out.append({"day": d.isoformat(), "imported": 0, "status": "required_source_missing", "errors": errors})
        else:
            result = import_csv_day(store, d.isoformat(), rows)
            out.append(result | {"status": "ok", "optional_errors": errors})
        d += timedelta(days=1)
    return out


def _recorded_before_close(timestamp, day, deadline):
    """SQLite CURRENT_TIMESTAMP is UTC; local scheduled deadline is JST."""
    if not timestamp or not deadline:
        return False
    try:
        snap = datetime.fromisoformat(str(timestamp).replace(' ', 'T'))
        if snap.tzinfo is None:
            snap = snap.replace(tzinfo=timezone.utc)
        jst = timezone(timedelta(hours=9))
        end = datetime.fromisoformat(f'{day}T{deadline}:00').replace(tzinfo=jst)
        return snap.astimezone(jst) <= end
    except (ValueError, TypeError):
        return False


def _safe_snapshot(data, timestamp, day, deadline):
    if not data or not _recorded_before_close(timestamp, day, deadline):
        return {}
    try:
        return json.loads(data)
    except (ValueError, TypeError):
        return {}


def import_local_db(store, original_path):
    """Read original SQLite in read-only mode. Never run schema migrations."""
    uri = f"file:{Path(original_path).resolve().as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=10)
    con.row_factory = sqlite3.Row
    records = []
    skipped = Counter()
    try:
        rs = con.execute("""
          SELECT r.date,r.jcd,r.rno,r.trifecta,r.payout_yen,r.payload AS result_payload,
                 sl.payload AS racelist,sl.captured_at AS racelist_time,
                 bi.payload AS beforeinfo,bi.captured_at AS beforeinfo_time,
                 sc.deadline,evt.event_grade,tide.tide_phase,tide.created_at AS tide_time
          FROM race_results r
          LEFT JOIN race_snapshots sl ON sl.date=r.date AND sl.jcd=r.jcd AND sl.rno=r.rno AND sl.kind='racelist'
          LEFT JOIN race_snapshots bi ON bi.date=r.date AND bi.jcd=r.jcd AND bi.rno=r.rno AND bi.kind='beforeinfo'
          LEFT JOIN race_schedule sc ON sc.date=r.date AND sc.jcd=r.jcd AND sc.rno=r.rno
          LEFT JOIN venue_event_meta evt ON evt.date=r.date AND evt.jcd=r.jcd
          LEFT JOIN tide_race_context tide ON tide.date=r.date AND tide.jcd=r.jcd AND tide.rno=r.rno
          ORDER BY r.date,r.jcd,r.rno
        """).fetchall()
        for row in rs:
            day = str(row["date"] or "")
            if re.fullmatch(r"\d{8}", day): day = f"{day[:4]}-{day[4:6]}-{day[6:]}"
            try:
                Date.fromisoformat(day)
                venue = str(row["jcd"]).zfill(2); rno = int(row["rno"])
            except (ValueError, TypeError):
                skipped["invalid_key"] += 1; continue
            combo, payout = parse_combo(row["trifecta"]), positive_yen(row["payout_yen"])
            if not combo or payout is None or venue not in VENUES or rno not in range(1, 13):
                skipped["invalid_result"] += 1; continue
            clock = valid_clock(row["deadline"])
            racelist = _safe_snapshot(row["racelist"], row["racelist_time"], day, clock)
            try:
                result_payload = json.loads(row["result_payload"] or '{}')
            except (ValueError, TypeError):
                result_payload = {}
            # 6艇正常出走が確認できない結果は返還を誤計算しうるため除外。
            finishers = result_payload.get('finishers') or []
            racer_rows = racelist.get('racers') or []
            confirmed_six = (
                isinstance(finishers, list) and len(finishers) == 6
                and all(isinstance(x, dict) for x in finishers)
                and {x.get('lane') for x in finishers} == set(range(1,7))
                and {x.get('finish') for x in finishers} == set(range(1,7))
                and all(not x.get('status') and str(x.get('st_raw') or '').upper() not in ('F','L')
                        for x in finishers)
            )
            if not confirmed_six:
                skipped['six_boat_finish_not_verified'] += 1; continue
            before = _safe_snapshot(row["beforeinfo"], row["beforeinfo_time"], day, clock)
            if (racelist.get("has_scratch") or racelist.get("scratch_lanes")):
                skipped["scratched"] += 1; continue
            racers = {int(x["lane"]): {"class": x.get("class"), "avg_st": x.get("avg_st")}
                      for x in racelist.get("racers", []) if isinstance(x, dict) and str(x.get("lane")) in "123456"}
            weather = before.get("weather") or {}
            pre_racers = {int(x["lane"]): x.get("exhibition_time")
                          for x in before.get("racers", []) if isinstance(x, dict) and str(x.get("lane")) in "123456"}
            features = feature_map(day, rno, clock, row["event_grade"],
                                   weather.get("weather"), weather.get("wind_direction"),
                                   weather.get("wind_speed_m"), weather.get("wave_height_cm"),
                                   row["tide_phase"] if _recorded_before_close(row['tide_time'], day, clock) else None,
                                   racers, pre_racers)
            records.append({"key": f"{day.replace('-', '')}{venue}{rno:02d}", "day": day,
                            "venue": venue, "rno": rno, "combo": combo, "payout_yen": payout,
                            "features": json.dumps(features, ensure_ascii=False, sort_keys=True),
                            "source": "RACEPO local result/pre-race snapshots"})
    finally:
        con.close()
    return {"imported": store.upsert(records), "skipped": dict(skipped)}


def formation(first, second, third, maximum=13):
    """Strict 3T combination expansion; a boat may never appear twice."""
    f = [int(x) for x in first]; s = [int(x) for x in second]; t = [int(x) for x in third]
    if not all(1 <= x <= 6 for x in f + s + t):
        raise ValueError("boat numbers must be 1..6")
    bets = {f"{a}-{b}-{c}" for a in f for b in s for c in t if len({a, b, c}) == 3}
    if not bets or len(bets) > maximum:
        raise ValueError(f"formation contains {len(bets)} tickets, max {maximum}")
    return frozenset(bets)


def _patterns(row):
    tags = row["features"]
    out = [(key, str(tags[key])) for key in PATTERN_FIELDS if key in tags]
    base = [(k, str(tags[k])) for k in PAIR_FIELDS if k in tags]
    pairs = [tuple(sorted((a, b))) for a, b in combinations(base, 2)]
    triples = [tuple((k, str(tags[k])) for k in group) for group in TRIPLES if all(k in tags for k in group)]
    return [(x,) for x in out] + pairs + triples + [()]


def _format_conditions(pattern):
    return [{"field": k, "value": v} for k, v in pattern]


def _coverage(rows, bets, stake=100):
    n = len(rows)
    hits = sum(r["combo"] in bets for r in rows)
    paid = sum(r["payout_yen"] for r in rows if r["combo"] in bets)
    invested = n * len(bets) * stake
    return {"races": n, "hits": hits, "hit_rate": round(hits / n * 100, 3) if n else None,
            "tickets": len(bets), "stake_per_ticket": stake,
            "total_stake_yen": invested, "total_payout_yen": paid,
            "net_yen": paid-invested,
            "roi": round(paid / invested * 100, 3) if invested else None}


def _candidates(train, max_tickets=13):
    observed = Counter(r["combo"] for r in train)
    options = {}
    for combo, _ in observed.most_common(12):
        options[combo] = frozenset((combo,))
    for n in range(1, 7):
        rem = [x for x in range(1, 7) if x != n]
        for second_len, third_len in ((1, 2), (2, 3), (2, 4), (3, 3)):
            sec_score = Counter(int(r["combo"].split("-")[1]) for r in train if r["combo"].startswith(f"{n}-"))
            third_score = Counter(int(r["combo"].split("-")[2]) for r in train if r["combo"].startswith(f"{n}-"))
            secs = sorted(rem, key=lambda x: (-sec_score[x], x))[:second_len]
            thirds = sorted(rem, key=lambda x: (-third_score[x], x))[:third_len]
            if secs and thirds:
                try:
                    options[f"{n}-{''.join(map(str,secs))}-{''.join(map(str,thirds))}"] = formation((n,), secs, thirds, max_tickets)
                except ValueError: pass
    for n in range(1, 7):
        rem = sorted(x for x in range(1, 7) if x != n)
        for s in combinations(rem, 2):
            third = tuple(s) + tuple(x for x in rem if x not in s)[:1]
            try:
                options[f"{n}-{''.join(map(str,s))}-{''.join(map(str,third))}"] = formation((n,), s, third, max_tickets)
            except ValueError: pass
    for label, ff, ss, tt in (("1-23-234", [1], [2, 3], [2, 3, 4]),
                               ("1-234-234", [1], [2, 3, 4], [2, 3, 4])):
        options[label] = formation(ff, ss, tt, max_tickets)
    # Keep the smallest canonical name for identical bet sets.
    unique = {}
    for label, bets in options.items():
        unique.setdefault(tuple(sorted(bets)), label)
    return [(label, frozenset(combos)) for combos, label in unique.items()]


def _comparison_formations():
    """Predeclared buy patterns: not tuned to a venue or its validation period.

    Descriptive 20-point first-place coverage is allowed even though the live
    predictor's maximum of 13 points is intentionally unchanged.
    """
    return [
        ("1-全-全", formation([1], [2,3,4,5,6], [2,3,4,5,6], maximum=20)),
        ("1-2345-2345", formation([1], [2,3,4,5], [2,3,4,5])),
        ("1-23-234", formation([1], [2,3], [2,3,4])),
        ("1-23-23", formation([1], [2,3], [2,3])),
        ("1-234-234", formation([1], [2,3,4], [2,3,4])),
        ("1-2-3", formation([1], [2], [3])),
        ("1-3-2", formation([1], [3], [2])),
        ("1-6-4", formation([1], [6], [4])),
    ]


def _historical_comparisons(train, test, min_train=30, min_test=15):
    """Calculate accurate, transparent, *descriptive* results for four seasons.

    All groups and formations are predefined independently of outcomes. Both
    favorable and unfavorable holdout results are retained. The client displays
    only a small subset; it does not use holdout ROI to choose those rows.
    """
    comparisons = []
    fixed_formations = _comparison_formations()
    for season in SEASON_NAMES:
        specs = [(('season', season),)]
        for band in ('1-4', '5-8', '9-12'):
            specs.append((('season', season), ('race_band', band)))
            for level in ('A1', 'B1'):
                specs.append((('season', season), ('race_band', band), ('lane1_class', level)))
        for grade in ('G1', 'SG'):
            specs.append((('season', season), ('grade', grade)))
        for conditions in specs:
            trows = [r for r in train if all(r['features'].get(k) == v for k,v in conditions)]
            vrows = [r for r in test if all(r['features'].get(k) == v for k,v in conditions)]
            if len(trows) < min_train or len(vrows) < min_test:
                continue
            for label, bets in fixed_formations:
                comparisons.append({
                    'season': season, 'condition': _format_conditions(conditions),
                    'formation': label, 'train': _coverage(trows, bets),
                    'validation': _coverage(vrows, bets),
                    'status': 'historical_comparison_only',
                })
    return comparisons


def analyze_venue(store, venue, min_train=DEFAULT_MIN_TRAIN, min_test=DEFAULT_MIN_TEST,
                  max_tickets=13, top=30):
    if venue not in VENUES:
        raise ValueError("venue must be 01..24")
    rows = store.read_venue(venue)
    days = sorted({r["day"] for r in rows})
    first_counts = Counter(x['combo'][0] for x in rows)
    pair_counts = Counter(x['combo'][:3] for x in rows)
    # Descriptive base rates for every one of the 120 3T results, not only
    # the historically most successful picks (which would bias the display).
    all_3t = [f'{a}-{b}-{c}' for a in range(1,7) for b in range(1,7) for c in range(1,7)
              if len({a,b,c}) == 3]
    baseline = {
        'all_3t': {combo: _coverage(rows, frozenset([combo])) for combo in all_3t},
        'first': {str(i): {'hits': first_counts[str(i)], 'rate': round(first_counts[str(i)] / len(rows)*100,3) if rows else None}
                  for i in range(1,7)},
        'pair_first1': {f'1-{i}': {'hits': pair_counts[f'1-{i}'], 'rate': round(pair_counts[f'1-{i}']/len(rows)*100,3) if rows else None}
                        for i in range(2,7)},
        'formation_1_23_234': _coverage(rows, formation([1], [2,3], [2,3,4])),
    }
    report = {"venue": venue, "total_races": len(rows), "dates": [days[0], days[-1]] if days else [],
              "baselines": baseline,
              "min_train": min_train, "min_test": min_test, "stake_per_ticket_yen": 100,
              "status": "not_enough_data", "candidates": [], "comparisons": [],
              "season_counts": {s: sum(r['features'].get('season') == s for r in rows) for s in SEASON_NAMES},
              "caveat": "探索・検証は過去データ上。多数比較による過適合のため将来成績は未保証。自動購入や本番AIへの反映なし。"}
    if len(days) < 2:
        store.save_report(venue, report); return report
    cutoff = days[max(1, min(len(days)-1, int(len(days)*.7)))]
    report["split_day"] = cutoff
    train = [r for r in rows if r["day"] < cutoff]
    test = [r for r in rows if r["day"] >= cutoff]
    report["train_races"], report["test_races"] = len(train), len(test)
    # A descriptive comparison is distinct from a statistically screened pick.
    # It can be displayed even when the much stricter candidate gate fails.
    report["comparisons"] = _historical_comparisons(train, test)
    report["season_counts"] = {s: sum(r['features'].get('season') == s for r in rows)
                               for s in SEASON_NAMES}
    report["comparison_note"] = ("春3〜5月・夏6〜8月・秋9〜11月・冬12〜2月。"
         "学習期間で発見した傾向は後の検証期間と比較。ランキングではなく過去実績の表示です。"
         "異なる条件間の高回収率は選択バイアスの影響を受けます。")
    if len(train) < min_train or len(test) < min_test:
        store.save_report(venue, report); return report
    report["status"] = "analyzed"
    patterns_train, patterns_test = defaultdict(list), defaultdict(list)
    for r in train:
        for pattern in _patterns(r): patterns_train[pattern].append(r)
    for r in test:
        for pattern in _patterns(r):
            if pattern in patterns_train: patterns_test[pattern].append(r)
    best = []
    for pattern, subset in patterns_train.items():
        holdout = patterns_test.get(pattern, [])
        if len(subset) < min_train or len(holdout) < min_test:
            continue
        for label, bets in _candidates(subset, max_tickets):
            tr = _coverage(subset, bets); te = _coverage(holdout, bets)
            if tr["hits"] < 5 or te["hits"] < 3 or tr["roi"] < 100 or te["roi"] < 100:
                continue
            best.append({"condition": _format_conditions(pattern), "formation": label,
                         "picks": sorted(bets), "train": tr, "validation": te,
                         "status": "historical_validation_only"})
    # Do not claim statistical certainty; multiple-hypothesis searching remains.
    best.sort(key=lambda x: (x["validation"]["roi"], x["validation"]["hits"],
                             x["validation"]["races"]), reverse=True)
    report["candidates"] = best[:top]
    report["eligible_patterns"] = sum(len(s)>=min_train and len(patterns_test.get(k,[]))>=min_test
                                      for k,s in patterns_train.items())
    store.save_report(venue, report)
    return report


def inspect_formation(store, venue, expression, conditions):
    if venue not in VENUES:
        raise ValueError('invalid venue')
    parts = expression.strip().replace(' ', '').split('-')
    if len(parts) != 3:
        raise ValueError('expected 1-23-234 formation')
    chunks = []
    for part in parts:
        lane_str = '123456' if part == '全' else part
        if not lane_str or not all(x in '123456' for x in lane_str) or len(set(lane_str)) != len(lane_str):
            raise ValueError('invalid formation: '+part)
        chunks.append([int(x) for x in lane_str])
    bets = formation(*chunks)
    if any(k not in PATTERN_FIELDS for k in conditions) or len(conditions) > 6:
        raise ValueError('unsupported condition field or too many conditions')
    # Compatibility with previously documented CLI queries (two-period season).
    # Newly supplied season=spring/summer/autumn/winter uses the canonical four seasons.
    query = dict(conditions)
    if query.get('season') in ('11-03', '04-10'):
        query['season_window'] = query.pop('season')
    rows = [row for row in store.read_venue(venue)
            if all(str(row['features'].get(k, '')) == str(v) for k,v in query.items())]
    return {'venue': venue, 'formation': expression, 'conditions': conditions,
            'picks': sorted(bets), 'historical': _coverage(rows, bets),
            'status': 'descriptive_only_not_validation',
            'note': 'Same data used for the descriptive result; not verified for future use.'}


def main(argv=None):
    p = argparse.ArgumentParser(description="RACEPO independent statistical research engine")
    p.add_argument("--store", default=str(default_store()), help="separate research SQLite DB")
    sub = p.add_subparsers(dest="action", required=True)
    sync = sub.add_parser("sync", help="explicitly fetch daily public CSVs")
    sync.add_argument("--from-date", required=True); sync.add_argument("--to-date", required=True)
    sync.add_argument("--local-csv-root", help="use locally downloaded CSVs instead of network")
    loc = sub.add_parser("import-local", help="read existing RACEPO DB (read-only)")
    loc.add_argument("--source-db", required=True)
    anal = sub.add_parser("analyze", help="discover and validate candidate formations")
    sub.add_parser("analyze-all", help="analyze all 24 venues and store their reports")
    anal.add_argument("--venue", choices=sorted(VENUES), required=True)
    anal.add_argument("--min-train", type=int, default=DEFAULT_MIN_TRAIN)
    anal.add_argument("--min-test", type=int, default=DEFAULT_MIN_TEST)
    anal.add_argument("--max-tickets", type=int, default=13)
    anal.add_argument("--top", type=int, default=20)
    inspect = sub.add_parser("inspect", help="historical stats for an explicitly chosen formation and conditions")
    inspect.add_argument("--venue", choices=sorted(VENUES), required=True)
    inspect.add_argument("--formation", required=True)
    inspect.add_argument("--conditions", default="{}", help='JSON object: {"season":"winter","race_band":"9-12"}')
    show = sub.add_parser("show", help="show previously saved report")
    show.add_argument("--venue", choices=sorted(VENUES), required=True)
    args = p.parse_args(argv)
    store = Store(args.store)
    if args.action == "sync":
        output = sync_days(store, args.from_date, args.to_date, args.local_csv_root)
    elif args.action == "import-local":
        output = import_local_db(store, args.source_db)
    elif args.action == "analyze-all":
        output = [{"venue": v, "status": (report := analyze_venue(store, v))["status"],
                   "total_races": report["total_races"], "candidates": len(report["candidates"])}
                  for v in sorted(VENUES)]
    elif args.action == "analyze":
        if args.min_train < 10 or args.min_test < 10 or not 1 <= args.max_tickets <= 13 or not 1 <= args.top <= 100:
            p.error("minimum 10 races per split, 1..13 tickets, 1..100 candidates")
        output = analyze_venue(store, args.venue, args.min_train, args.min_test, args.max_tickets, args.top)
    elif args.action == 'inspect':
        conditions = json.loads(args.conditions)
        if not isinstance(conditions, dict):
            p.error('--conditions must be a JSON object')
        output = inspect_formation(store, args.venue, args.formation, conditions)
    else:
        output = store.report(args.venue) or {"status": "no_report", "venue": args.venue}
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
