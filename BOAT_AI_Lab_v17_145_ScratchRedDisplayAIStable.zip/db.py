from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import calendar
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

# Every racer is identified by the official registration number plus name.
# A racer enters this store only after appearing in an official racelist/result;
# retired or inactive racers therefore are not proactively bulk-collected.
TRACKED_RACERS = {"4320": "峰竜太"}


def _calendar_months_ago(value: datetime, months: int) -> datetime:
    """Return the same wall-clock time the requested calendar months ago."""
    month_index = value.year * 12 + value.month - 1 - months
    year, zero_based_month = divmod(month_index, 12)
    month = zero_based_month + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return value.replace(year=year, month=month, day=day)


def _official_course_payload(raw_payload: str | dict | None) -> dict | None:
    """Recognise only a complete official six-course data snapshot."""
    try:
        payload = raw_payload if isinstance(raw_payload, dict) else json.loads(raw_payload or "{}")
    except (TypeError, json.JSONDecodeError):
        return None
    courses = payload.get("course_stats") or []
    if int(payload.get("course_stats_version") or 0) < 2 or len(courses) != 6:
        return None
    return payload


def _sqlite_datetime(value: str | None) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value)) if value else None
    except (TypeError, ValueError):
        return None


class BoatDB:
    def __init__(self, path: str | None = None):
        if path is None:
            local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
            shared_dir = Path(local_app) / "BOAT_AI_Lab"
            shared_dir.mkdir(parents=True, exist_ok=True)
            shared_db = shared_dir / "boat_ai.db"

            # 初回だけ旧バージョンの同階層DBがあれば移行
            legacy = Path("boat_ai.db")
            if not shared_db.exists() and legacy.exists():
                try:
                    shutil.copy2(legacy, shared_db)
                except Exception:
                    pass

            self.path = shared_db
        else:
            self.path = Path(path)

        self._init()

    def connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self.connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS venue_meeting_day (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                day_number INTEGER,
                day_label TEXT,
                official_label TEXT,
                source TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd)
            );

            CREATE TABLE IF NOT EXISTS race_schedule (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                deadline TEXT,
                source TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS venue_event_meta (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                event_grade TEXT,
                event_title TEXT,
                source TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd)
            );

            CREATE TABLE IF NOT EXISTS daily_fixed_data_state (
                date TEXT PRIMARY KEY,
                venue_codes TEXT NOT NULL,
                completed_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS basic_data_state (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                logic_version TEXT NOT NULL,
                status TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                last_error TEXT,
                PRIMARY KEY(date, jcd, rno, logic_version)
            );

            CREATE TABLE IF NOT EXISTS race_snapshots (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                kind TEXT NOT NULL,
                captured_at TEXT DEFAULT CURRENT_TIMESTAMP,
                payload TEXT NOT NULL,
                PRIMARY KEY(date, jcd, rno, kind)
            );

            CREATE TABLE IF NOT EXISTS race_results (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                trifecta TEXT,
                payout_yen INTEGER,
                odds REAL,
                kimarite TEXT,
                payload TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                confidence REAL,
                judgement TEXT,
                scenario TEXT,
                main_picks TEXT,
                value_picks TEXT,
                leaks TEXT,
                source_snapshot TEXT,
                ai_comment TEXT,
                UNIQUE(date, jcd, rno)
            );

            CREATE TABLE IF NOT EXISTS racer_comments (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                lane INTEGER NOT NULL,
                comment TEXT NOT NULL,
                source TEXT,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date, jcd, rno, lane)
            );

            CREATE TABLE IF NOT EXISTS user_race_insights (
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                rno INTEGER NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,jcd,rno)
            );

            CREATE TABLE IF NOT EXISTS tracked_racer_profiles (
                registration_no TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1,
                last_seen_date TEXT,
                profile_json TEXT NOT NULL DEFAULT '{}',
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS tracked_racer_results (
                registration_no TEXT NOT NULL,
                meeting_id TEXT NOT NULL,
                date TEXT NOT NULL,
                jcd TEXT NOT NULL,
                meeting_day INTEGER,
                rno INTEGER NOT NULL,
                lane INTEGER,
                course INTEGER,
                finish INTEGER,
                st_raw TEXT,
                source_url TEXT,
                PRIMARY KEY(registration_no,date,jcd,rno)
            );

            CREATE TABLE IF NOT EXISTS tracked_racer_course_monthly (
                registration_no TEXT NOT NULL,
                scope TEXT NOT NULL,
                month TEXT NOT NULL,
                course INTEGER NOT NULL,
                starts INTEGER NOT NULL DEFAULT 0,
                first_count INTEGER NOT NULL DEFAULT 0,
                second_count INTEGER NOT NULL DEFAULT 0,
                third_count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(registration_no,scope,month,course)
            );

            CREATE TABLE IF NOT EXISTS racer_official_monthly (
                registration_no TEXT NOT NULL,
                month TEXT NOT NULL,
                name TEXT NOT NULL,
                payload TEXT NOT NULL,
                saved_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(registration_no,month)
            );

            -- One row is created only for racers who appear in that day's
            -- official racelist.  It is the durable, truthful progress log
            -- for the all-day official racer-search collection.
            CREATE TABLE IF NOT EXISTS daily_racer_official_collection (
                date TEXT NOT NULL,
                registration_no TEXT NOT NULL,
                name TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                last_error TEXT,
                verified INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(date,registration_no)
            );

            CREATE TABLE IF NOT EXISTS venue_knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                jcd TEXT NOT NULL,
                venue TEXT,
                source_url TEXT NOT NULL,
                source_kind TEXT NOT NULL,
                title TEXT,
                content_text TEXT,
                content_hash TEXT,
                local_path TEXT,
                fetched_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(jcd, source_url)
            );

            CREATE INDEX IF NOT EXISTS idx_venue_knowledge_jcd
            ON venue_knowledge(jcd);

            CREATE TABLE IF NOT EXISTS venue_knowledge_state (
                jcd TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                completed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                source_count INTEGER DEFAULT 0
            );
            """)
            for reg, name in TRACKED_RACERS.items():
                con.execute("""
                    INSERT INTO tracked_racer_profiles(registration_no,name,active)
                    VALUES(?,?,1)
                    ON CONFLICT(registration_no) DO UPDATE SET name=excluded.name,active=1
                """, (reg, name))



    def save_before_atomic(self, date, jcd, rno, data):
        payload = json.dumps(data, ensure_ascii=False)
        with self.connect() as con:
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, str(jcd).zfill(2), int(rno), "beforeinfo", payload))
            con.commit()

    def before_snapshot_quality(self, date, jcd, rno):
        snap = self.get_snapshot(date, str(jcd).zfill(2), int(rno), "beforeinfo")
        if not snap:
            return {"meaningful": False, "racers": 0, "starts": 0, "original_exhibition": 0, "weather_fields": 0}

        data = snap.get("data") or {}
        racers = data.get("racers") or []
        starts = data.get("start_display") or []
        original = data.get("original_exhibition") or []
        weather = data.get("weather") or {}
        wf = sum(1 for v in weather.values() if v is not None and v != "")

        return {
            "meaningful": bool(racers or starts or original or wf),
            "racers": len(racers),
            "starts": len(starts),
            "original_exhibition": len(original),
            "weather_fields": wf,
        }

    def get_before_complete_keys(self, date):
        out = set()
        for row in self.get_day_snapshots(date, "beforeinfo"):
            data = row.get("data") or {}
            racers = data.get("racers") or []
            starts = data.get("start_display") or []
            original = data.get("original_exhibition") or []
            weather = data.get("weather") or {}
            wf = sum(1 for v in weather.values() if v is not None and v != "")
            if racers or starts or original or wf:
                out.add((str(row["jcd"]).zfill(2), int(row["rno"])))
        return out

    def get_scratch_audited_keys(self, date: str):
        REQUIRED_AUDIT_VERSION = "scratch-audit-v1"

        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload
                FROM race_snapshots
                WHERE date=? AND kind='racelist'
            """, (date,)).fetchall()

        out = set()

        for row in rows:
            try:
                data = json.loads(row["payload"])
                if data.get("scratch_audit_version") == REQUIRED_AUDIT_VERSION:
                    out.add(
                        (
                            str(row["jcd"]).zfill(2),
                            int(row["rno"]),
                        )
                    )
            except Exception:
                pass

        return out

    def get_odds_complete_keys(self, date: str):
        REQUIRED_VALIDATION_VERSION = "scratch-matrix-v2"

        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload
                FROM race_snapshots
                WHERE date=? AND kind='odds3t'
            """, (date,)).fetchall()

        out = set()
        for row in rows:
            try:
                data = json.loads(row["payload"])
                if data.get("odds_validation_version") != REQUIRED_VALIDATION_VERSION:
                    continue

                odds = data.get("odds") or []
                expected = int(data.get("expected_count") or 120)
                combos = [str(x.get("combo") or "") for x in odds]

                if (
                    expected > 0
                    and len(odds) == expected
                    and len(set(combos)) == expected
                ):
                    out.add((str(row["jcd"]).zfill(2), int(row["rno"])))
            except Exception:
                pass
        return out

    def save_odds_atomic(
        self,
        date: str,
        jcd: str,
        rno: int,
        odds_data: dict,
    ):
        """
        Save the 3連単 odds snapshot only when caller already validated
        that all 120 combinations exist.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        payload = json.dumps(odds_data, ensure_ascii=False)

        with self.connect() as con:
            con.execute("BEGIN")
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, jcd, rno, "odds3t", payload))
            con.commit()

    def verify_odds_snapshot(self, date: str, jcd: str, rno: int):
        REQUIRED_VALIDATION_VERSION = "scratch-matrix-v2"
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        with self.connect() as con:
            row = con.execute("""
                SELECT payload
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind='odds3t'
            """, (date, jcd, rno)).fetchone()

        if not row:
            return False

        try:
            data = json.loads(row["payload"])
        except Exception:
            return False

        if data.get("odds_validation_version") != REQUIRED_VALIDATION_VERSION:
            return False

        odds = data.get("odds") or []
        expected = int(data.get("expected_count") or 120)
        combos = [str(x.get("combo") or "") for x in odds]

        return (
            expected > 0
            and len(odds) == expected
            and len(combos) == expected
            and len(set(combos)) == expected
            and all("-" in c for c in combos)
        )

    def save_basic_race_atomic(
        self,
        date: str,
        jcd: str,
        rno: int,
        race_data: dict,
        deadline: str,
        logic_version: str,
    ):
        """
        One transaction:
          1) racelist snapshot
          2) deadline schedule
          3) completed state

        If any SQL step fails, none of the three is committed.
        """
        jcd = str(jcd).zfill(2)
        rno = int(rno)
        payload = json.dumps(race_data, ensure_ascii=False)

        with self.connect() as con:
            con.execute("BEGIN")

            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET
                    payload=excluded.payload,
                    captured_at=CURRENT_TIMESTAMP
            """, (date, jcd, rno, "racelist", payload))

            con.execute("""
                INSERT INTO race_schedule(date,jcd,rno,deadline,source,updated_at)
                VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno)
                DO UPDATE SET
                    deadline=excluded.deadline,
                    source=excluded.source,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, jcd, rno, deadline,
                "racelist-basic-atomic"
            ))

            con.execute("""
                INSERT INTO basic_data_state(
                    date,jcd,rno,logic_version,status,last_error,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno,logic_version)
                DO UPDATE SET
                    status=excluded.status,
                    last_error=NULL,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, jcd, rno, logic_version,
                "complete", None
            ))

            con.commit()

    def mark_basic_error(
        self,
        date: str,
        jcd: str,
        rno: int,
        logic_version: str,
        error: str,
    ):
        with self.connect() as con:
            con.execute("""
                INSERT INTO basic_data_state(
                    date,jcd,rno,logic_version,status,last_error,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd,rno,logic_version)
                DO UPDATE SET
                    status='error',
                    last_error=excluded.last_error,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, str(jcd).zfill(2), int(rno),
                logic_version, "error", str(error)[:1000]
            ))
            con.commit()

    def get_basic_complete_keys(self, date: str, logic_version: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno
                FROM basic_data_state
                WHERE date=? AND logic_version=? AND status='complete'
            """, (date, logic_version)).fetchall()

        return {
            (str(row["jcd"]).zfill(2), int(row["rno"]))
            for row in rows
        }

    def get_verified_basic_complete_keys(self, date: str, logic_version: str):
        """Return only completion markers backed by a valid saved racelist.

        ZIP rollbacks intentionally keep the shared database.  A previous
        process may therefore leave a stale ``complete`` marker behind.  Do
        not let that marker hide a missing or partial six-boat racelist.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT b.jcd,b.rno,s.payload,r.deadline
                FROM basic_data_state AS b
                LEFT JOIN race_snapshots AS s
                  ON s.date=b.date AND s.jcd=b.jcd AND s.rno=b.rno
                 AND s.kind='racelist'
                LEFT JOIN race_schedule AS r
                  ON r.date=b.date AND r.jcd=b.jcd AND r.rno=b.rno
                WHERE b.date=? AND b.logic_version=? AND b.status='complete'
            """, (date, logic_version)).fetchall()

        verified = set()
        for row in rows:
            try:
                payload = json.loads(row["payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            racers = payload.get("racers") or []
            saved_deadline = payload.get("deadline")
            schedule_deadline = row["deadline"]
            if (
                len(racers) == 6
                and schedule_deadline
                and str(saved_deadline) == str(schedule_deadline)
            ):
                verified.add((str(row["jcd"]).zfill(2), int(row["rno"])))
        return verified

    def basic_progress(self, date: str, logic_version: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT status, COUNT(*) AS cnt
                FROM basic_data_state
                WHERE date=? AND logic_version=?
                GROUP BY status
            """, (date, logic_version)).fetchall()

        result = {"complete": 0, "error": 0}
        for row in rows:
            result[row["status"]] = int(row["cnt"])
        return result

    def verify_basic_race(
        self,
        date: str,
        jcd: str,
        rno: int,
        expected_deadline: str,
        logic_version: str,
    ):
        jcd = str(jcd).zfill(2)
        rno = int(rno)

        with self.connect() as con:
            snap = con.execute("""
                SELECT payload
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind='racelist'
            """, (date, jcd, rno)).fetchone()

            sched = con.execute("""
                SELECT deadline
                FROM race_schedule
                WHERE date=? AND jcd=? AND rno=?
            """, (date, jcd, rno)).fetchone()

            state = con.execute("""
                SELECT status
                FROM basic_data_state
                WHERE date=? AND jcd=? AND rno=? AND logic_version=?
            """, (date, jcd, rno, logic_version)).fetchone()

        if not snap or not sched or not state:
            return False

        try:
            data = json.loads(snap["payload"])
        except Exception:
            return False

        racers = data.get("racers") or []

        return (
            len(racers) == 6
            and str(sched["deadline"]) == str(expected_deadline)
            and state["status"] == "complete"
        )

    def save_snapshot(self, date: str, jcd: str, rno: int, kind: str, data: Any):
        payload = json.dumps(data, ensure_ascii=False)
        with self.connect() as con:
            con.execute("""
                INSERT INTO race_snapshots(date,jcd,rno,kind,payload)
                VALUES(?,?,?,?,?)
                ON CONFLICT(date,jcd,rno,kind)
                DO UPDATE SET payload=excluded.payload, captured_at=CURRENT_TIMESTAMP
            """, (date,jcd,rno,kind,payload))

    def save_monthly_official_racer_data(self, date: str, racers: list[dict]):
        """Keep one official stat snapshot per racer per calendar month."""
        month = str(date)[:6]
        with self.connect() as con:
            for racer in racers or []:
                reg = str(racer.get("registration_no") or "")
                name = str(racer.get("name") or "")
                if not reg or not name:
                    continue
                payload = {
                    "registration_no": reg, "name": name, "class": racer.get("class"),
                    "branch": racer.get("branch"), "origin": racer.get("origin"),
                    "age": racer.get("age"), "weight_kg": racer.get("weight_kg"),
                    "avg_st": racer.get("avg_st"), "f": racer.get("f"), "l": racer.get("l"),
                    "national": racer.get("national"), "local": racer.get("local"),
                }
                con.execute("""
                    INSERT INTO racer_official_monthly(registration_no,month,name,payload)
                    VALUES(?,?,?,?) ON CONFLICT(registration_no,month) DO NOTHING
                """, (reg, month, name, json.dumps(payload, ensure_ascii=False)))
            cutoff = (datetime.now() - timedelta(days=365)).strftime("%Y%m")
            con.execute("DELETE FROM racer_official_monthly WHERE month<?", (cutoff,))

    def daily_official_racer_targets(self, date: str):
        """Today's unique official registrations, from saved racelists only."""
        expected = {}
        with self.connect() as con:
            rows = con.execute("SELECT payload FROM race_snapshots WHERE date=? AND kind='racelist'", (date,)).fetchall()
            for row in rows:
                try:
                    racers = json.loads(row["payload"] or "{}").get("racers") or []
                except (TypeError, json.JSONDecodeError):
                    racers = []
                for racer in racers:
                    reg, name = str(racer.get("registration_no") or ""), str(racer.get("name") or "")
                    if reg and name:
                        expected[reg] = name
            for reg, name in expected.items():
                con.execute("""
                    INSERT INTO daily_racer_official_collection(date,registration_no,name,status)
                    VALUES(?,?,?,'pending') ON CONFLICT(date,registration_no) DO NOTHING
                """, (date, reg, name))
        return [{"registration_no": reg, "name": name} for reg, name in expected.items()]

    def official_racer_backlog_dates(self, current_date: str, lookback_days: int = 7):
        """Return recent past dates that still contain unfinished racers.

        A failed request near midnight must not be abandoned merely because
        the daily collector rolled over to a new date.  Limit the scan to a
        short recent window so old historical failures cannot create an
        unlimited crawl.
        """
        try:
            current = datetime.strptime(str(current_date), "%Y%m%d")
        except ValueError:
            return []
        cutoff = (current - timedelta(days=max(1, int(lookback_days)))).strftime("%Y%m%d")
        with self.connect() as con:
            rows = con.execute("""
                SELECT DISTINCT date
                FROM daily_racer_official_collection
                WHERE date<? AND date>=? AND status!='complete'
                ORDER BY date DESC
            """, (str(current_date), cutoff)).fetchall()
        return [str(row["date"]) for row in rows]

    def official_racer_collection_pending(self, date: str):
        """Return only entrants whose official course data needs refreshing.

        A complete official six-course snapshot is reused for six calendar
        months.  When it expires, only that dynamic snapshot is deleted; the
        racer's stable profile remains.  The next daily appearance therefore
        naturally puts the racer back into the collection queue.
        """
        self.daily_official_racer_targets(date)
        with self.connect() as con:
            cutoff = _calendar_months_ago(datetime.utcnow(), 6)

            # The monthly table also contains light racelist snapshots.  Only
            # delete expired official course payloads; never delete profiles or
            # unrelated historical race data.
            stored = con.execute("""
                SELECT registration_no,month,payload,saved_at
                FROM racer_official_monthly
            """).fetchall()
            for row in stored:
                saved_at = _sqlite_datetime(row["saved_at"])
                if _official_course_payload(row["payload"]) and (not saved_at or saved_at <= cutoff):
                    con.execute("""
                        DELETE FROM racer_official_monthly
                        WHERE registration_no=? AND month=?
                    """, (row["registration_no"], row["month"]))

            # A racer with valid data collected less than six months ago is
            # complete for today without another request to the official site.
            daily = con.execute("""
                SELECT registration_no,status
                FROM daily_racer_official_collection WHERE date=?
            """, (date,)).fetchall()
            for target in daily:
                official_rows = con.execute("""
                    SELECT payload,saved_at
                    FROM racer_official_monthly
                    WHERE registration_no=? ORDER BY saved_at DESC
                """, (target["registration_no"],)).fetchall()
                valid = any(
                    _official_course_payload(row["payload"])
                    and (_sqlite_datetime(row["saved_at"]) or datetime.min) > cutoff
                    for row in official_rows
                )
                if valid:
                    con.execute("""
                        UPDATE daily_racer_official_collection
                        SET status='complete',verified=1,last_error=NULL,
                            updated_at=CURRENT_TIMESTAMP
                        WHERE date=? AND registration_no=?
                    """, (date, target["registration_no"]))
                elif target["status"] in ("complete", "saved"):
                    con.execute("""
                        UPDATE daily_racer_official_collection
                        SET status='pending',verified=0,last_error=NULL,
                            updated_at=CURRENT_TIMESTAMP
                        WHERE date=? AND registration_no=?
                    """, (date, target["registration_no"]))

            # Transient HTTP failures and official-page variations are retried
            # after a cooldown.  A deployment can also stop the process after
            # a row was marked collecting; revive that stale state as well.
            con.execute("""
                UPDATE daily_racer_official_collection
                SET status='pending',last_error=NULL,updated_at=CURRENT_TIMESTAMP
                WHERE date=? AND status IN ('failed','collecting')
                  AND updated_at<=datetime('now','-15 minutes')
            """, (date,))
            rows = con.execute("""
                SELECT registration_no,name,status FROM daily_racer_official_collection
                WHERE date=? AND status='pending' ORDER BY registration_no
            """, (date,)).fetchall()
        return [dict(x) for x in rows]

    def mark_official_racer_collection(self, date: str, registration_no: str, *, status: str, error: str | None = None, verified: bool = False):
        with self.connect() as con:
            con.execute("""
                UPDATE daily_racer_official_collection
                SET status=?, last_error=?, verified=?, updated_at=CURRENT_TIMESTAMP
                WHERE date=? AND registration_no=?
            """, (status, error, 1 if verified else 0, date, str(registration_no)))

    def save_official_racer_search_data(self, date: str, data: dict):
        """Persist official racer-search course data for six-month reuse."""
        reg, name = str(data.get("registration_no") or ""), str(data.get("name") or "")
        if not reg or not name:
            raise ValueError("選手登録番号または氏名がありません")
        month = str(date)[:6]
        with self.connect() as con:
            profile = dict(data.get("profile") or {})
            profile.update({"registration_no": reg, "name": name, "last_seen_date": date})
            con.execute("""
                INSERT INTO tracked_racer_profiles(registration_no,name,active,last_seen_date,profile_json)
                VALUES(?,?,1,?,?) ON CONFLICT(registration_no) DO UPDATE SET
                  name=excluded.name,active=1,last_seen_date=excluded.last_seen_date,
                  profile_json=excluded.profile_json,updated_at=CURRENT_TIMESTAMP
            """, (reg, name, date, json.dumps(profile, ensure_ascii=False)))
            con.execute("""
                INSERT INTO racer_official_monthly(registration_no,month,name,payload)
                VALUES(?,?,?,?) ON CONFLICT(registration_no,month) DO UPDATE SET
                  name=excluded.name,payload=excluded.payload,saved_at=CURRENT_TIMESTAMP
            """, (reg, month, name, json.dumps(data, ensure_ascii=False)))

    def save_racer_profiles_from_racelist(self, date: str, racers: list[dict]):
        """Save stable official player information as soon as a racelist is read.

        Dynamic official figures are stored separately in the monthly table so
        opening a player page never has to wait for a result to be confirmed.
        """
        with self.connect() as con:
            for racer in racers or []:
                reg, name = str(racer.get("registration_no") or ""), str(racer.get("name") or "")
                if not reg or not name:
                    continue
                profile = {
                    "name": name, "registration_no": reg, "class": racer.get("class"),
                    "branch": racer.get("branch"), "origin": racer.get("origin"),
                    "age": racer.get("age"), "weight_kg": racer.get("weight_kg"),
                    "last_seen_date": date,
                }
                con.execute("""
                    INSERT INTO tracked_racer_profiles(registration_no,name,active,last_seen_date,profile_json)
                    VALUES(?,?,1,?,?)
                    ON CONFLICT(registration_no) DO UPDATE SET
                      name=excluded.name,active=1,last_seen_date=excluded.last_seen_date,
                      profile_json=excluded.profile_json,updated_at=CURRENT_TIMESTAMP
                """, (reg, name, date, json.dumps(profile, ensure_ascii=False)))

    def get_daily_racer_collection_status(self, date: str):
        """Read-only progress for the day's already-saved racer records.

        This status never initiates another official request or verification
        pass; it only reports what the normal collection has saved.
        """
        month = str(date)[:6]
        expected = {}
        with self.connect() as con:
            snapshots = con.execute("SELECT payload FROM race_snapshots WHERE date=? AND kind='racelist'", (date,)).fetchall()
            for snap in snapshots:
                try:
                    racers = json.loads(snap["payload"] or "{}").get("racers") or []
                except (TypeError, json.JSONDecodeError):
                    racers = []
                for racer in racers:
                    reg, name = str(racer.get("registration_no") or ""), str(racer.get("name") or "")
                    if reg:
                        expected[reg] = name or expected.get(reg) or reg
            for reg, name in expected.items():
                con.execute("INSERT INTO daily_racer_official_collection(date,registration_no,name,status) VALUES(?,?,?,'pending') ON CONFLICT(date,registration_no) DO NOTHING", (date, reg, name))
            rows = con.execute("SELECT registration_no,name,status,verified,last_error FROM daily_racer_official_collection WHERE date=?", (date,)).fetchall()
        total = len(expected)
        reflected = sum(1 for x in rows if x["status"] in ("saved", "complete"))
        saved = reflected
        verified = sum(1 for x in rows if x["verified"])
        failed = sum(1 for x in rows if x["status"] == "failed")
        missing = [{"registration_no": x["registration_no"], "name": x["name"], "error": x["last_error"]} for x in rows if x["status"] != "complete"]
        if not total:
            phase, message = "出走表の反映待ち", "当日の出走表が保存されると、対象選手を自動で数えます。"
        elif any(x["status"] == "collecting" for x in rows):
            phase, message = "公式データを収集中", "公式レーサー検索からコース別成績を収集しています。"
        elif any(x["status"] == "pending" for x in rows):
            phase, message = "公式データを収集中", "出走予定選手を順に収集しています。"
        elif failed and not any(x["status"] in ("pending", "collecting") for x in rows):
            phase, message = "一部取得失敗", "保存済みの選手は完了です。未完了の選手は公式ページの取得失敗として表示します。"
        elif reflected < total:
            phase, message = "公式データを保存中", "選手ごとの公式コース別成績を反映・保存しています。"
        elif verified < total:
            phase, message = "保存内容を確認中", "反映・保存済みの選手数を一度だけ照合しています。"
        else:
            phase, message = "完了", "当日の出走予定選手の反映・保存・照合が完了しました。"
        return {"date": date, "phase": phase, "message": message, "total": total, "reflected": reflected, "saved": saved, "verified": verified, "failed": failed, "missing": missing[:30]}

    def save_results(self, date: str, jcd: str, rows: list[dict]):
        with self.connect() as con:
            for row in rows:
                payload = json.dumps(row, ensure_ascii=False)
                con.execute("""
                    INSERT INTO race_results(date,jcd,rno,trifecta,payout_yen,odds,kimarite,payload)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(date,jcd,rno)
                    DO UPDATE SET
                      trifecta=excluded.trifecta,
                      payout_yen=excluded.payout_yen,
                      odds=excluded.odds,
                      kimarite=excluded.kimarite,
                      payload=excluded.payload,
                      updated_at=CURRENT_TIMESTAMP
                """, (
                    date, jcd, row["rno"], row.get("trifecta"),
                    row.get("payout_yen"), row.get("odds"),
                    row.get("kimarite"), payload
                ))

    def sync_trial_racer_tracker(self, date: str, jcd: str, rows: list[dict]):
        """Save only the configured trial racer from already-fetched results.

        No additional broad crawl is triggered here.  The normal official
        race/result collector supplies the source data, then this method
        stores the selected racer's result when present.
        """
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            snap = con.execute("""
                SELECT payload FROM race_snapshots
                WHERE date=? AND jcd=? AND kind='racelist'
            """, (date, jcd)).fetchall()
            day_row = con.execute("""
                SELECT day_number FROM venue_meeting_day WHERE date=? AND jcd=?
            """, (date, jcd)).fetchone()
            meeting_day = day_row["day_number"] if day_row else None

            races = {}
            for row in snap:
                try:
                    race = json.loads(row["payload"] or "{}")
                except (TypeError, json.JSONDecodeError):
                    continue
                races[int(race.get("rno") or 0)] = race

            touched = set()
            for result in rows or []:
                rno = int(result.get("rno") or 0)
                race = races.get(rno) or {}
                racer_by_lane = {
                    int(x.get("lane") or 0): x for x in race.get("racers") or []
                }
                event = str(result.get("event_title") or race.get("event_title") or "").strip()
                meeting_id = f"{jcd}:{event}" if event else f"{jcd}:{date}"
                st_by_lane = {
                    int(x.get("lane") or 0): x.get("st_raw")
                    for x in result.get("start_courses") or []
                }
                for finisher in result.get("finishers") or []:
                    lane = int(finisher.get("lane") or 0)
                    racer = racer_by_lane.get(lane) or {}
                    reg = str(finisher.get("registration_no") or racer.get("registration_no") or "")
                    if not reg:
                        continue
                    name = str(finisher.get("name") or racer.get("name") or reg)
                    profile = {
                        "name": name,
                        "class": racer.get("class"),
                        "branch": racer.get("branch"),
                        "national": racer.get("national"),
                        "local": racer.get("local"),
                        "avg_st": racer.get("avg_st"),
                        "last_seen_date": date,
                    }
                    con.execute("""
                        INSERT INTO tracked_racer_profiles
                          (registration_no,name,active,last_seen_date,profile_json)
                        VALUES(?,?,1,?,?)
                        ON CONFLICT(registration_no) DO UPDATE SET
                          name=excluded.name,active=1,last_seen_date=excluded.last_seen_date,
                          profile_json=excluded.profile_json,updated_at=CURRENT_TIMESTAMP
                    """, (reg, name, date, json.dumps(profile, ensure_ascii=False)))
                    con.execute("""
                        INSERT INTO tracked_racer_results
                          (registration_no,meeting_id,date,jcd,meeting_day,rno,lane,course,finish,st_raw,source_url)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(registration_no,date,jcd,rno) DO UPDATE SET
                          meeting_id=excluded.meeting_id,meeting_day=excluded.meeting_day,
                          lane=excluded.lane,course=excluded.course,finish=excluded.finish,
                          st_raw=excluded.st_raw,source_url=excluded.source_url
                    """, (
                        reg, meeting_id, date, jcd, meeting_day, rno, lane,
                        finisher.get("course"), finisher.get("finish"),
                        finisher.get("st_raw") or st_by_lane.get(lane),
                        result.get("detail_source_url"),
                    ))
                    touched.add(reg)

            for reg in touched:
                self._compact_trial_racer_locked(con, reg)
            tracked = next(iter(touched), "4320")
        return self.get_trial_racer_tracker(tracked)

    def _compact_trial_racer_locked(self, con, registration_no: str):
        meetings = con.execute("""
            SELECT meeting_id,MAX(date) AS last_date FROM tracked_racer_results
            WHERE registration_no=? GROUP BY meeting_id ORDER BY last_date DESC
        """, (registration_no,)).fetchall()
        keep = {x["meeting_id"] for x in meetings[:3]}
        old = con.execute("""
            SELECT * FROM tracked_racer_results WHERE registration_no=?
        """, (registration_no,)).fetchall()
        for row in old:
            if row["meeting_id"] in keep or not row["course"] or not row["finish"]:
                continue
            month = str(row["date"])[:6]
            scopes = ("national", f"local:{row['jcd']}")
            for scope in scopes:
                con.execute("""
                    INSERT INTO tracked_racer_course_monthly
                      (registration_no,scope,month,course,starts,first_count,second_count,third_count)
                    VALUES(?,?,?,?,1,?,?,?)
                    ON CONFLICT(registration_no,scope,month,course) DO UPDATE SET
                      starts=starts+1,first_count=first_count+excluded.first_count,
                      second_count=second_count+excluded.second_count,
                      third_count=third_count+excluded.third_count
                """, (registration_no, scope, month, int(row["course"]),
                      1 if int(row["finish"]) == 1 else 0,
                      1 if int(row["finish"]) == 2 else 0,
                      1 if int(row["finish"]) == 3 else 0))
            con.execute("""
                DELETE FROM tracked_racer_results
                WHERE registration_no=? AND date=? AND jcd=? AND rno=?
            """, (registration_no, row["date"], row["jcd"], row["rno"]))

        cutoff = (datetime.now() - timedelta(days=365)).strftime("%Y%m%d")
        con.execute("DELETE FROM tracked_racer_results WHERE registration_no=? AND date<?", (registration_no, cutoff))
        con.execute("DELETE FROM tracked_racer_course_monthly WHERE registration_no=? AND month<?", (registration_no, cutoff[:6]))

    def get_trial_racer_tracker(self, registration_no: str = "4320"):
        registration_no = str(registration_no)
        with self.connect() as con:
            profile = con.execute("SELECT * FROM tracked_racer_profiles WHERE registration_no=?", (registration_no,)).fetchone()
            detail = con.execute("""
                SELECT * FROM tracked_racer_results WHERE registration_no=?
                ORDER BY date DESC,jcd,rno DESC
            """, (registration_no,)).fetchall()
            monthly = con.execute("""
                SELECT * FROM tracked_racer_course_monthly WHERE registration_no=?
                ORDER BY scope,month,course
            """, (registration_no,)).fetchall()
        return {
            "registration_no": registration_no,
            "profile": ({**dict(profile), "profile_json": json.loads(profile["profile_json"] or "{}")}
                        if profile else {"name": TRACKED_RACERS.get(registration_no), "active": True}),
            "recent_meetings": [dict(x) for x in detail],
            "monthly_aggregates": [dict(x) for x in monthly],
            "retention": {"recent_meetings": 3, "rolling_days": 365, "monthly_cleanup": True},
        }

    def get_racer_public_data(self, registration_no: str):
        """Player page data: profile, latest three meetings and 6m/1y stats."""
        base = self.get_trial_racer_tracker(registration_no)
        now = datetime.now()
        windows = {"six_months": now - timedelta(days=183), "one_year": now - timedelta(days=365)}
        details = base["recent_meetings"]
        monthly = base["monthly_aggregates"]
        out = {}
        for key, cutoff in windows.items():
            cutoff_date = cutoff.strftime("%Y%m%d")
            counts = {scope: {course: [0, 0, 0, 0] for course in range(1, 7)} for scope in ("national",)}
            for row in details:
                if row["date"] < cutoff_date or not row["course"] or not row["finish"]:
                    continue
                c = counts["national"][int(row["course"])]
                c[0] += 1
                if int(row["finish"]) <= 3:
                    c[int(row["finish"])] += 1
            for row in monthly:
                if row["month"] < cutoff_date[:6] or row["scope"] != "national":
                    continue
                c = counts["national"][int(row["course"])]
                c[0] += row["starts"]; c[1] += row["first_count"]; c[2] += row["second_count"]; c[3] += row["third_count"]
            by_course = []
            for course, c in counts["national"].items():
                starts, first, second, third = c
                by_course.append({"course": course, "starts": starts, "first": first, "second": second, "third": third,
                                  "trio_rate": round((first + second + third) / starts * 100, 1) if starts else None})
            earliest = min([x["date"] for x in details] + [x["month"] + "01" for x in monthly] or [now.strftime("%Y%m%d")])
            out[key] = {"published": earliest <= cutoff_date, "courses": by_course}
        official = None
        cutoff = _calendar_months_ago(datetime.utcnow(), 6)
        with self.connect() as con:
            official_rows = con.execute("""
                SELECT month,payload,saved_at FROM racer_official_monthly
                WHERE registration_no=? ORDER BY saved_at DESC
            """, (str(registration_no),)).fetchall()
        for row in official_rows:
            payload = _official_course_payload(row["payload"])
            saved_at = _sqlite_datetime(row["saved_at"])
            if payload and saved_at and saved_at > cutoff:
                official = {"month": row["month"], "saved_at": row["saved_at"], "data": payload}
                break
        base["official_data"] = official
        base["course_rates"] = out
        return base

    def result_history(self, jcd: str, limit: int = 100):
        with self.connect() as con:
            rows = con.execute("""
                SELECT * FROM race_results
                WHERE jcd=?
                ORDER BY date DESC, rno DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def get_today_venue_tendency(self, date: str, jcd: str, before_rno: int):
        """Summarise only confirmed earlier races at this venue on this day.

        Restricting the query to ``rno < before_rno`` prevents a result from
        leaking into its own prediction while allowing later races to react to
        an unusual same-day course/frame pattern.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT rno,trifecta FROM race_results
                WHERE date=? AND jcd=? AND rno<? AND trifecta IS NOT NULL
                ORDER BY rno
            """, (str(date), str(jcd).zfill(2), int(before_rno))).fetchall()
        first = {lane: 0 for lane in range(1, 7)}
        top3 = {lane: 0 for lane in range(1, 7)}
        used = []
        for row in rows:
            lanes = [int(x) for x in re.findall(r"[1-6]", str(row["trifecta"] or ""))]
            if len(lanes) != 3 or len(set(lanes)) != 3:
                continue
            first[lanes[0]] += 1
            for lane in lanes:
                top3[lane] += 1
            used.append({"rno": int(row["rno"]), "trifecta": "-".join(map(str, lanes))})
        total = len(used)
        return {
            "completed_races": total,
            "results": used,
            "lanes": {
                lane: {
                    "first_count": first[lane],
                    "top3_count": top3[lane],
                    "first_rate": round(first[lane] / total * 100, 1) if total else None,
                    "top3_rate": round(top3[lane] / total * 100, 1) if total else None,
                }
                for lane in range(1, 7)
            },
            "source": "same-day-confirmed-results-before-target-race",
        }

    def save_prediction(self, date: str, jcd: str, rno: int, data: dict):
        with self.connect() as con:
            con.execute("""
                INSERT INTO predictions(
                    date,jcd,rno,confidence,judgement,scenario,
                    main_picks,value_picks,leaks,source_snapshot,ai_comment
                )
                VALUES(?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(date,jcd,rno)
                DO UPDATE SET
                    created_at=CURRENT_TIMESTAMP,
                    confidence=excluded.confidence,
                    judgement=excluded.judgement,
                    scenario=excluded.scenario,
                    main_picks=excluded.main_picks,
                    value_picks=excluded.value_picks,
                    leaks=excluded.leaks,
                    source_snapshot=excluded.source_snapshot,
                    ai_comment=excluded.ai_comment
            """, (
                date, jcd, rno,
                data.get("confidence"),
                data.get("judgement"),
                data.get("scenario"),
                json.dumps(data.get("main_picks", []), ensure_ascii=False),
                json.dumps(data.get("value_picks", []), ensure_ascii=False),
                json.dumps(data.get("leaks", []), ensure_ascii=False),
                json.dumps(data.get("source_snapshot", {}), ensure_ascii=False),
                data.get("ai_comment"),
            ))

    def get_prediction(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            row = con.execute("""
                SELECT * FROM predictions
                WHERE date=? AND jcd=? AND rno=?
            """, (date,jcd,rno)).fetchone()
        if not row:
            return None
        d = dict(row)
        for k in ["main_picks","value_picks","leaks","source_snapshot"]:
            try:
                d[k] = json.loads(d[k]) if d.get(k) else ([] if k != "source_snapshot" else {})
            except Exception:
                pass
        return d

    def update_prediction_final_odds(self, date: str, jcd: str, rno: int, data: dict):
        """Update post-deadline odds JSON without changing prediction timestamp."""
        with self.connect() as con:
            con.execute("""
                UPDATE predictions
                   SET main_picks=?,value_picks=?,source_snapshot=?
                 WHERE date=? AND jcd=? AND rno=?
            """, (
                json.dumps(data.get("main_picks", []), ensure_ascii=False),
                json.dumps(data.get("value_picks", []), ensure_ascii=False),
                json.dumps(data.get("source_snapshot", {}), ensure_ascii=False),
                date, str(jcd).zfill(2), int(rno),
            ))

    def save_user_insight(self, date: str, jcd: str, rno: int, note: str):
        note = str(note or "").strip()[:2000]
        with self.connect() as con:
            con.execute("""
                INSERT INTO user_race_insights(date,jcd,rno,note)
                VALUES(?,?,?,?)
                ON CONFLICT(date,jcd,rno)
                DO UPDATE SET note=excluded.note,updated_at=CURRENT_TIMESTAMP
            """, (date, str(jcd).zfill(2), int(rno), note))
        return self.get_user_insight(date, jcd, rno)

    def get_user_insight(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            row = con.execute("""
                SELECT date,jcd,rno,note,updated_at
                FROM user_race_insights
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), int(rno))).fetchone()
        return dict(row) if row else {
            "date": date, "jcd": str(jcd).zfill(2), "rno": int(rno),
            "note": "", "updated_at": None,
        }

    def save_comments(self, date: str, jcd: str, rno: int, comments: list[dict]):
        with self.connect() as con:
            for c in comments:
                con.execute("""
                    INSERT INTO racer_comments(date,jcd,rno,lane,comment,source)
                    VALUES(?,?,?,?,?,?)
                    ON CONFLICT(date,jcd,rno,lane)
                    DO UPDATE SET
                      comment=excluded.comment,
                      source=excluded.source,
                      saved_at=CURRENT_TIMESTAMP
                """, (date,jcd,rno,c["lane"],c["comment"],c.get("source")))

    def get_comments(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            rows = con.execute("""
                SELECT lane,comment,source,saved_at
                FROM racer_comments
                WHERE date=? AND jcd=? AND rno=?
                ORDER BY lane
            """,(date,jcd,rno)).fetchall()
        return [dict(x) for x in rows]

    def compare_prediction(self, date: str, jcd: str, rno: int):
        pred = self.get_prediction(date,jcd,rno)
        with self.connect() as con:
            res = con.execute("""
                SELECT * FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """,(date,jcd,rno)).fetchone()

        if not pred or not res:
            return {
                "prediction": pred,
                "result": dict(res) if res else None,
                "comparison": None
            }

        result = dict(res)
        actual = result.get("trifecta")
        main = pred.get("main_picks") or []
        value = pred.get("value_picks") or []
        all_picks = [x.get("combo") if isinstance(x,dict) else x for x in (main + value)]

        hit = actual in all_picks if actual else False

        expected_first = None
        if all_picks:
            try:
                firsts = [str(x).split("-")[0] for x in all_picks if x]
                expected_first = max(set(firsts), key=firsts.count) if firsts else None
            except Exception:
                expected_first = None

        actual_first = str(actual).split("-")[0] if actual else None
        first_match = expected_first == actual_first if expected_first and actual_first else None

        return {
            "prediction": pred,
            "result": result,
            "comparison": {
                "hit": hit,
                "expected_first": expected_first,
                "actual_first": actual_first,
                "first_match": first_match,
                "kimarite": result.get("kimarite")
            }
        }



    def get_snapshot(self, date: str, jcd: str, rno: int, kind: str):
        with self.connect() as con:
            row = con.execute("""
                SELECT payload,captured_at
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=? AND kind=?
            """,(date,jcd,rno,kind)).fetchone()
        if not row:
            return None
        try:
            return {
                "data": json.loads(row["payload"]),
                "captured_at": row["captured_at"]
            }
        except Exception:
            return None


    def get_day_snapshots(self, date: str, kind: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,payload,captured_at
                FROM race_snapshots
                WHERE date=? AND kind=?
                ORDER BY jcd,rno
            """,(date,kind)).fetchall()

        out = []
        for row in rows:
            try:
                payload = json.loads(row["payload"])
            except Exception:
                continue
            out.append({
                "jcd": row["jcd"],
                "rno": row["rno"],
                "captured_at": row["captured_at"],
                "data": payload,
            })
        return out

    def get_local_frame_stats(self, before_date: str, jcd: str, racers: list[dict]):
        """Build racer x venue x frame history from already saved official races.

        Only races before ``before_date`` are used, so a prediction can never
        learn from its own day or a future result.  The trifecta identifies the
        top three boat numbers; the saved racelist supplies registration number
        and frame.
        """
        wanted = {
            (str(x.get("registration_no") or ""), int(x.get("lane") or 0))
            for x in (racers or [])
            if x.get("registration_no") and 1 <= int(x.get("lane") or 0) <= 6
        }
        if not wanted:
            return {}

        with self.connect() as con:
            rows = con.execute("""
                SELECT s.date,s.payload,rr.trifecta
                FROM race_snapshots s
                JOIN race_results rr
                  ON rr.date=s.date AND rr.jcd=s.jcd AND rr.rno=s.rno
                WHERE s.kind='racelist' AND s.jcd=? AND s.date<?
                  AND rr.trifecta IS NOT NULL
                ORDER BY s.date,s.rno
            """, (str(jcd).zfill(2), before_date)).fetchall()

        counts = {
            key: {"starts": 0, "first": 0, "second": 0, "third": 0,
                  "from_date": None, "to_date": None}
            for key in wanted
        }
        for row in rows:
            try:
                data = json.loads(row["payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            top = [x for x in str(row["trifecta"] or "").replace(" ", "").split("-") if x in "123456"]
            if len(top) != 3 or len(set(top)) != 3:
                continue
            positions = {int(lane): pos + 1 for pos, lane in enumerate(top)}
            for racer in data.get("racers") or []:
                reg = str(racer.get("registration_no") or "")
                try:
                    lane = int(racer.get("lane") or 0)
                except (TypeError, ValueError):
                    # Older saved snapshots may contain the official marker
                    # "欠"/"欠場" in this field.  Keep the snapshot intact,
                    # but do not let one non-racing row abort all AI reads.
                    continue
                key = (reg, lane)
                if key not in counts or racer.get("scratched"):
                    continue
                item = counts[key]
                item["starts"] += 1
                pos = positions.get(lane)
                if pos == 1:
                    item["first"] += 1
                elif pos == 2:
                    item["second"] += 1
                elif pos == 3:
                    item["third"] += 1
                item["from_date"] = item["from_date"] or row["date"]
                item["to_date"] = row["date"]

        out = {}
        for (reg, lane), item in counts.items():
            starts = item["starts"]
            if not starts:
                continue
            out[(reg, lane)] = {
                **item,
                "frame": lane,
                "win_rate": round(item["first"] / starts * 100, 1),
                "quinella_rate": round((item["first"] + item["second"]) / starts * 100, 1),
                "trio_rate": round((item["first"] + item["second"] + item["third"]) / starts * 100, 1),
                "source": "saved-official-racelist-and-results",
            }
        return out

    def get_racer_course_stats(self, before_date: str, racers: list[dict]):
        """Return per-racer results by actual entry course from saved official results.

        This deliberately uses only result-detail records captured before the
        target day.  It never fabricates a course from the boat frame, and it
        cannot leak a result from the race being predicted into the score.
        """
        wanted = {
            str(x.get("registration_no") or "")
            for x in (racers or []) if x.get("registration_no")
        }
        if not wanted:
            return {}

        with self.connect() as con:
            rows = con.execute("""
                SELECT s.date,s.payload,rr.payload AS result_payload
                FROM race_snapshots s
                JOIN race_results rr
                  ON rr.date=s.date AND rr.jcd=s.jcd AND rr.rno=s.rno
                WHERE s.kind='racelist' AND s.date<? AND rr.payload IS NOT NULL
                ORDER BY s.date,s.jcd,s.rno
            """, (before_date,)).fetchall()

        counts = {
            reg: {course: {"starts": 0, "first": 0, "second": 0,
                           "third": 0, "from_date": None, "to_date": None}
                  for course in range(1, 7)}
            for reg in wanted
        }
        for row in rows:
            try:
                result = json.loads(row["result_payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            for finisher in result.get("finishers") or []:
                reg = str(finisher.get("registration_no") or "")
                course = int(finisher.get("course") or 0)
                finish = int(finisher.get("finish") or 0)
                if reg not in counts or not (1 <= course <= 6) or not (1 <= finish <= 6):
                    continue
                item = counts[reg][course]
                item["starts"] += 1
                if finish == 1:
                    item["first"] += 1
                elif finish == 2:
                    item["second"] += 1
                elif finish == 3:
                    item["third"] += 1
                item["from_date"] = item["from_date"] or row["date"]
                item["to_date"] = row["date"]

        out = {}
        for reg, by_course in counts.items():
            shaped = {}
            for course, item in by_course.items():
                starts = item["starts"]
                if not starts:
                    continue
                shaped[course] = {
                    **item,
                    "course": course,
                    "win_rate": round(item["first"] / starts * 100, 1),
                    "quinella_rate": round((item["first"] + item["second"]) / starts * 100, 1),
                    "trio_rate": round((item["first"] + item["second"] + item["third"]) / starts * 100, 1),
                    "source": "saved-official-result-details",
                }
            if shaped:
                out[reg] = shaped
        return out

    def get_tilt_outcome_stats(self, before_date: str):
        """Learn finishing rates for 3-degree tilt from saved official races.

        Only races before ``before_date`` are used, so the race being predicted
        and the rest of its day can never leak into the model.  Rates are kept
        by actual boat lane and also as an all-lane total.  The predictor still
        applies sample-size shrinkage because 3-degree starts are uncommon.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT b.payload AS before_payload,rr.payload AS result_payload
                FROM race_snapshots b
                JOIN race_results rr
                  ON rr.date=b.date AND rr.jcd=b.jcd AND rr.rno=b.rno
                WHERE b.kind='beforeinfo' AND b.date<?
                  AND rr.payload IS NOT NULL
                ORDER BY b.date,b.jcd,b.rno
            """, (before_date,)).fetchall()

        def blank():
            return {"starts": 0, "first": 0, "second": 0, "third": 0}

        counts = {
            "high": {lane: blank() for lane in range(1, 7)},
            "other": {lane: blank() for lane in range(1, 7)},
        }
        for row in rows:
            try:
                before = json.loads(row["before_payload"] or "{}")
                result = json.loads(row["result_payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            finish_by_lane = {
                int(x.get("lane") or 0): int(x.get("finish") or 0)
                for x in (result.get("finishers") or [])
                if str(x.get("lane") or "").isdigit()
                and str(x.get("finish") or "").isdigit()
            }
            for racer in before.get("racers") or []:
                try:
                    lane = int(racer.get("lane") or 0)
                    tilt = float(racer.get("tilt"))
                except (TypeError, ValueError):
                    continue
                finish = finish_by_lane.get(lane)
                if not (1 <= lane <= 6 and finish and 1 <= finish <= 6):
                    continue
                bucket = counts["high" if tilt >= 2.5 else "other"][lane]
                bucket["starts"] += 1
                if finish == 1:
                    bucket["first"] += 1
                elif finish == 2:
                    bucket["second"] += 1
                elif finish == 3:
                    bucket["third"] += 1

        def shape(item):
            n = item["starts"]
            return {
                **item,
                "first_rate": round(item["first"] / n * 100, 1) if n else None,
                "quinella_rate": round((item["first"] + item["second"]) / n * 100, 1) if n else None,
                "trio_rate": round((item["first"] + item["second"] + item["third"]) / n * 100, 1) if n else None,
            }

        by_lane = {
            lane: {name: shape(counts[name][lane]) for name in ("high", "other")}
            for lane in range(1, 7)
        }
        return {
            "by_lane": by_lane,
            "sample_minimum": 5,
            "source": "saved-official-beforeinfo-and-results-before-target-day",
        }

    def get_local_frame_history(self, before_date: str, jcd: str, racers: list[dict], limit: int = 10):
        """Last local starts for each racer in the same frame as today's race."""
        targets = {
            (str(x.get("registration_no") or ""), int(x.get("lane") or 0)): {
                "lane": int(x.get("lane") or 0),
                "registration_no": str(x.get("registration_no") or ""),
                "name": x.get("name"),
                "history": [],
            }
            for x in (racers or []) if x.get("registration_no")
        }
        if not targets:
            return {"racers": [], "missing_details": []}
        with self.connect() as con:
            rows = con.execute("""
                SELECT s.date,s.rno,s.payload,rr.trifecta,rr.payload AS result_payload
                FROM race_snapshots s JOIN race_results rr
                  ON rr.date=s.date AND rr.jcd=s.jcd AND rr.rno=s.rno
                WHERE s.kind='racelist' AND s.jcd=? AND s.date<?
                  AND rr.trifecta IS NOT NULL
                ORDER BY s.date DESC,s.rno DESC
            """, (str(jcd).zfill(2), before_date)).fetchall()
        missing = set()
        for row in rows:
            try:
                race = json.loads(row["payload"] or "{}")
                result = json.loads(row["result_payload"] or "{}")
            except (TypeError, json.JSONDecodeError):
                continue
            finishers = result.get("finishers") or []
            by_reg = {str(x.get("registration_no") or ""): x for x in finishers}
            by_lane = {int(x.get("lane") or 0): x for x in finishers}
            top = [int(x) for x in str(row["trifecta"] or "").split("-") if x.isdigit()]
            for old in race.get("racers") or []:
                key = (str(old.get("registration_no") or ""), int(old.get("lane") or 0))
                target = targets.get(key)
                if not target or len(target["history"]) >= limit or old.get("scratched"):
                    continue
                found = by_reg.get(key[0]) or by_lane.get(key[1])
                if found:
                    finish = found.get("finish")
                    course = found.get("course")
                    if course is None or finish is None:
                        missing.add((row["date"], int(row["rno"])))
                else:
                    finish = top.index(key[1]) + 1 if key[1] in top else None
                    course = None
                    missing.add((row["date"], int(row["rno"])))
                target["history"].append({
                    "date": row["date"], "rno": int(row["rno"]),
                    "frame": key[1], "course": course, "finish": finish,
                    "detail_complete": bool(found and course is not None and finish is not None),
                })
        return {
            "racers": [targets[k] for k in sorted(targets, key=lambda x: x[1])],
            "missing_details": [
                {"date": date, "jcd": str(jcd).zfill(2), "rno": rno}
                for date, rno in sorted(missing, reverse=True)
            ],
        }







    def get_result_for_race_db(self, date: str, jcd: str, rno: int):
        with self.connect() as con:
            row = con.execute("""
                SELECT trifecta,payout_yen,odds,kimarite,payload,updated_at
                FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), int(rno))).fetchone()

        if not row:
            return None

        try:
            payload = json.loads(row["payload"]) if row["payload"] else {}
        except Exception:
            payload = {}

        return {
            **payload,
            "trifecta": row["trifecta"],
            "payout_yen": row["payout_yen"],
            "odds": row["odds"],
            "kimarite": row["kimarite"],
            "updated_at": row["updated_at"],
        }

    def get_result_complete_keys(self, date: str):
        return self.get_confirmed_result_races(date)

    def get_confirmed_result_races(self, date: str):
        """
        Return {(jcd, rno)} for races whose final result is already persisted.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,trifecta,payout_yen,payload
                FROM race_results WHERE date=?
            """, (date,)).fetchall()

        complete = set()
        for row in rows:
            final = row["trifecta"] is not None and row["payout_yen"] is not None
            if not final:
                try: final = bool(json.loads(row["payload"] or "{}").get("result_confirmed"))
                except (TypeError, json.JSONDecodeError): final = False
            if final: complete.add((str(row["jcd"]).zfill(2), int(row["rno"])))
        return complete

    def save_meeting_day(
        self,
        date: str,
        jcd: str,
        day_number: int | None,
        day_label: str | None,
        official_label: str | None = None,
        source: str = "official",
    ):
        with self.connect() as con:
            con.execute("""
                INSERT INTO venue_meeting_day(
                    date,jcd,day_number,day_label,official_label,source,updated_at
                )
                VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd) DO UPDATE SET
                    day_number=excluded.day_number,
                    day_label=excluded.day_label,
                    official_label=excluded.official_label,
                    source=excluded.source,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                date, str(jcd).zfill(2),
                day_number, day_label, official_label, source
            ))
            con.commit()

    def get_day_meeting_days(self, date: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,day_number,day_label,official_label,source
                FROM venue_meeting_day
                WHERE date=?
            """, (date,)).fetchall()

        return {
            str(row["jcd"]).zfill(2): {
                "number": row["day_number"],
                "label": row["day_label"],
                "official_label": row["official_label"],
                "source": row["source"],
            }
            for row in rows
        }

    def save_venue_event_meta(self, date: str, jcd: str, grade: str | None,
                              title: str | None, source: str = "official-racelist"):
        """Persist grade metadata under the exact date + venue code pair."""
        allowed = {"一般戦", "G3", "G2", "G1", "PG1", "SG"}
        if grade not in allowed:
            return False
        with self.connect() as con:
            con.execute("""
                INSERT INTO venue_event_meta(date,jcd,event_grade,event_title,source,updated_at)
                VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date,jcd) DO UPDATE SET
                    event_grade=CASE
                        WHEN venue_event_meta.event_grade<>'一般戦'
                         AND excluded.event_grade='一般戦'
                        THEN venue_event_meta.event_grade
                        ELSE excluded.event_grade END,
                    event_title=CASE
                        WHEN venue_event_meta.event_grade<>'一般戦'
                         AND excluded.event_grade='一般戦'
                        THEN venue_event_meta.event_title
                        ELSE COALESCE(excluded.event_title,venue_event_meta.event_title) END,
                    source=CASE
                        WHEN venue_event_meta.event_grade<>'一般戦'
                         AND excluded.event_grade='一般戦'
                        THEN venue_event_meta.source
                        ELSE excluded.source END,
                    updated_at=CURRENT_TIMESTAMP
            """, (date, str(jcd).zfill(2), grade, title, source))
        return True

    def get_day_venue_event_meta(self, date: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,event_grade,event_title,source,updated_at
                FROM venue_event_meta WHERE date=?
            """, (date,)).fetchall()
        return {
            str(row["jcd"]).zfill(2): {
                "event_grade": row["event_grade"],
                "event_title": row["event_title"],
                "grade_source": row["source"],
                "grade_updated_at": row["updated_at"],
            }
            for row in rows
        }

    def save_race_schedule(self, date: str, jcd: str, races: list[dict], source: str = "official"):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            for race in races:
                rno = int(race["rno"])
                deadline = race.get("deadline")
                if not deadline:
                    continue
                con.execute("""
                    INSERT INTO race_schedule(date,jcd,rno,deadline,source,updated_at)
                    VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                    ON CONFLICT(date,jcd,rno) DO UPDATE SET
                        deadline=excluded.deadline,
                        source=excluded.source,
                        updated_at=CURRENT_TIMESTAMP
                """, (date, jcd, rno, deadline, source))
            con.commit()

    def get_race_schedule(self, date: str, jcd: str):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            rows = con.execute("""
                SELECT rno,deadline,source,updated_at
                FROM race_schedule
                WHERE date=? AND jcd=?
                ORDER BY rno
            """, (date, jcd)).fetchall()
        return [
            {
                "rno": int(row["rno"]),
                "deadline": row["deadline"],
                "source": row["source"],
                "updated_at": row["updated_at"],
            }
            for row in rows
        ]

    def get_venue_racelists(self, date: str, jcd: str):
        """Read one venue's saved racelists in a single SQLite query.

        The venue screen needs only the already-saved six-boat rows.  Returning
        them together avoids twelve parallel HTTP/SQLite reads and, importantly,
        does not discard the registration number used by the racer-photo UI.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT rno,payload,captured_at
                FROM race_snapshots
                WHERE date=? AND jcd=? AND kind='racelist'
                ORDER BY rno
            """, (date, str(jcd).zfill(2))).fetchall()
        races = []
        for row in rows:
            try:
                data = json.loads(row["payload"])
            except (TypeError, json.JSONDecodeError):
                continue
            races.append({
                "rno": int(row["rno"]),
                "race": data,
                "captured_at": row["captured_at"],
            })
        return races

    def get_day_schedule(self, date: str):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,deadline,source,updated_at
                FROM race_schedule
                WHERE date=?
                ORDER BY jcd,rno
            """, (date,)).fetchall()

        out = {}
        for row in rows:
            jcd = str(row["jcd"]).zfill(2)
            out.setdefault(jcd, []).append({
                "rno": int(row["rno"]),
                "deadline": row["deadline"],
                "source": row["source"],
                "updated_at": row["updated_at"],
            })
        return out

    def save_fixed_day_complete(self, date: str, venue_codes: list[str]):
        """Mark the day's fixed 0:00-08:00 data as fully stored."""
        codes = sorted({str(code).zfill(2) for code in venue_codes})
        with self.connect() as con:
            con.execute("""
                INSERT INTO daily_fixed_data_state(date,venue_codes,completed_at)
                VALUES(?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(date) DO UPDATE SET
                    venue_codes=excluded.venue_codes,
                    completed_at=CURRENT_TIMESTAMP
            """, (date, json.dumps(codes, ensure_ascii=False)))
            con.commit()

    def get_fixed_day_complete(self, date: str):
        with self.connect() as con:
            row = con.execute("""
                SELECT venue_codes,completed_at
                FROM daily_fixed_data_state
                WHERE date=?
            """, (date,)).fetchone()

        if not row:
            return None
        try:
            codes = [str(code).zfill(2) for code in json.loads(row["venue_codes"])]
        except Exception:
            return None
        return {"venue_codes": codes, "completed_at": row["completed_at"]}

    def get_racelist_presence(self, date: str):
        """
        Return {jcd: [rno,...]} for racelist snapshots already stored for date.
        Used only as a fallback for day/open-venue detection.
        """
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno
                FROM race_snapshots
                WHERE date=? AND kind='racelist'
                ORDER BY jcd,rno
            """, (date,)).fetchall()

        out = {}
        for row in rows:
            jcd = str(row["jcd"]).zfill(2)
            out.setdefault(jcd, []).append(int(row["rno"]))
        return out

    def get_race_revision(self, date: str, jcd: str, rno: int):
        """
        軽量な更新検知用。
        payload本体を返さず、各データの更新時刻だけ返す。
        """
        with self.connect() as con:
            snaps = con.execute("""
                SELECT kind,captured_at
                FROM race_snapshots
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), rno)).fetchall()

            result = con.execute("""
                SELECT updated_at
                FROM race_results
                WHERE date=? AND jcd=? AND rno=?
            """, (date, str(jcd).zfill(2), rno)).fetchone()

        out = {
            "racelist": None,
            "beforeinfo": None,
            "odds3t": None,
            "result": result["updated_at"] if result else None,
        }
        for row in snaps:
            if row["kind"] in out:
                out[row["kind"]] = row["captured_at"]

        out["token"] = "|".join([
            str(out["racelist"] or ""),
            str(out["beforeinfo"] or ""),
            str(out["odds3t"] or ""),
            str(out["result"] or ""),
        ])
        return out

    def get_snapshot_index(self, date: str, kind: str):
        """Return {(jcd, rno): captured_at} for one day/kind."""
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,rno,captured_at
                FROM race_snapshots
                WHERE date=? AND kind=?
            """, (date, kind)).fetchall()
        return {
            (str(row["jcd"]).zfill(2), int(row["rno"])): row["captured_at"]
            for row in rows
        }

    def prediction_summary(self, date: str | None = None):
        with self.connect() as con:
            if date:
                pred_rows = con.execute("""
                    SELECT date,jcd,rno FROM predictions WHERE date=?
                """,(date,)).fetchall()
            else:
                pred_rows = con.execute("""
                    SELECT date,jcd,rno FROM predictions
                """).fetchall()

            total = len(pred_rows)
            hit = 0

            for p in pred_rows:
                pred = self.get_prediction(p["date"], p["jcd"], p["rno"])
                res = con.execute("""
                    SELECT trifecta FROM race_results
                    WHERE date=? AND jcd=? AND rno=?
                """,(p["date"],p["jcd"],p["rno"])).fetchone()

                if not res or not res["trifecta"] or not pred:
                    continue

                picks = []
                for item in (pred.get("main_picks") or []) + (pred.get("value_picks") or []):
                    picks.append(item.get("combo") if isinstance(item,dict) else item)

                if res["trifecta"] in picks:
                    hit += 1

        return {
            "predictions": total,
            "hits": hit,
            "hit_rate": round(hit / total * 100, 1) if total else None,
        }


    def save_venue_knowledge(
        self, jcd, venue, source_url, source_kind,
        title="", content_text="", content_hash="", local_path=None
    ):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            con.execute("""
                INSERT INTO venue_knowledge(
                    jcd, venue, source_url, source_kind, title,
                    content_text, content_hash, local_path
                )
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(jcd, source_url)
                DO UPDATE SET
                    venue=excluded.venue,
                    source_kind=excluded.source_kind,
                    title=excluded.title,
                    content_text=excluded.content_text,
                    content_hash=excluded.content_hash,
                    local_path=excluded.local_path,
                    fetched_at=CURRENT_TIMESTAMP
            """, (
                jcd, venue, source_url, source_kind, title,
                content_text, content_hash, local_path
            ))
            con.commit()

    def get_venue_knowledge(self, jcd, limit=500):
        jcd = str(jcd).zfill(2)
        limit = min(max(int(limit), 1), 2000)
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,venue,source_url,source_kind,title,
                       content_hash,local_path,fetched_at,
                       length(content_text) AS text_length
                FROM venue_knowledge
                WHERE jcd=?
                ORDER BY fetched_at DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def get_venue_knowledge_text(self, jcd, limit=300):
        jcd = str(jcd).zfill(2)
        limit = min(max(int(limit), 1), 1000)
        with self.connect() as con:
            rows = con.execute("""
                SELECT source_url,source_kind,title,content_text,fetched_at
                FROM venue_knowledge
                WHERE jcd=? AND coalesce(content_text,'') <> ''
                ORDER BY
                  CASE source_kind
                    WHEN 'boatrace-official-stadium' THEN 0
                    WHEN 'venue-official-pdf' THEN 1
                    ELSE 2
                  END,
                  fetched_at DESC
                LIMIT ?
            """, (jcd, limit)).fetchall()
        return [dict(x) for x in rows]

    def is_venue_knowledge_complete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            row = con.execute("""
                SELECT status FROM venue_knowledge_state
                WHERE jcd=?
            """, (jcd,)).fetchone()
        return bool(row and row["status"] == "complete")

    def mark_venue_knowledge_complete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            count = con.execute("""
                SELECT count(*) AS n
                FROM venue_knowledge
                WHERE jcd=?
            """, (jcd,)).fetchone()["n"]

            con.execute("""
                INSERT INTO venue_knowledge_state(
                    jcd,status,completed_at,source_count
                )
                VALUES(?, 'complete', CURRENT_TIMESTAMP, ?)
                ON CONFLICT(jcd)
                DO UPDATE SET
                    status='complete',
                    completed_at=CURRENT_TIMESTAMP,
                    source_count=excluded.source_count
            """, (jcd, int(count or 0)))
            con.commit()
        return int(count or 0)

    def mark_venue_knowledge_incomplete(self, jcd):
        jcd = str(jcd).zfill(2)
        with self.connect() as con:
            count = con.execute("""
                SELECT count(*) AS n
                FROM venue_knowledge
                WHERE jcd=?
            """, (jcd,)).fetchone()["n"]
            con.execute("""
                INSERT INTO venue_knowledge_state(
                    jcd,status,completed_at,source_count
                )
                VALUES(?, 'incomplete', CURRENT_TIMESTAMP, ?)
                ON CONFLICT(jcd)
                DO UPDATE SET
                    status='incomplete',
                    completed_at=CURRENT_TIMESTAMP,
                    source_count=excluded.source_count
            """, (jcd, int(count or 0)))
            con.commit()

    def venue_knowledge_complete_codes(self):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd FROM venue_knowledge_state
                WHERE status='complete'
                ORDER BY jcd
            """).fetchall()
        return [str(x["jcd"]).zfill(2) for x in rows]

    def venue_knowledge_monitor(self):
        names = {
            "01":"桐生","02":"戸田","03":"江戸川","04":"平和島",
            "05":"多摩川","06":"浜名湖","07":"蒲郡","08":"常滑",
            "09":"津","10":"三国","11":"びわこ","12":"住之江",
            "13":"尼崎","14":"鳴門","15":"丸亀","16":"児島",
            "17":"宮島","18":"徳山","19":"下関","20":"若松",
            "21":"芦屋","22":"福岡","23":"唐津","24":"大村",
        }
        out=[]
        with self.connect() as con:
            states={
                str(r["jcd"]).zfill(2): dict(r)
                for r in con.execute(
                    "SELECT * FROM venue_knowledge_state"
                ).fetchall()
            }
            rows=con.execute("""
                SELECT jcd, source_kind, count(*) AS n,
                       sum(length(coalesce(content_text,''))) AS chars
                FROM venue_knowledge
                GROUP BY jcd, source_kind
            """).fetchall()

        by={}
        for r in rows:
            j=str(r["jcd"]).zfill(2)
            x=by.setdefault(j, {"kinds":{}, "sources":0, "chars":0})
            x["kinds"][r["source_kind"]]=int(r["n"] or 0)
            x["sources"]+=int(r["n"] or 0)
            x["chars"]+=int(r["chars"] or 0)

        for jcd in [f"{i:02d}" for i in range(1,25)]:
            x=by.get(jcd, {"kinds":{}, "sources":0, "chars":0})
            st=states.get(jcd,{})
            kinds=x["kinds"]
            official=sum(
                n for k,n in kinds.items()
                if k != "external-summary-fallback"
            )
            fallback=int(kinds.get("external-summary-fallback",0))
            complete=(st.get("status")=="complete")
            if complete:
                label="反映完了"
            elif fallback:
                label="外部資料で補完中"
            elif official:
                label="公式資料を解析中"
            else:
                label="未取得"
            out.append({
                "jcd":jcd, "venue":names[jcd],
                "status":st.get("status") or "pending",
                "label":label,
                "sources":x["sources"],
                "chars":x["chars"],
                "official_sources":official,
                "fallback_sources":fallback,
                "source_kinds":kinds,
            })
        return out

    def venue_knowledge_summary(self):
        with self.connect() as con:
            rows = con.execute("""
                SELECT jcd,
                       count(*) AS sources,
                       sum(CASE WHEN source_kind LIKE '%pdf%' OR
                                         source_kind LIKE '%file%'
                                THEN 1 ELSE 0 END) AS files,
                       max(fetched_at) AS last_fetched_at
                FROM venue_knowledge
                GROUP BY jcd
                ORDER BY jcd
            """).fetchall()
        return [dict(x) for x in rows]
