from __future__ import annotations

"""Nationwide/local actual-entry-course history collection.

Policy (v17.181)
----------------
* Historical backfill may access the official daily K download only from
  00:00 through 23:59 JST (all day).
* Only racers already seen by BOAT AI Lab whose historical scan is not complete
  are selected. Completed racers are never crawled again.
* One official daily file is downloaded at a time, filtered to those target
  racers, reflected into SQLite, then the persisted cursor moves backward.
* There is a 30-second pause after each successful/no-data day. A failed
  request is retried at most three times with a 60-second pause. After the
  third failure the nightly job stops and the affected racers are exposed as
  errors on the home screen. The same date is retried the next night.
* Historical backfill is allowed throughout the day (00:00-23:59 JST). The
  persisted cursor makes the scan restart-safe.
* During race hours this module performs NO historical web access. Confirmed
  live race results update the same table through BoatDB.save_results().
* Detailed rows are retained only for the newest 10 runs per
  racer/venue/actual-course. Nationwide newest-10 is reconstructed from those
  bounded local rows.
* Each racer's official registration term is used as the historical floor.
  A 136期 rookie therefore stops at the 2025-05 debut term instead of scanning
  pointless pre-debut files back to 2002. One racer can never hold the others
  open merely because that racer has fewer than 10 starts in some courses.
"""

import io
import re
import threading
import time
from datetime import datetime, timedelta, time as dt_time
from zoneinfo import ZoneInfo

import requests
from bs4 import BeautifulSoup

JST = ZoneInfo("Asia/Tokyo")
HISTORY_FLOOR = "20020101"
SUCCESS_PAUSE_SECONDS = 30
RETRY_PAUSE_SECONDS = 60
MAX_FETCH_ATTEMPTS = 3

VENUES = [
    "桐生","戸田","江戸川","平和島","多摩川","浜名湖","蒲郡","常滑","津","三国","びわこ","住之江",
    "尼崎","鳴門","丸亀","児島","宮島","徳山","下関","若松","芦屋","福岡","唐津","大村",
]
VENUE_CODE = {name: f"{i:02d}" for i, name in enumerate(VENUES, 1)}


def _registration_term_floor(period: int) -> str:
    """Convert BOAT RACE registration term to its May/November debut-term floor.

    136期 debuted in May 2025 and 135期 in November 2024. Terms are six-month
    cohorts, so this gives a conservative lower bound for official race history.
    """
    period = int(period)
    reference_period = 136
    reference_month_index = 2025 * 12 + (5 - 1)
    month_index = reference_month_index - (reference_period - period) * 6
    year, month0 = divmod(month_index, 12)
    return f"{year:04d}{month0 + 1:02d}01"


def _norm(s: str) -> str:
    return re.sub(r"[\s　]+", "", str(s or "")).replace("ボートレース", "")


def _st_number(raw: str):
    s = str(raw or "").strip().upper().replace("０", "0")
    if not s:
        return None
    m = re.fullmatch(r"F\s*([0-9]*\.?[0-9]+)", s)
    if m:
        try:
            return -float(m.group(1))
        except ValueError:
            return None
    if s.startswith("L"):
        return None
    try:
        v = float(s)
        return v if -1 < v < 2 else None
    except ValueError:
        return None


def parse_k_text(text: str, yyyymmdd: str) -> list[dict]:
    """Parse official K text into racer/run rows; 3連単 is intentionally omitted."""
    rows: list[dict] = []
    jcd = None
    rno = None
    in_result_rows = False
    race_rows: list[dict] = []

    def flush_race():
        nonlocal race_rows
        if not race_rows:
            return
        numeric = [(i, _st_number(x.get("st_raw"))) for i, x in enumerate(race_rows)]
        numeric = [(i, v) for i, v in numeric if v is not None]
        numeric.sort(key=lambda z: z[1])
        last = None
        rank = 0
        for pos, (idx, value) in enumerate(numeric, 1):
            if last is None or abs(value - last) > 1e-9:
                rank = pos
                last = value
            race_rows[idx]["st_rank"] = rank
        rows.extend(race_rows)
        race_rows = []

    for raw_line in text.splitlines():
        line = raw_line.rstrip("\r\n")
        compact = _norm(line)
        for name, code in sorted(VENUE_CODE.items(), key=lambda kv: len(kv[0]), reverse=True):
            if name in compact and ("成績" in compact or "ボートレース" in line):
                flush_race()
                jcd = code
                rno = None
                in_result_rows = False
                break

        m_race = re.match(r"^\s*(\d{1,2})R\s+.*H\s*\d+", line, re.I)
        if m_race:
            flush_race()
            rno = int(m_race.group(1))
            in_result_rows = False
            continue
        if "スタートタイミンク" in line or "スタートタイミング" in line:
            in_result_rows = True
            continue
        if not in_result_rows or not jcd or not rno:
            continue
        if not line.strip() or set(line.strip()) <= {"-"}:
            if race_rows and not line.strip():
                flush_race()
                in_result_rows = False
            continue

        finish = lane = reg = entry = st_raw = None
        if len(line) >= 48:
            finish = line[2:4].strip()
            lane = line[6:7].strip()
            reg = line[8:12].strip()
            entry = line[38:39].strip()
            st_raw = line[43:47].strip()
        if not (lane and lane.isdigit() and reg and reg.isdigit() and entry and entry.isdigit()):
            m = re.match(r"^\s*(\S{1,2})\s+([1-6])\s+(\d{4})\s+(.+?)\s+(\d{1,2})\s+(\d{1,2})\s+(\d\.\d{2})\s+([1-6])\s+(\S+)", line)
            if not m:
                continue
            finish, lane, reg, entry, st_raw = m.group(1), m.group(2), m.group(3), m.group(8), m.group(9)
        try:
            lane_i, course_i = int(lane), int(entry)
        except (TypeError, ValueError):
            continue
        if not (1 <= lane_i <= 6 and 1 <= course_i <= 6):
            continue
        finish_clean = str(finish or "").lstrip("0") or "0"
        race_rows.append({
            "date": yyyymmdd, "jcd": jcd, "rno": rno,
            "registration_no": str(reg), "lane": lane_i,
            "course": course_i, "finish": finish_clean,
            "st_raw": str(st_raw or "").strip(), "st_rank": None,
            "source": "official-k-download-backfill",
        })
    flush_race()
    return rows


class OfficialCourseHistoryCollector:
    """Restart-safe historical collector for missing course history."""

    def __init__(self, db):
        self.db = db
        self._thread = None
        self._stop = threading.Event()
        self.status = self.db.get_course_history_collection_status()

    @staticmethod
    def _in_window(now: datetime) -> bool:
        return dt_time(0, 0) <= now.time() <= dt_time(23, 59, 59, 999999)

    @staticmethod
    def _seconds_until_next_midnight(now: datetime) -> float:
        tomorrow = (now + timedelta(days=1)).date()
        next_run = datetime.combine(tomorrow, dt_time(0, 0), tzinfo=JST)
        return max(1.0, (next_run - now).total_seconds())

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._scheduler, name="course-history-backfill", daemon=True)
        self._thread.start()

    def _scheduler(self):
        while not self._stop.is_set():
            now = datetime.now(JST)
            if self._in_window(now):
                self._run_nightly_window()
                now = datetime.now(JST)
                # After one backfill pass/error, do not immediately restart and
                # hammer the source. Wait until the next 00:00 cycle.
                self._stop.wait(self._seconds_until_next_midnight(now))
            else:
                self.status = self.db.get_course_history_collection_status()
                self._stop.wait(min(self._seconds_until_next_midnight(now), 300))

    def _fetch_day(self, session: requests.Session, cursor) -> tuple[str, list[dict], str | None]:
        ymd = cursor.strftime("%Y%m%d")
        yy = cursor.strftime("%y%m%d")
        url = f"https://www1.mbrace.or.jp/od2/K/{cursor:%Y%m}/k{yy}.lzh"
        last_error = None
        for attempt in range(1, MAX_FETCH_ATTEMPTS + 1):
            if self._stop.is_set() or not self._in_window(datetime.now(JST)):
                return "window_end", [], None
            try:
                r = session.get(url, timeout=20)
                if r.status_code == 404:
                    return "no_data", [], None
                r.raise_for_status()
                try:
                    import lhafile
                except ImportError as exc:
                    raise RuntimeError("lhafile が未導入です。requirements.txt から再デプロイしてください") from exc
                archive = lhafile.Lhafile(io.BytesIO(r.content))
                names = archive.namelist()
                if not names:
                    raise RuntimeError("公式Kファイルを展開できませんでした")
                raw = archive.read(names[0])
                return "ok", parse_k_text(raw.decode("cp932", errors="replace"), ymd), None
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt < MAX_FETCH_ATTEMPTS:
                    self._stop.wait(RETRY_PAUSE_SECONDS)
        return "error", [], last_error

    def _resolve_racer_floor(self, session: requests.Session, racer: dict) -> str:
        """Resolve/persist a real per-racer floor, using saved profile first.

        This is one profile lookup per unresolved racer, not a repeating poll.
        Failure leaves the old conservative floor; the normal daily-file retry
        policy still applies and no other racer is blocked by the lookup.
        """
        reg = str(racer.get("registration_no") or "")
        existing = str(racer.get("floor_date") or HISTORY_FLOOR)
        if existing != HISTORY_FLOOR:
            return existing
        period = self.db.get_course_history_profile_period(reg)
        if period is None:
            try:
                url = f"https://www.boatrace.jp/owpc/pc/data/racersearch/profile?toban={reg}"
                r = session.get(url, timeout=20)
                r.raise_for_status()
                text = BeautifulSoup(r.content, "html.parser").get_text(" ", strip=True)
                m = re.search(r"登録期\s*[:：]?\s*(\d{2,3})\s*期", text)
                if m:
                    period = int(m.group(1))
            except Exception:
                period = None
        if period is None:
            return existing
        floor = _registration_term_floor(period)
        self.db.set_course_history_racer_floor(reg, floor, period)
        return floor

    def _complete_past_floor(self):
        pending = self.db.get_course_history_pending_racers()
        done = []
        for x in pending:
            cursor = str(x.get("cursor_date") or "")
            floor = str(x.get("floor_date") or HISTORY_FLOOR)
            if cursor and cursor < floor:
                done.append(str(x["registration_no"]))
        if done:
            self.db.complete_course_history_racers(done)
        return done

    def _run_nightly_window(self):
        now = datetime.now(JST)
        start_date = (now.date() - timedelta(days=1)).strftime("%Y%m%d")
        self.db.ensure_course_history_racer_targets(start_date, HISTORY_FLOOR)

        session = requests.Session()
        session.headers.update({"User-Agent": "BOAT-AI-Lab/1.0 official-result-history-nightly"})

        # Resolve a realistic lower bound once per unresolved racer. This fixes
        # young racers such as 136期 from being scanned years before debut.
        for racer in self.db.get_course_history_pending_racers():
            if self._stop.is_set() or not self._in_window(datetime.now(JST)):
                return
            self._resolve_racer_floor(session, racer)

        self._complete_past_floor()
        targets = self.db.get_course_history_pending_racers()
        if not targets:
            self.status = self.db.get_course_history_collection_status()
            return
        target_regs = {str(x["registration_no"]) for x in targets}

        while self._in_window(datetime.now(JST)) and not self._stop.is_set():
            self._complete_past_floor()
            current = [x for x in self.db.get_course_history_pending_racers()
                       if str(x["registration_no"]) in target_regs]
            if not current:
                break

            # Work on the newest outstanding day. Racers with an older cursor
            # wait without being re-read; each racer owns its own cursor/floor.
            cursor_text = max(str(x.get("cursor_date") or start_date) for x in current)
            cursor = datetime.strptime(cursor_text, "%Y%m%d").date()
            ymd = cursor.strftime("%Y%m%d")
            active = {
                str(x["registration_no"]): x for x in current
                if str(x.get("cursor_date") or start_date) == ymd
                and ymd >= str(x.get("floor_date") or HISTORY_FLOOR)
            }
            if not active:
                self._complete_past_floor()
                continue

            state, rows, error = self._fetch_day(session, cursor)
            if state == "window_end":
                break
            if state == "error":
                # Only racers whose cursor is this failed day are marked. A
                # single racer/error never corrupts or rewinds completed ones.
                self.db.mark_course_history_fetch_error(list(active), ymd, error or "取得失敗", MAX_FETCH_ATTEMPTS)
                self.status = self.db.get_course_history_collection_status()
                return

            if state == "ok" and rows:
                filtered = [x for x in rows if str(x.get("registration_no") or "") in active]
                self.db.save_course_history_runs(filtered, keep_per_local_course=10)

            next_date = (cursor - timedelta(days=1)).strftime("%Y%m%d")
            self.db.advance_course_history_racers(list(active), next_date)
            self._complete_past_floor()
            self.status = self.db.get_course_history_collection_status()
            self._stop.wait(SUCCESS_PAUSE_SECONDS)

        self.status = self.db.get_course_history_collection_status()
