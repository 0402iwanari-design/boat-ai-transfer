from __future__ import annotations

import itertools
import math
import unicodedata
import re
from datetime import datetime, timezone, timedelta

JST = timezone(timedelta(hours=9), name="JST")

LANE_BASE = {1: 1.00, 2: 0.74, 3: 0.69, 4: 0.63, 5: 0.52, 6: 0.44}
CLASS_SCORE = {"A1": 1.00, "A2": 0.78, "B1": 0.54, "B2": 0.35}

COLLECTION_CATALOG = [
    ("meeting_results", "節間成績"),
    ("national_lane_results", "全国成績（当該枠/コースデータ優先）"),
    ("local_lane_results", "当地同枠成績（保存済み公式結果から集計）"),
    ("course_quinella_rate", "選手コース別2連対率（保存済み公式結果から集計）"),
    ("motor", "モーター成績"),
    ("boat", "ボート成績"),
    ("avg_st", "平均ST"),
    ("exhibition_time", "展示タイム"),
    ("start_exhibition_st", "スタート展示ST"),
    ("start_entry", "スタート展示進入/STタイミング"),
    ("original_exhibition", "オリジナル展示"),
    ("wind_speed", "風速"),
    ("wind_direction", "風向"),
    ("tide", "潮（満潮・干潮等）"),
    ("wave_height", "波高"),
    ("comments", "選手コメント"),
    ("venue_material", "場特性資料"),
    ("in_escape_rate", "イン逃げ率 / 1コース1着率"),
    ("winning_method", "決まり手傾向"),
    ("popular_combos", "出やすい出目"),
    ("odds", "3連単オッズ"),
]


def _num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = re.search(r"-?\d+(?:\.\d+)?", str(v).replace(",", "").replace("%", ""))
    return float(m.group()) if m else None


def _first(d, *keys):
    if not isinstance(d, dict):
        return None
    for k in keys:
        if d.get(k) not in (None, ""):
            return d.get(k)
    return None


def _lane_map(rows):
    out = {}
    for x in rows or []:
        if not isinstance(x, dict):
            continue
        lane = _num(_first(x, "lane", "boat", "waku", "course"))
        if lane and 1 <= int(lane) <= 6:
            out[int(lane)] = x
    return out


def _stats_present(block):
    if not isinstance(block, dict):
        return False
    return any(_num(v) is not None for v in block.values())


def _parse_start(st_raw):
    if st_raw is None:
        return None
    s = str(st_raw).strip().upper()
    m = re.search(r"([FL]?)(?:0)?\.(\d{2})", s)
    if not m:
        return None
    val = int(m.group(2)) / 100.0
    if m.group(1) == "F":
        val = -val
    return val


def _extract_odds(odds):
    out = {}
    for row in (odds or {}).get("odds") or []:
        combo = str(_first(row, "combo", "combination", "trifecta") or "")
        nums = re.findall(r"[1-6]", combo)
        val = _num(_first(row, "odds", "value", "rate"))
        if len(nums) == 3 and len(set(nums)) == 3 and val is not None and math.isfinite(val) and val > 0:
            out["-".join(nums)] = val
    return out


def _extract_percentage(text, labels):
    for label in labels:
        # conservative: percentage must be near the label
        pat = rf"{label}.{{0,24}}?(\d{{1,3}}(?:\.\d+)?)\s*%"
        m = re.search(pat, text, re.I)
        if m:
            v = float(m.group(1))
            if 0 <= v <= 100:
                return v
    return None


def build_venue_profile(documents):
    """
    Build venue characteristics from saved materials.

    Important:
    - Do NOT display raw crawled sentences as-is.
    - First reject legal/event/racer/program text.
    - Then score only water/course/weather/race-development material.
    - Finally convert evidence into short, normalized venue-characteristic notes.
    """
    chunks = []
    source_kinds = set()
    for x in (documents or []):
        if not isinstance(x, dict):
            continue
        title = str(x.get("title") or "").strip()
        body = str(x.get("content_text") or "").strip()
        kind = str(x.get("source_kind") or "").strip()
        if kind:
            source_kinds.add(kind)
        if title or body:
            chunks.append((title + "\n" + body).strip())

    text = unicodedata.normalize("NFKC", "\n".join(chunks)[:1200000])

    in_escape = _extract_percentage(
        text,
        [r"イン逃げ率", r"1コース1着率", r"1号艇1着率", r"イン1着率"]
    )

    methods = {}
    method_labels = {
        "逃げ": [r"逃げ"],
        "差し": [r"差し"],
        "まくり": [r"(?<!差し)まくり(?!差し)"],
        "まくり差し": [r"まくり差し"],
        "抜き": [r"抜き"],
    }
    for name, labels in method_labels.items():
        val = _extract_percentage(text, labels)
        if val is not None:
            methods[name] = val

    combo_hits = {}
    for m in re.finditer(
        r"公式3連単出目統計\s+([1-6])-([1-6])-([1-6])\s+(\d{1,3}(?:\.\d+)?)%",
        text
    ):
        aa, bb, cc, pct = m.groups()
        if len({aa, bb, cc}) != 3:
            continue
        combo = f"{aa}-{bb}-{cc}"
        val = float(pct)
        if 0 <= val <= 100:
            combo_hits[combo] = max(combo_hits.get(combo, 0), val)

    popular = [
        {"combo": k, "rate": v}
        for k, v in sorted(
            combo_hits.items(), key=lambda kv: kv[1], reverse=True
        )[:8]
    ]

    # -----------------------------
    # Relevance filter
    # -----------------------------
    positive_groups = {
        "水面・コース": (
            "水面", "1マーク", "１マーク", "2マーク", "２マーク",
            "ターンマーク", "コース幅", "バック水面", "ホーム水面",
            "ピット", "進入", "広い", "狭い", "振って", "距離"
        ),
        "風": (
            "向かい風", "追い風", "横風", "風速", "風向", "海風", "季節風",
            "強風", "弱風"
        ),
        "潮・波": (
            "満潮", "干潮", "潮位", "潮", "うねり", "波高", "波",
            "海水", "淡水", "汽水", "流れ"
        ),
        "レース傾向": (
            "イン", "センター", "アウト", "逃げ", "差し", "まくり",
            "まくり差し", "抜き", "伸び", "出足", "回り足", "旋回",
            "ダッシュ", "スロー"
        ),
    }

    hard_reject = (
        "使用日時", "申請書", "使用許可", "秩序", "善良な風俗",
        "入場料", "参加費", "営利", "未成年", "利用規約", "プライバシー",
        "Copyright", "お問い合わせ", "サイトマップ", "ログイン", "投票",
        "開催期間中", "シリーズ注目", "イベント", "トークショー",
        "プレゼント", "キャンペーン", "選手名", "登録番号",
        "出場予定選手", "レースガイド", "ライブ&リプレイ",
    )

    racer_noise = (
        "級別", "支部", "年齢", "勝率", "2連率", "3連率", "平均ST",
        "モーター", "ボート", "登録", "選手", "当地3年", "全国"
    )

    def split_candidates(src):
        # First normal Japanese sentence boundaries.
        out = re.split(r"(?<=[。！？])\s*|\n+", src)
        # Legacy flattened pages: create windows around meaningful keywords.
        flat = re.sub(r"\s+", " ", src)
        all_terms = []
        for vals in positive_groups.values():
            all_terms.extend(vals)
        for kw in dict.fromkeys(all_terms):
            for mm in list(re.finditer(re.escape(kw), flat))[:10]:
                left = max(0, mm.start() - 80)
                right = min(len(flat), mm.end() + 120)
                win = flat[left:right]
                # Trim to punctuation if available.
                p0 = max(
                    win.rfind("。", 0, mm.start() - left),
                    win.rfind("！", 0, mm.start() - left),
                    win.rfind("？", 0, mm.start() - left),
                )
                if p0 >= 0:
                    win = win[p0+1:]
                ends = [x for x in (
                    win.find("。", 15), win.find("！", 15), win.find("？", 15)
                ) if x >= 0]
                if ends:
                    win = win[:min(ends)+1]
                out.append(win)
        return out

    def relevance(sentence):
        s = re.sub(r"\s+", " ", sentence or "").strip()
        if len(s) < 10:
            return -999, []
        if any(x in s for x in hard_reject):
            return -999, []
        # Racer/program rows are usually data dumps rather than venue traits.
        racer_hits = sum(1 for x in racer_noise if x in s)
        if racer_hits >= 3:
            return -999, []

        cats = []
        score = 0
        for cat, words in positive_groups.items():
            hits = sum(1 for w in words if w in s)
            if hits:
                cats.append(cat)
                score += min(hits, 4) * 2

        # Prefer explanatory language.
        for x in ("ため", "ので", "傾向", "多い", "少ない", "強い", "弱い",
                  "有利", "不利", "届く", "決まり", "影響", "特徴", "なりやすい",
                  "広く", "狭く", "遠い", "近い"):
            if x in s:
                score += 1

        # Penalize date/program-like blobs and huge numeric rows.
        if len(re.findall(r"\d", s)) >= 18:
            score -= 8
        if s.count("%") >= 4:
            score -= 5
        if len(s) > 220:
            score -= 2

        return score, cats

    evidences = []
    seen = set()
    for raw in split_candidates(text):
        s = re.sub(r"\s+", " ", raw or "").strip(" ・|\t\r\n")
        score, cats = relevance(s)
        if score < 4 or not cats:
            continue
        key = re.sub(r"[\s　。、・|]", "", s)
        if not key:
            continue
        if any(key in old or old in key for old in list(seen)[-50:]):
            continue
        seen.add(key)
        evidences.append({
            "text": s[:220],
            "score": score,
            "categories": cats,
        })

    evidences.sort(key=lambda x: x["score"], reverse=True)

    # -----------------------------
    # Normalize into concise notes.
    # We intentionally do not echo whole source sentences.
    # -----------------------------
    notes = []

    def add_note(label, body):
        body = re.sub(r"\s+", " ", body).strip(" 。")
        if body and not any(body in x or x in body for x in notes):
            notes.append(f"{label}：{body}")

    joined = " ".join(x["text"] for x in evidences[:60])

    # Water / geometry
    water_bits = []
    if re.search(r"1マーク.{0,20}(振|寄|位置)", joined):
        water_bits.append("1マークの配置に特徴あり")
    if re.search(r"(1マーク|１マーク).{0,35}(2マーク|２マーク).{0,20}(遠|距離)", joined) or \
       re.search(r"(2マーク|２マーク).{0,35}(1マーク|１マーク).{0,20}(遠|距離)", joined):
        water_bits.append("1・2マーク間の距離に特徴あり")
    if re.search(r"(水面|コース).{0,18}(広|ワイド)", joined):
        water_bits.append("水面・コースは比較的広め")
    if re.search(r"(水面|コース).{0,18}(狭|タイト)", joined):
        water_bits.append("水面・コースは比較的狭め")
    if "海水" in joined:
        water_bits.append("海水水面")
    elif "汽水" in joined:
        water_bits.append("汽水水面")
    elif "淡水" in joined:
        water_bits.append("淡水水面")
    if water_bits:
        add_note("水面・コース", " / ".join(dict.fromkeys(water_bits)))

    # Wind
    wind_bits = []
    if "向かい風" in joined:
        wind_bits.append("向かい風の影響を受ける場面あり")
    if "追い風" in joined:
        wind_bits.append("追い風の影響を受ける場面あり")
    if "横風" in joined:
        wind_bits.append("横風の影響を受ける場面あり")
    if re.search(r"(風|強風).{0,20}(強|影響|荒)", joined):
        wind_bits.append("風の強さがレース展開に影響しやすい")
    if wind_bits:
        add_note("風", " / ".join(dict.fromkeys(wind_bits)))

    # Tide / wave
    tide_bits = []
    if any(x in joined for x in ("満潮", "干潮", "潮位")):
        tide_bits.append("潮位変化を確認したい水面")
    if "うねり" in joined:
        tide_bits.append("うねりの影響が出る場合あり")
    if re.search(r"(波|波高).{0,20}(高|影響|荒)", joined):
        tide_bits.append("波の状態が走りに影響する場合あり")
    if tide_bits:
        add_note("潮・波", " / ".join(dict.fromkeys(tide_bits)))

    # Race development
    race_bits = []
    if re.search(r"イン.{0,18}(強|有利|逃げ)", joined):
        race_bits.append("イン優勢の記述あり")
    if re.search(r"イン.{0,18}(弱|不利|苦戦)", joined):
        race_bits.append("インが絶対ではない記述あり")
    if re.search(r"センター.{0,20}(まくり|攻め|強)", joined):
        race_bits.append("センター勢の攻めに注意")
    if re.search(r"ダッシュ.{0,20}(まくり|攻め|届)", joined):
        race_bits.append("ダッシュ勢の攻めが届く記述あり")
    if "まくり差し" in joined:
        race_bits.append("まくり差しの展開も要注意")
    if re.search(r"2マーク.{0,20}(抜き|逆転)", joined):
        race_bits.append("2マークでの逆転・抜きに注意")
    if race_bits:
        add_note("レース傾向", " / ".join(dict.fromkeys(race_bits)))

    # If evidence exists but rules could not confidently normalize it,
    # report "under analysis" instead of dumping unrelated source text.
    if notes:
        direction = "収集資料を関連性判定し、場特性として使える内容だけを反映"
        analysis_state = "reflected"
    elif evidences:
        direction = "場特性に関係する資料を確認中。内容を整理してから反映します"
        analysis_state = "analyzing"
    elif documents:
        direction = "資料は保存済みですが、場特性として使える文章をまだ確認できていません"
        analysis_state = "no_relevant_text"
    else:
        direction = "場特性資料をまだ取得できていません"
        analysis_state = "no_documents"

    return {
        "direction": direction,
        "characteristic_notes": notes[:8],
        "in_escape_rate": in_escape,
        "winning_methods": methods,
        "popular_combos": popular,
        "document_count": len(documents or []),
        "relevant_evidence_count": len(evidences),
        "analysis_state": analysis_state,
        "source_kinds": sorted(source_kinds),
    }


def _meeting_results(racer):
    for key in ("meeting_results", "series_results", "current_meeting", "session_results"):
        v = racer.get(key) if isinstance(racer, dict) else None
        if v:
            return v
    return None


def _lane_specific(racer, locality):
    # Future collector adapters may use any of these aliases.
    keys = (
        *(("local_frame_stats", "local_frame") if locality == "local" else ()),
        f"{locality}_lane", f"{locality}_course",
        f"{locality}_lane_results", f"{locality}_course_results",
        f"{locality}_waku"
    )
    for k in keys:
        v = racer.get(k) if isinstance(racer, dict) else None
        if isinstance(v, dict) and _stats_present(v):
            return v
        if v not in (None, "", [], {}):
            return v
    # The current official racelist exposes the racer's nationwide/local
    # aggregate block as ``national`` / ``local``.  Prefer a future true
    # course-specific block above, but do not throw away this useful fallback.
    v = racer.get(locality) if isinstance(racer, dict) else None
    if isinstance(v, dict) and _stats_present(v):
        return v
    return None


def _course_stats(racer, course):
    """Saved official-result performance for one actual entry course."""
    rows = racer.get("course_stats") if isinstance(racer, dict) else None
    if not isinstance(rows, dict):
        return None
    return rows.get(course) or rows.get(str(course))


def build_availability(race, before, odds, documents, venue_profile):
    racers = (race or {}).get("racers") or []
    br = (before or {}).get("racers") or []
    starts = (before or {}).get("start_display") or []
    original = (before or {}).get("original_exhibition") or []
    weather = (before or {}).get("weather") or {}
    comments = (before or {}).get("comments") or []

    def any_racer(pred):
        return bool(racers) and any(pred(x) for x in racers if isinstance(x, dict))

    flags = {
        "meeting_results": any_racer(lambda x: bool(_meeting_results(x))),
        "national_lane_results": any_racer(lambda x: bool(_lane_specific(x, "national"))),
        "local_lane_results": any_racer(lambda x: bool(_lane_specific(x, "local"))),
        "course_quinella_rate": any_racer(lambda x: bool(_course_stats(x, int(x.get("lane") or 0)))),
        "motor": any_racer(lambda x: _stats_present(x.get("motor") or {})),
        "boat": any_racer(lambda x: _stats_present(x.get("boat") or {})),
        "avg_st": any_racer(lambda x: _num(x.get("avg_st")) is not None),
        "exhibition_time": any(_num(x.get("exhibition_time")) is not None for x in br),
        "start_exhibition_st": any(_parse_start(x.get("st_raw")) is not None for x in starts),
        "start_entry": bool(starts) and any(x.get("course") is not None for x in starts),
        "original_exhibition": bool(original),
        "wind_speed": _num(weather.get("wind_speed_m")) is not None,
        "wind_direction": bool(weather.get("wind_direction")),
        "tide": any(weather.get(k) for k in ("tide_phase", "high_tide_time", "low_tide_time")),
        "wave_height": _num(weather.get("wave_height_cm")) is not None,
        "comments": bool(comments),
        "venue_material": bool(documents),
        "in_escape_rate": venue_profile.get("in_escape_rate") is not None,
        "winning_method": bool(venue_profile.get("winning_methods")),
        "popular_combos": bool(venue_profile.get("popular_combos")),
        "odds": bool(_extract_odds(odds)),
    }

    return [
        {
            "key": key,
            "label": label,
            "available": bool(flags.get(key)),
        }
        for key, label in COLLECTION_CATALOG
    ]


def _venue_lane_adjustments(active, venue_profile):
    """Small, evidence-based venue/course correction; never overrides racers."""
    active = [int(x) for x in active]
    out = {lane: {"score": 0.0, "reasons": []} for lane in active}
    vp = venue_profile or {}
    escape = _num(vp.get("in_escape_rate"))
    if escape is not None and 1 in out:
        # Around 50% is neutral.  The bounded correction is intentionally much
        # smaller than current-series, racer, motor and exhibition factors.
        delta = max(-5.0, min(5.0, (escape - 50.0) * 0.18))
        out[1]["score"] += delta
        out[1]["reasons"].append(f"場のイン逃げ率{escape:g}%")
        outside = [x for x in active if x != 1]
        if outside:
            share = -delta / len(outside)
            for lane in outside:
                out[lane]["score"] += share

    methods = vp.get("winning_methods") or {}
    method_targets = {
        "差し": (2,),
        "まくり": (3, 4),
        "まくり差し": (3, 4, 5),
    }
    for method, targets in method_targets.items():
        rate = _num(methods.get(method))
        lanes = [x for x in targets if x in out]
        if rate is None or not lanes:
            continue
        # The percentages in venue material may use different denominators, so
        # this is a capped relative hint rather than a direct probability.
        add = min(2.5, max(0.0, rate) * 0.05) / len(lanes)
        for lane in lanes:
            out[lane]["score"] += add
            out[lane]["reasons"].append(f"場の{method}傾向")
    return out


def _pre_lane_score(lane, racer):
    """
    PRE-BEFORE model.
    User-specified basis only:
      meeting performance
      national result for this lane/course
      local result for this lane/course
      motor
      boat
    Missing items are not silently replaced with unrelated values.
    """
    # 枠だけで予想が決まらないよう基礎点を抑え、選手本人の当該コース
    # 成績・今節の走りを相対的に重くする。
    score = LANE_BASE.get(lane, 0.4) * 12
    reasons = [f"{lane}枠基礎"]

    meeting = _meeting_results(racer)
    if meeting:
        # Generic support for structured future collectors.
        vals = []
        if isinstance(meeting, dict):
            for k in ("score", "rate", "avg_rank", "points", "win_rate"):
                v = _num(meeting.get(k))
                if v is not None:
                    vals.append((k, v))
        if vals:
            k, v = vals[0]
            if "avg_rank" in k:
                # 1.0 is excellent, 6.0 is poor. Current-series form is a
                # meaningful PRE factor but must not dominate all other data.
                form = max(0.0, min((6.0 - v) / 5.0, 1.0))
                score += form * 22
                reasons.append(f"節間平均着 {v:.2f}")
            else:
                score += max(0, min(v / 8.0, 1.2)) * 22
                reasons.append("節間成績")

        else:
            entries = meeting.get("entries") if isinstance(meeting, dict) else None
            numeric = []
            for e in (entries or []):
                f = str((e or {}).get("finish") or "")
                if f.isdigit():
                    numeric.append(int(f))
            if numeric:
                av = sum(numeric) / len(numeric)
                form = max(0.0, min((6.0 - av) / 5.0, 1.0))
                score += form * 22
                reasons.append(f"節間平均着 {av:.2f}")
            else:
                score += 3
                reasons.append("節間成績")

        # 今節のSTはF持ちなどで普段より慎重なスタートになっている
        # 状態も表す。F/L表記は平均に混ぜず、正常値だけで評価する。
        entries = meeting.get("entries") if isinstance(meeting, dict) else []
        st_values = []
        for e in entries or []:
            raw = str((e or {}).get("st") or "").strip().upper()
            if re.fullmatch(r"0?\.\d{2}", raw):
                st_values.append(float(raw if raw.startswith("0") else "0" + raw))
        meeting_avg_st = _num(meeting.get("avg_st")) if isinstance(meeting, dict) else None
        if meeting_avg_st is None and st_values:
            meeting_avg_st = sum(st_values) / len(st_values)
        if meeting_avg_st is not None:
            st_adj = max(-8.0, min(8.0, (0.19 - meeting_avg_st) * 80.0))
            score += st_adj
            reasons.append(f"節間平均ST {meeting_avg_st:.2f}")
            f_count = int(_num(_first(racer, "f", "f_count", "flying")) or 0)
            if f_count and meeting_avg_st >= 0.18:
                score -= 2.5
                reasons.append(f"F{f_count}持ち・節間ST慎重")

    # Before the start exhibition is published, boat frame is the best known
    # entry-course estimate.  The POST stage can still change the final score
    # using the actual entry information, while this history is a transparent
    # supporting signal rather than a replacement for official racer data.
    course_block = _course_stats(racer, lane)
    if isinstance(course_block, dict):
        first_rate = _num(course_block.get("first_rate"))
        q = _num(course_block.get("quinella_rate"))
        trio = _num(course_block.get("trio_rate"))
        course_avg_st = _num(course_block.get("avg_st"))
        starts = int(_num(course_block.get("starts")) or 0)
        if q is None:
            second_rate = _num(course_block.get("second_rate"))
            if first_rate is not None and second_rate is not None:
                q = first_rate + second_rate
        if first_rate is not None:
            score += max(0, min(first_rate / 100.0, 1.0)) * 14
            reasons.append(f"公式 {lane}コース1着{first_rate:g}%")
        if q is not None and starts:
            reliability = min(1.0, max(0.2, starts / 20.0))
            score += max(0, min(q / 100.0, 1.1)) * 18 * reliability
            reasons.append(f"{lane}コース2連{q:g}%（{starts}走）")
        elif q is not None:
            score += max(0, min(q / 100.0, 1.1)) * 18
            reasons.append(f"公式 {lane}コース2連{q:g}%")
        elif trio is not None:
            # Official racer-search course page publishes course-specific
            # three-in-the-money performance even before our own history has
            # accumulated.  It is a supporting signal, not a substitute for
            # current race / motor / exhibition information.
            score += max(0, min(trio / 100.0, 1.1)) * 10
            reasons.append(f"公式 {lane}コース3連{trio:g}%")
        if course_avg_st is not None:
            score += max(-5.0, min(5.0, (0.19 - course_avg_st) * 50.0))
            reasons.append(f"公式 {lane}コース平均ST {course_avg_st:.2f}")

        # 「1枠だから逃げる」ではなく、その選手が実際に1コースで
        # 弱い場合はイン基礎点を打ち消す。2連対率を優先し、未取得時
        # は3連対率を補助判定に使う。
        if lane == 1:
            if q is not None and q < 55:
                penalty = min(12.0, (55.0 - q) * 0.35)
                score -= penalty
                reasons.append(f"1コース2連率低め -{penalty:.1f}")
            elif q is None and trio is not None and trio < 68:
                penalty = min(10.0, (68.0 - trio) * 0.25)
                score -= penalty
                reasons.append(f"1コース3連率低め -{penalty:.1f}")

    for locality, label, weight in (
        ("national", "全国成績（当該枠/コース優先）", 22),
        ("local", "当地同枠成績", 18),
    ):
        block = _lane_specific(racer, locality)
        if isinstance(block, dict):
            win = _num(_first(block, "win_rate", "first_rate", "1st_rate", "rate"))
            q = _num(_first(block, "quinella_rate", "2ren", "top2_rate"))
            sample = int(_num(_first(block, "starts", "sample_size", "races")) or 0)
            reliability = min(1.0, max(0.25, sample / 12.0)) if sample else 1.0
            if win is not None:
                score += max(0, min(win / (100 if win > 10 else 8), 1.2)) * weight * reliability
                reasons.append(
                    f"当地同枠実績 {sample}走" if locality == "local" and sample else label
                )
            elif q is not None:
                score += max(0, min(q / 100.0, 1.2)) * (weight * 0.7) * reliability
                reasons.append(
                    f"当地同枠実績 {sample}走" if locality == "local" and sample else label
                )
        elif block:
            score += weight * 0.25
            reasons.append(label)

    motor = racer.get("motor") or {}
    mr = _num(_first(motor, "quinella_rate", "2ren", "rate"))
    if mr is not None:
        score += max(0, min(mr / 50.0, 1.3)) * 24
        reasons.append(f"モーター2連{mr:g}%")

    boat = racer.get("boat") or {}
    br = _num(_first(boat, "quinella_rate", "2ren", "rate"))
    if br is not None:
        score += max(0, min(br / 50.0, 1.3)) * 14
        reasons.append(f"ボート2連{br:g}%")

    if racer.get("scratched") or str(racer.get("status") or "") == "欠場":
        return -9999, ["欠場"]

    return score, reasons


def _post_adjustment(lane, racer, before_row, start_row, original_row, weather, comments):
    """
    POST-BEFORE adjustment:
      PRE basis +
      start exhibition ST / entry timing
      original exhibition
      wind speed/direction
      tide
      wave height
      comments
    """
    adj = 0.0
    reasons = []

    st = _parse_start((start_row or {}).get("st_raw"))
    if st is not None:
        # good start around 0.05-0.15. F-like starts receive caution.
        if st < 0:
            adj -= 3.0
            reasons.append(f"展示ST F{abs(st):.2f}")
        else:
            adj += max(-2.0, min((0.22 - st) / 0.17, 1.0) * 10)
            reasons.append(f"展示ST {st:.2f}")

    course = _num((start_row or {}).get("course"))
    if course is not None:
        course = int(course)
        if course == lane:
            reasons.append(f"進入{course}コース")
        else:
            # moving inward is a small plus, outward a small minus
            adj += max(-4, min(4, (lane - course) * 1.5))
            reasons.append(f"進入変化 {lane}枠→{course}コース")

    # Regular exhibition time is available as a secondary movement clue.
    ex = _num((before_row or {}).get("exhibition_time"))
    if ex is not None and 6.0 <= ex <= 8.0:
        adj += max(-2, min(5, (7.10 - ex) * 8))
        reasons.append(f"展示{ex:.2f}")

    metrics = (original_row or {}).get("metrics") or {}
    vals = []
    for label, value in metrics.items():
        v = _num(value)
        if v is not None:
            vals.append((label, v))
    if vals:
        # Absolute scales vary by venue, therefore only a modest positive
        # availability adjustment here. Relative ranking is added later.
        reasons.append("オリジナル展示")

    wind = _num(weather.get("wind_speed_m"))
    direction = weather.get("wind_direction")
    if wind is not None:
        # Weather affects scenario more than raw strength; keep score impact small.
        if wind >= 5:
            adj -= 0.5 if lane == 1 else 0
        reasons.append(f"風{wind:g}m {direction or ''}".strip())

    wave = _num(weather.get("wave_height_cm"))
    if wave is not None:
        if wave >= 5 and lane in (5, 6):
            adj -= 0.8
        reasons.append(f"波高{wave:g}cm")

    tide = weather.get("tide_phase") or ""
    if tide:
        reasons.append(f"潮:{tide}")

    c = next(
        (x for x in comments or [] if _num(x.get("lane")) == lane),
        None
    )
    if c and c.get("comment"):
        text = str(c["comment"])
        positive = ("良い", "いい", "出足", "伸び", "上向", "納得", "足はいい")
        negative = ("悪い", "弱い", "合ってない", "重い", "足りない", "厳しい")
        if any(w in text for w in positive):
            adj += 2.5
        if any(w in text for w in negative):
            adj -= 2.5
        reasons.append("選手コメント")

    return adj, reasons


def _original_relative_adjustments(original_rows):
    rows = _lane_map(original_rows)
    adjustments = {i: 0.0 for i in range(1, 7)}
    # For each metric, lower time is usually better. Compare only within the same
    # named metric so venue-specific scales are not mixed.
    labels = set()
    for row in rows.values():
        labels.update((row.get("metrics") or {}).keys())

    for label in labels:
        vals = []
        for lane, row in rows.items():
            v = _num((row.get("metrics") or {}).get(label))
            if v is not None:
                vals.append((lane, v))
        if len(vals) < 3:
            continue
        vals.sort(key=lambda x: x[1])
        best = vals[0][1]
        worst = vals[-1][1]
        span = max(worst - best, 1e-6)
        for lane, v in vals:
            adjustments[lane] += ((worst - v) / span - 0.5) * 3.0
    return adjustments


def _normalize(scores):
    vals = list(scores.values())
    mn, mx = min(vals), max(vals)
    if mx - mn < 1e-9:
        return {k: 0.5 for k in scores}
    return {k: (v - mn) / (mx - mn) for k, v in scores.items()}


def _combo_list(scores, active, odds_map=None, limit=6, venue_profile=None):
    norm = _normalize(scores)
    venue_rates = {
        str(x.get("combo")): _num(x.get("rate"))
        for x in (venue_profile or {}).get("popular_combos", [])
        if isinstance(x, dict) and x.get("combo")
    }
    rows = []
    for a, b, c in itertools.permutations(active, 3):
        s = norm[a] * 0.58 + norm[b] * 0.27 + norm[c] * 0.15
        # modest course prior only; racer/equipment scores remain central
        if a == 1:
            s += 0.035
        combo = f"{a}-{b}-{c}"
        venue_rate = venue_rates.get(combo)
        if venue_rate is not None:
            # Venue draw history is a supporting prior, capped so that it
            # cannot displace strong racer/exhibition evidence by itself.
            s += min(0.06, max(0.0, venue_rate) * 0.008)
        odd = (odds_map or {}).get(combo)
        rows.append({
            "combo": combo,
            "score": round(s, 4),
            "odds": odd,
            "venue_rate": venue_rate,
            "value_score": (
                round(s * math.log1p(odd), 4)
                if odd is not None else None
            ),
        })
    rows.sort(key=lambda x: x["score"], reverse=True)
    return rows[:limit], rows


def _parse_user_insight(note, active):
    """Free text is a capped supporting opinion, never a replacement for data."""
    text = unicodedata.normalize("NFKC", str(note or "")).strip()
    out = {lane: 0.0 for lane in active}
    reasons = {lane: [] for lane in active}
    combos = []
    for m in re.finditer(r"([1-6])\s*[-=→>]\s*([1-6])\s*[-=→>]\s*([1-6])", text):
        nums = [int(m.group(i)) for i in (1, 2, 3)]
        combo = "-".join(map(str, nums))
        if len(set(nums)) == 3 and all(x in active for x in nums) and combo not in combos:
            combos.append(combo)
    positive = ("本命", "軸", "強い", "良い", "買い", "逃げ", "まくり", "差し", "残す", "期待")
    negative = ("弱い", "不安", "消し", "切り", "外す", "厳しい", "遅い", "評価下げ")
    clauses = [x for x in re.split(r"[。.!！?？、,\n]+", text) if x.strip()]
    for lane in active:
        # Sentiment needs an explicit unit. Bare digits inside a combination
        # such as 3-1-4 must never be mistaken for a lane opinion. Keep the
        # judgement inside the same punctuation-delimited clause.
        windows = [c for c in clauses if re.search(rf"(?<!\d){lane}(?:号艇|コース|枠)", c)]
        pos = sum(1 for w in windows if any(k in w for k in positive))
        neg = sum(1 for w in windows if any(k in w for k in negative))
        adj = max(-5.0, min(5.0, (pos-neg) * 2.5))
        if adj:
            out[lane] = adj
            reasons[lane].append(f"自分の見立て {'+' if adj > 0 else ''}{adj:.1f}")
    return {"text": text, "lane_adjustments": out, "reasons": reasons, "combos": combos[:6]}


def _apply_user_combos(rows, combos):
    wanted = set(combos or [])
    if not wanted:
        return rows
    for row in rows:
        if row.get("combo") in wanted:
            row["score"] = round(float(row.get("score") or 0) + 0.08, 4)
            row["user_input"] = True
            odd = row.get("odds")
            row["value_score"] = (
                round(row["score"] * math.log1p(odd), 4)
                if isinstance(odd, (int, float)) and odd > 0 else None
            )
    rows.sort(key=lambda x: x["score"], reverse=True)
    return rows


def _select_picks_with_user(rows, combos, limit=6):
    """Keep data-led candidates while guaranteeing up to 3 explicit user picks."""
    explicit = set((combos or [])[:3])
    selected = [x for x in rows[:max(3, limit-len(explicit))]]
    for combo in (combos or [])[:3]:
        row = next((x for x in rows if x.get("combo") == combo), None)
        if row and not any(x.get("combo") == combo for x in selected):
            selected.append(row)
    for row in rows:
        if len(selected) >= limit:
            break
        if not any(x.get("combo") == row.get("combo") for x in selected):
            selected.append(row)
    return selected[:limit]


def strategy_options(rows):
    """Score-ranked candidates. Synthetic odds assume equalized gross payouts."""
    valid = [dict(x) for x in rows if isinstance(x.get("odds"), (int, float))
             and math.isfinite(x["odds"]) and x["odds"] > 0]
    selected = []
    inverse = 0.0
    for row in sorted(valid, key=lambda x: x["score"], reverse=True):
        nxt = inverse + 1 / row["odds"]
        if nxt <= 1 / 1.5:
            selected.append(row)
            inverse = nxt
        if len(selected) == 6:
            break
    value = sorted(valid, key=lambda x: x.get("value_score") or 0, reverse=True)[:6]
    def pack(picks, name):
        inv = sum(1 / x["odds"] for x in picks)
        return {"label": name, "picks": picks,
                "synthetic_odds": 1 / inv if inv else None,
                "status": "候補あり" if picks else ("オッズ待ち" if not valid else "条件未達・見送り"),
                "allocation": "払戻均等配分（100円単位の丸め前）"}
    return {"hit": pack(selected, "的中率重視"), "return": pack(value, "回収率重視")}


def _scenario(scores, race_map, weather=None, venue_profile=None):
    order = sorted(scores, key=lambda x: scores[x], reverse=True)
    a, b, c = order[:3]
    an = (race_map.get(a) or {}).get("name") or f"{a}号艇"
    bn = (race_map.get(b) or {}).get("name") or f"{b}号艇"

    if a == 1:
        text = f"1号艇{an}を中心にイン先マイ想定。相手筆頭は{b}号艇{bn}、次位は{c}号艇。"
    elif a in (3, 4):
        text = f"{a}号艇{an}のセンター攻めを軸に想定。{b}号艇{bn}を対抗、1号艇の残しも警戒。"
    else:
        text = f"{a}号艇{an}を総合首位評価。{b}号艇{bn}との主導権争いを想定。"

    if weather:
        wind = _num(weather.get("wind_speed_m"))
        wd = weather.get("wind_direction")
        wave = _num(weather.get("wave_height_cm"))
        tide = weather.get("tide_phase")
        bits = []
        if wind is not None:
            bits.append(f"風{wind:g}m/s{(' '+wd) if wd else ''}")
        if wave is not None:
            bits.append(f"波高{wave:g}cm")
        if tide:
            bits.append(f"潮:{tide}")
        if bits:
            text += " 直前水面条件は" + "・".join(bits) + "。"

    vp = venue_profile or {}
    if vp.get("direction"):
        text += " 場傾向：" + vp["direction"] + "。"

    return text


def predict(date, jcd, rno, race, before, odds, venue_documents, *,
            mode="balanced", preview=False, user_insight=""):
    race = race or {}
    before = before or {}
    race_map = _lane_map(race.get("racers") or [])
    before_map = _lane_map(before.get("racers") or [])
    start_map = _lane_map(before.get("start_display") or [])
    original_map = _lane_map(before.get("original_exhibition") or [])
    weather = before.get("weather") or {}
    comments = before.get("comments") or []
    odds_map = _extract_odds(odds)

    venue_profile = build_venue_profile(venue_documents)
    availability = build_availability(
        race, before, odds, venue_documents, venue_profile
    )

    active = [
        lane for lane, r in race_map.items()
        if not r.get("scratched") and str(r.get("status") or "") != "欠場"
    ]
    insight = _parse_user_insight(user_insight, active)
    if len(active) < 3:
        empty_stage = {
            "confidence": 0,
            "scenario": "出走データ不足",
            "picks": [],
            "lane_scores": {},
            "missing": ["出走データ不足"],
        }
        return {
            "confidence": 0,
            "judgement": "見送り",
            "scenario": "出走データ不足",
            "main_picks": [],
            "value_picks": [],
            "leaks": ["出走データ不足"],
            "source_snapshot": {
                "engine": "AI Dual Base v2.1",
                "pre_prediction": empty_stage,
                "post_prediction": empty_stage,
                "availability": availability,
                "venue_profile": venue_profile,
                "post_ready": False,
            },
            "ai_comment": "AI Dual Base v2",
        }

    # ---------- PRE-BEFORE ----------
    pre_scores = {}
    pre_details = {}
    for lane in active:
        score, reasons = _pre_lane_score(lane, race_map[lane])
        score += insight["lane_adjustments"].get(lane, 0.0)
        reasons += insight["reasons"].get(lane, [])
        pre_scores[lane] = score
        pre_details[lane] = {
            "lane": lane,
            "name": race_map[lane].get("name"),
            "score": round(score, 2),
            "reasons": reasons,
        }

    venue_adjustments = _venue_lane_adjustments(active, venue_profile)
    for lane in active:
        adj = venue_adjustments.get(lane) or {}
        pre_scores[lane] += float(adj.get("score") or 0)
        pre_details[lane]["score"] = round(pre_scores[lane], 2)
        pre_details[lane]["reasons"] = (
            pre_details[lane]["reasons"] + (adj.get("reasons") or [])
        )[:12]

    pre_picks, all_pre = _combo_list(
        pre_scores, active, odds_map=odds_map, limit=6,
        venue_profile=venue_profile,
    )
    all_pre = _apply_user_combos(all_pre, insight["combos"])
    pre_picks = _select_picks_with_user(all_pre, insight["combos"], 6)
    pre_missing_keys = {
        "meeting_results": "節間成績",
        "national_lane_results": "全国成績（当該枠/コースデータ優先）",
        "local_lane_results": "当地同枠成績（保存済み公式結果から集計）",
        "motor": "モーター成績",
        "boat": "ボート成績",
    }
    available_map = {x["key"]: x["available"] for x in availability}
    pre_missing = [
        label for key, label in pre_missing_keys.items()
        if not available_map.get(key)
    ]

    pre_order = sorted(pre_scores, key=lambda x: pre_scores[x], reverse=True)
    pre_margin = pre_scores[pre_order[0]] - pre_scores[pre_order[1]]
    pre_conf = max(30, min(88, 48 + pre_margin * 1.4))
    pre_conf *= 1 - min(0.10 * len(pre_missing), 0.45)
    pre_conf = round(pre_conf, 1)

    pre_stage = {
        "confidence": pre_conf,
        "scenario": _scenario(pre_scores, race_map, None, venue_profile),
        "picks": pre_picks,
        "strategies": strategy_options(all_pre),
        "lane_scores": pre_details,
        "missing": pre_missing,
        "basis": [
            "節間成績", "全国成績（当該枠/コース優先）",
            "当地同枠成績", "モーター", "ボート",
            "場別イン・決まり手・出目傾向"
            , "自分の見立て（入力時のみ・補助点）"
        ],
    }

    # ---------- POST-BEFORE ----------
    post_scores = dict(pre_scores)
    post_details = {k: dict(v) for k, v in pre_details.items()}
    original_rel = _original_relative_adjustments(
        before.get("original_exhibition") or []
    )

    for lane in active:
        adj, rs = _post_adjustment(
            lane, race_map[lane], before_map.get(lane, {}),
            start_map.get(lane, {}), original_map.get(lane, {}),
            weather, comments
        )
        adj += original_rel.get(lane, 0.0)
        post_scores[lane] += adj
        post_details[lane]["score"] = round(post_scores[lane], 2)
        post_details[lane]["reasons"] = (
            post_details[lane].get("reasons", []) + rs
        )[:12]

    post_picks, all_post = _combo_list(
        post_scores, active, odds_map=odds_map, limit=6,
        venue_profile=venue_profile,
    )
    all_post = _apply_user_combos(all_post, insight["combos"])
    post_picks = _select_picks_with_user(all_post, insight["combos"], 6)

    value = [
        x for x in all_post
        if x.get("odds") is not None and x["odds"] > 0
    ]
    value.sort(
        key=lambda x: x.get("value_score")
        if x.get("value_score") is not None else -1,
        reverse=True
    )
    value = value[:6]

    post_required = {
        "start_exhibition_st": "スタート展示ST",
        "start_entry": "スタート展示進入/STタイミング",
        "original_exhibition": "オリジナル展示",
        "wind_speed": "風速",
        "wind_direction": "風向",
        "tide": "潮",
        "wave_height": "波高",
        "comments": "選手コメント",
    }
    post_missing = [
        label for key, label in post_required.items()
        if not available_map.get(key)
    ]

    post_order = sorted(post_scores, key=lambda x: post_scores[x], reverse=True)
    margin = post_scores[post_order[0]] - post_scores[post_order[1]]
    confidence = max(32, min(92, 54 + margin * 1.5))
    confidence *= 1 - min(0.055 * len(post_missing), 0.42)
    confidence = round(confidence, 1)

    # "post_ready" means at least core start display + water conditions are present.
    post_ready = bool(
        available_map.get("start_exhibition_st")
        and available_map.get("wind_speed")
        and available_map.get("wave_height")
    )

    post_stage = {
        "confidence": confidence,
        "scenario": _scenario(post_scores, race_map, weather, venue_profile),
        "picks": post_picks,
        "strategies": strategy_options(all_post),
        "lane_scores": post_details,
        "missing": post_missing,
        "basis": [
            "事前予想の基礎データ",
            "スタート展示ST/進入",
            "オリジナル展示",
            "風速・風向",
            "潮",
            "波高",
            "選手コメント",
            "場別イン・決まり手・出目傾向",
            "自分の見立て（入力時のみ・補助点）",
        ],
        "ready": post_ready,
    }

    if confidence >= 72 and post_ready:
        judgement = "勝負候補"
    elif confidence >= 56:
        judgement = "慎重"
    else:
        judgement = "見送り"

    leaks = [x["label"] for x in availability if not x["available"]]

    snapshot = {
        "engine": "AI Dual Base v2.1",
        "generated_at": datetime.now(JST).isoformat(),
        "preview": bool(preview),
        "mode": mode,
        "pre_prediction": pre_stage,
        "post_prediction": post_stage,
        "availability": availability,
        "venue_profile": venue_profile,
        "post_ready": post_ready,
        "user_insight": insight,
    }

    return {
        "confidence": confidence,
        "judgement": judgement,
        "scenario": post_stage["scenario"],
        "main_picks": post_picks,
        "value_picks": value,
        "leaks": leaks,
        "source_snapshot": snapshot,
        "ai_comment": (
            "事前予想と直前予想を分離。×の項目は予想根拠に使用していません。"
            "予想・利益を保証するものではありません。"
        ),
    }
