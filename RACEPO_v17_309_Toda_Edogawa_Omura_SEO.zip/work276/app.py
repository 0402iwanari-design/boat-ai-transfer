from __future__ import annotations

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, Response
import time
from fastapi.staticfiles import StaticFiles

from boat_source import BoatRaceSource
from collector import BackgroundCollector
from venue_knowledge import VenueKnowledgeCollector
from virtual_bets import VirtualBetGame
from trial_backfill import MineInitialScan
from tide_system import TideCollector
from course_history import OfficialCourseHistoryCollector
import auto_deploy
import admin_auth
import threading

app = FastAPI(title="レースポ Backend", version="17.292")

@app.middleware("http")
async def request_performance_middleware(request: Request, call_next):
    """Expose server-side latency separately from browser/network latency."""
    started = time.perf_counter()
    status_code = 500
    try:
        response = await call_next(request)
        status_code = response.status_code
    except Exception:
        elapsed_ms = (time.perf_counter() - started) * 1000
        print(
            f"[PERF] {request.method} {request.url.path} status=500 "
            f"server_ms={elapsed_ms:.1f} exception=1",
            flush=True,
        )
        raise
    elapsed_ms = (time.perf_counter() - started) * 1000
    response.headers["Server-Timing"] = f"app;dur={elapsed_ms:.1f}"
    if elapsed_ms >= 500:
        print(
            f"[PERF] {request.method} {request.url.path} status={status_code} "
            f"server_ms={elapsed_ms:.1f} query={request.url.query[:160]}",
            flush=True,
        )
    return response
# PCでの確認版（localhost）から、ConoHaに蓄積した共通の集計履歴を読めるようにする。
# 許可するのはローカル確認用のURLだけで、外部サイトからの読取りは許可しない。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)

_admin_failed = {}
_admin_failed_lock = threading.Lock()

class AdminLoginPayload(BaseModel):
    username: str
    password: str


@app.get("/api/admin/session")
def admin_session(request: Request):
    return {"authenticated": admin_auth.is_admin(request), "configured": bool(admin_auth.config())}


@app.post("/api/admin/login")
def admin_login(payload: AdminLoginPayload, request: Request):
    # Basic per-address throttling; never put credentials in logs or URLs.
    remote = request.client.host if request.client else "unknown"
    now = time.monotonic()
    with _admin_failed_lock:
        history = [t for t in _admin_failed.get(remote, []) if now - t < 300]
        _admin_failed[remote] = history
        if len(history) >= 8:
            raise HTTPException(429, "ログイン試行が多すぎます。5分後に再試行してください")
    if not admin_auth.authenticate(payload.username, payload.password):
        with _admin_failed_lock:
            _admin_failed[remote] = (_admin_failed.get(remote, []) + [now])[-8:]
        raise HTTPException(401, "IDまたはパスワードが正しくありません")
    with _admin_failed_lock:
        _admin_failed.pop(remote, None)
    response = JSONResponse({"authenticated": True})
    response.set_cookie(admin_auth.COOKIE, admin_auth.issue_session(), max_age=admin_auth.SESSION_SECONDS,
                        httponly=True, secure=request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https",
                        samesite="strict", path="/")
    return response


@app.post("/api/admin/logout")
def admin_logout():
    response = JSONResponse({"authenticated": False})
    response.delete_cookie(admin_auth.COOKIE, path="/", samesite="strict")
    return response


class PredictionPayload(BaseModel):
    confidence: float | None = None
    judgement: str | None = None
    scenario: str | None = None
    main_picks: list = []
    value_picks: list = []
    leaks: list = []
    source_snapshot: dict = {}
    ai_comment: str | None = None

class CommentItem(BaseModel):
    lane: int
    comment: str
    source: str | None = None

class CommentsPayload(BaseModel):
    comments: list[CommentItem]

class UserInsightPayload(BaseModel):
    note: str = ""

source = BoatRaceSource()
collector = BackgroundCollector(source)
knowledge_collector = VenueKnowledgeCollector(source.db)
game = VirtualBetGame(source.db)
mine_initial_scan = MineInitialScan(source)
tide_collector = TideCollector(source.db)
course_history_collector = OfficialCourseHistoryCollector(source.db)

class GameBetPayload(BaseModel):
    date: str
    jcd: str
    rno: int
    combo: str
    amount_yen: int
    odds: float

class GameBatchBetItem(BaseModel):
    combo: str
    amount_yen: int
    odds: float

class GameBatchBetPayload(BaseModel):
    date: str
    jcd: str
    rno: int
    bets: list[GameBatchBetItem]

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/api/deploy/status")
def deploy_status():
    """秘密の値は返さず、GitHub自動更新の準備状態だけを返す。"""
    status = {"configured": auto_deploy.configured(), "state": "not_started"}
    if auto_deploy.STATUS_FILE.is_file():
        try:
            status.update(__import__("json").loads(auto_deploy.STATUS_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return status


@app.post("/api/deploy/github")
async def github_deploy(request: Request, x_hub_signature_256: str | None = Header(default=None)):
    """GitHub push だけを、HMAC署名が一致した場合に限って受け付ける。"""
    payload = await request.body()
    if not auto_deploy.configured():
        raise HTTPException(503, "自動更新の初期設定がまだです")
    if not auto_deploy.verify_signature(payload, x_hub_signature_256):
        raise HTTPException(401, "GitHub署名を確認できません")
    if request.headers.get("x-github-event", "").lower() == "ping":
        return {"ok": True, "message": "GitHub連携を確認しました"}
    try:
        data = __import__("json").loads(payload.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "GitHubの送信内容を読めません")
    if request.headers.get("x-github-event", "").lower() != "push" or data.get("ref") != "refs/heads/main":
        return {"ok": True, "message": "mainブランチのZIP更新ではないため何もしません"}
    if not auto_deploy.queue_deploy():
        return {"ok": True, "message": "すでに更新処理中です"}
    return {"ok": True, "message": "自動更新を開始しました"}

# Public crawler endpoints (v17.305). Only permanent public pages.
@app.get("/sitemap.xml", include_in_schema=False)
def public_sitemap():
    urls = ("https://boat-lens.top/", "https://boat-lens.top/privacy",
            "https://boat-lens.top/terms", "https://boat-lens.top/disclaimer",
            "https://boat-lens.top/kojima", "https://boat-lens.top/toda",
            "https://boat-lens.top/edogawa", "https://boat-lens.top/omura")
    xml = ('<?xml version="1.0" encoding="UTF-8"?>\n'
           '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
           + "".join(f"  <url><loc>{url}</loc></url>\n" for url in urls)
           + '</urlset>\n')
    return Response(content=xml, media_type="application/xml",
                    headers={"Cache-Control": "public, max-age=3600"})

@app.get("/robots.txt", include_in_schema=False)
def public_robots():
    body = ("User-agent: *\n"
            "Disallow: /owner\n"
            "Disallow: /admin/\n"
            "Disallow: /api/\n"
            "Sitemap: https://boat-lens.top/sitemap.xml\n")
    return Response(content=body, media_type="text/plain",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.get("/kojima", include_in_schema=False)
def public_kojima_guide():
    return FileResponse("static/kojima.html", headers={"Cache-Control":"public, max-age=3600"})

# Read-only public aggregate for course / deciding-method analysis.
# This endpoint never writes to SQLite or triggers collection.
_PUBLIC_COURSE_GUIDES = {"kojima": "16", "toda": "02", "edogawa": "03", "omura": "24"}

@app.get("/api/public/{guide}/kimarite", include_in_schema=False)
def public_venue_kimarite(guide: str):
    """Summarize confirmed race results using a verified 6-lane entry mapping."""
    import json as _json
    from collections import Counter
    from fastapi import HTTPException
    jcd = _PUBLIC_COURSE_GUIDES.get(guide)
    if not jcd:
        raise HTTPException(status_code=404, detail="Not Found")
    methods = ("逃げ", "差し", "まくり", "まくり差し", "抜き", "恵まれ")
    counts = {str(c): Counter() for c in range(1, 7)}
    valid, latest = 0, None
    with source.db.connect() as con:
        rows = con.execute(
            """SELECT date,trifecta,kimarite,payload FROM race_results
               WHERE jcd=? AND trifecta IS NOT NULL AND kimarite IS NOT NULL
               ORDER BY date DESC,rno DESC LIMIT 1800""", (jcd,)
        ).fetchall()
    for row in rows:
        method = str(row["kimarite"] or "").strip()
        if method not in methods:
            continue
        first = str(row["trifecta"] or "").split("-")[0]
        if first not in {str(i) for i in range(1, 7)}:
            continue
        try:
            payload = _json.loads(row["payload"] or "{}")
        except (_json.JSONDecodeError, TypeError, ValueError):
            continue
        entries = payload.get("start_courses")
        if not isinstance(entries, list):
            continue
        mapping = {}
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            try:
                lane, course = int(entry.get("lane")), int(entry.get("course"))
            except (TypeError, ValueError):
                continue
            if 1 <= lane <= 6 and 1 <= course <= 6:
                mapping[lane] = course
        if len(mapping) != 6 or len(set(mapping.values())) != 6:
            continue
        course = mapping[int(first)]
        counts[str(course)][method] += 1
        valid += 1
        if latest is None:
            latest = row["date"]
    result = []
    for c in range(1, 7):
        group = counts[str(c)]
        wins = sum(group.values())
        ordered = sorted(group.items(), key=lambda x: (-x[1], methods.index(x[0])))
        result.append({"course": c, "wins": wins,
                       "race_share_pct": round(wins / valid * 100, 1) if valid else None,
                       "methods": [{"name": k, "count": v,
                                    "share_pct": round(v / wins * 100, 1)}
                                   for k, v in ordered]})
    return JSONResponse(content={"sample_races": valid, "latest_date": latest,
                                 "limit": 1800, "courses": result},
                        headers={"Cache-Control": "public, max-age=600"})

@app.get("/toda", include_in_schema=False)
def public_toda_guide():
    return FileResponse("static/toda.html", headers={"Cache-Control":"public, max-age=3600"})

@app.get("/edogawa", include_in_schema=False)
def public_edogawa_guide():
    return FileResponse("static/edogawa.html", headers={"Cache-Control":"public, max-age=3600"})

@app.get("/omura", include_in_schema=False)
def public_omura_guide():
    return FileResponse("static/omura.html", headers={"Cache-Control":"public, max-age=3600"})


@app.get("/privacy")
def policy_privacy():
    return FileResponse("static/privacy.html", headers={"Cache-Control":"no-store"})

@app.get("/terms")
def policy_terms():
    return FileResponse("static/terms.html", headers={"Cache-Control":"no-store"})

@app.get("/disclaimer")
def policy_disclaimer():
    return FileResponse("static/disclaimer.html", headers={"Cache-Control":"no-store"})

@app.get("/")
def index():
    return FileResponse(
        "static/index.html",
        headers={"Cache-Control":"no-store, no-cache, must-revalidate, max-age=0"}
    )

@app.on_event("startup")
async def start_background_collector():
    collector.start()
    knowledge_collector.start()
    tide_collector.start()
    course_history_collector.start()

@app.get("/api/background/status")
def background_status():
    return collector.status

@app.get("/api/tide/status")
def tide_status():
    """潮収集は既存15分前/30秒再試行/最終オッズとは独立。"""
    return tide_collector.status

@app.get("/api/tide/day/{yyyymmdd}")
def tide_day_status(yyyymmdd: str):
    validate_date(yyyymmdd)
    return tide_collector.day_status(yyyymmdd)

@app.post("/api/tide/collect-now")
def tide_collect_now():
    """画面確認用。定期実行と同じ潮専用Collectorだけを手動実行する。"""
    return tide_collector.collect_now(days=7)

@app.get("/api/tide/race-context/{yyyymmdd}/{jcd}")
def tide_race_context(yyyymmdd: str, jcd: str):
    """第3段階: 保存済み潮位・締切時刻・保存済み直前風データから複合水面判定。AI予想にはまだ反映しない。"""
    validate_date(yyyymmdd)
    return tide_collector.race_contexts(yyyymmdd, jcd)

@app.get("/api/venues")
def venues():
    return {"venues": source.venues}

@app.get("/api/day/{yyyymmdd}")
def day(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_fast(yyyymmdd)

@app.get("/api/day-status/{yyyymmdd}")
def day_status(yyyymmdd: str):
    validate_date(yyyymmdd)
    cached = source.cache.get(f"day_v16_{yyyymmdd}", 3600)
    return {
        "official_cached": bool(cached),
        "last_day_scan": collector.status.get("last_day_scan"),
        "collector_message": collector.status.get("last_message"),
    }

@app.get("/api/schedule/{yyyymmdd}/{jcd}")
def race_schedule(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return {
        "date": yyyymmdd,
        "jcd": jcd.zfill(2),
        "races": source.db.get_race_schedule(yyyymmdd, jcd.zfill(2)),
    }

@app.get("/api/race/{yyyymmdd}/{jcd}/{rno}")
def race(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_race(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/game-race/{yyyymmdd}/{jcd}/{rno}")
def game_race(yyyymmdd: str, jcd: str, rno: int):
    """Small DB-only payload for the virtual betting screen.

    It deliberately never fetches/rechecks the official racelist while a
    user is choosing odds, keeping the game screen responsive.
    """
    validate(yyyymmdd, rno)
    jcd = jcd.zfill(2)
    saved = source.db.get_snapshot(yyyymmdd, jcd, rno, "racelist")
    data = (saved or {}).get("data") or {}
    racers = data.get("racers") or []
    return {
        "date": yyyymmdd,
        "jcd": jcd,
        "rno": rno,
        "racers": [
            {"lane": row.get("lane"), "name": row.get("name")}
            for row in racers
        ],
    }

@app.get("/api/before/{yyyymmdd}/{jcd}/{rno}")
def before(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_before_info(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/odds3t/{yyyymmdd}/{jcd}/{rno}")
def odds3t(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_odds3t(yyyymmdd,jcd.zfill(2),rno)

@app.get("/api/game/{yyyymmdd}")
def game_dashboard(yyyymmdd: str):
    validate_date(yyyymmdd)
    return game.dashboard(yyyymmdd)

@app.post("/api/game/bet")
def game_bet(payload: GameBetPayload):
    validate_date(payload.date)
    try:
        return {"wallet": game.place(payload.date, payload.jcd, payload.rno, payload.combo, payload.amount_yen, payload.odds)}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/game/bets")
def game_bets(payload: GameBatchBetPayload):
    """Place a deduplicated set of virtual 3連単 bets in one operation."""
    validate_date(payload.date)
    try:
        rows = [x.model_dump() for x in payload.bets]
        return {"wallet": game.place_many(payload.date, payload.jcd, payload.rno, rows)}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/bundle/{yyyymmdd}/{jcd}/{rno}")
def bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/ui/{yyyymmdd}/{jcd}/{rno}")
def ui_bundle(yyyymmdd: str, jcd: str, rno: int):
    """
    フロント表示用。bundle をそのまま返す薄いエンドポイント。
    将来ここでAI予想・コメント等を統合する。
    """
    validate(yyyymmdd, rno)
    return source.get_bundle(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/cached/{yyyymmdd}/{jcd}/{rno}")
def cached_bundle(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_cached_bundle(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/cached-day/{yyyymmdd}")
def cached_day_racelists(yyyymmdd: str):
    validate_date(yyyymmdd)
    return source.get_day_racelists(yyyymmdd)

@app.get("/api/cached-venue/{yyyymmdd}/{jcd}")
def cached_venue_racelists(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return source.get_venue_racelists(yyyymmdd, jcd.zfill(2))

@app.get("/api/results/{yyyymmdd}/{jcd}")
def results(yyyymmdd: str, jcd: str):
    validate_date(yyyymmdd)
    return source.get_results(yyyymmdd,jcd.zfill(2))

@app.get("/api/history/{jcd}")
def history(jcd: str, limit: int = 100):
    return {"rows": source.db.result_history(jcd.zfill(2), min(max(limit,1),1000))}



@app.get("/api/ai-preview/{yyyymmdd}/{jcd}/{rno}")
def ai_preview(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=False, preview=True,
    )

@app.post("/api/ai-generate/{yyyymmdd}/{jcd}/{rno}")
def ai_generate(
    yyyymmdd: str, jcd: str, rno: int,
    mode: str = "balanced"
):
    validate(yyyymmdd, rno)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode=mode, save=True, preview=False,
    )


@app.post("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def save_prediction(yyyymmdd: str, jcd: str, rno: int, payload: PredictionPayload):
    validate(yyyymmdd,rno)
    return source.save_prediction(yyyymmdd,jcd.zfill(2),rno,payload.model_dump())

@app.get("/api/prediction/{yyyymmdd}/{jcd}/{rno}")
def get_prediction(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return source.get_prediction(yyyymmdd,jcd.zfill(2),rno)

@app.post("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def save_comments(yyyymmdd: str, jcd: str, rno: int, payload: CommentsPayload):
    validate(yyyymmdd,rno)
    return source.save_comments(
        yyyymmdd,jcd.zfill(2),rno,
        [x.model_dump() for x in payload.comments]
    )

@app.get("/api/comments/{yyyymmdd}/{jcd}/{rno}")
def get_comments(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd,rno)
    return {"comments": source.get_comments(yyyymmdd,jcd.zfill(2),rno)}

@app.get("/api/user-insight/{yyyymmdd}/{jcd}/{rno}")
def get_user_insight(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.db.get_user_insight(yyyymmdd, jcd.zfill(2), rno)

@app.post("/api/user-insight/{yyyymmdd}/{jcd}/{rno}")
def save_user_insight(yyyymmdd: str, jcd: str, rno: int, payload: UserInsightPayload):
    validate(yyyymmdd, rno)
    source.db.save_user_insight(yyyymmdd, jcd.zfill(2), rno, payload.note)
    return source.build_ai_prediction(
        yyyymmdd, jcd.zfill(2), rno,
        mode="balanced", save=False, preview=True,
    )

@app.get("/api/compare/{yyyymmdd}/{jcd}/{rno}")
def compare_prediction_result(yyyymmdd: str, jcd: str, rno: int, request: Request):
    admin_auth.require_admin(request)
    validate(yyyymmdd,rno)
    return source.compare(yyyymmdd,jcd.zfill(2),rno)


@app.get("/api/prediction-summary")
def prediction_summary(request: Request, date: str | None = None):
    admin_auth.require_admin(request)
    return source.prediction_summary(date)


@app.get("/api/diagnostic/ohmura")
def diagnostic_ohmura():
    return {
        "errors": collector.status.get("ohmura_errors", []),
        "current_state": collector.status.get("current_state"),
        "current_kind": collector.status.get("current_kind"),
        "current_venue": collector.status.get("current_venue"),
        "current_rno": collector.status.get("current_rno"),
    }


@app.get("/api/revision/{yyyymmdd}/{jcd}/{rno}")
def race_revision(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_race_revision(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/venue-knowledge/status")
def venue_knowledge_status():
    return {
        **knowledge_collector.status,
        "db_summary": source.db.venue_knowledge_summary(),
        "venues": source.db.venue_knowledge_monitor(),
    }

@app.get("/api/venue-profile/{jcd}")
def venue_profile(jcd: str):
    return source.get_current_venue_profile(str(jcd).zfill(2))


@app.get("/api/venue-knowledge/{jcd}")
def venue_knowledge(jcd: str, limit: int = 500):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "sources": source.db.get_venue_knowledge(code, limit),
    }

@app.get("/api/venue-knowledge-text/{jcd}")
def venue_knowledge_text(jcd: str, limit: int = 300):
    code = str(jcd).zfill(2)
    return {
        "jcd": code,
        "documents": source.db.get_venue_knowledge_text(code, limit),
    }


@app.get("/api/health")
def health():
    return {"ok": True, "version": "17.291", "background": collector.status["running"]}

def validate_date(yyyymmdd: str):
    if len(yyyymmdd) != 8 or not yyyymmdd.isdigit():
        raise HTTPException(400,"日付はYYYYMMDD形式")

def validate(yyyymmdd: str, rno: int):
    validate_date(yyyymmdd)
    if not 1 <= rno <= 12:
        raise HTTPException(400,"rnoは1〜12")


@app.get("/api/ai-results/{yyyymmdd}")
def ai_results(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    validate_date(yyyymmdd)
    from review_results import build_review
    return build_review(source.db, yyyymmdd, source.venues)

@app.get("/api/public-race-results/{yyyymmdd}")
def public_race_results(yyyymmdd: str):
    validate_date(yyyymmdd)
    from review_results import build_review
    original = build_review(source.db, yyyymmdd, source.venues)
    allowed = ("rno", "actual", "result_odds", "popularity", "kimarite", "result_confirmed", "result_status")
    return {"date": yyyymmdd, "venues": [
        {"code": v["code"], "name": v["name"], "races": [
            {key: r.get(key) for key in allowed} for r in v.get("races", [])
        ]} for v in original.get("venues", [])
    ]}

@app.get("/api/prediction-learning/{yyyymmdd}")
def prediction_learning(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    validate_date(yyyymmdd)
    from prediction_learning import build_learning_report
    return build_learning_report(source.db, yyyymmdd, source.venues)

# Brief in-process response cache: repeated screen opens and 15-second browser
# polls must not redo the full historical statistics query unnecessarily.
# Keep the existing aggregation and its financial calculations unchanged.
_ai_statistics_cache = {}
_ai_statistics_cache_lock = __import__("threading").Lock()

@app.get("/owner", response_class=HTMLResponse)
def owner_dashboard(request: Request):
    from pathlib import Path
    return HTMLResponse((Path(__file__).parent / "static" / "owner.html").read_text(encoding="utf-8"), headers={"Cache-Control":"no-store", "X-Robots-Tag":"noindex, nofollow", "Referrer-Policy":"same-origin", "Content-Security-Policy":"frame-ancestors 'none'"})

@app.get("/admin/skip-analysis", response_class=HTMLResponse)
def skip_analysis_page(request: Request):
    """Read-only comparison of all bets and historically recommended bets."""
    admin_auth.require_admin(request)
    from skip_analysis import render_skip_analysis
    return HTMLResponse(render_skip_analysis(), headers={"Cache-Control": "no-store"})


@app.get("/api/ai-statistics/{yyyymmdd}")
def ai_statistics(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    validate_date(yyyymmdd)
    now = time.monotonic()
    with _ai_statistics_cache_lock:
        cached = _ai_statistics_cache.get(yyyymmdd)
        if cached and now - cached[0] < 60:
            return cached[1]
    from review_statistics import build_statistics
    result = build_statistics(source.db, yyyymmdd, source.venues)
    with _ai_statistics_cache_lock:
        _ai_statistics_cache[yyyymmdd] = (time.monotonic(), result)
        if len(_ai_statistics_cache) > 8:
            oldest = min(_ai_statistics_cache, key=lambda k: _ai_statistics_cache[k][0])
            _ai_statistics_cache.pop(oldest, None)
    return result

@app.get("/api/prediction-result-review/{yyyymmdd}/{jcd}/{rno}")
def prediction_result_review(yyyymmdd: str, jcd: str, rno: int, request: Request):
    admin_auth.require_admin(request)
    validate(yyyymmdd, rno)
    from prediction_learning import build_detailed_review
    return build_detailed_review(source.db, yyyymmdd, jcd.zfill(2), rno, source.venues)


@app.get("/api/prediction-review-status/{yyyymmdd}")
def prediction_review_status(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    """Fast overview: read persisted state only. Never run AI analysis here."""
    validate_date(yyyymmdd)
    confirmed = source.db.get_confirmed_result_races(yyyymmdd)
    out = []
    with source.db.connect() as con:
        pred_rows = con.execute(
            "SELECT jcd,rno FROM predictions WHERE date=? ORDER BY jcd,rno",
            (yyyymmdd,)
        ).fetchall()
        review_rows = con.execute(
            "SELECT jcd,rno,review_json FROM prediction_result_reviews WHERE date=? ORDER BY jcd,rno",
            (yyyymmdd,)
        ).fetchall()

    saved_by = {}
    for row in pred_rows:
        saved_by.setdefault(str(row["jcd"]).zfill(2), set()).add(int(row["rno"]))

    analyzed_by = {}
    import json as _json
    for row in review_rows:
        try:
            payload = _json.loads(row["review_json"] or "{}")
        except (TypeError, ValueError):
            payload = {}
        if payload.get("status") == "complete":
            analyzed_by.setdefault(str(row["jcd"]).zfill(2), set()).add(int(row["rno"]))

    result_by = {}
    for jcd, rno in confirmed:
        result_by.setdefault(str(jcd).zfill(2), set()).add(int(rno))

    for venue in source.venues:
        code = str(venue.get("code") or venue.get("jcd") or "").zfill(2)
        saved_rnos = sorted(saved_by.get(code, set()))
        result_rnos = sorted(result_by.get(code, set()))
        analyzed_rnos = sorted(analyzed_by.get(code, set()) & set(saved_rnos) & set(result_rnos))
        if not saved_rnos and not result_rnos and not analyzed_rnos:
            continue
        out.append({
            "code": code,
            "saved_rnos": saved_rnos,
            "result_rnos": result_rnos,
            "analyzed_rnos": analyzed_rnos,
            "saved_count": len(saved_rnos),
            "result_count": len(result_rnos),
            "analyzed_count": len(analyzed_rnos),
            "last_analyzed_rno": max(analyzed_rnos) if analyzed_rnos else None,
            "last_result_rno": max(result_rnos) if result_rnos else None,
        })
    return {"date": yyyymmdd, "venues": out}


@app.get("/api/daily-review-summary/{yyyymmdd}")
def daily_review_summary(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    """Daily roll-up. Reads saved rows only; never triggers per-race analysis."""
    validate_date(yyyymmdd)
    import json as _json
    venue_names = {str(v.get("code") or "").zfill(2): v.get("name") for v in source.venues}
    with source.db.connect() as con:
        preds = con.execute("SELECT jcd,rno,source_snapshot FROM predictions WHERE date=? ORDER BY jcd,rno",(yyyymmdd,)).fetchall()
        results = con.execute("SELECT jcd,rno,trifecta,payout_yen,odds FROM race_results WHERE date=? ORDER BY jcd,rno",(yyyymmdd,)).fetchall()
        reviews = con.execute("SELECT jcd,rno,review_json FROM prediction_result_reviews WHERE date=? ORDER BY jcd,rno",(yyyymmdd,)).fetchall()
    result_map={(str(r["jcd"]).zfill(2),int(r["rno"])):dict(r) for r in results if r["trifecta"] and r["payout_yen"] is not None}
    review_map={}
    for r in reviews:
        try: d=_json.loads(r["review_json"] or "{}")
        except Exception: d={}
        if d.get("status")=="complete": review_map[(str(r["jcd"]).zfill(2),int(r["rno"]))]=d
    total_stake=0.0; total_return=0.0; purchased=0; hit=0; pick_total=0
    best=None; worst=None; goods=[]; bads=[]; candidates=[]
    for p in preds:
        key=(str(p["jcd"]).zfill(2),int(p["rno"]))
        try: snap=_json.loads(p["source_snapshot"] or "{}") if isinstance(p["source_snapshot"],str) else (p["source_snapshot"] or {})
        except Exception: snap={}
        stage=snap.get("post_prediction") or snap.get("pre_prediction") or {}
        strategies=stage.get("strategies") or {}
        option=(strategies.get("return") or strategies.get("return_rate") or strategies.get("value")
                or strategies.get("hit") or strategies.get("hit_rate") or strategies.get("accuracy")
                or strategies.get("base") or {})
        raw=option.get("picks") or []
        entries=[]; seen=set()
        for x in raw:
            c=x.get("combo") if isinstance(x,dict) else x
            if not c:
                continue
            c=str(c).replace(" ","").replace("=","-")
            if c in seen:
                continue
            seen.add(c)
            st=None
            if isinstance(x,dict):
                v=x.get("stake_yen",x.get("stake"))
                try: st=float(v) if v is not None else None
                except (TypeError,ValueError): st=None
                if st is not None and st<=0: st=None
            entries.append({"combo":c,"stake":st})
        picks=[x["combo"] for x in entries]
        race_stake=0.0
        if picks:
            if all(x["stake"] is not None for x in entries):
                race_stake=sum(x["stake"] for x in entries)
            else:
                race_stake=5000.0
                fallback=race_stake/len(entries)
                for x in entries: x["stake"]=fallback
            purchased+=1; pick_total+=len(picks); total_stake+=race_stake
        res=result_map.get(key)
        ret=0.0
        if res and picks:
            actual=str(res["trifecta"]).replace(" ","").replace("=","-")
            winner=next((x for x in entries if x["combo"]==actual),None)
            if winner is not None:
                hit+=1
                ret=float(winner.get("stake") or 0)*float(res["odds"] or 0)
                total_return+=ret
        net=ret-race_stake
        item={"jcd":key[0],"venue":venue_names.get(key[0],key[0]),"rno":key[1],"net":round(net)}
        if picks and (best is None or net>best["net"]): best=item
        if picks and (worst is None or net<worst["net"]): worst=item
        rv=review_map.get(key) or {}
        goods += list(rv.get("good_points") or [])
        bads += list(rv.get("bad_points") or [])
        candidates += list(rv.get("learning_candidates") or [])
    def uniq(xs,limit=5):
        out=[]
        for x in xs:
            if x and x not in out: out.append(x)
            if len(out)>=limit: break
        return out
    return {"date":yyyymmdd,"prediction_count":len(preds),"purchased_count":purchased,
            "skip_count":max(0,len(preds)-purchased),"analyzed_count":len(review_map),
            "hit_count":hit,"hit_rate":round(hit/purchased*100,1) if purchased else 0,
            "investment_yen":round(total_stake),"return_yen":round(total_return),
            "net_yen":round(total_return-total_stake),
            "return_rate":round(total_return/total_stake*100,1) if total_stake else 0,
            "avg_picks":round(pick_total/purchased,1) if purchased else 0,
            "best_race":best,"worst_race":worst,
            "good_points":uniq(goods),"bad_points":uniq(bads),
            "learning_candidates":uniq(candidates),
            "learning_policy":"1日だけの結果では重みを変更しません。傾向を蓄積し、十分な件数とバックテストで改善を確認してから学習対象にします。"}


@app.get("/api/result-detail/{yyyymmdd}/{jcd}/{rno}")
def result_detail(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_saved_result_detail(yyyymmdd, jcd.zfill(2), rno)

@app.get("/api/completion/{yyyymmdd}")
def completion(yyyymmdd: str):
    validate_date(yyyymmdd)
    return {"date": yyyymmdd, "completed": [list(x) for x in sorted(source.db.get_confirmed_result_races(yyyymmdd))]}

@app.get("/api/course-history/status")
def course_history_status(request: Request):
    admin_auth.require_admin(request)
    # v17.185: status includes saved-history progress plus final completion.
    return course_history_collector.status

@app.get("/api/course-history/{yyyymmdd}/{jcd}/{rno}")
def course_history(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_course_history_for_race(yyyymmdd, jcd.zfill(2), rno)

@app.get("/api/local-frame-history/{yyyymmdd}/{jcd}/{rno}")
def local_frame_history(yyyymmdd: str, jcd: str, rno: int):
    validate(yyyymmdd, rno)
    return source.get_local_frame_history(yyyymmdd, jcd.zfill(2), rno)


@app.get("/api/trial-racer/4320")
def trial_racer_mine():
    """Safe status endpoint for the 峰竜太-only collection trial."""
    return source.db.get_trial_racer_tracker("4320")

@app.get("/api/racer/{registration_no}")
def racer_data(registration_no: str):
    return source.get_racer_public_data_fast(registration_no)

@app.get("/api/admin/collection-monitor/{yyyymmdd}")
def admin_collection_monitor(yyyymmdd: str, request: Request):
    """Read-only administrative view of collection, reflection, saving, and errors."""
    admin_auth.require_admin(request)
    validate_date(yyyymmdd)
    official = source.db.get_daily_racer_collection_status(yyyymmdd)
    # The status helper reads persisted collection state and does not fetch
    # official site pages. Retain full pending/error details for the owner.
    with source.db.connect() as con:
        records = con.execute(
            "SELECT registration_no,name,status,verified,last_error,updated_at "
            "FROM daily_racer_official_collection WHERE date=? "
            "ORDER BY CASE status WHEN 'failed' THEN 0 WHEN 'collecting' THEN 1 "
            "WHEN 'pending' THEN 2 ELSE 3 END,registration_no",
            (yyyymmdd,),
        ).fetchall()
    official["details"] = [dict(r) for r in records if r["status"] != "complete"][:120]
    return {
        "date": yyyymmdd,
        "official": official,
        "course_history": course_history_collector.status,
        "background": {k: v for k, v in collector.status.items()
                       if isinstance(v, (str, int, float, bool, type(None)))},
        "background_workers": collector.status.get("parallel_racer_active", []),
    }


@app.get("/api/racer-collection-status/{yyyymmdd}")
def racer_collection_status(yyyymmdd: str, request: Request):
    admin_auth.require_admin(request)
    """Progress monitor only; never starts another collection pass."""
    validate_date(yyyymmdd)
    return source.db.get_daily_racer_collection_status(yyyymmdd)


@app.get("/api/trial-racer/4320/start")
def start_trial_racer_mine(days: int = 7):
    """Start the capped, one-racer initial scan from a browser link."""
    return mine_initial_scan.start(days)


@app.get("/api/trial-racer/4320/scan-status")
def trial_racer_mine_scan_status():
    return mine_initial_scan.status


@app.get("/api/official-coverage")
def official_coverage():
    return {"venues": knowledge_collector.coverage, "status": knowledge_collector.status}

@app.post("/api/official-rescan")
def official_rescan():
    return knowledge_collector.request_rescan()
