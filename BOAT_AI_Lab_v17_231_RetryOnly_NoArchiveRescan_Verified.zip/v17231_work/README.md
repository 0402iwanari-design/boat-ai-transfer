BOAT AI Lab v17.231

節間成績・公式確定結果検証復旧版

今回の修正範囲は節間成績のみです。

- スマホ/PC共通の表示側は R / 進入 / ST / 着順 の4段表示を維持。
- 2日目以降の開催場では、現在の出走表HTMLだけに依存しません。
- 今日の開催日数 N を基準に、BOAT RACE公式の過去日出走表から N-1 ... 1日目を公式日数で照合します。
- 同一開催と確認できた過去日のBOAT RACE公式結果を取得し、6艇分の 実進入 / ST / 着順 をDBへ保存します。
- 保存した公式確定結果を登録番号で今日の12Rスナップショットへ反映します。
- 画面のバックグラウンド進捗に、過去何日を検証したか、結果詳細何Rが揃ったか、節間行何件、画面反映何Rかを表示します。
- 過去結果が既に完全保存済みなら再取得しません。
- 同一開催日を公式の開催日数で証明できない場合は、別開催を混ぜず診断理由を表示します。

AI予想、資金配分、コース履歴収集ロジックは変更していません。

v17.231 change
- Error retry phase no longer starts by re-reading the racer's 2026..2020 history.
- When the previous full build ended specifically as "個別レース再試行待ち", only the rows in course_history_failed_candidates are retried.
- If those rows all succeed, the racer is marked complete immediately.
- If some still fail, only those rows stay queued for the next retry cycle.
- Safety guard keeps full-build behavior for crashes/other incomplete states, so retry-only cannot skip unfinished initial history.
