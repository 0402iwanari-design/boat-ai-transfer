"""Small, on-demand historical scan for the 峰竜太 tracker trial.

It is intentionally capped at seven days and one racer.  This validates the
official-page route before any longer, all-active-racer collection is planned.
"""
from __future__ import annotations

import threading
from datetime import datetime, timedelta, timezone

JST = timezone(timedelta(hours=9))


class MineInitialScan:
    def __init__(self, source):
        self.source = source
        self._lock = threading.Lock()
        self.status = {
            "state": "idle", "days": 0, "checked_dates": 0,
            "checked_races": 0, "matches": 0, "last_error": None,
        }

    def start(self, days: int = 7):
        days = max(1, min(int(days), 7))
        with self._lock:
            if self.status["state"] == "running":
                return {**self.status, "started": False}
            self.status = {
                "state": "running", "days": days, "checked_dates": 0,
                "checked_races": 0, "matches": 0, "last_error": None,
            }
            thread = threading.Thread(target=self._run, args=(days,), daemon=True,
                                      name="mine-initial-scan")
            thread.start()
        return {**self.status, "started": True}

    def _run(self, days: int):
        try:
            today = datetime.now(JST).date()
            for offset in range(1, days + 1):
                date = (today - timedelta(days=offset)).strftime("%Y%m%d")
                day = self.source.get_day(date)
                self.status["checked_dates"] += 1
                for venue in day.get("venues") or []:
                    if not venue.get("open"):
                        continue
                    jcd = str(venue.get("code") or "").zfill(2)
                    # The official result list is fetched once per venue.  A
                    # racelist page is then read only for races with results.
                    result_rows = (self.source.get_results(date, jcd).get("results") or [])
                    for result in result_rows:
                        rno = int(result.get("rno") or 0)
                        if not rno:
                            continue
                        race = self.source.get_race(date, jcd, rno)
                        self.status["checked_races"] += 1
                        if any(str(x.get("registration_no") or "") == "4320"
                               for x in race.get("racers") or []):
                            self.source.db.sync_trial_racer_tracker(date, jcd, [result])
                            self.status["matches"] += 1
            self.status["state"] = "complete"
        except Exception as exc:
            self.status["state"] = "error"
            self.status["last_error"] = str(exc)

