from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import uuid4

JST = timezone(timedelta(hours=9), name="JST")
WEEKLY_GRANT = 10_000


class VirtualBetGame:
    """One shared, virtual-only 3連単 game wallet stored in BOAT AI Lab SQLite."""
    def __init__(self, db):
        self.db = db
        self._init()

    @staticmethod
    def _week_key(now=None):
        now = now or datetime.now(JST)
        monday = (now - timedelta(days=now.weekday())).date()
        return monday.isoformat()

    def _init(self):
        with self.db.connect() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS virtual_game_wallet (
              wallet_id INTEGER PRIMARY KEY CHECK(wallet_id=1),
              balance_yen INTEGER NOT NULL,
              last_week TEXT NOT NULL,
              updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS virtual_game_bets (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              date TEXT NOT NULL, jcd TEXT NOT NULL, rno INTEGER NOT NULL,
              combo TEXT NOT NULL, amount_yen INTEGER NOT NULL, odds REAL,
              batch_id TEXT,
              status TEXT NOT NULL DEFAULT '投票済み', payout_yen INTEGER,
              settled_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              UNIQUE(date,jcd,rno,combo,created_at)
            );
            CREATE INDEX IF NOT EXISTS idx_virtual_game_bets_date ON virtual_game_bets(date,jcd,rno);
            """)
            columns = {row["name"] for row in con.execute("PRAGMA table_info(virtual_game_bets)")}
            if "batch_id" not in columns:
                con.execute("ALTER TABLE virtual_game_bets ADD COLUMN batch_id TEXT")

    def wallet(self):
        key = self._week_key()
        with self.db.connect() as con:
            row = con.execute("SELECT balance_yen,last_week FROM virtual_game_wallet WHERE wallet_id=1").fetchone()
            if not row:
                con.execute("INSERT INTO virtual_game_wallet(wallet_id,balance_yen,last_week) VALUES(1,?,?)", (WEEKLY_GRANT, key))
                return {"balance_yen": WEEKLY_GRANT, "week_key": key, "weekly_grant": WEEKLY_GRANT}
            old = datetime.fromisoformat(row["last_week"]).date()
            new = datetime.fromisoformat(key).date()
            weeks = max(0, (new-old).days // 7)
            balance = int(row["balance_yen"]) + weeks * WEEKLY_GRANT
            if weeks:
                con.execute("UPDATE virtual_game_wallet SET balance_yen=?,last_week=?,updated_at=CURRENT_TIMESTAMP WHERE wallet_id=1", (balance,key))
            return {"balance_yen": balance, "week_key": key, "weekly_grant": WEEKLY_GRANT, "added_weeks": weeks}

    def settle(self):
        with self.db.connect() as con:
            rows = con.execute("SELECT id,date,jcd,rno,combo,amount_yen FROM virtual_game_bets WHERE status='投票済み'").fetchall()
            settled = 0
            for b in rows:
                result = con.execute("SELECT trifecta,payout_yen FROM race_results WHERE date=? AND jcd=? AND rno=?", (b["date"],b["jcd"],b["rno"])).fetchone()
                if not result or not result["trifecta"] or result["payout_yen"] is None:
                    continue
                payout = int(result["payout_yen"]) * int(b["amount_yen"]) // 100 if result["trifecta"] == b["combo"] else 0
                con.execute("UPDATE virtual_game_bets SET status=?,payout_yen=?,settled_at=CURRENT_TIMESTAMP WHERE id=?", ("的中" if payout else "不的中", payout, b["id"]))
                if payout:
                    con.execute("UPDATE virtual_game_wallet SET balance_yen=balance_yen+?,updated_at=CURRENT_TIMESTAMP WHERE wallet_id=1", (payout,))
                settled += 1
        return settled

    def place(self, date, jcd, rno, combo, amount, odds):
        return self.place_many(date, jcd, rno, [{"combo": combo, "amount_yen": amount, "odds": odds}])

    def place_many(self, date, jcd, rno, bets):
        """Atomically subtract and save multiple unique 100-yen bets."""
        if not isinstance(bets, list) or not bets:
            raise ValueError("投票する出目を選択してください")
        normalized = {}
        for item in bets:
            combo = str(item.get("combo") or "")
            amount = int(item.get("amount_yen") or 0)
            if amount < 100 or amount % 100:
                raise ValueError("投票額は100円単位で入力してください")
            parts = combo.split("-")
            if len(parts) != 3 or any(x not in {"1","2","3","4","5","6"} for x in parts) or len(set(parts)) != 3:
                raise ValueError("正しい3連単の組番を選択してください")
            # Same combination selected in odds / popularity / formation becomes one bet.
            normalized[combo] = {"amount_yen": amount, "odds": float(item.get("odds") or 0)}
        total = sum(x["amount_yen"] for x in normalized.values())
        self.settle()
        info = self.wallet()
        if info["balance_yen"] < total:
            raise ValueError("残高が足りません")
        jcd = str(jcd).zfill(2)
        batch_id = uuid4().hex
        if self.db.get_result_for_race_db(date, jcd, int(rno)):
            raise ValueError("結果が確定したレースには投票できません")
        with self.db.connect() as con:
            con.execute("UPDATE virtual_game_wallet SET balance_yen=balance_yen-?,updated_at=CURRENT_TIMESTAMP WHERE wallet_id=1", (total,))
            for combo, item in normalized.items():
                con.execute("INSERT INTO virtual_game_bets(date,jcd,rno,combo,amount_yen,odds,batch_id) VALUES(?,?,?,?,?,?,?)", (date,jcd,int(rno),combo,item["amount_yen"],item["odds"],batch_id))
        return self.wallet()

    def _legacy_place(self, date, jcd, rno, combo, amount, odds):
        amount = int(amount)
        if amount < 100 or amount % 100:
            raise ValueError("投票額は100円単位で入力してください")
        if not isinstance(combo, str) or len(combo.split("-")) != 3:
            raise ValueError("3連単の組番を選択してください")
        self.settle()
        info = self.wallet()
        if info["balance_yen"] < amount:
            raise ValueError("残高が足りません")
        if self.db.get_result_for_race_db(date, jcd, int(rno)):
            raise ValueError("結果が確定したレースには投票できません")
        with self.db.connect() as con:
            con.execute("UPDATE virtual_game_wallet SET balance_yen=balance_yen-?,updated_at=CURRENT_TIMESTAMP WHERE wallet_id=1", (amount,))
            con.execute("INSERT INTO virtual_game_bets(date,jcd,rno,combo,amount_yen,odds) VALUES(?,?,?,?,?,?)", (date,str(jcd).zfill(2),int(rno),combo,amount,float(odds)))
        return self.wallet()

    def dashboard(self, date):
        self.settle()
        info = self.wallet()
        with self.db.connect() as con:
            bets = [dict(x) for x in con.execute("SELECT * FROM virtual_game_bets WHERE date=? ORDER BY id ASC", (date,)).fetchall()]
            high = [dict(x) for x in con.execute("SELECT * FROM virtual_game_bets WHERE status='的中' ORDER BY odds DESC,id DESC LIMIT 10").fetchall()]
            payout = [dict(x) for x in con.execute("SELECT * FROM virtual_game_bets WHERE status='的中' ORDER BY payout_yen DESC,id DESC LIMIT 10").fetchall()]
        return {"wallet":info,"bets":bets,"high_odds":high,"payout_ranking":payout}
