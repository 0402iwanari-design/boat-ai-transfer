
import io
import re
import requests

TODA_JCD = "02"
TODA_PDF_URL = "https://www.boatrace-toda.jp/pdf/{date}_kenkyu.pdf?ver=1"


def _clean(s):
    return re.sub(r"\s+", " ", str(s or "")).strip()


def _pdf_text_from_bytes(data: bytes) -> str:
    """
    Use pypdf when available.  The launcher already installs Python packages;
    this module fails softly if pypdf is unavailable.
    """
    try:
        from pypdf import PdfReader
    except Exception:
        return ""

    try:
        reader = PdfReader(io.BytesIO(data))
        parts = []
        for page in reader.pages:
            parts.append(page.extract_text() or "")
        return "\n".join(parts)
    except Exception:
        return ""


def _normalize_name(name: str) -> str:
    # PDFs frequently insert spaces between family/given name.
    return re.sub(r"[\s　]+", "", str(name or ""))


def _comment_candidates(text: str):
    """
    Pull short human-language lines from Toda's research paper.
    This deliberately avoids treating numeric/statistical rows as comments.
    """
    rows = []
    for raw in text.splitlines():
        line = _clean(raw)
        if not line:
            continue
        if len(line) < 4 or len(line) > 90:
            continue
        # Ignore lines dominated by figures/symbols.
        digit_ratio = sum(ch.isdigit() for ch in line) / max(1, len(line))
        if digit_ratio > 0.32:
            continue
        if re.fullmatch(r"[0-9０-９\s./%→←\-]+", line):
            continue
        rows.append(line)
    return rows


def parse_toda_comments(pdf_text: str, racers: list, rno: int):
    """
    Pilot parser.

    Toda's paper layout changes occasionally, so we anchor on racer names:
      racer name -> nearby short Japanese sentence -> comment

    We only accept a comment when a racer name is found in the extracted PDF
    text.  This prevents comments being attached to the wrong racer.
    """
    normalized_text = _normalize_name(pdf_text)
    lines = _comment_candidates(pdf_text)

    out = []

    for racer in racers or []:
        lane = racer.get("lane")
        name = _clean(racer.get("name"))
        compact_name = _normalize_name(name)

        if not compact_name or compact_name not in normalized_text:
            continue

        # Find lines around the name in extracted order.
        idxs = []
        for i, line in enumerate(lines):
            if compact_name in _normalize_name(line):
                idxs.append(i)

        best = None
        for idx in idxs:
            nearby = lines[max(0, idx - 4): min(len(lines), idx + 6)]
            for candidate in nearby:
                c = candidate
                ccompact = _normalize_name(c)
                if compact_name in ccompact:
                    # If same line contains text after the name, use tail.
                    pos = ccompact.find(compact_name)
                    # Work with original line approximately; safe fallback below.
                    tail = re.sub(
                        r"^.*?" + re.escape(name).replace(r"\ ", r"\s*"),
                        "",
                        c,
                        count=1
                    )
                    tail = _clean(tail).lstrip("：:・- ")
                    if len(tail) >= 4 and not re.match(r"^[0-9０-９]", tail):
                        best = tail[:160]
                        break
                    continue

                # Nearby sentence candidate: avoid headers/stat lines.
                if any(k in c for k in [
                    "勝率", "展示", "モーター", "ボート", "進入",
                    "ST", "着", "連率", "登録", "級別", "支部"
                ]):
                    continue
                if len(c) >= 5:
                    best = c[:160]
                    break
            if best:
                break

        if best:
            out.append({
                "lane": lane,
                "name": name,
                "comment": best,
                "source": "boatrace-toda.jp",
                "source_kind": "toda_kenkyu_pdf",
            })

    return out


def fetch_toda_comments(date: str, rno: int, racers: list):
    url = TODA_PDF_URL.format(date=date)
    try:
        resp = requests.get(
            url,
            timeout=(5.0, 18.0),
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 Chrome/140 Safari/537.36"
                )
            },
        )
        resp.raise_for_status()
    except Exception as e:
        return {
            "ok": False,
            "comments": [],
            "source_url": url,
            "reason": f"戸田公式コメントPDF取得失敗: {e}",
        }

    text = _pdf_text_from_bytes(resp.content)
    if not text:
        return {
            "ok": False,
            "comments": [],
            "source_url": url,
            "reason": "戸田公式PDFの文字抽出に失敗（pypdf未導入またはPDF構造非対応）",
        }

    comments = parse_toda_comments(text, racers, int(rno))

    return {
        "ok": bool(comments),
        "comments": comments,
        "source_url": url,
        "reason": None if comments else "戸田公式PDF内で選手コメントを対応付けできませんでした",
    }


def fetch_venue_comments(date: str, jcd: str, rno: int, racers: list):
    """
    Venue adapter dispatcher.
    Start with Toda only.  Other venues can be added independently later.
    """
    jcd = str(jcd).zfill(2)

    if jcd == TODA_JCD:
        return fetch_toda_comments(date, rno, racers)

    return {
        "ok": False,
        "comments": [],
        "source_url": None,
        "reason": "このレース場はコメント取得アダプター未対応です",
    }
