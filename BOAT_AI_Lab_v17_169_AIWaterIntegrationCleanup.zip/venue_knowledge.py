from __future__ import annotations

import json
import unicodedata
from datetime import datetime, timezone, timedelta
import hashlib
import io
import os
import re
import threading
import time
from collections import deque
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag

import requests
from bs4 import BeautifulSoup

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None


VENUE_NAMES = {
    "01": "桐生", "02": "戸田", "03": "江戸川", "04": "平和島",
    "05": "多摩川", "06": "浜名湖", "07": "蒲郡", "08": "常滑",
    "09": "津", "10": "三国", "11": "びわこ", "12": "住之江",
    "13": "尼崎", "14": "鳴門", "15": "丸亀", "16": "児島",
    "17": "宮島", "18": "徳山", "19": "下関", "20": "若松",
    "21": "芦屋", "22": "福岡", "23": "唐津", "24": "大村",
}

# Venue official sites. These are only crawl seeds; links are discovered
# from the public official pages themselves.
VENUE_SEEDS = {
    "01": ["https://www.kiryu-kyotei.com/"],
    "02": [
        "https://www.boatrace-toda.jp/",
        "https://www.boatrace-toda.jp/book/kouryakubook.html",
    ],
    "03": ["https://www.boatrace-edogawa.com/"],
    "04": ["https://www.heiwajima.gr.jp/"],
    "05": ["https://www.boatrace-tamagawa.com/"],
    "06": ["https://www.boatrace-hamanako.jp/"],
    "07": ["https://www.gamagori-kyotei.com/"],
    "08": ["https://www.boatrace-tokoname.jp/"],
    "09": ["https://www.boatrace-tsu.com/"],
    "10": ["https://www.boatrace-mikuni.jp/"],
    "11": ["https://www.boatrace-biwako.jp/"],
    "12": ["https://www.boatrace-suminoe.jp/"],
    "13": ["https://www.boatrace-amagasaki.jp/"],
    "14": ["https://www.n14.jp/"],
    "15": ["https://www.marugameboat.jp/"],
    "16": ["https://www.kojimaboat.jp/"],
    "17": ["https://www.boatrace-miyajima.com/"],
    "18": ["https://www.boatrace-tokuyama.jp/"],
    "19": ["https://www.boatrace-shimonoseki.jp/"],
    "20": ["https://www.wmb.jp/"],
    "21": ["https://www.boatrace-ashiya.com/"],
    "22": ["https://www.boatrace-fukuoka.com/"],
    "23": ["https://www.boatrace-karatsu.jp/"],
    "24": ["https://omurakyotei.jp/"],
}

try:
    for entry in json.loads((Path(__file__).parent / "official_sources.json").read_text(encoding="utf-8")):
        code, url = entry["jcd"], entry["url"]
        if code in VENUE_SEEDS and url not in VENUE_SEEDS[code]:
            VENUE_SEEDS[code].append(url)
except (OSError, ValueError, KeyError):
    pass

SCAN_VERSION = "17.134-user-venue-sources-1"

# The user supplied these observations together with screenshots from the
# venue guides.  They are stored as an explicit source instead of being mixed
# into scraped text, so the AI can use them even when a source site is slow or
# changes its markup.
USER_VENUE_NOTES = {
    "01": "桐生は淡水。水面は硬く、艇が跳ねやすい。荒水面では旋回・波乗り適性を重視する。",
    "02": "戸田は淡水。水面は硬く、艇が跳ねやすい。狭い水面のため展示の旋回と舟の跳ね方を重視する。",
    "03": "江戸川の進入は基本的に枠なり。ただし実際のスタート展示進入を優先する。",
}

RELEVANT_WORDS = (
    "出目", "展示", "オリジナル", "一周", "直線", "周り足", "回り足", "展示タイム", "exhibition", "suimen", "deme", "time",
    "データ", "攻略", "舟券", "水面", "コース", "傾向", "統計", "成績",
    "決まり手", "モーター", "ボート", "レーサー", "選手", "スタート",
    "潮", "風", "気象", "進入", "勝率", "入着", "book", "data",
    "guide", "pdf", "download", "statistics", "record",
)

SKIP_WORDS = (
    "login", "member", "vote", "投票", "ticket", "shop", "goods",
    "privacy", "contact", "recruit", "facebook", "twitter", "instagram",
    "youtube", "javascript:", "mailto:", "tel:",
)

FILE_EXTS = (".pdf", ".csv", ".xlsx", ".xls", ".zip", ".lzh", ".txt")


CHARACTERISTIC_KEYWORDS = (
    "1マーク", "2マーク", "１マーク", "２マーク", "ターンマーク",
    "水面", "水質", "コース幅", "幅", "距離", "バック", "ホーム",
    "ピット", "進入", "風", "向かい風", "追い風", "横風",
    "潮", "満潮", "干潮", "潮位", "うねり", "波",
    "淡水", "海水", "汽水", "イン", "センター", "アウト",
    "逃げ", "差し", "まくり", "まくり差し", "伸び", "出足",
    "旋回", "護岸", "建物", "防風",
)

FALLBACK_SUMMARY_URLS = (
    ("艇脳 24場特徴ガイド", "https://www.boatrace-stats.com/guides/venue-guide"),
    ("BOATCRAFT 24場ガイド", "https://yutakacraft.jp/boatcraft/venues"),
)


def extract_official_combos(soup, source_url):
    """Only explicit combination/share columns; never infer from high-payout tables."""
    found = []
    for table in soup.find_all("table"):
        headers = [unicodedata.normalize("NFKC", x.get_text(" ", strip=True)) for x in table.find_all("th")]
        if not any("出目" in x or "組番" in x for x in headers):
            continue
        if not any(any(k in x for k in ("占有率", "出現率", "割合")) for x in headers):
            continue
        for tr in table.find_all("tr"):
            cells = [unicodedata.normalize("NFKC", x.get_text(" ", strip=True)) for x in tr.find_all("td", recursive=False)]
            combinations = []
            rates = []
            for cell in cells:
                m = re.fullmatch(r"([1-6])\s*[-－→ ]\s*([1-6])\s*[-－→ ]\s*([1-6])", cell)
                if m and len(set(m.groups())) == 3:
                    combinations.append("-".join(m.groups()))
                m = re.fullmatch(r"(\d{1,3}(?:\.\d+)?)\s*%", cell)
                if m and 0 <= float(m.group(1)) <= 100:
                    rates.append(float(m.group(1)))
            if len(combinations) == 1 and len(rates) == 1:
                found.append({"combo":combinations[0],"rate":rates[0],"source_url":source_url})
    return found


class VenueKnowledgeCollector:
    """
    Low-priority collector for public venue-characteristic material.

    It is intentionally independent from the live race collector:
    a slow venue site cannot block racelist/odds/before/result updates.
    """

    def __init__(self, db):
        self.db = db
        self.running = False
        self.rescan = threading.Event()
        self.thread = None
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 Chrome/140 Safari/537.36 "
                "BOAT-AI-Lab-personal-research"
            ),
            "Accept-Language": "ja,en;q=0.7",
        })

        local_app = os.environ.get("LOCALAPPDATA") or str(Path.home())
        self.file_root = Path(local_app) / "BOAT_AI_Lab" / "venue_knowledge_files"
        self.file_root.mkdir(parents=True, exist_ok=True)
        self.coverage = {}
        for code in VENUE_NAMES:
            record = self.db.get_snapshot("00000000", code, 0, "official-deep-scan")
            if record:
                self.coverage[code] = record.get("data") or {}

        self.status = {
            "running": False,
            "phase": "待機中",
            "current_jcd": None,
            "current_venue": None,
            "current_url": None,
            "venues_done": 0,
            "venues_total": 24,
            "pages_saved": 0,
            "files_saved": 0,
            "errors": 0,
            "last_error": None,
            "last_completed_at": None,
            "next_full_scan": "起動後に公式資料を巡回",
            "venues_skipped_saved": 0,
            "official_retries": 0,
            "fallback_used": 0,
            "quality_rechecks": 0,
            "current_stage": "待機中",
            "current_attempt": 0,
        }

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.running = True
        self.status["running"] = True
        self.thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="venue-knowledge",
        )
        self.thread.start()

    def stop(self):
        self.running = False
        self.status["running"] = False

    def _sleep(self, seconds):
        end = time.time() + seconds
        while self.running and time.time() < end:
            time.sleep(min(1.0, end - time.time()))

    def _normalize_url(self, base, href):
        if not href:
            return None
        href = href.strip()
        low = href.lower()
        if any(x in low for x in SKIP_WORDS):
            return None
        url = urljoin(base, href)
        url, _ = urldefrag(url)
        if not url.startswith(("http://", "https://")):
            return None
        return url

    def _host_key(self, url):
        host = (urlparse(url).hostname or "").lower()
        return host[4:] if host.startswith("www.") else host

    def _same_site(self, seed, url):
        a = self._host_key(seed)
        b = self._host_key(url)
        return bool(a and b and (a == b or b.endswith("." + a) or a.endswith("." + b)))

    def _is_relevant(self, label):
        s = (label or "").lower()
        return any(w.lower() in s for w in RELEVANT_WORDS)

    def _save_record(self, jcd, source_url, source_kind, title, text, local_path=None):
        clean = re.sub(r"\s+", " ", text or "").strip()
        digest = hashlib.sha256((clean or source_url).encode("utf-8", "ignore")).hexdigest()
        self.db.save_venue_knowledge(
            jcd=jcd,
            venue=VENUE_NAMES.get(jcd, jcd),
            source_url=source_url,
            source_kind=source_kind,
            title=title or "",
            content_text=clean,
            content_hash=digest,
            local_path=str(local_path) if local_path else None,
        )
        self.status["pages_saved"] += 1
        report = self.coverage.get(jcd)
        if report is not None:
            report["saved"] += 1
            # Report finding relevant material, not proof that race-specific values were parsed.
            for category, terms in {"出目資料": ("出目", "3連単出目", "３連単出目"),
                                    "展示資料": ("オリジナル展示", "一周", "周り足", "回り足", "直線タイム"),
                                    "水面資料": ("水面特性", "進入コース", "潮位")}.items():
                if any(term in clean for term in terms) and len(clean) >= 120:
                    refs = report["categories"].setdefault(category, [])
                    if source_url not in refs:
                        refs.append(source_url)

    def _save_binary(self, jcd, url, data):
        ext = Path(urlparse(url).path).suffix.lower() or ".bin"
        name = hashlib.sha256(url.encode("utf-8")).hexdigest()[:24] + ext
        d = self.file_root / jcd
        d.mkdir(parents=True, exist_ok=True)
        p = d / name
        p.write_bytes(data)
        self.status["files_saved"] += 1
        return p

    def _decode_text(self, response):
        enc = response.encoding
        if not enc or enc.lower() in ("iso-8859-1", "ascii"):
            enc = response.apparent_encoding or "utf-8"
        try:
            return response.content.decode(enc, errors="replace")
        except Exception:
            return response.text

    def _fetch_one(self, jcd, url):
        self.status["current_url"] = url
        r = self.session.get(url, timeout=(7, 20), allow_redirects=True)
        r.raise_for_status()

        final_url = r.url
        content_type = (r.headers.get("content-type") or "").lower()
        path_ext = Path(urlparse(final_url).path).suffix.lower()

        # Avoid unexpectedly huge files.
        if len(r.content) > 25 * 1024 * 1024:
            raise RuntimeError("25MBを超えるため保存を見送り")

        if "pdf" in content_type or path_ext == ".pdf":
            local = self._save_binary(jcd, final_url, r.content)
            text = ""
            if PdfReader is not None:
                try:
                    reader = PdfReader(io.BytesIO(r.content))
                    chunks = []
                    for page in reader.pages[:300]:
                        chunks.append(page.extract_text() or "")
                    text = "\n".join(chunks)
                except Exception:
                    text = ""
            self._save_record(
                jcd, final_url, "venue-official-pdf",
                Path(urlparse(final_url).path).name, text, local
            )
            return [], True

        if path_ext in FILE_EXTS and path_ext != ".pdf":
            local = self._save_binary(jcd, final_url, r.content)
            text = ""
            if path_ext in (".csv", ".txt"):
                text = self._decode_text(r)
            self._save_record(
                jcd, final_url, "venue-official-file",
                Path(urlparse(final_url).path).name, text, local
            )
            return [], True

        if "html" not in content_type and not final_url.endswith(("/", ".htm", ".html", ".php")):
            return [], False

        html = self._decode_text(r)
        soup = BeautifulSoup(html, "html.parser")
        local = self._save_binary(jcd, final_url + ".html" if not path_ext else final_url, r.content)
        # Record script/iframe origins for per-site diagnostics; do not guess JSON fields.
        embedded = [(tag.get("src"), True) for tag in soup.find_all("iframe", src=True)]
        report = self.coverage.get(jcd)
        if report is not None:
            refs = [urljoin(final_url, tag.get("src")) for tag in soup.find_all("script", src=True)]
            report.setdefault("script_sources", {})[final_url] = refs[:30]
        for tag in soup(["script", "style", "noscript", "svg"]):
            tag.decompose()

        title = soup.title.get_text(" ", strip=True) if soup.title else ""
        combos = extract_official_combos(soup, final_url)
        for tag in soup.select("nav,header,footer"):
            tag.decompose()
        text = soup.get_text("\n", strip=True)
        if combos:
            text += "\n" + "\n".join(f"公式3連単出目統計 {x['combo']} {x['rate']}%" for x in combos)
            if report is not None:
                report.setdefault("parsed_combo_sources", {})[final_url] = combos
        self._save_record(
            jcd, final_url, "venue-official-html", title, text, local
        )

        links = [(urljoin(final_url, url), True) for url, _ in embedded]
        for a in soup.find_all("a", href=True):
            href = self._normalize_url(final_url, a.get("href"))
            if not href:
                continue
            label = (a.get_text(" ", strip=True) + " " + a.get("href", "")).strip()
            links.append((href, self._is_relevant(label)))
        return links, False

    def _crawl_venue(self, jcd):
        seeds = VENUE_SEEDS.get(jcd) or []
        if not seeds:
            return

        visited = set()
        q = deque((s, 0, True) for s in seeds)
        max_pages = 160
        max_depth = 4
        saved = 0
        attempts = 0

        while self.running and q and attempts < max_pages:
            url, depth, forced = q.popleft()
            if url in visited:
                continue
            visited.add(url)
            attempts += 1

            if not any(self._same_site(seed, url) for seed in seeds):
                continue

            try:
                links, is_file = self._fetch_one(jcd, url)
                saved += 1
            except Exception as e:
                self.status["errors"] += 1
                self.status["last_error"] = f"{jcd} {url}: {e}"
                self.coverage[jcd]["failed"].append({"url": url, "error": str(e)[:250]})
                self._sleep(0.8)
                continue

            if depth >= max_depth or is_file:
                self._sleep(0.55)
                continue

            # Depth 0: discover the site's sections broadly.
            # Depth 1+: continue only through data/strategy/statistics-like links.
            priority = []
            normal = []
            for href, relevant in links:
                if href in visited:
                    continue
                if not any(self._same_site(seed, href) for seed in seeds):
                    continue
                if relevant or Path(urlparse(href).path).suffix.lower() in FILE_EXTS:
                    priority.append((href, depth + 1, relevant))
                elif depth == 0:
                    normal.append((href, depth + 1, False))

            # Relevant material first so data files are not starved by nav pages.
            for item in priority[:80]:
                q.append(item)
            for item in normal[:40]:
                q.append(item)

            self._sleep(0.8)
        self.coverage[jcd]["visited"] = len(visited)
        self.coverage[jcd]["remaining_queue"] = len(q)
        self.coverage[jcd]["limited"] = bool(q)

    def _save_boatrace_official_stadium_data(self, jcd):
        """
        Try the current BOAT RACE official venue page first.
        Keep the old data URL as a compatibility fallback.
        """
        urls = [
            f"https://www.boatrace.jp/owpc/pc/site/place/stadium/br{jcd}/",
            f"https://www.boatrace.jp/owpc/pc/data/stadium?jcd={jcd}",
        ]
        errors = []

        for url in urls:
            try:
                self.status["current_url"] = url
                r = self.session.get(url, timeout=(7, 20))
                r.raise_for_status()
                soup = BeautifulSoup(self._decode_text(r), "html.parser")
                for tag in soup(["script", "style", "noscript", "svg"]):
                    tag.decompose()

                title = soup.title.get_text(" ", strip=True) if soup.title else ""
                text = soup.get_text("\n", strip=True)

                # Avoid treating a generic error/redirect page as venue material.
                score = sum(1 for k in CHARACTERISTIC_KEYWORDS if k in text)
                if len(text) < 120 or score < 2:
                    raise ValueError(
                        f"場特性本文が不足 text={len(text)} keyword_score={score}"
                    )

                self._save_record(
                    jcd, r.url, "boatrace-official-stadium", title, text
                )
                return True
            except Exception as ex:
                errors.append(f"{url}: {ex}")

        raise RuntimeError(" / ".join(errors))


    def _knowledge_quality(self, jcd):
        docs = self.db.get_venue_knowledge_text(jcd, 600)
        source_count = len(docs)
        keyword_hits = 0
        useful_docs = 0
        total_chars = 0

        for doc in docs:
            text = (doc.get("content_text") or "")
            total_chars += len(text)
            hits = sum(1 for k in CHARACTERISTIC_KEYWORDS if k in text)
            keyword_hits += hits
            if hits >= 2 and len(text) >= 120:
                useful_docs += 1

        # One genuinely useful official page is enough. Do not require dozens
        # of pages; page count alone is not quality.
        good = (
            useful_docs >= 1
            and keyword_hits >= 3
            and total_chars >= 200
        )

        return {
            "good": good,
            "source_count": source_count,
            "useful_docs": useful_docs,
            "keyword_hits": keyword_hits,
            "total_chars": total_chars,
        }


    def _extract_fallback_segment(self, full_text, venue_name):
        """
        External 24-venue guides contain all venues on one page.
        Extract only the requested venue's neighborhood so other venues do not
        leak into this venue's AI profile.
        """
        text = re.sub(r"\s+", " ", full_text or "").strip()
        if not text:
            return ""

        positions = [m.start() for m in re.finditer(re.escape(venue_name), text)]
        if not positions:
            return ""

        venue_names = list(VENUE_NAMES.values())
        best = ""

        for pos in positions:
            end = min(len(text), pos + 4500)

            # Stop when another venue heading appears after enough room.
            for other in venue_names:
                if other == venue_name:
                    continue
                q = text.find(other, pos + max(80, len(venue_name)))
                if q != -1:
                    end = min(end, q)

            segment = text[max(0, pos - 160):end].strip()
            score = sum(1 for k in CHARACTERISTIC_KEYWORDS if k in segment)

            if score > sum(1 for k in CHARACTERISTIC_KEYWORDS if k in best):
                best = segment

        return best[:5000]


    def _fetch_external_fallback(self, jcd):
        venue_name = VENUE_NAMES[jcd]
        saved = 0

        for title, url in FALLBACK_SUMMARY_URLS:
            try:
                self.status["current_url"] = url
                r = self.session.get(url, timeout=(7, 20), allow_redirects=True)
                r.raise_for_status()
                soup = BeautifulSoup(self._decode_text(r), "html.parser")
                for tag in soup(["script", "style", "noscript", "svg"]):
                    tag.decompose()
                full_text = soup.get_text("\n", strip=True)
                segment = self._extract_fallback_segment(
                    full_text, venue_name
                )

                hits = sum(
                    1 for k in CHARACTERISTIC_KEYWORDS if k in segment
                )
                if len(segment) < 80 or hits < 2:
                    continue

                self._save_record(
                    jcd,
                    url,
                    "external-summary-fallback",
                    f"{title} / {venue_name}",
                    segment,
                )
                saved += 1
            except Exception as ex:
                self.status["last_error"] = (
                    f"外部まとめ {venue_name}: {ex}"
                )

            self._sleep(0.8)

        if saved:
            self.status["fallback_used"] += 1
        return saved



    def request_rescan(self):
        self.rescan.set()
        return {"queued": True, "message": "公式資料の再収集を予約しました"}

    def scan_all(self, force=False):
        self.status.update(phase="24場の公式資料を再確認中", venues_done=0,
                           pages_saved=0, files_saved=0, venues_skipped_saved=0)
        for code in VENUE_NAMES:
            if not self.running:
                return
            previous = self.coverage.get(code) or {}
            if not force and previous.get("version") == SCAN_VERSION and previous.get("status") == "収集済（公開リンクの範囲）":
                self.status["venues_done"] += 1
                self.status["venues_skipped_saved"] += 1
                continue
            report = {"version": SCAN_VERSION, "venue": VENUE_NAMES[code], "saved": 0,
                      "visited": 0, "failed": [], "categories": {}, "status": "収集中",
                      "started_at": datetime.now(timezone(timedelta(hours=9))).isoformat()}
            self.coverage[code] = report
            self.status.update(current_jcd=code, current_venue=VENUE_NAMES[code],
                               current_stage="出目・展示・水面の公式資料を巡回中", current_attempt=1)
            self.db.mark_venue_knowledge_incomplete(code)
            if code in USER_VENUE_NOTES:
                self._save_record(
                    code,
                    "user://venue-observation/" + code,
                    "user-provided-venue-note",
                    f"{VENUE_NAMES[code]} 水面補足",
                    USER_VENUE_NOTES[code],
                )
            try:
                self._save_boatrace_official_stadium_data(code)
            except Exception as e:
                report["failed"].append({"url": "BOAT RACE場データ", "error": str(e)[:250]})
            self._crawl_venue(code)
            # Unknown dynamic/embedded tables are never labelled as fully collected.
            missing = [x for x in ("出目資料", "展示資料", "水面資料") if not report["categories"].get(x)]
            report["unconfirmed"] = missing
            report["status"] = "要確認" if missing or report["failed"] or report.get("limited") else "収集済（公開リンクの範囲）"
            report["finished_at"] = datetime.now(timezone(timedelta(hours=9))).isoformat()
            self.db.save_snapshot("00000000", code, 0, "official-deep-scan", report)
            (self.file_root / (code + "_coverage.json")).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
            if report["status"].startswith("収集済"):
                self.db.mark_venue_knowledge_complete(code)
            self.status["venues_done"] += 1
        self.status.update(phase="公式巡回終了・未確認項目は場別記録を参照", current_jcd=None,
                           current_venue=None, current_url=None, current_stage="巡回終了",
                           next_full_scan="再収集ボタンで再実行", last_completed_at=datetime.now(timezone(timedelta(hours=9))).isoformat())

    def _run(self):
        self._sleep(20)
        while self.running:
            force = self.rescan.is_set()
            self.rescan.clear()
            try:
                self.scan_all(force=force)
            except Exception as e:
                self.status.update(last_error=str(e), phase="公式資料収集エラー")
            while self.running and not self.rescan.is_set():
                self._sleep(1)
        self.status["running"] = False
