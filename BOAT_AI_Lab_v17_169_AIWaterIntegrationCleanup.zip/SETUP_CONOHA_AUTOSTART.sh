#!/usr/bin/env bash
# Run once as root from a deployed BOAT AI Lab release directory.
set -euo pipefail

ROOT=/opt/boat-ai-lab
LAUNCHER="$ROOT/run-boat-ai.sh"
SERVICE=/etc/systemd/system/boat-ai-lab.service

install -d -m 755 "$ROOT"
cat > "$LAUNCHER" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
ROOT=/opt/boat-ai-lab
release="$(find "$ROOT/releases" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\n' | sort -nr | head -n 1 | cut -d' ' -f2-)"
test -n "$release"
exec "$release/.venv/bin/python" -m uvicorn app:app --host 0.0.0.0 --port 8000
EOF
chmod 755 "$LAUNCHER"

cat > "$SERVICE" <<'EOF'
[Unit]
Description=BOAT AI Lab
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/boat-ai-lab
ExecStart=/opt/boat-ai-lab/run-boat-ai.sh
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable boat-ai-lab.service
echo "設定完了。次回のサーバー再起動後もBOAT AI Labは自動で起動します。"
