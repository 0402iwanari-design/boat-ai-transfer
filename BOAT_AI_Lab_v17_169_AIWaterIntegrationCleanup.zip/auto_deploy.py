"""GitHub push webhook を受けて BOAT AI Lab を安全に更新する小さな実行器。"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT = Path(os.environ.get("BOAT_APP_ROOT", "/opt/boat-ai-lab"))
REPOSITORY = ROOT / "x"
RELEASES = ROOT / "releases"
SECRET_FILE = ROOT / ".boat_ai_github_webhook_secret"
LOCK_FILE = ROOT / ".boat_ai_deploy.lock"
STATUS_FILE = ROOT / "auto_deploy_status.json"
LOG_FILE = ROOT / "auto_deploy.log"


def configured() -> bool:
    return SECRET_FILE.is_file() and bool(SECRET_FILE.read_text(encoding="utf-8").strip())


def verify_signature(payload: bytes, signature: str | None) -> bool:
    if not configured() or not signature or not signature.startswith("sha256="):
        return False
    secret = SECRET_FILE.read_text(encoding="utf-8").strip().encode("utf-8")
    expected = "sha256=" + hmac.new(secret, payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def _write_status(state: str, message: str) -> None:
    ROOT.mkdir(parents=True, exist_ok=True)
    STATUS_FILE.write_text(json.dumps({"state": state, "message": message, "updated_at": int(time.time())}, ensure_ascii=False), encoding="utf-8")


def _run(command: list[str], *, cwd: Path | None = None) -> str:
    result = subprocess.run(command, cwd=cwd, check=True, text=True, capture_output=True)
    return (result.stdout or "") + (result.stderr or "")


def _safe_extract(archive: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with zipfile.ZipFile(archive) as zf:
        for member in zf.infolist():
            target = (destination / member.filename).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError("ZIP内に不正なパスがあります")
        zf.extractall(destination)


def _project_directory(release: Path) -> Path:
    if (release / "requirements.txt").is_file() and (release / "app.py").is_file():
        return release
    candidates = [p for p in release.iterdir() if p.is_dir() and (p / "requirements.txt").is_file() and (p / "app.py").is_file()]
    if len(candidates) == 1:
        return candidates[0]
    raise RuntimeError("ZIP内にアプリ本体（requirements.txt / app.py）が見つかりません")


def queue_deploy() -> bool:
    ROOT.mkdir(parents=True, exist_ok=True)
    if LOCK_FILE.exists():
        # 古い異常終了のロックだけは回復できるようにする。
        if time.time() - LOCK_FILE.stat().st_mtime < 20 * 60:
            return False
        LOCK_FILE.unlink(missing_ok=True)
    LOCK_FILE.write_text(str(os.getpid()), encoding="utf-8")
    with LOG_FILE.open("a", encoding="utf-8") as log:
        subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--deploy"],
            cwd=str(Path(__file__).resolve().parent),
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
    return True


def deploy() -> None:
    try:
        _write_status("running", "GitHubから更新を取得中")
        time.sleep(2)  # webhookの応答を返してから、現在のアプリを停止する。
        if not REPOSITORY.is_dir():
            raise RuntimeError("GitHub連携フォルダ /opt/boat-ai-lab/x がありません")

        before = _run(["git", "-C", str(REPOSITORY), "rev-parse", "HEAD"]).strip()
        _run(["git", "-C", str(REPOSITORY), "pull", "--ff-only"])
        changed = _run(["git", "-C", str(REPOSITORY), "diff", "--name-only", before, "HEAD"]).splitlines()
        archives = [REPOSITORY / name for name in changed if name.lower().endswith(".zip")]
        archives = [path for path in archives if path.is_file()]
        if not archives:
            _write_status("skipped", "今回のGitHub更新にはZIPがありません")
            return

        archive = archives[-1]
        safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in archive.stem)[:80]
        release = RELEASES / f"{time.strftime('%Y%m%d-%H%M%S')}_{safe_name}"
        _safe_extract(archive, release)
        project = _project_directory(release)

        _write_status("running", "必要な部品を準備中")
        _run([sys.executable, "-m", "venv", ".venv"], cwd=project)
        python = project / ".venv" / "bin" / "python"
        _run([str(python), "-m", "pip", "install", "-r", "requirements.txt"], cwd=project)

        _write_status("running", "アプリを切り替え中")
        subprocess.run(["pkill", "-f", "uvicorn app:app"], check=False)
        time.sleep(2)
        with (ROOT / "boat_ai_server.log").open("a", encoding="utf-8") as log:
            subprocess.Popen(
                [str(python), "-m", "uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"],
                cwd=project,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                close_fds=True,
            )
        _write_status("success", f"更新完了：{archive.name}")
    except Exception as exc:
        _write_status("error", str(exc))
        with LOG_FILE.open("a", encoding="utf-8") as log:
            log.write(f"ERROR: {exc}\n")
    finally:
        LOCK_FILE.unlink(missing_ok=True)


if __name__ == "__main__":
    if "--deploy" in sys.argv:
        deploy()
