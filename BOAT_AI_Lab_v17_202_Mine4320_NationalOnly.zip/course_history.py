from __future__ import annotations
"""v17.202 validation build: racer 4320 (峰竜太) nationwide-only test.

Collection flow for this validation:
1. Wait until today's official racelist is saved locally.
2. Find 4320 in today's racelist and identify only the venue where he races today.
3. Check whether national/local actual-entry-course buckets are incomplete.
4. Fetch the racer's own yearly all-races pages directly (never crawl 24 venues by date).
5. Classify each run by actual entry course 1..6.
6. Keep newest max 10 for national and today's local venue.
7. Stop as soon as every bucket has 10; otherwise continue only down through 2023.
8. Reaching 2023 with fewer than 10 (including zero) is normal completion.

Special results:
- 欠場 is ignored because the racer did not actually start.
- F/L and other actual-start special results are preserved as text when parseable.
"""
import re, threading
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup

JST=ZoneInfo('Asia/Tokyo'); FLOOR_YEAR=2023; FLOOR='20230101'
VALIDATION_REG='4320'
VALIDATION_NAME='峰竜太'
VALIDATION_LOCAL_JCD='16'  # target row compatibility only; v17.202 collects nationwide only
VENUES=['桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村']
VENUE_CODE={n:f'{i:02d}' for i,n in enumerate(VENUES,1)}
def _norm(s): return re.sub(r'[\s\u3000]+','',str(s or ''))
def _venue_code(s):
    n=_norm(s)
    return next((code for name,code in VENUE_CODE.items() if _norm(name)==n),None)
def _date_token(s,year):
    m=re.search(r'(?<!\d)(\d{1,2})/(\d{1,2})(?!\d)',str(s or ''))
    return f'{year}{int(m.group(1)):02d}{int(m.group(2)):02d}' if m else None
def _race_token(s):
    m=re.fullmatch(r'\s*(\d{1,2})R\s*',str(s or '')); return int(m.group(1)) if m else None
def _course_token(s):
    t=_norm(s); return int(t) if re.fullmatch(r'[1-6]',t) else None
def _st_token(s):
    """Race ST only. Bare 1..6 must NEVER be accepted as ST."""
    t=_norm(s).upper()
    if re.fullmatch(r'\.\d{1,2}',t): return t
    if re.fullmatch(r'[FL]\.\d{1,2}',t): return t
    if t in {'F','L'}: return t
    return None
def _rank_token(s):
    m=re.fullmatch(r'\(([1-6])\)',_norm(s)); return int(m.group(1)) if m else None
def _finish_token(s):
    t=_norm(s).replace('着','')
    return t if re.fullmatch(r'[1-6]|F|L|S[012]|K[01]|転|落|沈|妨|失|不完|エ|欠',t) else None

def _expand_table(table):
    """Expand rowspan/colspan so date headers line up with race/data columns."""
    grid=[]
    spans={}  # col -> [rows_remaining_after_current, text]
    for tr in table.find_all('tr'):
        row=[]; col=0
        cells=tr.find_all(['th','td'], recursive=False)
        ci=0
        while ci < len(cells) or spans:
            while col in spans:
                rem,text=spans[col]
                while len(row)<=col: row.append('')
                row[col]=text
                if rem<=1: del spans[col]
                else: spans[col]=[rem-1,text]
                col+=1
            if ci>=len(cells):
                # only remaining spans at larger columns
                if not spans: break
                next_col=min(spans)
                while col<next_col:
                    row.append(''); col+=1
                continue
            cell=cells[ci]; ci+=1
            text=' '.join(cell.stripped_strings)
            try: cs=max(1,int(cell.get('colspan',1)))
            except (TypeError,ValueError): cs=1
            try: rs=max(1,int(cell.get('rowspan',1)))
            except (TypeError,ValueError): rs=1
            for _ in range(cs):
                while col in spans:
                    rem,old=spans[col]
                    while len(row)<=col: row.append('')
                    row[col]=old
                    if rem<=1: del spans[col]
                    else: spans[col]=[rem-1,old]
                    col+=1
                while len(row)<=col: row.append('')
                row[col]=text
                if rs>1: spans[col]=[rs-1,text]
                col+=1
        grid.append(row)
    width=max((len(r) for r in grid),default=0)
    return [r+['']*(width-len(r)) for r in grid]

class OfficialCourseHistoryCollector:
    def __init__(self,db):
        self.db=db; self._thread=None; self._stop=threading.Event()
        self.status={'phase':'本日の出走表待ち','validation_mode':'峰竜太（4320）1人検証'}
    def start(self):
        if self._thread and self._thread.is_alive(): return
        self._thread=threading.Thread(target=self._scheduler,daemon=True,name='mine-course-history-validation'); self._thread.start()
    def _scheduler(self):
        while not self._stop.is_set():
            today=datetime.now(JST).strftime('%Y%m%d')
            try:self._run(today)
            except Exception as e:
                self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),'phase':'収集処理エラー','scheduler_error':f'{type(e).__name__}: {e}','validation_mode':'峰竜太（4320）1人検証'}
            self._stop.wait(10)
    def _reset_validation_racer(self,today):
        """v17.202 one-time clean slate for course history.

        The previous all-racer validation data was unreliable, so this validation build
        clears the entire course-history subsystem once, then rebuilds only 4320.
        Other BOAT AI Lab data is untouched.
        """
        key='course_history_v17_202_national_only_mine4320'
        start=(datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d')
        with self.db.connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS app_migrations (
                migration_key TEXT PRIMARY KEY, applied_at TEXT DEFAULT CURRENT_TIMESTAMP
            )""")
            if con.execute('SELECT 1 FROM app_migrations WHERE migration_key=?',(key,)).fetchone():
                return False
            con.execute('DELETE FROM racer_course_runs')
            con.execute('DELETE FROM course_history_target_state')
            con.execute('DELETE FROM course_history_racer_state')
            con.execute("""UPDATE course_history_backfill_state
                SET status='pending',next_date=?,days_scanned=0,runs_saved=0,last_success_date=NULL,
                    last_error=NULL,completed=0,updated_at=CURRENT_TIMESTAMP WHERE id=1""",(start,))
            con.execute('INSERT INTO app_migrations(migration_key) VALUES(?)',(key,))
        return True

    def _national_counts(self,reg):
        with self.db.connect() as con:
            rows=con.execute('SELECT course,COUNT(*) n FROM racer_course_runs WHERE registration_no=? AND date>=? GROUP BY course',(reg,FLOOR)).fetchall()
        return {int(x['course']):min(10,int(x['n'])) for x in rows}

    def _national_done(self,nm):
        return all(nm.get(c,0)>=10 for c in range(1,7))

    def _parse_year(self,html,year,reg):
        """Parse yearly racer results with expanded rowspan/colspan columns.

        Each race column gets its own date and venue.  This avoids assigning one venue
        to an entire HTML table and avoids shifted dates when the site uses merged cells.
        The actual-entry/ST/finish search remains tolerant rather than fixed offsets.
        """
        soup=BeautifulSoup(html,'html.parser'); out=[]
        for table in soup.find_all('table'):
            rows=_expand_table(table)
            if not rows: continue
            width=max((len(r) for r in rows),default=0)
            if not width: continue

            # Per-column context. Expanded rowspan/colspan keeps headers aligned.
            col_dates={}
            col_jcds={}
            for col in range(width):
                for row in rows:
                    cell=row[col] if col < len(row) else ''
                    d=_date_token(cell,year)
                    if d and col not in col_dates:
                        col_dates[col]=d
                    v=_venue_code(cell)
                    if v and col not in col_jcds:
                        col_jcds[col]=v

            # Some layouts put venue/date in a leading merged header cell. Propagate
            # nearest context horizontally, but never invent values from another table.
            last_date=None; last_jcd=None
            for col in range(width):
                if col in col_dates: last_date=col_dates[col]
                elif last_date: col_dates[col]=last_date
                if col in col_jcds: last_jcd=col_jcds[col]
                elif last_jcd: col_jcds[col]=last_jcd

            for ri,row in enumerate(rows):
                race_cols={i:_race_token(c) for i,c in enumerate(row) if _race_token(c)}
                if not race_cols: continue
                followers=rows[ri+1:ri+9]
                for col,rno in race_cols.items():
                    date=col_dates.get(col)
                    jcd=col_jcds.get(col)
                    if not date or date<FLOOR or not jcd: continue
                    vals=[r[col] if col<len(r) else '' for r in followers]
                    course=next((_course_token(v) for v in vals if _course_token(v) is not None),None)
                    st=next((_st_token(v) for v in vals if _st_token(v) is not None),None)
                    rank=None; finish=None
                    if st is not None:
                        si=next((k for k,v in enumerate(vals) if _st_token(v) is not None),None)
                        if si is not None:
                            for v in vals[si+1:]:
                                rr=_rank_token(v)
                                if rr is not None: rank=rr; break
                    for v in reversed(vals):
                        f=_finish_token(v)
                        if f is not None: finish=f; break
                    if not course or st is None or finish is None or finish=='欠': continue
                    out.append({'date':date,'jcd':jcd,'rno':rno,'registration_no':reg,'lane':None,
                                'course':course,'finish':finish,'st_raw':st,'st_rank':rank,
                                'source':f'racer-yearly:boatfrontier-expanded-v17202:{year}'})
        uniq={(x['date'],x['jcd'],x['rno']):x for x in out}
        return sorted(uniq.values(),key=lambda x:(x['date'],x['jcd'],x['rno']),reverse=True)

    def _fetch_year(self,reg,name,year,jcd):
        """Use the same yearly URL pattern as the working validation build."""
        url=f'https://boatfrontier.jp/racer/{reg}/allraces/{year}'
        self.status.update({'phase':'全国コース履歴取得中','crawl_stage':f'{name}（{reg}） {year}年 全出走データ取得中','scan_date':str(year),'crawl_jcd':jcd,'last_fetch_state':'fetching','last_fetch_error':None,'direct_source':url})
        s=requests.Session(); s.headers.update({'User-Agent':'Mozilla/5.0 BOAT-AI-Lab/1.0'})
        last=None
        for attempt in range(1,4):
            try:
                r=s.get(url,timeout=(5,15)); r.raise_for_status()
                rows=self._parse_year(r.text,year,reg)
                self.status.update({'last_fetch_state':'ok','last_fetch_error':None,'last_parsed_rows':len(rows),'direct_source':r.url})
                return rows,{'url':r.url,'http':r.status_code,'attempt':attempt,'parsed':len(rows)}
            except Exception as e:
                last=f'{type(e).__name__}: {e}'
                self.status.update({'last_fetch_error':last,'last_fetch_state':f'retry {attempt}/3','direct_source':url})
                if attempt<3:self._stop.wait(2)
        raise RuntimeError(last or f'{year}年データ取得失敗')

    def _ensure_validation_target(self,today):
        """v17.201 validation only: create 4320/児島 target without relying on racelist snapshots.

        The previous validation build still depended on race_snapshots(kind='racelist').
        When that upstream cache missed 児島, the collector stayed at 0 targets and the
        history collector itself was never tested.  For this one-racer validation we
        intentionally isolate the history pipeline from that unrelated prerequisite.
        """
        start=(datetime.now(JST).date()-timedelta(days=1)).strftime('%Y%m%d')
        with self.db.connect() as con:
            old=con.execute("SELECT 1 FROM course_history_target_state WHERE registration_no=? AND jcd=?",
                            (VALIDATION_REG,VALIDATION_LOCAL_JCD)).fetchone()
            if old is None:
                con.execute("""INSERT INTO course_history_target_state
                    (registration_no,jcd,name,status,cursor_date,floor_date,target_date)
                    VALUES(?,?,?,'pending',?,?,?)""",
                    (VALIDATION_REG,VALIDATION_LOCAL_JCD,VALIDATION_NAME,start,FLOOR,today))
            else:
                con.execute("""UPDATE course_history_target_state
                    SET name=?,status=CASE WHEN target_date=? AND status='complete' THEN status ELSE 'pending' END,
                        cursor_date=COALESCE(cursor_date,?),floor_date=?,target_date=?,
                        retry_count=0,failed_date=NULL,last_error=NULL,updated_at=CURRENT_TIMESTAMP
                    WHERE registration_no=? AND jcd=?""",
                    (VALIDATION_NAME,today,start,FLOOR,today,VALIDATION_REG,VALIDATION_LOCAL_JCD))

    def _run(self,today):
        # v17.202: nationwide-only, one racer. No local-course completion requirement.
        reset_now=self._reset_validation_racer(today)
        self._ensure_validation_target(today)
        self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),
                     'phase':'峰竜太（4320）全国コース履歴をゼロから取得開始',
                     'validation_mode':'峰竜太（4320）全国のみ検証',
                     'current_racer':VALIDATION_NAME,'current_registration_no':VALIDATION_REG,
                     'clean_reset_applied':bool(reset_now),
                     'note':'v17.202。コース履歴だけ全選手分を初回削除し、峰竜太4320の全国1〜6Cだけを各最新10走まで収集。当地はまだ収集しない。'}
        pending=self.db.get_course_history_pending_targets(today,only_registration_no=VALIDATION_REG)
        if not pending:
            st=self.db.get_course_history_target_status(today,VALIDATION_REG)
            self.status={**st,'phase':'峰竜太（4320）全国履歴完了','validation_mode':'峰竜太（4320）全国のみ検証'}
            return

        t=pending[0]; reg=str(t['registration_no']); jcd=str(t['jcd']).zfill(2); name=str(t.get('name') or reg)
        nm=self._national_counts(reg)
        if self._national_done(nm):
            self.db.complete_course_history_targets([(reg,jcd)])
            return

        total=0; checked=[]; lastdiag={}; reached_floor=False
        try:
            for year in range(datetime.now(JST).year,FLOOR_YEAR-1,-1):
                nm=self._national_counts(reg)
                if self._national_done(nm): break
                rows,lastdiag=self._fetch_year(reg,name,year,jcd); checked.append(year)

                # rows are newest first. Select only the remaining nationwide slots,
                # so the DB itself contains at most 10 runs per course for this test.
                remaining={c:max(0,10-nm.get(c,0)) for c in range(1,7)}
                useful=[]
                for x in rows:
                    c=int(x['course'])
                    if remaining.get(c,0)<=0: continue
                    useful.append(x)
                    remaining[c]-=1
                if useful:
                    self.db.save_course_history_runs(useful,keep_per_local_course=10)
                    total+=len(useful)

            reached_floor=bool(checked and checked[-1]==FLOOR_YEAR)
            nm=self._national_counts(reg)
            if self._national_done(nm) or reached_floor:
                self.db.complete_course_history_targets([(reg,jcd)])
            self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),
                         'phase':f'{name} 全国コース履歴確認完了' if (self._national_done(nm) or reached_floor) else '全国コース履歴保存中',
                         'validation_mode':'峰竜太（4320）全国のみ検証',
                         'current_racer':name,'current_registration_no':reg,
                         'last_fetch_state':'ok','last_parsed_rows':total,'last_matched_rows':total,
                         'last_fetch_date':today,'crawl_stage':f'{reg}本人→年別全出走→全国のみ（確認年 {checked}）',
                         'national_counts':nm,'local_counts':{},'checked_years':checked,
                         'floor_reached':reached_floor,'direct_source':lastdiag.get('url'),
                         'note':'v17.202。全国1〜6Cだけを各最新10走まで保存。新しい年から順に埋め、10走揃ったコースは古い年から追加しない。当地点検は次段階。'}
        except Exception as e:
            self.db.mark_course_history_target_errors([(reg,jcd)],str(self.status.get('scan_date') or ''),f'{type(e).__name__}: {e}',3)
            self.status={**self.db.get_course_history_target_status(today,VALIDATION_REG),
                         'phase':'峰竜太の全国履歴収集エラー',
                         'validation_mode':'峰竜太（4320）全国のみ検証',
                         'current_racer':name,'current_registration_no':reg,
                         'scheduler_error':f'{type(e).__name__}: {e}'}

